# kiikoread 0.3.3-rc99 定制版 · 宣传图说明

四个尺寸，全部为本机程序生成（无外部素材），可直接用于 GitHub / 论坛 / 聊天分享。
设计语言：米白纸感底 + 墨色文字 + 墨绿/赭石点缀，与电子墨水屏阅读器的气质一致。
**注意**：图中设备画面中，贪吃蛇与 2048 是早期真机截图；阅读页、书架、特色功能、时钟是
按当前界面逻辑绘制的“界面示意”，图内已标注“界面示意图 · 实际以真机为准”。

| 文件 | 尺寸 | 用途 |
|---|---|---|
| `poster-01-overview.png` | 1240 × 1754 | 主海报 / 竖版长图分享（A4 比例，可打印） |
| `poster-02-features-long.png` | 1240 × 4860 | 功能长图（论坛/公众号/README 内嵌长文） |
| `poster-03-square.png` | 1080 × 1080 | 方形分享图（微信/QQ/群头像式宣传） |
| `social-preview-1280x640.png` | 1280 × 640 | GitHub 仓库 Social Preview（Settings → Social preview 上传） |

## 用到的地方

- **GitHub 仓库**：Settings → General → Social preview 上传 `social-preview-1280x640.png`；
  README 开头可内嵌主海报 `poster-01-overview.png`。
- **Release 页面**：发布 Release 时在描述里内嵌长图或主海报（GitHub 支持直接粘贴图片上传）。
- **论坛/群聊**：方形图适合单张分享；长图适合一次性讲完所有功能。
- 所有图里已标注 `sha256` 前缀与“未真机验证”，避免误导。

## 重新生成

脚本：`C:\dshb\make_promo.py`（运行需 Pillow；本机用 Python 3.x 直接执行即可）：

```powershell
& "C:\Users\dodo\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe" C:\dshb\make_promo.py
```

生成结果输出到本目录。改文案/配色只需编辑脚本中的常量（`PAPER`/`INK`/`GREEN`/`RUST`）
或对应 `poster_*()` 函数内的文字。
