/* SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include <stdbool.h>

/// 空闲时启动有界后台对时；主循环独占 PMU 与 NVS 的交接。
/// 开机空闲时每六小时用已保存 WiFi 尝试一次无线对时（不在开机后立刻检测；成功/失败后都关闭 WiFi）；
/// 已在线时每小时校准一次；不常驻无线任务。
/// Start bounded background sync while idle; the main loop alone hands time to PMU/NVS.
/// While powered on it tries a wireless sync every six hours with the saved WiFi (no immediate
/// check right after boot; the radio is stopped afterwards whether it succeeds or fails), or
/// calibrates hourly while already online; no resident radio task.
void app_time_service_poll(bool idle);
