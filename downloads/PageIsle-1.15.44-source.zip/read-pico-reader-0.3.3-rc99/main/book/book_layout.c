/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：借鉴阅读演示的逐码点折行，建立 PSRAM 页表并绘制章节。
 * English: Adapt the reading demo's codepoint wrapping into PSRAM chapter pagination.
 *
 * 冻结：原文由调用方持有；字体测量和绘制必须由调用方串行化。
 * Frozen: Caller owns source text and serializes all font measurement and drawing.
 */
#include "book_layout.h"
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include "book_highlight.h"
#include "esp_heap_caps.h"
#include "ttf_font.h"

#define PAGE_MAX 4096u
#define PSRAM_CAPS (MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)

static const char* s_text;
static size_t s_len;
static size_t* s_pages;
static size_t s_count;
static size_t s_capacity;
static book_layout_draw_cursor_t *s_idle_draw;
static char* s_line;
static size_t s_line_capacity;
static EpdRect s_rect;
static int s_px;
static unsigned s_line_percent = 150, s_paragraph_percent = 50;
static int s_tracking_px;
static unsigned s_first_line_indent_em = 2;
static int s_first_line_indent_adjust_px;
static unsigned s_reading_line;
static int s_reading_line_offset;
static bool s_images_visible = true;
// 当前章节号只用于查划线记录；偏移仍是本页文字缓冲内的字节位置。
// The active chapter only keys highlight ranges; offsets remain byte positions inside this page text.
static uint16_t s_highlight_chapter;
static bool s_highlight_preview_on;
static uint16_t s_highlight_preview_chapter;
static uint32_t s_highlight_preview_start, s_highlight_preview_end;
void book_layout_set_highlight_chapter(uint16_t chapter) { s_highlight_chapter = chapter; }
// 长按拖动时的临时选段：只参与本次绘制，不落盘，松手后由调用方转成正式记录。
// Temporary drag range: drawn only for this frame and never persisted; the caller commits it on release.
void book_layout_set_highlight_preview(uint16_t chapter, bool active, uint32_t start, uint32_t end) {
    s_highlight_preview_on = active;
    s_highlight_preview_chapter = chapter;
    s_highlight_preview_start = start;
    s_highlight_preview_end = end;
}
// 竖排：同一套折行与禁则逻辑，只是推进方向朝下、堆叠方向朝左。
// Vertical setting: the same wrapping and kinsoku logic, with the advance running down and the
// stack running leftward.
static bool s_vertical;
// 竖排首页右起为竖排题头预留的列宽，调用方按同一宽度绘制题头。
// Columns reserved from the right of the first vertical page for a vertical chapter heading; the
// caller draws the heading into the same width.
static unsigned s_chapter_lead_width;
static size_t s_lead_skip;
static unsigned s_lead_height;

static const blk_t* s_blocks;
static size_t s_block_count;
// 布局代次：重排或释放后自增，页内位图缓存靠它失效。/ Bumped on rebuild or free so page bitmap caches expire.
static uint32_t s_generation;

// 页内插图：图片序号、页内 y、显示宽高。平坦池按页顺序存放，每页用起点表切片，
// 这样大多数没有插图的页只花两个下标。
// Images placed on a page: index, y within the page, and display width/height. The pool is flat
// and ordered by page, sliced by a per-page start table, so a page without images costs two
// indices and nothing else.
typedef struct {
    int16_t image;
    int16_t y;
    int16_t width;
    int16_t height;
} layout_image_t;

static layout_image_t* s_images;
static size_t s_image_count;
static size_t s_image_capacity;
static uint32_t* s_page_img_start;

static book_layout_image_dims_fn s_dims_fn;
static void* s_dims_ctx;

// 插图可用区域。通栏开启时宽度换成整屏，竖直方向仍是正文那一条，分页数学不动。
// Region illustrations may occupy. With full bleed on, its width becomes the panel's and its
// vertical band stays the body's, leaving the pagination math alone.
static EpdRect s_image_rect;
// 通栏宽度（整屏像素）。面板常量，重排不必跟着改；0 关闭。
// Full-bleed width in panel pixels. A panel constant, so re-layouts need not update it; 0 disables.
static int s_image_bleed_width;

// 块表是有序字节区间，二分查找当前行样式。/ Blocks are ordered byte ranges; binary-search the line style.
static const blk_t* block_at(size_t off) {
    if (!s_block_count) return NULL;
    size_t lo = 0, hi = s_block_count;
    while (lo + 1 < hi) {
        size_t mid = lo + (hi - lo) / 2;
        if (s_blocks[mid].offset <= off) lo = mid;
        else hi = mid;
    }
    return &s_blocks[lo];
}

// 字体 run 表由调用方借用（和块表同一份 html_text），绘制时按段换字体。
// The run table is borrowed from the caller's html_text, next to the block table, so drawing
// can switch faces span by span.
static const html_run_t* s_runs;
static size_t s_run_count;

// 一行最多切几段字体。屏上一行十几个字，段数只由内联标签决定。
// How many face spans one line may carry: a line holds a dozen glyphs and spans only come
// from inline tags.
#define LINE_RUN_MAX 64u
static ttf_run_t s_line_runs[LINE_RUN_MAX];
static size_t s_line_run_count;

// 行内样式段与斜体覆盖率遮罩：都在 PSRAM，布局释放或重排时一起还回去。
// 一行最多切 32 段，超过就整行退回普通绘制。
// Inline style spans and the italic coverage mask, both in PSRAM and handed back when the layout
// is freed or rebuilt. One line carries at most 32 spans; more falls back to plain drawing.
typedef struct {
    size_t start; ///< s_line 内的字节起点 / byte start inside s_line
    size_t len; ///< 字节数 / byte count
    int width; ///< 自然宽，不含段后字距 / natural width, excluding the trailing tracking step
    int step; ///< 到下一段的推进量 / advance to the next span
    uint8_t style; ///< HTML_STYLE_* 位或 / HTML_STYLE_* bits
    uint8_t slot; ///< 字体槽 / font slot
} style_span_t;
#define STYLE_SPAN_MAX 32u
// ttf_text_mask_px 的宽度上限；横屏一行可达 1216 像素，超宽段按字切开逐段落墨。
// Width cap of ttf_text_mask_px; a landscape line may reach 1216 pixels, so wide spans are cut
// at glyph boundaries and inked piece by piece.
#define STYLE_MASK_MAX_WIDTH 684u
static style_span_t* s_spans;
static uint8_t* s_mask;
static size_t s_mask_size;

void book_layout_set_runs(const html_run_t* runs, size_t count) {
    s_runs = (runs != NULL && count > 0) ? runs : NULL;
    s_run_count = s_runs != NULL ? count : 0;
}

// 该字节属于哪个字体槽。没有 run 表就一律系统字体，排版与从前完全一致。
// Which face owns this byte. Without a run table everything is the system face and the
// layout behaves exactly as before.
static uint8_t slot_at(size_t off) {
    if (s_runs == NULL) return TTF_FONT_SLOT_SYSTEM;
    const blk_t* block = block_at(off);
    if (block == NULL || block->run_count == 0 || off < block->offset) return TTF_FONT_SLOT_SYSTEM;
    size_t rel = off - block->offset;
    size_t last = block->run_first + block->run_count;
    if (last > s_run_count) last = s_run_count;
    uint8_t slot = TTF_FONT_SLOT_SYSTEM;
    for (size_t i = block->run_first; i < last; ++i) {
        if (s_runs[i].offset > rel) break;
        slot = s_runs[i].slot;
    }
    return slot;
}

// 装载失败或没装载的槽一律退回系统字体：拿一张空字体去量宽会得到零。
// A slot that failed to load, or never loaded, falls back to the system face; measuring an
// empty face would return zero.
static uint8_t slot_ready_or_system(uint8_t slot) {
    if (slot != TTF_FONT_SLOT_SYSTEM && !ttf_font_slot_ready(slot)) return TTF_FONT_SLOT_SYSTEM;
    return slot;
}

static void slot_select_for(size_t off) {
    uint8_t slot = slot_ready_or_system(slot_at(off));
    if (slot != (uint8_t)ttf_font_selected()) ttf_font_select(slot);
}

static void line_run_push(size_t offset, uint8_t slot) {
    if (offset > UINT32_MAX) return;
    if (s_line_run_count) {
        ttf_run_t* prev = &s_line_runs[s_line_run_count - 1];
        if (prev->slot == slot) return;
        if (prev->offset == (uint32_t)offset) {
            prev->slot = slot;
            return;
        }
    }
    if (s_line_run_count >= LINE_RUN_MAX) return;
    s_line_runs[s_line_run_count].offset = (uint32_t)offset;
    s_line_runs[s_line_run_count].slot = slot;
    ++s_line_run_count;
}

// 把块内 run 平移到 s_line 的坐标系：s_line 从 visible_off 起，只覆盖这一行。
// Shift the block's runs into s_line coordinates; s_line starts at visible_off and covers
// this line only.
static void line_runs_build(const blk_t* block, size_t visible_off, size_t line_end) {
    s_line_run_count = 0;
    if (s_runs == NULL || block == NULL || block->run_count == 0) return;
    size_t block_end = block->offset + block->len;
    if (visible_off < block->offset || line_end > block_end || line_end <= visible_off) return;
    size_t base = visible_off - block->offset, stop = line_end - block->offset;
    size_t last = block->run_first + block->run_count;
    if (last > s_run_count) last = s_run_count;
    for (size_t i = block->run_first; i < last; ++i) {
        size_t from = s_runs[i].offset, to = from + s_runs[i].len;
        if (to <= base) continue;
        if (from >= stop) break;
        line_run_push(from > base ? from - base : 0, slot_ready_or_system(s_runs[i].slot));
    }
}

// 拒绝截断、过长编码、代理项和嵌入零字节。/ Reject truncation, overlong encodings, surrogates and embedded NUL.
static size_t codepoint_size(const char* text, size_t remaining) {    if (!remaining) return 0;
    const unsigned char* p = (const unsigned char*)text;
    if (p[0] > 0 && p[0] < 0x80) return 1;
    size_t n = p[0] >= 0xc2 && p[0] <= 0xdf ? 2 :
               p[0] >= 0xe0 && p[0] <= 0xef ? 3 :
               p[0] >= 0xf0 && p[0] <= 0xf4 ? 4 : 0;
    if (!n || n > remaining) return 0;
    for (size_t i = 1; i < n; i++) if ((p[i] & 0xc0) != 0x80) return 0;
    if ((p[0] == 0xe0 && p[1] < 0xa0) || (p[0] == 0xed && p[1] >= 0xa0) ||
        (p[0] == 0xf0 && p[1] < 0x90) || (p[0] == 0xf4 && p[1] >= 0x90)) return 0;
    return n;
}

static uint32_t codepoint_value(const char* text, size_t n) {
    const unsigned char* p = (const unsigned char*)text;
    if (n == 1) return p[0];
    uint32_t cp = p[0] & (0x7f >> n);
    for (size_t i = 1; i < n; ++i) cp = (cp << 6) | (p[i] & 63);
    return cp;
}

// 插图容器常带全角空白、零宽字符和换行实体；它们不是可阅读的独立段落。
// Image wrappers often contain fullwidth spaces, zero-width characters and line-break entities, not readable paragraphs.
static bool image_spacing_block(const blk_t* block) {
    if (!block || block->image >= 0) return false;
    size_t end = block->offset + block->len;
    for (size_t at = block->offset; at < end;) {
        size_t n = codepoint_size(s_text + at, end - at);
        if (!n) return false;
        uint32_t cp = codepoint_value(s_text + at, n);
        bool space = cp == ' ' || (cp >= '\t' && cp <= '\r') || cp == 0x85 || cp == 0xa0 ||
                     cp == 0x1680 || (cp >= 0x2000 && cp <= 0x200b) || cp == 0x2028 ||
                     cp == 0x2029 || cp == 0x202f || cp == 0x205f || cp == 0x2060 ||
                     cp == 0x3000 || cp == 0xfeff;
        if (!space) return false;
        at += n;
    }
    return true;
}

// 只跳过插图相邻的空白块，保留原文字节位置、正文段落与 TXT 的手动空行。
// Skip only image-adjacent spacer blocks; keep source offsets, text paragraphs and manual TXT blank lines.
static size_t skip_image_spacing(size_t off) {
    while (off < s_len && s_block_count) {
        const blk_t* block = block_at(off);
        if (block->offset != off) break;
        size_t end = block->offset + block->len;
        if (block->image >= 0) {
            if (s_images_visible) break;
        } else {
            if (!image_spacing_block(block)) break;
            size_t first = (size_t)(block - s_blocks), last = first + 1;
            while (last < s_block_count && image_spacing_block(&s_blocks[last])) ++last;
            bool adjacent = (first > 0 && s_blocks[first - 1].image >= 0) ||
                            (last < s_block_count && s_blocks[last].image >= 0);
            if (!adjacent) break;
            end = s_blocks[last - 1].offset + s_blocks[last - 1].len;
        }
        off = end;
        if (off < s_len && s_text[off] == '\n') ++off;
    }
    return off;
}

// 中文排版禁则：右标点不得出现在行首，左标点不得停在行尾。
// CJK kinsoku: closing punctuation may not start a line; opening punctuation may not end one.
static bool prohibited_line_start(uint32_t cp) {
    switch (cp) {
        case 0x0021: case 0x0025: case 0x0029: case 0x002c: case 0x002e: case 0x003a:
        case 0x003b: case 0x003f: case 0x005d: case 0x007d:
        case 0x2019: case 0x201d: case 0x2026: case 0x3001: case 0x3002: case 0x3009:
        case 0x300b: case 0x300d: case 0x300f: case 0x3011: case 0x3015: case 0x3017:
        case 0x3019: case 0x301b: case 0xff01: case 0xff05: case 0xff09: case 0xff0c:
        case 0xff0e: case 0xff1a: case 0xff1b: case 0xff1f: case 0xff3d: case 0xff5d:
            return true;
        default: return false;
    }
}

static bool prohibited_line_end(uint32_t cp) {
    switch (cp) {
        case 0x0028: case 0x005b: case 0x007b: case 0x2018: case 0x201c: case 0x3008:
        case 0x300a: case 0x300c: case 0x300e: case 0x3010: case 0x3014: case 0x3016:
        case 0x3018: case 0x301a: case 0xff08: case 0xff3b: case 0xff5b:
            return true;
        default: return false;
    }
}

uint32_t book_layout_generation(void) { return s_generation; }

void book_layout_free(void) {
    ++s_generation;
    free(s_pages);
    free(s_line);
    free(s_images);
    free(s_page_img_start);
    free(s_spans);
    free(s_mask);
    s_pages = NULL;
    s_line = NULL; s_line_capacity = 0;
    s_images = NULL;
    s_page_img_start = NULL;
    s_spans = NULL;
    s_mask = NULL;
    s_mask_size = 0;
    s_image_count = s_image_capacity = 0;
    s_text = NULL;
    s_count = s_capacity = s_len = 0;
    s_px = 0;
    s_blocks = NULL;
    s_block_count = 0;
    s_image_rect = (EpdRect){0, 0, 0, 0};
}

void book_layout_set_spacing(unsigned line_percent, unsigned paragraph_percent) {
    s_line_percent = line_percent >= 100 && line_percent <= 200 ? line_percent : 150;
    s_paragraph_percent = paragraph_percent <= 100 ? paragraph_percent : 50;
}
void book_layout_set_typography(int tracking_px) {
    s_tracking_px = tracking_px >= -15 && tracking_px <= 15 ? tracking_px : 0;
}
void book_layout_set_first_line_indent(unsigned em) {
    s_first_line_indent_em = em <= 3 ? em : 2;
}
void book_layout_set_first_line_indent_adjust(int px) {
    s_first_line_indent_adjust_px = px >= -100 && px <= 100 ? px : 0;
}
EpdRect book_layout_balanced_rect(EpdRect outer, int px, int tracking_px) {
    if (px <= 0 || outer.width < px || tracking_px < -15 || tracking_px > 15) return outer;
    int step = px + tracking_px;
    if (step <= 0) return outer;
    int columns = 1 + (outer.width - px) / step;
    int used = px + (columns - 1) * step;
    outer.x += (outer.width - used) / 2;
    outer.width = used;
    return outer;
}
void book_layout_set_reading_line(unsigned style) {
    s_reading_line = style <= 2 ? style : 0;
}
void book_layout_set_reading_line_offset(int offset_px) {
    s_reading_line_offset = offset_px < -8 ? -8 : offset_px > 8 ? 8 : offset_px;
}
void book_layout_set_images_visible(bool visible) { s_images_visible = visible; }
void book_layout_set_vertical(bool vertical) { s_vertical = vertical; }
bool book_layout_vertical(void) { return s_vertical; }
void book_layout_set_chapter_lead_width(unsigned width_px) { s_chapter_lead_width = width_px; }
void book_layout_set_chapter_lead(size_t skip_bytes, unsigned height_px) {
    s_lead_skip = skip_bytes;
    s_lead_height = height_px;
}

void book_layout_set_image_dims(book_layout_image_dims_fn fn, void* ctx) {
    s_dims_fn = fn;
    s_dims_ctx = ctx;
}

void book_layout_set_image_bleed_width(int screen_width) {
    s_image_bleed_width = screen_width > 0 ? screen_width : 0;
}

EpdRect book_layout_image_rect(void) {
    return s_image_rect.width > 0 ? s_image_rect : s_rect;
}

// 每次重排由正文栏推出插图区域：宽度换成整屏并与正文栏同心，其余保持原样。
// Derive the illustration region from the body column on every re-layout: the width becomes the
// panel's, concentric with the column, and everything else stays put.
static void resolve_image_rect(void) {
    s_image_rect = s_rect;
    if (s_image_bleed_width > s_rect.width) {
        s_image_rect.x = s_rect.x + (s_rect.width - s_image_bleed_width) / 2;
        s_image_rect.width = s_image_bleed_width;
    }
}

// 按插图区域等比缩放、不超过区域高、不放大——与参考实现同一套规则。
// Aspect-fit to the illustration region, never taller than it, never upscaled, matching the
// reference implementations.
static bool image_display_size(int image, int* out_w, int* out_h) {
    if (out_w) *out_w = 0;
    if (out_h) *out_h = 0;
    if (!s_dims_fn) return false;
    int w = 0, h = 0;
    if (!s_dims_fn(s_dims_ctx, image, &w, &h) || w <= 0 || h <= 0) return false;
    int64_t cw = s_image_rect.width, ch = s_image_rect.height;
    if (cw <= 0 || ch <= 0) return false;
    if (w > cw) { h = (int)((int64_t)h * cw / w); w = (int)cw; }
    if (h > ch) { w = (int)((int64_t)w * ch / h); h = (int)ch; }
    if (w < 1) w = 1;
    if (h < 1) h = 1;
    if (out_w) *out_w = w;
    if (out_h) *out_h = h;
    return true;
}

static bool record_page_image(int image, int y, int w, int h) {
    if (s_image_count == s_image_capacity) {
        size_t cap = s_image_capacity ? s_image_capacity * 2 : 16;
        if (cap > PAGE_MAX * 4) return false;
        layout_image_t* grown = heap_caps_realloc(s_images, cap * sizeof(*grown), PSRAM_CAPS);
        if (!grown) return false;
        s_images = grown;
        s_image_capacity = cap;
    }
    layout_image_t* rec = &s_images[s_image_count++];
    rec->image = (int16_t)image;
    rec->y = (int16_t)y;
    rec->width = (int16_t)w;
    rec->height = (int16_t)h;
    if (s_page_img_start && s_count) s_page_img_start[s_count] = (uint32_t)s_image_count;
    return true;
}

int book_layout_page_image_count(size_t page) {
    if (page >= s_count || !s_page_img_start) return 0;
    return (int)(s_page_img_start[page + 1] - s_page_img_start[page]);
}

bool book_layout_page_image_at(size_t page, int i, int* image, int* y, int* width, int* height) {
    if (page >= s_count || !s_page_img_start || i < 0) return false;
    uint32_t a = s_page_img_start[page];
    if ((uint32_t)i >= s_page_img_start[page + 1] - a) return false;
    const layout_image_t* rec = &s_images[a + (uint32_t)i];
    if (image) *image = rec->image;
    if (y) *y = rec->y;
    if (width) *width = rec->width;
    if (height) *height = rec->height;
    return true;
}

int book_layout_page_image(size_t page) {
    if (page >= s_count || !s_block_count) return -1;
    const blk_t* block = block_at(s_pages[page]);
    if (!block || block->offset != s_pages[page] || block->image < 0) return -1;
    // 图片流进正文之后，插图常常正好落在页首，只判断"页首是图片块"会把普通文字页也算成整页插图。
    // 这里要求这一页的范围【只覆盖这一个图片块】，才是真正需要强刷的整页灰阶图。
    // Once images flow into the page an inline image often sits at the top, so testing only the
    // page start also matched ordinary text pages. Require the page to span exactly this image
    // block: that is a whole-page gray bitmap, the case the forced refresh exists for.
    size_t after = block->offset + block->len;
    if (after < s_len && s_text[after] == '\n') ++after;
    size_t page_end = page + 1 < s_count ? s_pages[page + 1] : s_len;
    return page_end == after ? block->image : -1;
}

// 标题块整体高度：用同一套 take_line 逐行量一遍，供「标题不跨页拆分」判断。
// Total height of a heading block, measured with the same take_line pass so a two-line title can be
// kept whole on one page instead of being split across a page boundary.
static bool take_line(size_t off, int advance_limit, int hang_margin, size_t* next,
                      bool* paragraph_end, int* px, bool* heading,
                      int* line_width, int* indent, uint8_t* align,
                      int* margin_before, int* margin_after);
static int line_height_for(int px);
static int gap_for(int height, bool heading);
static int heading_block_height(const blk_t* block) {
    if (!block) return -1;
    size_t at = block->offset;
    const size_t end = block->offset + block->len;
    int total = 0, guard = 0;
    while (at < end && guard++ < 128) {
        size_t next; bool pend, hd; int px, w, ind, mb, ma; uint8_t al;
        if (!take_line(at, s_rect.width, s_rect.x, &next, &pend, &px, &hd, &w, &ind, &al, &mb, &ma)) return -1;
        if (next <= at) break;
        const int lh = line_height_for(px);
        if (at == block->offset) total += mb;
        total += lh;
        if (pend) total += gap_for(lh, hd) + ma;
        at = next;
    }
    return total;
}

static int line_height_for(int px) { return (int)((unsigned)px * s_line_percent / 100); }
static int gap_for(int height, bool heading) {
    return (int)((unsigned)height * s_paragraph_percent / (heading ? 150 : 100));
}

// 该块前一块是否也是标题：书里两行标题常被解析成一串连续的标题块（"第一章" + "章节标题"），
// 这个串必须当作一个整体参与分页，不能在两块之间强制分页。
// Whether the previous block is a heading too: two-line titles often arrive as a run of
// consecutive heading blocks ("Chapter 1" + "chapter title"); the run must paginate as one unit
// and must never be split by the level-2 page break.
static bool prev_block_is_heading(const blk_t* block) {
    if (!block || block < s_blocks) return false;
    const size_t idx = (size_t)(block - s_blocks);
    if (idx == 0 || idx > s_block_count) return false;
    const blk_t* prev = &s_blocks[idx - 1];
    return prev->heading && prev->image < 0;
}

// 从该块起连续标题块的合计高度，用于把多行标题/副标题作为一整块判断是否放得下。
// Total height of the heading run starting at this block, so a multi-line title moves as one unit.
static int heading_run_height(const blk_t* block) {
    if (!block || block < s_blocks) return -1;
    size_t idx = (size_t)(block - s_blocks);
    if (idx >= s_block_count) return -1;
    int total = 0;
    while (idx < s_block_count && s_blocks[idx].heading && s_blocks[idx].image < 0) {
        const int height = heading_block_height(&s_blocks[idx]);
        if (height < 0) return -1;
        total += height;
        if (total > (1 << 20)) break;
        ++idx;
    }
    return total;
}

static bool append_page(size_t off) {
    if (s_count == PAGE_MAX) return false;
    if (s_count == s_capacity) {
        size_t cap = s_capacity ? s_capacity * 2 : 16;
        size_t* pages = heap_caps_realloc(s_pages, cap * sizeof(*pages), PSRAM_CAPS);
        if (!pages) return false;
        s_pages = pages;
        // 起点表要多一项：第 page 页的插图区间是 [start[page], start[page+1])。
        // The start table needs one extra slot: page `page` owns [start[page], start[page+1]).
        uint32_t* starts = heap_caps_realloc(s_page_img_start, (cap + 1) * sizeof(*starts), PSRAM_CAPS);
        if (!starts) return false;
        s_page_img_start = starts;
        s_capacity = cap;
    }
    s_pages[s_count] = off;
    s_page_img_start[s_count] = (uint32_t)s_image_count;
    ++s_count;
    s_page_img_start[s_count] = (uint32_t)s_image_count;
    return true;
}

// 段首的全角/半角空白不参与排版，缩进由阅读设置决定；返回第一个可见字节。
// Leading blanks of a paragraph take no part in typesetting -- the reader setting owns the
// indent -- so return the first visible byte.
static size_t visible_start(size_t off, size_t limit) {
    while (off < limit) {
        size_t n = codepoint_size(s_text + off, limit - off);
        if (!n) break;
        uint32_t cp = codepoint_value(s_text + off, n);
        if (cp == ' ' || cp == '\t' || cp == 0xa0 || cp == 0x1680 ||
            (cp >= 0x2000 && cp <= 0x200b) || cp == 0x202f || cp == 0x205f ||
            cp == 0x2060 || cp == 0x3000 || cp == 0xfeff) {
            off += n; continue;
        }
        break;
    }
    return off;
}

// 折行时保留原文字节位置；CRLF 算一个段落边界。advance_limit 是行宽（竖排是列高），
// hang_margin 是允许标点悬挂的外侧留白（竖排为 0，列底没有可悬挂的空白）。
// Preserve source offsets while wrapping; CRLF is one paragraph boundary. advance_limit is the
// line width (the column height vertically) and hang_margin is the outer slack a hanging mark may
// use (0 vertically: a column has no bottom margin to hang into).
// 行缓冲按实际UTF-8长度增长，包含零宽字符的长行仍可安全扩容；失败保留原指针。
// Grow by actual UTF-8 line bytes, including long zero-width runs; failed growth keeps the old allocation.
static bool line_append(size_t at, const char *text, size_t bytes) {
    if (at > s_len || bytes > s_len - at) return false;
    size_t need = at + bytes + 1;
    if (need > s_line_capacity) {
        size_t capacity = s_line_capacity ? s_line_capacity : 256;
        while (capacity < need) {
            if (capacity > (s_len + 1) / 2) { capacity = s_len + 1; break; }
            capacity *= 2;
        }
        if (capacity > s_len + 1) capacity = s_len + 1;
        char *next = heap_caps_realloc(s_line, capacity, PSRAM_CAPS);
        if (!next) return false;
        s_line = next; s_line_capacity = capacity;
    }
    if (bytes) memcpy(s_line + at, text, bytes);
    s_line[at + bytes] = 0;
    return true;
}
static bool take_line(size_t off, int advance_limit, int hang_margin, size_t* next,
                      bool* paragraph_end, int* px, bool* heading,
                      int* line_width, int* indent, uint8_t* align,
                      int* margin_before, int* margin_after) {
    const blk_t* block = block_at(off);
    *heading = block && block->heading;
    *px = s_px + (*heading ? 8 : 0);
    // 书内 CSS font-size：按块把阅读字号缩放到书里声明的比例（50–250%）。0/未指定保持原字号。
    // In-book CSS font-size scales the reader size per block (50–250%); 0/unspecified keeps it.
    {
        const int percent = block && block->font_percent ? block->font_percent : 100;
        if (percent != 100) *px = (*px * percent + 50) / 100;
        if (*px < 8) *px = 8;
    }
    bool first_line = block ? off == block->offset :
        off == 0 || s_text[off - 1] == '\n' || s_text[off - 1] == '\r';
    *align = block ? block->align : 0;
    // 首行缩进由阅读设置统一控制；书内标题和对齐块仍保持原本的位置。
    // The reader setting controls paragraph indent; headings and aligned blocks keep their placement.
    *indent = 0;
    if (first_line && !*heading && !*align) {
        // 缩进按当前字体真实全角字宽和字间距计算，不把行高当字宽。
        // Indent by actual full-width advances plus tracking, not by the font's line height.
        slot_select_for(off);
        // 全角空格在部分字体中不是一个汉字宽，使用正文汉字的实际推进量。
        // Some faces have a narrow ideographic space; use an actual CJK advance instead.
        int advance = ttf_text_width_px(*px, "一");
        if (advance <= 0) advance = *px;
        advance += s_tracking_px;
        if (advance < 1) advance = 1;
        *indent = advance * (int)s_first_line_indent_em;
        if (s_first_line_indent_em) *indent += s_first_line_indent_adjust_px;
        if (*indent < 0) *indent = 0;
    }
    if (*indent >= advance_limit) *indent = advance_limit > 1 ? advance_limit - 1 : 0;
    if (*indent + *px > advance_limit) *indent = 0;
    *margin_before = first_line && block ? (int)((unsigned)*px * block->margin_before_percent / 100) : 0;
    *margin_after = block ? (int)((unsigned)*px * block->margin_after_percent / 100) : 0;
    size_t limit = block ? block->offset + block->len : s_len;
    // 纸书常把全角空格写进段首；统一由阅读设置决定缩进，原文偏移仍保留。
    // Printed-book source often contains leading spaces; the reader setting owns the visual indent.
    size_t visible_off = off;
    if (first_line && !*heading && !*align) visible_off = visible_start(off, limit);
    if (first_line && !*heading && !*align) {
        if (visible_off < limit && *indent > 0) {
            size_t n = codepoint_size(s_text + visible_off, limit - visible_off);
            if (!n) return false;
            uint32_t cp = codepoint_value(s_text + visible_off, n);
            if (prohibited_line_end(cp)) {
                // 段首开标点自身常有半字留白，向缩进区悬挂，保持可见左边缘对齐。
                // Hang an opener's own leading whitespace into the indent, keeping its ink edge aligned.
                char glyph[5]; memcpy(glyph, s_text + visible_off, n); glyph[n] = 0;
                slot_select_for(visible_off);
                int bearing = ttf_text_left_bearing_px(*px, glyph);
                if (bearing > *indent) bearing = *indent;
                if (bearing > 0) *indent -= bearing;
            }
        }
    }
    int available = advance_limit - *indent;
    size_t end = visible_off;
    size_t last_start = visible_off;
    uint32_t last_cp = 0;
    int64_t width = 0;
    int64_t last_width = 0;
    int glyph_count = 0;
    s_line[0] = 0;
    *paragraph_end = false;
    while (end < limit && s_text[end] != '\r' && s_text[end] != '\n') {
        size_t n = codepoint_size(s_text + end, s_len - end);
        if (!n) return false;
        uint32_t cp = codepoint_value(s_text + end, n);
        // 字体逐字取整后累加 advance；单字测量避免反复扫描整行前缀。
        // Font advances are rounded per glyph and summed; measure each glyph once instead of every prefix.
        char glyph[5];
        memcpy(glyph, s_text + end, n);
        glyph[n] = 0;
        // 每个字都按自己那一段的字体量宽：行宽、字距和对齐算法一个字没改。
        // Every glyph is measured in its own span's face; width, tracking and alignment math
        // are untouched.
        slot_select_for(end);
        int64_t candidate = width + ttf_text_width_px(*px, glyph) +
                            (end > visible_off && !*heading ? s_tracking_px : 0);
        if (candidate < 0) return false;
        if (candidate > available) {
            if (end == visible_off) return false;
            // 优先让行尾正文对齐，再允许右标点小幅悬挂到留白；超出安全宽度才回退前一字。
            // Align the text edge first, hang a closing mark slightly into the margin, then roll back only if needed.
            if (prohibited_line_start(cp)) {
                // 竖排传 0：列底没有可悬挂的留白，标点一律回退到下一列。
                // Vertical setting passes 0: a column has no bottom slack to hang into, so the
                // mark always rolls back to the next column.
                int hang = hang_margin > 4 ? *px / 3 : 0;
                if (hang > hang_margin - 4) hang = hang_margin - 4;
                if (hang < 0) hang = 0;
                int squeeze = glyph_count > 1 ? (glyph_count - 1) * 3 : 0;
                if (candidate <= (int64_t)available + hang + squeeze) {
                    if (!line_append(end - visible_off, glyph, n)) return false;
                    width = candidate;
                    end += n;
                    break;
                }
                if (last_start > visible_off) {
                    end = last_start;
                    s_line[end - visible_off] = 0;
                    width = last_width;
                    break;
                }
                // 极窄行容不下两个字时才保留悬挂，避免出现以标点开头的死循环。
                // Only a one-glyph-wide line may hang punctuation to avoid a non-progressing wrap.
                if (candidate <= (int64_t)available + *px * 2) {
                    if (!line_append(end - visible_off, glyph, n)) return false;
                    width = candidate;
                    end += n;
                    break;
                }
            }
            // 若最后一个字是左括号，将它回退到下一行；极窄行则让括号和首字成组悬挂。
            // Move a trailing opener to the next line; on a one-glyph line keep the pair together.
            if (prohibited_line_end(last_cp)) {
                if (last_start > visible_off) {
                    end = last_start;
                    s_line[end - visible_off] = 0;
                    width = last_width;
                } else if (candidate <= (int64_t)available + *px * 2) {
                    if (!line_append(end - visible_off, glyph, n)) return false;
                    width = candidate;
                    end += n;
                }
            }
            break;
        }
        last_width = width;
        width = candidate;
        ++glyph_count;
        last_start = end;
        last_cp = cp;
        if (!line_append(end - visible_off, glyph, n)) return false;
        end += n;
    }
    line_runs_build(block, visible_off, end);
    *line_width = (int)width;
    *next = end;
    if (end < s_len && (s_text[end] == '\r' || s_text[end] == '\n')) {
        *next = end + 1;
        if (s_text[end] == '\r' && *next < s_len && s_text[*next] == '\n') (*next)++;
        *paragraph_end = !block || !block->line_break_after;
    }
    return *next > off;
}

// 行内从 visible 起点到 bytes 字节处的前缀像素宽（含字距），用于划线色带的起止边界。
// Prefix width in pixels from the visible line start to `bytes` (including tracking), for band edges.
static int line_prefix_width(int px, const char *line, size_t bytes, int tracking) {
    int width = 0, glyphs = 0;
    size_t i = 0;
    const size_t len = strlen(line);
    while (i < bytes && i < len) {
        size_t n = codepoint_size(line + i, len - i);
        if (!n) break;
        char glyph[5];
        memcpy(glyph, line + i, n);
        glyph[n] = 0;
        width += ttf_text_width_px(px, glyph);
        if (glyphs) width += tracking;
        ++glyphs;
        i += n;
    }
    return width;
}

/* ---- 行内样式绘制 / Inline style drawing ---- */
// Markdown 的粗体/斜体/高亮只覆盖行内一段字节。样式位非零的行按样式与字体槽切段，
// 逐段推进并在段末恢复引擎状态；样式位为零的行完全走原来的整行绘制路径（EPUB/TXT 零回归）。
// Markdown emphasis only covers byte spans inside a line. A line with nonzero style bits is split
// by style and face into spans that advance and restore engine state as they go; a line with zero
// style bits keeps the original whole-line drawing path (no EPUB/TXT regression).

// 该字节的样式位与字体槽。样式 run 是稀疏的：未覆盖的字节 style=0，所以样式必须按区间包含
// 判断（rel 落在 [offset, offset+len) 内）；字体槽沿用 slot_at 的“最后一条已开始的 run”语义，
// 与原有排版/绘制一字不差。没有 run 表或该块没有 run 时样式为零、字体为系统槽。
// Style bits and face slot for this byte. Style runs are sparse: uncovered bytes are style 0, so
// the style needs a range containment test (rel inside [offset, offset+len)). The face keeps
// slot_at's "last run that has started" rule and therefore stays identical to the original
// pagination and drawing. Without a run table or runs for the block the style is zero and the face
// is the system slot.
static void run_style_slot_at(size_t off, uint8_t* style, uint8_t* slot) {
    uint8_t bits = 0;
    uint8_t face = TTF_FONT_SLOT_SYSTEM;
    if (s_runs != NULL) {
        const blk_t* block = block_at(off);
        if (block != NULL && block->run_count != 0 && off >= block->offset) {
            size_t rel = off - block->offset;
            size_t last = block->run_first + block->run_count;
            if (last > s_run_count) last = s_run_count;
            for (size_t i = block->run_first; i < last; ++i) {
                if (s_runs[i].offset > rel) break;
                face = s_runs[i].slot;
                if (rel < s_runs[i].offset + s_runs[i].len) {
                    bits = s_runs[i].style;
                    break;
                }
            }
        }
    }
    if (style != NULL) *style = bits;
    if (slot != NULL) *slot = face;
}

// 本行范围是否被非零样式 run 覆盖。纯查找、不落墨、不动字体，返回假时调用方原封不动走旧路径。
// Whether a nonzero-style run overlaps this line's byte range. A pure lookup: no ink, no font
// change; a false result sends the caller down the original path untouched.
static bool line_has_style(const blk_t* block, size_t line_start, size_t bytes) {
    if (s_runs == NULL || block == NULL || block->run_count == 0 || bytes == 0) return false;
    size_t block_end = block->offset + block->len;
    if (line_start < block->offset || line_start >= block_end) return false;
    size_t line_end = line_start + bytes;
    if (line_end > block_end) line_end = block_end;
    size_t base = line_start - block->offset;
    size_t stop = line_end - block->offset;
    size_t last = block->run_first + block->run_count;
    if (last > s_run_count) last = s_run_count;
    for (size_t i = block->run_first; i < last; ++i) {
        size_t from = s_runs[i].offset;
        size_t to = from + s_runs[i].len;
        if (to <= base) continue;
        if (from >= stop) break;
        if (s_runs[i].style != 0) return true;
    }
    return false;
}

// 按样式位与字体槽把本行切段，并量出每段自然宽与推进量（自然宽 + 段内字数 * 字距）。
// 返回 false 表示段数超限、内存不足或可见文字没有任何样式，调用方必须整行退回普通绘制。
// Split the line into spans by style bits and face and measure each span's natural width and
// advance (natural width plus one tracking step per glyph). False means the span cap, memory or a
// line without any visible styled glyph stopped it; the caller then falls back to plain drawing.
static bool style_spans_build(char* line, size_t line_visible, int line_px, int tracking,
                              size_t* out_count) {
    if (s_spans == NULL) {
        s_spans = heap_caps_malloc(STYLE_SPAN_MAX * sizeof(*s_spans), PSRAM_CAPS);
        if (s_spans == NULL) return false;
    }
    const size_t line_len = strlen(line);
    size_t count = 0;
    size_t start = 0;
    size_t at = 0;
    uint8_t style = 0;
    uint8_t slot = TTF_FONT_SLOT_SYSTEM;
    bool started = false;
    bool any_style = false;
    while (at < line_len) {
        size_t n = codepoint_size(line + at, line_len - at);
        if (!n) return false;
        uint8_t glyph_style = 0;
        uint8_t glyph_slot = TTF_FONT_SLOT_SYSTEM;
        run_style_slot_at(line_visible + at, &glyph_style, &glyph_slot);
        glyph_slot = slot_ready_or_system(glyph_slot);
        if (!started) {
            started = true;
            style = glyph_style;
            slot = glyph_slot;
        } else if (glyph_style != style || glyph_slot != slot) {
            if (count == STYLE_SPAN_MAX) return false;
            style_span_t* span = &s_spans[count++];
            span->start = start;
            span->len = at - start;
            span->style = style;
            span->slot = slot;
            start = at;
            style = glyph_style;
            slot = glyph_slot;
        }
        if (glyph_style != 0) any_style = true;
        at += n;
    }
    // 没有任何可见字带样式时返回假：例如样式 run 只盖住了段首被跳过的空白。
    // No visible glyph carries a style: for example the run only covered skipped leading blanks.
    if (!started || !any_style || count == STYLE_SPAN_MAX) return false;
    style_span_t* tail = &s_spans[count++];
    tail->start = start;
    tail->len = line_len - start;
    tail->style = style;
    tail->slot = slot;
    // 量宽沿用排版口径：整段一次测量（引擎逐字取整后累加），段内每个字之间补字间距。
    // 量宽期间不能按 run 换字体，否则同一段会串字面。
    // Measure like layout does: one call per span (the engine rounds per glyph and sums) and one
    // tracking step between its glyphs. The run table must stay off while measuring, or one span
    // would mix faces.
    ttf_draw_set_runs(NULL, 0);
    for (size_t i = 0; i < count; ++i) {
        style_span_t* span = &s_spans[i];
        ttf_font_select(span->slot);
        char saved = line[span->start + span->len];
        line[span->start + span->len] = 0;
        int width = ttf_text_width_px(line_px, line + span->start);
        line[span->start + span->len] = saved;
        if (width < 0) width = 0;
        size_t glyphs = 0;
        for (size_t k = 0; k < span->len;) {
            size_t n = codepoint_size(line + span->start + k, span->len - k);
            if (!n) break;
            k += n;
            ++glyphs;
        }
        long long step = (long long)width + (long long)glyphs * (long long)tracking;
        span->width = width;
        span->step = step < 0 ? 0 : step > (long long)INT_MAX ? INT_MAX : (int)step;
    }
    *out_count = count;
    return true;
}

// 单段落字：整行共用基线，字间距只加在段内相邻字之间。
// Ink one span on the shared line baseline, adding tracking only between its glyphs.
static void draw_plain_span(uint8_t* fb, int x, int baseline, int line_px, const char* text,
                            int tracking, uint8_t bg) {
    if (tracking != 0)
        ttf_draw_text_px_spaced(fb, x, baseline, line_px, text, tracking, 0, bg);
    else
        ttf_draw_text_px(fb, x, baseline, line_px, text, EPD_DRAW_ALIGN_LEFT, 0, bg);
}

// 斜体落墨：覆盖率遮罩按行横向剪切后逐像素 blit，第 row 行右移 (height-1-row)/8 像素，
// 保证剪切量非负且不超过预留的 line_px/2；粗斜体再并上右移一列的那一次落墨（双押），笔画加粗。
// 单个遮罩受 ttf_text_mask_px 的 684 像素宽上限约束，横屏长段按字切开逐块落墨；字距非零时
// 逐字落墨，让字距由笔位置补上。进入前按段宽一次把遮罩分配到位，分配失败整段回落普通绘制，
// 不会出现半段样式半段素。
// Italic inking: shear a coverage mask row by row, shifting row `row` right by (height-1-row)/8
// so the shear stays nonnegative and inside the reserved line_px/2; a bold italic unions the copy
// shifted one column right (double strike) to thicken the stroke. One mask is capped at 684 pixels
// wide by ttf_text_mask_px, so a wide landscape span is cut at glyph boundaries; with nonzero
// tracking each glyph is masked on its own so tracking still comes from the pen position. The mask
// is allocated once for the whole span up front: a failed allocation falls back for the whole span
// instead of leaving half of it styled.
static bool style_mask_blit(uint8_t* fb, int x, int line_top, int line_px, int ascender,
                            char* text, size_t bytes, int width, int tracking, int bg,
                            bool bold) {
    const unsigned height = (unsigned)line_px * 2u;
    if (line_px <= 0 || height > 180u || bytes == 0 || width <= 0) return false;
    const int room = line_px / 2;
    const int pad = line_px / 4;
    unsigned mask_max = (unsigned)(width + room + pad);
    if (mask_max > STYLE_MASK_MAX_WIDTH) mask_max = STYLE_MASK_MAX_WIDTH;
    if (mask_max == 0) return false;
    const size_t mask_bytes = (size_t)mask_max * height;
    if (mask_bytes > s_mask_size) {
        uint8_t* grown = heap_caps_realloc(s_mask, mask_bytes, PSRAM_CAPS);
        if (grown == NULL) return false;
        s_mask = grown;
        s_mask_size = mask_bytes;
    }
    int pen = x;
    size_t at = 0;
    while (at < bytes) {
        size_t chunk_at = at;
        int chunk_width = 0;
        while (at < bytes) {
            size_t n = codepoint_size(text + at, bytes - at);
            if (!n) return true;
            char glyph[5];
            memcpy(glyph, text + at, n);
            glyph[n] = 0;
            int advance = ttf_text_width_px(line_px, glyph);
            if (advance < 0) advance = 0;
            if (chunk_width > 0 &&
                chunk_width + advance + room + pad > (int)STYLE_MASK_MAX_WIDTH) break;
            chunk_width += advance;
            at += n;
            if (tracking != 0) break;
        }
        unsigned mask_w = (unsigned)(chunk_width + room + pad);
        if (mask_w > mask_max) mask_w = mask_max;
        if (mask_w == 0) { pen += chunk_width + tracking; continue; }
        memset(s_mask, 0, (size_t)mask_w * height);
        // 段尾临时切断：字库按零结尾串取字，量宽与遮罩都只看这一块。
        // Cut the chunk end temporarily: the face reads a NUL-terminated string, so measuring and
        // the mask only see this chunk.
        char saved = text[at];
        text[at] = 0;
        bool masked = ttf_text_mask_px(s_mask, mask_w, height, pad, ascender, line_px,
                                       text + chunk_at);
        if (!masked) {
            // 遮罩不可用：这一块按普通文字落墨，笔位置不受影响。
            // Mask unavailable: ink this chunk as plain text; the pen position is unchanged.
            draw_plain_span(fb, pen, line_top + ascender, line_px, text + chunk_at, 0, bg);
            text[at] = saved;
            pen += chunk_width + tracking;
            continue;
        }
        text[at] = saved;
        for (unsigned row = 0; row < height; ++row) {
            const int shift = ((int)height - 1 - (int)row) / 8;
            const uint8_t* src = s_mask + (size_t)row * mask_w;
            for (unsigned col = 0; col < mask_w; ++col) {
                unsigned alpha = src[col];
                if (bold && col > 0 && src[col - 1] > alpha) alpha = src[col - 1];
                if (alpha == 0) continue;
                // 覆盖率在深灰墨水与底色之间混：fg=0，只取高四位，与 epd_draw_pixel 的灰阶一致。
                // Blend coverage between dark ink and the background: fg=0, high nibble only,
                // matching epd_draw_pixel's gray scale.
                const int ink = bg - (int)(alpha * (unsigned)bg / 255u);
                epd_draw_pixel(pen + (int)col - pad + shift, line_top + (int)row,
                               (uint8_t)(ink << 4), fb);
            }
        }
        pen += chunk_width + tracking;
    }
    return true;
}

// 按段绘制一行样式文字：高亮先铺灰底、粗体临时抬字重、斜体走剪切遮罩，段末恢复引擎状态。
// 绘制结束一定还原字重、run 表与字体槽，任何一段失败都只是这一段退回普通绘制。
// Draw one styled line span by span: highlighter band first, bold raises the weight temporarily,
// italics go through the sheared mask, and the engine state is restored per span. The weight, run
// table and face cursor are always restored at the end; a failed span only falls back to plain
// drawing for itself.
static void draw_styled_line(uint8_t* fb, int x, int line_top, int baseline, int line_px,
                             int line_height, size_t count, int tracking, uint8_t bg) {
    const int inset = line_px / 8 > 1 ? line_px / 8 : 1;
    const int band_h = line_height - inset * 2;
    const int ascender = baseline - line_top;
    const int old_weight = ttf_get_weight();
    int pen = x;
    ttf_draw_set_runs(NULL, 0);
    for (size_t i = 0; i < count; ++i) {
        const style_span_t* span = &s_spans[i];
        char saved = s_line[span->start + span->len];
        s_line[span->start + span->len] = 0;
        const char* text = s_line + span->start;
        const uint8_t style = span->style;
        // 高亮段在灰底上落字，抗锯齿也向同一灰度混合；其它段沿用本行原来的底色口径。
        // Highlight spans ink over the band gray and blend anti-aliasing toward it; other spans
        // keep the line's original background level.
        const uint8_t span_bg = (style & HTML_STYLE_HIGHLIGHT) != 0 ? 10 : bg;
        ttf_font_select(span->slot);
        // 高亮底色：位置与高度照搬选中色带（rect.y+used+inset，行高减去上下收边），宽度是段宽。
        // Highlighter band: same position and height as the selection band (rect.y+used+inset,
        // line height minus both insets), and the span's width.
        if ((style & HTML_STYLE_HIGHLIGHT) != 0 && band_h > 0 && span->width > 0)
            epd_fill_rect((EpdRect){pen, line_top + inset, span->width, band_h}, 0xa0, fb);
        bool inked = false;
        if ((style & HTML_STYLE_ITALIC) != 0) {
            // 斜体（含粗斜体）走遮罩：粗斜体的加粗由遮罩双押完成。
            // Italics (bold italics included) take the mask; a bold italic is thickened by the
            // mask's double strike instead of a weight change.
            inked = style_mask_blit(fb, pen, line_top, line_px, ascender, s_line + span->start,
                                    span->len, span->width, tracking, span_bg,
                                    (style & HTML_STYLE_BOLD) != 0);
        }
        if (!inked && (style & HTML_STYLE_BOLD) != 0) {
            // 粗体按可变字体的字重轴加重；字形缓存按字重分键，不会串形，段末马上还原。
            // 斜体遮罩不可用时也落到这里，保住粗体的加重效果。
            // Bold moves the variable face's weight axis; the glyph cache keys on weight so faces
            // never mix, and the previous weight comes back at the end of the span. A failed
            // italic mask lands here too, keeping the bold weight.
            const int lifted = old_weight + 250 > 800 ? 800 : old_weight + 250;
            ttf_set_weight(lifted);
            draw_plain_span(fb, pen, baseline, line_px, text, tracking, span_bg);
            ttf_set_weight(old_weight);
        } else if (!inked) {
            draw_plain_span(fb, pen, baseline, line_px, text, tracking, span_bg);
        }
        s_line[span->start + span->len] = saved;
        pen += span->step;
    }
    ttf_set_weight(old_weight);
    ttf_draw_set_runs(NULL, 0);
    ttf_font_select(TTF_FONT_SLOT_SYSTEM);
}


/* ---- 竖排 / Vertical setting ---- */
// 竖排分页：整页自右向左铺列，列内自上而下；插图独占一页，前后各断一次。
// 每字是正立、抬到字格右上角还是转 90°，由字体引擎的竖排绘制统一决定。
// Vertical pagination: columns fill the page right to left and each column runs down; an
// illustration takes a page of its own, breaking both before and after it. Whether a glyph stands
// upright, lifts into the cell's corner or turns 90° is the font engine's vertical drawing rule.
static bool build_vertical(size_t len) {
    size_t off = s_lead_skip;
    size_t visible = skip_image_spacing(off);
    if (visible < len) off = visible;
    else if (!s_images_visible) {
        for (size_t i = 0; i < s_block_count; ++i)
            if (s_blocks[i].image >= 0 && s_blocks[i].offset >= off) { off = s_blocks[i].offset; break; }
    }
    if (!append_page(off)) return false;
    // 首页右起为竖排题头留出列宽；留太多时第一列正文会另起一页，不会卡住。
    // The first page keeps room for a vertical chapter heading at its right; if that is too wide
    // the first body column starts a new page instead of stalling.
    int64_t used = s_count == 1 && s_chapter_lead_width < (unsigned)s_rect.width
        ? (int64_t)s_chapter_lead_width : 0;
    while (off < len) {
        size_t visible_off = skip_image_spacing(off);
        if (visible_off != off) { off = visible_off; continue; }
        const blk_t* block = block_at(off);
        if (block && block->image >= 0 && off == block->offset) {
            int img_w = 0, img_h = 0;
            // 首页题头占的就是顶部这一条，插图不能在题头上开画。
            // The first page's heading owns the top band, so an illustration may not start there.
            bool heading_band = s_count == 1 && s_lead_height > 0;
            if (image_display_size(block->image, &img_w, &img_h)) {
                if ((used || heading_band) && !append_page(off)) return false;
                if (!record_page_image(block->image, 0, img_w, img_h)) return false;
                off = block->offset + block->len;
                if (off < len && s_text[off] == '\n') ++off;
                // 图后另起一页给正文，图页自己只剩这一张图。
                // Start a fresh page for the text so the image page holds nothing else.
                if (off < len && !append_page(off)) return false;
                used = 0;
            } else {
                if ((used || heading_band) && !append_page(off)) return false;
                used = s_rect.width;
                off = block->offset + block->len;
                if (off < len && s_text[off] == '\n') ++off;
            }
            continue;
        }
        int lead = s_count == 1 ? (int)s_lead_height : 0;
        // 竖排同样让二级标题另起一页，保证横竖排的分节行为一致；页面太短时不单开一页。
        // Vertical setting breaks at level-2 headings too, keeping both settings consistent; a
        // page shorter than a third stays as-is.
        const blk_t* vsection = block_at(off);
        if (vsection && off == vsection->offset && vsection->heading &&
            vsection->heading_level == 2 && !vsection->chapter_start && !vsection->auxiliary &&
            !prev_block_is_heading(vsection) &&
            used > s_rect.height / 3) {
            if (!append_page(off)) return false;
            used = 0;
            lead = 0;
        }
        size_t next;
        bool paragraph_end, heading;
        int px, run_height, indent, margin_before, margin_after;
        uint8_t align;
        if (!take_line(off, s_rect.height - lead, 0, &next, &paragraph_end, &px, &heading,
                       &run_height, &indent, &align, &margin_before, &margin_after)) return false;
        int pitch = line_height_for(px);
        if (pitch > s_rect.width) return false;
        int leading = used ? margin_before : 0;
        if (used + leading + pitch > s_rect.width) {
            if (!append_page(off)) return false;
            used = 0;
            leading = 0;
        }
        used += leading + pitch;
        if (paragraph_end) used += gap_for(pitch, heading) + margin_after;
        off = next;
    }
    return true;
}

bool book_layout_build(const char* utf8, size_t len, EpdRect rect, int px) {
    return book_layout_build_blocks(utf8, len, NULL, 0, rect, px);
}
bool book_layout_build_blocks(const char* utf8, size_t len, const blk_t* blocks, size_t count, EpdRect rect, int px) {
    book_layout_free();
    if ((!utf8 && len) || len == SIZE_MAX || s_lead_skip > len || s_lead_height >= (unsigned)rect.height ||
        px <= 0 || px > INT_MAX / 3 ||
        rect.width <= 0 || rect.height <= 0 || rect.x < 0 || rect.y < 0 ||
        rect.x > INT_MAX - rect.width || rect.y > INT_MAX - rect.height) return false;
    int line_height = line_height_for(px);
    if (line_height > rect.height) return false;
    for (size_t off = 0; off < len;) {
        size_t n = codepoint_size(utf8 + off, len - off);
        if (!n) return false;
        off += n;
    }
    if (count) {
        if (!blocks || count > HTML_TEXT_MAX_BLOCKS) return false;
        size_t expected = 0;
        for (size_t i = 0; i < count; ++i) {
            const blk_t* b = &blocks[i];
            if (b->offset != expected || b->offset >= len || !b->len || b->len > len - b->offset ||
                ((unsigned char)utf8[b->offset] & 0xc0) == 0x80) return false;
            size_t end = b->offset + b->len;
            if (i + 1 < count) {
                if (end >= len || utf8[end] != '\n') return false;
                expected = end + 1;
            } else if (end != len) return false;
        }
    }
    s_blocks = blocks;
    s_block_count = count;
    s_text = utf8;
    s_len = len;
    s_px = px;
    s_rect = rect;
    resolve_image_rect();
    s_line_capacity = len + 1 < 256 ? len + 1 : 256;
    s_line = heap_caps_malloc(s_line_capacity, PSRAM_CAPS);
    size_t off = s_lead_skip;
    if (!s_line) goto fail;
    // 竖排：整章按列自右向左重排；题头列、图页与页界都走同一条路径（与 rc100 相同）。
    // Vertical setting typesets the chapter into right-to-left columns; the heading column,
    // illustration pages and page breaks all come from that path (same as rc100).
    if (s_vertical) {
        if (!build_vertical(len)) goto fail;
        ttf_font_select(TTF_FONT_SLOT_SYSTEM);
        return true;
    }
    size_t visible_off = skip_image_spacing(off);
    if (visible_off < len) off = visible_off;
    else if (!s_images_visible) {
        // 纯插图章节仍保留可检测的插图页，让跨章跳过逻辑继续前进。
        // Image-only chapters keep a detectable image page for the chapter-skip path.
        for (size_t i = 0; i < count; ++i)
            if (blocks[i].image >= 0 && blocks[i].offset >= off) { off = blocks[i].offset; break; }
    }
    if (!append_page(off)) goto fail;
    int64_t used = s_lead_height;
    while (off < len) {
        size_t visible = skip_image_spacing(off);
        if (visible != off) { off = visible; continue; }
        const blk_t* block = block_at(off);
        if (block && block->image >= 0 && off == block->offset) {
            int img_w = 0, img_h = 0;
            if (image_display_size(block->image, &img_w, &img_h)) {
                // 图是页面流里的一个块：放得下就留在本页，文字接着图下面排；放不下才翻页。
                // An image is one block in the page flow: keep it on this page when it fits and
                // let the text continue below it; only start a new page when it does not fit.
                if (used && used + img_h > s_image_rect.height) {
                    if (!append_page(off)) goto fail;
                    used = 0;
                }
                if (!record_page_image(block->image, (int)used, img_w, img_h)) goto fail;
                used += img_h + px / 4;  // 图下留四分之一行高（用户反馈上下留白太粗） / a quarter line under the image
            } else {
                // 取不到尺寸时退回整页显示，保证纯插图章节仍可被跨章跳过逻辑识别。
                // Without dimensions, fall back to a whole-page image so an image-only chapter
                // stays detectable by the chapter-skip path.
                if (used && !append_page(off)) goto fail;
                used = rect.height;
            }
            off = block->offset + block->len;
            if (off < len && utf8[off] == '\n') ++off;
            continue;
        }
        // 二级标题（h2）另起一页：书内二级目录/小节从新页开始，不挤在上一节末尾。
        // 页面太短（不足三分之一）时不单开一页，避免只剩章标题的空页。
        // A level-2 heading starts a new page so second-level sections never run into the
        // previous section's last lines; a page shorter than a third stays as-is so a chapter
        // title does not end up alone on a page.
        const blk_t* section = block_at(off);
        if (section && off == section->offset && section->heading &&
            section->heading_level == 2 && !section->chapter_start && !section->auxiliary &&
            !prev_block_is_heading(section) &&
            used > rect.height / 3) {
            if (!append_page(off)) goto fail;
            used = 0;
        }
        // 标题（尤其两行标题）整体不跨页拆分：整块放不下就移到下一页，标题不在页界处被拆开。
        // 多行标题的相邻标题块按「一串」合并计算，避免"第一章"和"章节标题"分到两页。
        // Keep a heading block (especially a two-line title) whole; move it to the next page when
        // the remaining space cannot hold all of its lines. Consecutive heading blocks are measured
        // as one run so "Chapter 1" and its title never end up on different pages.
        if (section && off == section->offset && section->heading && used > 0 &&
            !prev_block_is_heading(section)) {
            const int need = heading_run_height(section);
            if (need > 0 && used + need > rect.height) {
                if (!append_page(off)) goto fail;
                used = 0;
            }
        }
        size_t next;
        bool paragraph_end, heading;
        int line_px, line_width, indent, margin_before, margin_after;
        uint8_t align;
        if (!take_line(off, s_rect.width, s_rect.x, &next, &paragraph_end, &line_px, &heading,
                       &line_width, &indent, &align, &margin_before, &margin_after)) goto fail;
        (void)line_width; (void)indent; (void)align;
        line_height = line_height_for(line_px);
        if (line_height > rect.height) goto fail;
        int leading = used ? margin_before : 0;
        if (used + leading + line_height > rect.height) {
            if (!append_page(off)) goto fail;
            used = 0;
            leading = 0;
        }
        used += leading + line_height;
        if (paragraph_end) used += gap_for(line_height, heading) + margin_after;
        off = next;
    }
    // 测量会按 run 移动游标；还回去，后面的界面与状态栏仍从系统字体起。
    // Measuring moves the cursor across spans; hand it back so the UI and status bar still
    // start from the system face.
    ttf_font_select(TTF_FONT_SLOT_SYSTEM);
    return true;
fail:
    ttf_font_select(TTF_FONT_SLOT_SYSTEM);
    book_layout_free();
    return false;
}

size_t book_layout_page_count(void) { return s_count; }

size_t book_layout_page_start_offset(size_t page) {
    return page < s_count ? s_pages[page] : s_len;
}

size_t book_layout_page_for_offset(size_t off) {
    size_t lo = 0, hi = s_count;
    while (lo + 1 < hi) {
        size_t mid = lo + (hi - lo) / 2;
        if (s_pages[mid] <= off) lo = mid;
        else hi = mid;
    }
    return lo;
}

// 阅读线只铺在有字的地方：整行只有空白字符时不画。
// Guides cover inked spans only; whitespace-only lines get none.
static bool line_has_ink(const char* line) {
    for (const char* at = line; at && *at; ++at)
        if (*at != ' ' && *at != '\t' && *at != '\r' && *at != '\n') return true;
    return false;
}

// 画一列：字格居中于列宽，列内自上而下逐字；转 90° 的字走旋转绘制，右上角标点抬高半格。
// 完整列把余量摊到字间，和横排的两端对齐同一套规则。
// Draw one column: em boxes are centered across the column pitch and glyphs run downward.
// Rotated glyphs use the rotated draw and corner marks lift half a cell. A complete column
// spreads its slack between glyphs, mirroring horizontal justification.
static void draw_vertical_column(uint8_t* fb, EpdRect rect, int left, int pitch, int lead,
                                 int px, int indent, uint8_t align, int run_height,
                                 bool justify) {
    const int cell = left + (pitch - px) / 2;
    const int available = rect.height - lead;
    const size_t line_len = strlen(s_line);
    int y = rect.y + lead + indent;
    // 竖排里的居中与右对齐是列内的纵向对齐，和横排的行内对齐一一对应。
    // Centering and end alignment in vertical setting line the column up vertically, mirroring
    // their horizontal meaning inside a line.
    if (align == 1) y += (available - indent - run_height) / 2;
    else if (align == 2) y += available - indent - run_height;
    int extra = 0;
    int glyph_count = 0;
    for (size_t at = 0; at < line_len;) {
        size_t n = codepoint_size(s_line + at, line_len - at);
        if (!n) break;
        ++glyph_count;
        at += n;
    }
    if (justify) {
        int slack = available - indent - run_height;
        if (glyph_count > 1 && slack > 0) extra = slack / (glyph_count - 1);
    }
    if (s_reading_line && line_has_ink(s_line)) {
        // 阅读线跟着列走，位置在列的右侧：把整页逆时针转 90° 来读这一列，横排的「字下」正落在这里。
        // 原先画在列中线上（cell + px/2），等于穿字而过，看上去就是错乱。
        // 上下位置滑杆在竖排里横着移动这条线；再往里就压字了，所以夹在字格右边。
        // The guide follows the column and runs down its right side: turn the page 90° counter-clockwise
        // to read the column as a horizontal line and the horizontal "under the glyphs" lands here. It
        // used to sit on the column's centre line, straight through the glyphs. The offset slider moves
        // it sideways; it is clamped to the right of the glyph cell so it can never bite into the text.
        const int cell_left = left + (pitch - px) / 2;
        int guide_x = left + pitch - 2 + s_reading_line_offset;
        if (guide_x < cell_left + px + 1) guide_x = cell_left + px + 1;
        const int dash = s_reading_line == 1 ? 19 : 2;
        const int period = s_reading_line == 1 ? 31 : 13;
        // 与横排对称：竖排走整页高度、从页上边起算，每列的虚实节奏完全一样，不会因为列首缩进、
        // 居中或列长短而各画各的。只在有字的纵向范围内落墨：列首缩进与列尾留白保持白底。
        // Symmetric with the horizontal rule: the rhythm counts from the page's top edge so every
        // column shares it regardless of indent, centring or column length. The dashes ink only the
        // column's glyph span; the leading indent and the trailing blank stay white.
        const int ink_top = y;
        int ink_bottom = y + ttf_vertical_text_height_px(px, s_line, s_tracking_px + extra);
        if (ink_bottom > rect.y + rect.height) ink_bottom = rect.y + rect.height;
        for (int pos = rect.y; pos < rect.y + rect.height; pos += period) {
            int top = pos, bottom = pos + dash;
            if (bottom > rect.y + rect.height) bottom = rect.y + rect.height;
            if (top < ink_top) top = ink_top;
            if (bottom > ink_bottom) bottom = ink_bottom;
            if (bottom > top) epd_fill_rect((EpdRect){guide_x, top, 2, bottom - top}, 0x50, fb);
        }
    }
    // 整列一次交给字体引擎：它按 run 换字体，并按竖排规则决定每字正立、抬角还是转 90°。
    // Hand the whole column to the font engine: it follows the run table for faces and decides
    // per glyph whether it stands upright, lifts into the corner or turns 90°.
    // 本里程碑竖排列内不支持行内样式：高亮/粗体/斜体在竖排里都按普通文字绘制，
    // 只有横排正文会走分段样式路径；样式位为 0 的竖排行为与改动前完全一致。
    // This milestone does not apply inline styles inside vertical columns: highlight, bold and
    // italic are drawn as plain text there, and only horizontal body lines take the span path.
    // Columns with zero style bits behave exactly as before.
    ttf_draw_set_runs(s_line_run_count ? s_line_runs : NULL, s_line_run_count);
    (void)ttf_draw_text_px_vertical(fb, cell, y, px, s_line, s_tracking_px + extra, 0, 15);
    // 画完把游标还回去：页面其它文字、界面和状态栏都按系统字体走。
    // Hand the cursor back: every other page, the UI and the status bar use the system face.
    ttf_draw_set_runs(NULL, 0);
    ttf_font_select(TTF_FONT_SLOT_SYSTEM);
}

// 竖排绘制：与 build_vertical 走同样的折列与页界，只是这里落笔。
// Vertical drawing: the same column walk and page boundaries as build_vertical, inking as it goes.
static void draw_vertical_page(uint8_t* fb, size_t page, EpdRect rect) {
    size_t off = s_pages[page];
    size_t end = page + 1 < s_count ? s_pages[page + 1] : s_len;
    int64_t used = page == 0 && s_chapter_lead_width < (unsigned)rect.width
        ? (int64_t)s_chapter_lead_width : 0;
    uint32_t img_at = s_page_img_start ? s_page_img_start[page] : 0;
    const uint32_t img_end = s_page_img_start ? s_page_img_start[page + 1] : 0;
    if (s_idle_draw && s_idle_draw->started) {
        off=s_idle_draw->offset;used=s_idle_draw->used;img_at=s_idle_draw->image_at;
    }
    while (off < end) {
        size_t visible = skip_image_spacing(off);
        if (visible != off) { off = visible; continue; }
        const blk_t* image_block = block_at(off);
        if (image_block && image_block->image >= 0 && off == image_block->offset) {
            // 插图独占一页，位置由调用方按整页图绘制；记录只用于识别这一页。
            // The illustration owns its page and the caller draws it whole; the record only marks
            // the page.
            while (img_at < img_end && s_images[img_at].image != image_block->image) ++img_at;
            if (img_at < img_end) ++img_at;
            off = image_block->offset + image_block->len;
            if (off < end && s_text[off] == '\n') ++off;
            continue;
        }
        int lead = page == 0 ? (int)s_lead_height : 0;
        size_t next;
        bool paragraph_end, heading;
        int px, run_height, indent, margin_before, margin_after;
        uint8_t align;
        if (!take_line(off, rect.height - lead, 0, &next, &paragraph_end, &px, &heading,
                       &run_height, &indent, &align, &margin_before, &margin_after)) { if(s_idle_draw)s_idle_draw->failed=true; return; }
        int pitch = line_height_for(px);
        int leading = used ? margin_before : 0;
        if (used + leading + pitch > rect.width) return;
        used += leading;
        if (s_line[0]) {
            const blk_t* block = block_at(off);
            bool final_column = paragraph_end || next >= s_len ||
                (block && next >= block->offset + block->len);
            draw_vertical_column(fb, rect, rect.x + rect.width - (int)used - pitch, pitch, lead,
                                 px, indent, align, run_height,
                                 !heading && !align &&
                                 (!final_column || run_height > rect.height - lead - indent));
        }
        used += pitch;
        if (paragraph_end) used += gap_for(pitch, heading) + margin_after;
        off = next;
        if (s_idle_draw && off < end) {
            s_idle_draw->offset=off;s_idle_draw->used=used;s_idle_draw->image_at=img_at;
            s_idle_draw->started=true;s_idle_draw->complete=false;
            return;
        }
    }
}

void book_layout_draw_page(uint8_t* fb, size_t page, EpdRect rect, int px) {
    if (!fb || page >= s_count || px != s_px || rect.width != s_rect.width ||
        rect.height != s_rect.height || rect.x < 0 || rect.y < 0 ||
        rect.x > INT_MAX - rect.width || rect.y > INT_MAX - rect.height) return;
    // 走回退路径的"整页插图"没有图片记录：这里没有文字可画，那张图由调用方绘制，直接返回。
    // 有记录时说明图片已经流进正文，文字和图一起排。
    // A whole-page image from the fallback path has no record: there is no text to draw here and
    // the caller draws that image, so return. With records the image flowed into the page and the
    // text lays out alongside it.
    if (book_layout_page_image(page) >= 0 && book_layout_page_image_count(page) == 0) return;
    // 竖排列：列序自右向左，逐字立/转由字体引擎的竖排规则决定。
    // Vertical page: columns run right to left and the font engine decides each glyph's rotation.
    if (s_vertical) { draw_vertical_page(fb, page, rect); return; }
    size_t off = s_pages[page];
    size_t end = page + 1 < s_count ? s_pages[page + 1] : s_len;
    int64_t used = page == 0 ? s_lead_height : 0;
    // 本页插图按出现顺序排在池里，游标走到哪个块就用哪条记录，不必再查表。
    // This page's images sit in the pool in encounter order, so the walk just consumes them in
    // turn instead of looking each one up.
    uint32_t img_at = s_page_img_start ? s_page_img_start[page] : 0;
    const uint32_t img_end = s_page_img_start ? s_page_img_start[page + 1] : 0;
    if (s_idle_draw && s_idle_draw->started) {
        off=s_idle_draw->offset;used=s_idle_draw->used;img_at=s_idle_draw->image_at;
    }
    while (off < end) {
        size_t visible = skip_image_spacing(off);
        if (visible != off) { off = visible; continue; }
        const blk_t* image_block = block_at(off);
        if (image_block && image_block->image >= 0 && off == image_block->offset) {
            while (img_at < img_end && s_images[img_at].image != image_block->image) ++img_at;
            if (img_at < img_end) {
                const layout_image_t* rec = &s_images[img_at++];
                used = (int64_t)rec->y + rec->height + s_px / 2;
            }
            off = image_block->offset + image_block->len;
            if (off < end && s_text[off] == '\n') ++off;
            continue;
        }
        size_t next;
        bool paragraph_end, heading;
        int line_px, line_width, indent, margin_before, margin_after;
        uint8_t align;
        if (!take_line(off, s_rect.width, s_rect.x, &next, &paragraph_end, &line_px, &heading,
                       &line_width, &indent, &align, &margin_before, &margin_after)) { if(s_idle_draw)s_idle_draw->failed=true; return; }
        int line_height = line_height_for(line_px);
        int leading = used ? margin_before : 0;
        if (used + leading + line_height > rect.height) return;
        used += leading;
        if (s_line[0]) {
            int x = rect.x + indent;
            int available = rect.width - indent;
            if (align == 1) x += (available - line_width) / 2;
            else if (align == 2) x += available - line_width;
            // 行基线整行共用，取行首那一段的字体，免得同一行上下浮动。
            // The baseline is shared by the whole line, so take it from the span the line
            // starts in and keep the line from floating.
            slot_select_for(off);
            int baseline = rect.y + (int)used + ttf_ascender_px(line_px);
            const blk_t *line_block = block_at(off);
            // 行内样式：只有本行范围触及非零样式 run 时才切段绘制；否则下面原路径的调用
            // 一个不多一个不少（EPUB/TXT 零回归）。
            // Inline styles: split the line only when a nonzero-style run reaches it; otherwise the
            // original path below runs with exactly the same calls (no EPUB/TXT regression).
            bool styled_line = false;
            size_t styled_spans = 0;
            const int line_tracking = heading ? 0 : s_tracking_px;
            if (line_has_style(line_block, off, (size_t)(next - off))) {
                size_t line_visible = off;
                if (!heading && !align && off == line_block->offset)
                    line_visible = visible_start(off, line_block->offset + line_block->len);
                styled_line = style_spans_build(s_line, line_visible, line_px, line_tracking,
                                                &styled_spans);
                // 切段会移动字体游标；还回行首那一段的字体，后面的色带量宽与普通绘制口径不变。
                // Span building moves the face cursor; hand it back to the line's first face so the
                // band measurement and the plain path keep their original face.
                slot_select_for(off);
            }
            bool final_line = paragraph_end || next >= s_len ||
                (line_block && next >= line_block->offset + line_block->len);
            // 完整正文行对齐到统一右边界；悬挂标点最多使用少量右侧留白。
            // Justify complete body lines; a hanging closer may use a small part of the right margin.
            const bool fitted = !styled_line && !heading && !align &&
                (!final_line || line_width > available);
            int line_extent = line_width > 0 ? line_width : 0;
            if (fitted) {
                int hang = s_rect.x > 4 ? line_px / 3 : 0;
                if (hang > s_rect.x - 4) hang = s_rect.x - 4;
                line_extent = line_width > available ? available + hang : available;
            }
            // 荧光笔色带先铺在文字下面：灰底 0xd0，上下从行距里各收一点，不盖满整行。
            // 起止边界按选中字节裁到字的位置，长按从按住的字开始、拖到手指那个字结束。
            // The highlighter band goes under the glyphs first: 0xd0 gray, inset from the line box.
            // Its edges trim to the selected bytes so a drag starts and ends at the touched glyph.
            uint32_t band_start = 0, band_end = 0;
            bool banded = s_highlight_preview_on && s_highlight_preview_chapter == s_highlight_chapter &&
                s_highlight_preview_start < next && off < s_highlight_preview_end;
            if (banded) {
                band_start = s_highlight_preview_start;
                band_end = s_highlight_preview_end;
            } else if (book_highlight_range_at(s_highlight_chapter, (uint32_t)off, (uint32_t)next,
                                               &band_start, &band_end)) {
                banded = true;
            }
            if (banded) {
                // 逐字色带：按选中字节裁左右边界，长按只选中一个字，手指滑动时灰带
                // 随着字一个个增长；跨行、跨段的中间行自然铺满整行。
                // Glyph-accurate band: trim both edges to the selected bytes, so a long press
                // shows one glyph and the band grows glyph by glyph as the finger slides; fully
                // covered middle lines naturally span the whole line.
                size_t line_visible = off;
                if (!heading && !align) {
                    bool first = line_block ? off == line_block->offset :
                        off == 0 || s_text[off - 1] == '\n' || s_text[off - 1] == '\r';
                    if (first) line_visible = visible_start(off, line_block ? line_block->offset + line_block->len : s_len);
                }
                const size_t line_len = strlen(s_line);
                int band_x = x;
                int band_w = line_extent;
                if (band_start > line_visible && band_start - line_visible < line_len) {
                    int prefix = line_prefix_width(line_px, s_line, band_start - line_visible, s_tracking_px);
                    // 两端对齐的行字距被拉开，前缀宽度要按整行拉伸比例换算，否则色带起点会偏左。
                    // Justified lines spread the glyphs; scale the prefix by the line's stretch factor
                    // so the band starts at the actual glyph, not at the natural-width position.
                    if (fitted && line_width > 0 && line_extent > line_width)
                        prefix = (int)((int64_t)prefix * line_extent / line_width);
                    if (prefix > 0 && prefix < band_w) {
                        band_x += prefix;
                        band_w -= prefix;
                    }
                }
                if (band_end < (uint32_t)next && band_end > line_visible) {
                    size_t bytes = (size_t)(band_end - line_visible);
                    if (bytes > line_len) bytes = line_len;
                    int prefix = line_prefix_width(line_px, s_line, bytes, s_tracking_px);
                    if (fitted && line_width > 0 && line_extent > line_width)
                        prefix = (int)((int64_t)prefix * line_extent / line_width);
                    if (prefix > 0 && prefix < band_x + band_w - x) band_w = x + prefix - band_x;
                }
                int inset = line_px / 8;
                if (inset < 1) inset = 1;
                int band_h = line_height - inset * 2;
                // 0xa0 在墨水屏白底上明显可见，仍是浅灰荧光笔。
                // 0xa0 stays clearly visible on e-ink while remaining a light highlighter gray.
                if (band_h > 0 && band_w > 0)
                    epd_fill_rect((EpdRect){band_x, rect.y + (int)used + inset, band_w, band_h}, 0xa0, fb);
            }
            // 阅读线只铺在有字的横向范围：首行缩进、行尾空白和对齐留白保持白底。
            // 虚实仍从页左边缘起算，各行的点划节奏保持一致。
            // The guide inks only the line's glyph span: the first-line indent, trailing blanks and
            // alignment slack stay white. Dashes still count from the page's left edge so every line
            // keeps the same rhythm.
            if (s_reading_line && line_has_ink(s_line)) {
                int guide_y = rect.y + (int)used + line_px + (line_height - line_px) / 2 +
                              s_reading_line_offset;
                int dash = s_reading_line == 1 ? 19 : 2;
                int period = s_reading_line == 1 ? 31 : 13;
                const int ink_left = x, ink_right = x + line_extent;
                for (int dx = 0; dx < rect.width; dx += period) {
                    int left = rect.x + dx, right = rect.x + dx + dash;
                    if (right > rect.x + rect.width) right = rect.x + rect.width;
                    if (left < ink_left) left = ink_left;
                    if (right > ink_right) right = ink_right;
                    if (right > left)
                        epd_fill_rect((EpdRect){left, guide_y, right - left, 2}, 0x50, fb);
                }
            }
            // 有划线的行让抗锯齿向灰底混，避免字缘出现一圈白边。
            // Rows with a band blend anti-aliasing toward the band gray instead of leaving a white fringe.
            const uint8_t bg = banded ? 10 : 15;
            if (styled_line) {
                // 样式行逐段落墨，不套整行 run 表：每一段都已按自己的字体槽选好字面。
                // A styled line inks span by span and skips the line-wide run table: every span
                // has already selected its own face.
                draw_styled_line(fb, x, rect.y + (int)used, baseline, line_px, line_height,
                                 styled_spans, line_tracking, bg);
            } else {
                // 绘制按 run 换字体：行宽、字距、两端对齐的算法一个字没动，只有取字形的槽跟着走。
                // Drawing follows the runs: width, tracking and justification math are untouched,
                // only the slot each glyph comes from changes.
                ttf_draw_set_runs(s_line_run_count ? s_line_runs : NULL, s_line_run_count);
                if (fitted)
                    ttf_draw_text_px_fitted(fb, x, baseline, line_px, s_line, s_tracking_px,
                                            line_extent, 0, bg);
                else if (s_tracking_px && !heading)
                    ttf_draw_text_px_spaced(fb, x, baseline, line_px, s_line, s_tracking_px, 0, bg);
                else
                    ttf_draw_text_px(fb, x, baseline, line_px, s_line, EPD_DRAW_ALIGN_LEFT, 0, bg);
            }
            // 画完把游标还回去：页面其它文字、界面和状态栏都按系统字体走。
            // Hand the cursor back: every other page, the UI and the status bar use the system
            // face.
            ttf_draw_set_runs(NULL, 0);
            ttf_font_select(TTF_FONT_SLOT_SYSTEM);
        }
        used += line_height;
        if (paragraph_end) used += gap_for(line_height, heading) + margin_after;
        off = next;
        if (s_idle_draw && off < end) {
            s_idle_draw->offset=off;s_idle_draw->used=used;s_idle_draw->image_at=img_at;
            s_idle_draw->started=true;s_idle_draw->complete=false;
            return;
        }
    }
}

int book_layout_draw_slice(uint8_t *fb,size_t page,EpdRect rect,int px,book_layout_draw_cursor_t *cursor) {
    if(!cursor||!fb||s_idle_draw||page>=s_count||px!=s_px||rect.width!=s_rect.width||rect.height!=s_rect.height)return -1;
    if(!cursor->generation){cursor->generation=s_generation;cursor->page=page;}
    if(cursor->generation!=s_generation||cursor->page!=page||cursor->failed)return -1;
    if(cursor->complete)return 1;
    cursor->complete=true;
    s_idle_draw=cursor;
    book_layout_draw_page(fb,page,rect,px);
    s_idle_draw=NULL;
    ttf_draw_set_runs(NULL,0);ttf_font_select(TTF_FONT_SLOT_SYSTEM);
    return cursor->failed?-1:cursor->complete?1:0;
}

// 只在命中测试里走一遍与绘制相同的行推进；不落墨、不推屏、不改变布局状态。
// Walk the same line advance as drawing for hit testing only: no ink, no present, no layout change.
bool book_layout_line_at(size_t page, EpdRect rect, int px, int y, uint32_t* start, uint32_t* end) {
    if (!start || !end || page >= s_count || px != s_px || rect.width != s_rect.width ||
        rect.height != s_rect.height || rect.x < 0 || rect.y < 0 || s_idle_draw) return false;
    if (book_layout_page_image(page) >= 0 && book_layout_page_image_count(page) == 0) return false;
    size_t off = s_pages[page];
    const size_t page_end = page + 1 < s_count ? s_pages[page + 1] : s_len;
    int64_t used = page == 0 ? s_lead_height : 0;
    const int rel = y - rect.y;
    uint32_t img_at = s_page_img_start ? s_page_img_start[page] : 0;
    const uint32_t img_end = s_page_img_start ? s_page_img_start[page + 1] : 0;
    while (off < page_end) {
        size_t visible = skip_image_spacing(off);
        if (visible != off) { off = visible; continue; }
        const blk_t* image_block = block_at(off);
        if (image_block && image_block->image >= 0 && off == image_block->offset) {
            while (img_at < img_end && s_images[img_at].image != image_block->image) ++img_at;
            if (img_at < img_end) {
                const layout_image_t* rec = &s_images[img_at++];
                used = (int64_t)rec->y + rec->height + s_px / 2;
            }
            off = image_block->offset + image_block->len;
            if (off < page_end && s_text[off] == '\n') ++off;
            continue;
        }
        size_t next;
        bool paragraph_end, heading;
        int line_px, line_width, indent, margin_before, margin_after;
        uint8_t align;
        if (!take_line(off, s_rect.width, s_rect.x, &next, &paragraph_end, &line_px, &heading,
                       &line_width, &indent, &align, &margin_before, &margin_after)) return false;
        const int line_height = line_height_for(line_px);
        const int leading = used ? margin_before : 0;
        if (used + leading + line_height > rect.height) return false;
        used += leading;
        if (s_line[0] && rel >= used && rel < used + line_height) {
            *start = (uint32_t)off;
            *end = (uint32_t)next;
            return true;
        }
        used += line_height;
        if (paragraph_end) used += gap_for(line_height, heading) + margin_after;
        off = next;
    }
    return false;
}

// 字形级命中：同一套行推进，命中行内再按逐字 advance 找 x 所在的字；用于长按划线起点/终点。
// Glyph-level hit test: the same line walk, then per-glyph advances inside the line; used by
// long-press highlight anchors and drag endpoints.
bool book_layout_char_at(size_t page, EpdRect rect, int px, int x, int y,
                         uint32_t* start, uint32_t* len) {
    if (!start || !len || page >= s_count || px != s_px || rect.width != s_rect.width ||
        rect.height != s_rect.height || rect.x < 0 || rect.y < 0 || s_idle_draw) return false;
    if (book_layout_page_image(page) >= 0 && book_layout_page_image_count(page) == 0) return false;
    size_t off = s_pages[page];
    const size_t page_end = page + 1 < s_count ? s_pages[page + 1] : s_len;
    int64_t used = page == 0 ? s_lead_height : 0;
    const int rel = y - rect.y;
    uint32_t img_at = s_page_img_start ? s_page_img_start[page] : 0;
    const uint32_t img_end = s_page_img_start ? s_page_img_start[page + 1] : 0;
    while (off < page_end) {
        size_t visible = skip_image_spacing(off);
        if (visible != off) { off = visible; continue; }
        const blk_t* image_block = block_at(off);
        if (image_block && image_block->image >= 0 && off == image_block->offset) {
            while (img_at < img_end && s_images[img_at].image != image_block->image) ++img_at;
            if (img_at < img_end) {
                const layout_image_t* rec = &s_images[img_at++];
                used = (int64_t)rec->y + rec->height + s_px / 2;
            }
            off = image_block->offset + image_block->len;
            if (off < page_end && s_text[off] == '\n') ++off;
            continue;
        }
        size_t next;
        bool paragraph_end, heading;
        int line_px, line_width, indent, margin_before, margin_after;
        uint8_t align;
        if (!take_line(off, s_rect.width, s_rect.x, &next, &paragraph_end, &line_px, &heading,
                       &line_width, &indent, &align, &margin_before, &margin_after)) return false;
        const int line_height = line_height_for(line_px);
        const int leading = used ? margin_before : 0;
        if (used + leading + line_height > rect.height) return false;
        used += leading;
        if (s_line[0] && rel >= used && rel < used + line_height) {
            const blk_t* block = block_at(off);
            size_t line_visible = off;
            const bool first_line = block ? off == block->offset :
                off == 0 || s_text[off - 1] == '\n' || s_text[off - 1] == '\r';
            if (first_line && !heading && !align)
                line_visible = visible_start(off, block ? block->offset + block->len : s_len);
            int line_x = rect.x + indent;
            const int available = rect.width - indent;
            if (align == 1) line_x += (available - line_width) / 2;
            else if (align == 2) line_x += available - line_width;
            const size_t line_len = strlen(s_line);
            int cursor = line_x;
            for (size_t i = 0; i < line_len;) {
                size_t n = codepoint_size(s_line + i, line_len - i);
                if (!n) break;
                char glyph[5];
                memcpy(glyph, s_line + i, n);
                glyph[n] = 0;
                slot_select_for(line_visible + i);
                const int width = ttf_text_width_px(line_px, glyph);
                if (x < cursor + width || i + n >= line_len) {
                    *start = (uint32_t)(line_visible + i);
                    *len = (uint32_t)n;
                    ttf_font_select(TTF_FONT_SLOT_SYSTEM);
                    return true;
                }
                cursor += width + (i ? s_tracking_px : 0);
                i += n;
            }
            ttf_font_select(TTF_FONT_SLOT_SYSTEM);
            return false;
        }
        used += line_height;
        if (paragraph_end) used += gap_for(line_height, heading) + margin_after;
        off = next;
    }
    return false;
}
