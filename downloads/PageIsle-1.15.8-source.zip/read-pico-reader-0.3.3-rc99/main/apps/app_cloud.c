/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：坚果云同步页：账号配置、WebDAV 目录浏览、下载上书架、划线笔记导出。
 * English: Jianguoyun sync page: account setup, WebDAV browsing, downloads to the shelf and highlight export.
 * 中文：网络与文件操作全部在独立任务里执行，页面只读状态快照；取消用原子位，离页/锁屏前 join。
 * English: All network and file work runs in one worker task; the page reads snapshots only,
 *         cancellation is an atomic flag, and leaving the page or locking joins the worker first.
 * 中文：大缓冲（状态快照、目录项、书单、临时 Markdown）放 PSRAM；页面不进主菜单，从设置页进入。
 * English: Large buffers (status snapshot, directory entries, book list, temporary Markdown) live in
 *         PSRAM; the page is not in the root menu and is opened from Settings.
 */
#include "app_cloud.h"

#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>

#include "book_highlight.h"
#include "book_progress.h"
#include "book_progress_sync.h"
#include "book_store.h"
#include "book_title.h"
#include "display.h"
#include "e0470_epaper_waveform.h"
#include "esp_attr.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "read_pico_transfer.h"
#include "settings.h"
#include "ttf_font.h"
#include "ui_gesture.h"
#include "ui_keyboard.h"
#include "ui_kit.h"
#include "ui_menu.h"
#include "ui_nav.h"
#include "ui_text_input.h"
#include "webdav_client.h"

static const char *TAG = "cloud_page";

// ---- 版式常量 / Layout constants ----
#define CLOUD_ENTRY_MAX 256
#define CLOUD_BOOK_MAX 64
#define CLOUD_MD_MAX (96 * 1024)
#define CLOUD_MESSAGE_MAX 160
#define CLOUD_FIELD_PX 26
#define CLOUD_LIST_ROWS 7
#define CLOUD_LIST_TOP 368
#define CLOUD_LIST_ROW_H 86
#define CLOUD_BOOK_ROWS 8
#define CLOUD_BOOK_TOP 300
#define CLOUD_BOOK_ROW_H 86
// 联网任务栈：进度同步在同一任务内串行跑「枚举本机 → GET → 合并 → 写 NVS → PUT」，
// 比下载/浏览多叠一层 book_progress_sync_run 及其路径/探测缓冲，再压上 WebDAV、
// esp_http_client、esp-tls/mbedTLS 的握手调用链；8192 会在真正 GET/PUT 时溢出。
// 取 12288 与 ota_online.c 的联网任务一致（同一套 TLS 调用链已在真机验证）。
// Worker stack: the progress job runs "list local -> GET -> merge -> save NVS -> PUT" in this task,
// stacking book_progress_sync_run and its path/probe buffers on top of the WebDAV, esp_http_client
// and esp-tls/mbedTLS handshake chain; 8192 overflows once the real GET/PUT starts. 12288 matches
// ota_online.c's network worker, the same TLS chain already validated on devices.
#define CLOUD_WORKER_STACK 12288
#define CLOUD_POLL_MS 300
#define CLOUD_FILE_MAX 640
#define CLOUD_LOCAL_MAX (CLOUD_FILE_MAX + WEBDAV_NAME_MAX + 2) // 本地路径上限（含文件名）/ Local path bound
#define CLOUD_LOCAL_LIMIT 500 ///< webdav 下载 local_path 约 507 字节上限，留余量 / Leave margin under webdav's ~507-byte local limit

// ---- 视图、任务与状态 / Views, jobs and snapshots ----
typedef enum {
    CLOUD_VIEW_CONFIG = 0, ///< 账号配置 / Account setup
    CLOUD_VIEW_BROWSE,     ///< 目录浏览 / Remote browsing
    CLOUD_VIEW_TRANSFER,   ///< 下载或上传进度 / Download or upload progress
    CLOUD_VIEW_EXPORT,     ///< 笔记导出 / Note export
    CLOUD_VIEW_PROGRESS,   ///< 阅读进度同步 / Reading-progress sync
} cloud_view_t;

typedef enum {
    CLOUD_JOB_NONE = 0,
    CLOUD_JOB_TEST,
    CLOUD_JOB_LIST,
    CLOUD_JOB_DOWNLOAD,
    CLOUD_JOB_EXPORT,
    CLOUD_JOB_PROGRESS, ///< 阅读进度同步（下载合并再上传）/ Reading-progress sync (fetch, merge, upload)
} cloud_job_t;

/// 跨任务状态快照；s_mutex 保护，页面只读副本。/ Cross-task snapshot; guarded by s_mutex, the page reads copies.
typedef struct {
    cloud_job_t job;
    bool busy;
    bool done;
    bool ok;
    esp_err_t error;
    uint32_t done_bytes;
    uint32_t total_bytes;
    size_t entries;
    size_t hidden;
    book_progress_sync_result_t progress; ///< 进度同步统计 / reading-progress sync counters
    char message[CLOUD_MESSAGE_MAX];
} cloud_status_t;

/// 有划线的书；导出列表用。/ Books with highlights, used by the export list.
typedef struct {
    char path[BOOK_STORE_PATH_MAX];
    char title[72];
    uint16_t count;
} cloud_book_t;

typedef struct {
    char *buf;
    size_t cap;
    size_t used;
    bool truncated;
} md_writer_t;

// ---- 页面状态 / Page state ----
static cloud_view_t s_view;
static int s_pressed; ///< 按下的按钮 id；-1 表示没有 / Pressed button id, -1 for none
static char s_notice[CLOUD_MESSAGE_MAX];

static app_cloud_config_t s_config;
static ui_text_edit_t s_edit_user, s_edit_pass, s_edit_dir;
static ui_text_edit_t *s_edit_active;
static int s_field; ///< 正在编辑的输入行；-1 无 / Edited field, -1 for none

static webdav_entry_t *s_entries; ///< PSRAM 目录项 / PSRAM directory entries
static size_t s_entry_count;
static size_t s_entry_hidden;
static int s_entry_page;
static char s_root_dir[WEBDAV_PATH_MAX];
static char s_remote_dir[WEBDAV_PATH_MAX];
static bool s_confirm_overwrite;
static char s_confirm_name[WEBDAV_NAME_MAX];
static uint32_t s_confirm_size;

static cloud_book_t *s_books; ///< PSRAM 有笔记的书 / PSRAM books with notes
static size_t s_book_count;
static int s_book_page;
static int s_book_selected;
static bool s_export_pending; ///< 需要重新收集书单 / Book list needs a refresh
static char *s_md;            ///< PSRAM 临时 Markdown / PSRAM temporary Markdown
static bool s_open_requested;

// 阅读进度页的空闲态信息（本机记录数、上次同步时间）。
// Idle-state info for the reading-progress page (local record count and last sync time).
static uint16_t s_progress_local;
static uint32_t s_progress_last;

static bool s_upload;
static char s_job_remote[WEBDAV_PATH_MAX];
static char s_job_local[CLOUD_LOCAL_MAX];
static char s_job_name[WEBDAV_NAME_MAX];
static bool s_job_remove_local;

static SemaphoreHandle_t s_mutex, s_done;
static bool s_joinable;
static volatile bool s_cancel; ///< 取消位：用 GCC 原子内建访问，类型可直接交给 webdav 接口 / Atomic cancel flag
static bool s_worker_network_owned;
static cloud_job_t s_running_job;
static size_t s_list_count, s_list_hidden;
static EXT_RAM_BSS_ATTR cloud_status_t s_status;
static cloud_status_t s_ui; ///< 页面快照 / Page-side snapshot
static cloud_job_t s_start_pending;
static int64_t s_poll_ms;

static EpdRect s_paint_area;
static bool s_paint_gl16;
static bool s_paint_settle;

// ---- 前向声明 / Forward declarations ----
static bool cloud_sync_init(void);
static void cloud_status_get(cloud_status_t *out);
static void cloud_status_reset(cloud_job_t job, const char *message);
static void cloud_status_message(const char *message);
static void cloud_progress_cb(void *unused, uint32_t done, uint32_t total);
static bool cloud_online(char *message, size_t cap);
static esp_err_t cloud_apply_config(void);
static bool cloud_entries_ensure(void);
static bool cloud_books_ensure(void);
static bool cloud_remote_root(char *out, size_t cap);
static app_redraw_t cloud_progress_open(void);
static void cloud_draw_progress(uint8_t *fb);
static app_redraw_t cloud_progress_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev);
static bool cloud_job_start(cloud_job_t job);
static void cloud_job_join(void);
static void cloud_job_cancel(void);
static void cloud_worker(void *unused);
static bool cloud_list_visit(void *unused, const webdav_entry_t *entry);
static int cloud_entry_order(const void *left, const void *right);
static const char *cloud_error_text(esp_err_t err, char *out, size_t cap);

static void cloud_fit_text(char *text, int px, int width);
static void cloud_format_size(uint32_t bytes, char *out, size_t cap);
static void cloud_format_time(int64_t seconds, char *out, size_t cap);
static bool cloud_local_tm(struct tm *out);
static void cloud_relative(const char *absolute, char *out, size_t cap);
static bool cloud_path_below(const char *path, const char *root);
static bool cloud_file_supported(const char *name);
static void cloud_extension(const char *name, char *out, size_t cap);
static void md_put(md_writer_t *writer, const char *text);
static void md_printf(md_writer_t *writer, const char *format, ...);
static void cloud_meta_text(const char *source, char *out, size_t cap);
static void cloud_safe_name(const char *source, char *out, size_t cap);
static int cloud_wrap(uint8_t *fb, int x, int y, int px, int line_height, int width,
                      const char *text, int max_lines);

static app_redraw_t cloud_paint(EpdRect area, bool gl16);
static void cloud_header(uint8_t *fb, const char *title);
static EpdRect cloud_progress_rect(void);
static EpdRect cloud_field_rect(int field);
static EpdRect cloud_crumb_rect(void);
static int cloud_entry_pages(void);
static void cloud_entry_clamp(void);
static int cloud_book_pages(void);
static void cloud_book_clamp(void);
static EpdRect cloud_button_rect(int id);
static int cloud_button_hit(uint16_t x, uint16_t y);
static void cloud_draw_button(uint8_t *fb, int id);
static app_redraw_t cloud_button_feedback(app_ctx_t *ctx, int id);
static bool cloud_back_hit(uint16_t x, uint16_t y);
static app_redraw_t cloud_request_leave(app_ctx_t *ctx);
static app_redraw_t cloud_keyboard_paint(app_ctx_t *ctx, bool force_field);

static void cloud_config_load(void);
static void cloud_field_begin(int field);
static void cloud_field_end(void);
static app_redraw_t cloud_config_save(void);
static app_redraw_t cloud_config_test(void);
static app_redraw_t cloud_config_browse(void);
static void cloud_draw_config(uint8_t *fb);
static app_redraw_t cloud_config_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev);
static app_redraw_t cloud_keyboard_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev);

static void cloud_browse_open(void);
static app_redraw_t cloud_browse_up(void);
static app_redraw_t cloud_download_begin(const webdav_entry_t *entry);
static app_redraw_t cloud_browse_row(size_t index);
static void cloud_draw_browse(uint8_t *fb);
static void cloud_draw_confirm(uint8_t *fb);
static app_redraw_t cloud_browse_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev);
static app_redraw_t cloud_transfer_begin(void);

static bool cloud_export_visit(const char *path, const book_progress_t *progress, void *ctx);
static int cloud_book_order(const void *left, const void *right);
static void cloud_export_collect(void);
static size_t cloud_export_build(const cloud_book_t *book);
static bool cloud_export_prepare(void);
static void cloud_draw_export(uint8_t *fb);
static app_redraw_t cloud_export_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev);

static void cloud_draw_transfer_progress(uint8_t *fb);
static void cloud_draw_transfer(uint8_t *fb);
static app_redraw_t cloud_transfer_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev);

static app_redraw_t cloud_job_finished(app_ctx_t *ctx, const cloud_status_t *status);
static void render(app_ctx_t *ctx, uint8_t *fb);
static bool present(app_ctx_t *ctx, app_redraw_t redraw);
static EpdRect area_hint(app_ctx_t *ctx);
static app_redraw_t on_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev);
static app_redraw_t on_key(app_ctx_t *ctx, int key);
static app_redraw_t on_tick(app_ctx_t *ctx);
static void cloud_on_enter(app_ctx_t *ctx);
static void cloud_on_exit(app_ctx_t *ctx);
static void cloud_before_lock(app_ctx_t *ctx);
static void cloud_media_lost(app_ctx_t *ctx);
static bool cloud_menu_handle(app_ctx_t *ctx);
static bool cloud_edge_back(app_ctx_t *ctx);
static bool cloud_back_swipe_area(app_ctx_t *ctx, const ui_gesture_event_t *ev);

/* ================= 任务与状态 / Worker and status ================= */

static bool cloud_sync_init(void) {
    if (!s_mutex) s_mutex = xSemaphoreCreateMutex();
    if (!s_done) s_done = xSemaphoreCreateBinary();
    return s_mutex != NULL && s_done != NULL;
}

static void cloud_status_get(cloud_status_t *out) {
    if (!out) return;
    memset(out, 0, sizeof(*out));
    if (!s_mutex) return;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    memcpy(out, &s_status, sizeof(*out));
    xSemaphoreGive(s_mutex);
}

// 启动任务前重置快照：页面先看到“正在准备”，任务推进时再覆盖文案。
// Reset the snapshot right before a start so the page shows "preparing" until the worker updates it.
static void cloud_status_reset(cloud_job_t job, const char *message) {
    if (!s_mutex) return;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    memset(&s_status, 0, sizeof(s_status));
    s_status.job = job;
    s_status.busy = true;
    if (message) snprintf(s_status.message, sizeof(s_status.message), "%s", message);
    xSemaphoreGive(s_mutex);
}

static void cloud_status_message(const char *message) {
    if (!message || !s_mutex) return;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    snprintf(s_status.message, sizeof(s_status.message), "%s", message);
    xSemaphoreGive(s_mutex);
}

static void cloud_progress_cb(void *unused, uint32_t done, uint32_t total) {
    (void)unused;
    if (!s_mutex) return;
    if (xSemaphoreTake(s_mutex, pdMS_TO_TICKS(50)) != pdTRUE) return;
    s_status.done_bytes = done;
    s_status.total_bytes = total;
    xSemaphoreGive(s_mutex);
}

static const char *cloud_error_text(esp_err_t err, char *out, size_t cap) {
    if (out && cap) out[0] = 0;
    const char *text = webdav_error_text(err, out, cap);
    if (text && text[0]) return text;
    if (err == ESP_ERR_NOT_SUPPORTED) return "服务暂不可用，请稍后重试";
    if (err == ESP_ERR_TIMEOUT) return "网络超时，请重试";
    if (err == ESP_ERR_NO_MEM) return "内存不足，请退出其他任务后重试";
    if (err == ESP_ERR_INVALID_ARG) return "账号或路径无效，请检查配置";
    return "操作失败，请检查网络与账号";
}

static esp_err_t cloud_apply_config(void) {
    webdav_config_t config;
    memset(&config, 0, sizeof(config));
    snprintf(config.user, sizeof(config.user), "%s", s_config.user);
    snprintf(config.password, sizeof(config.password), "%s", s_config.password);
    return webdav_set_config(&config);
}

// 联网与对时照 ota_online.c 的 online()：复用已在线 STA，未配置则提示去 WiFi 设置。
// Mirror ota_online.c's online(): reuse a live STA, otherwise ask the user to provision WiFi.
static bool cloud_online(char *message, size_t cap) {
    read_pico_transfer_status_t state;
    read_pico_transfer_get_status(&state);
    if (!(state.mode == READ_PICO_TRANSFER_MODE_STA && state.network_ready)) {
        char ssid[33] = {0};
        bool saved = false;
        if (read_pico_transfer_get_saved_wifi(ssid, &saved) != ESP_OK || !saved) {
            snprintf(message, cap, "请先在设置的 WiFi 页面连接网络");
            return false;
        }
        read_pico_transfer_stop();
        read_pico_transfer_cfg_t config = {.mode = READ_PICO_TRANSFER_MODE_STA, .network_only = true};
        cloud_status_message("正在连接网络…");
        if (read_pico_transfer_start(&config) != ESP_OK) {
            snprintf(message, cap, "WiFi 连接失败，请重试");
            return false;
        }
        s_worker_network_owned = true;
    }
    int64_t deadline = esp_timer_get_time() + 30000000;
    while (!__atomic_load_n(&s_cancel, __ATOMIC_SEQ_CST)) {
        read_pico_transfer_service_poll();
        read_pico_transfer_get_status(&state);
        if (state.mode == READ_PICO_TRANSFER_MODE_STA && state.network_ready) {
            if (time(NULL) < 1704067200) {
                uint32_t utc = 0;
                cloud_status_message("正在校验网络时间…");
                if (read_pico_transfer_sync_time_online(&utc) != ESP_OK) {
                    snprintf(message, cap, "网络对时失败，请检查网络后重试");
                    return false;
                }
            }
            return true;
        }
        if (state.state == READ_PICO_TRANSFER_ERROR || esp_timer_get_time() >= deadline) break;
        vTaskDelay(pdMS_TO_TICKS(100));
    }
    if (!__atomic_load_n(&s_cancel, __ATOMIC_SEQ_CST)) snprintf(message, cap, "网络连接超时，请重试");
    return false;
}

static bool cloud_list_visit(void *unused, const webdav_entry_t *entry) {
    (void)unused;
    if (__atomic_load_n(&s_cancel, __ATOMIC_SEQ_CST)) return false;
    if (!entry || !entry->name[0]) return true;
    if (!strcmp(entry->name, ".") || !strcmp(entry->name, "..")) return true;
    if (!entry->is_dir && !cloud_file_supported(entry->name)) {
        ++s_list_hidden;
        return true;
    }
    if (s_list_count >= CLOUD_ENTRY_MAX) return false;
    memcpy(&s_entries[s_list_count], entry, sizeof(*entry));
    ++s_list_count;
    return true;
}

static int cloud_entry_order(const void *left, const void *right) {
    const webdav_entry_t *a = left;
    const webdav_entry_t *b = right;
    if (a->is_dir != b->is_dir) return a->is_dir ? -1 : 1;
    return strcasecmp(a->name, b->name);
}

static bool cloud_entries_ensure(void) {
    if (s_entries) return true;
    s_entries = heap_caps_calloc(CLOUD_ENTRY_MAX, sizeof(webdav_entry_t),
                                 MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    return s_entries != NULL;
}

static bool cloud_books_ensure(void) {
    if (s_books) return true;
    s_books = heap_caps_calloc(CLOUD_BOOK_MAX, sizeof(cloud_book_t),
                               MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    return s_books != NULL;
}

static void cloud_worker(void *unused) {
    (void)unused;
    const cloud_job_t job = s_running_job;
    esp_err_t err = ESP_OK;
    char message[CLOUD_MESSAGE_MAX] = {0};
    char error_text[96] = {0};
    book_progress_sync_result_t progress_result;
    memset(&progress_result, 0, sizeof(progress_result));
    s_worker_network_owned = false;
    s_list_count = s_list_hidden = 0;
    s_job_remove_local = s_job_remove_local && job == CLOUD_JOB_EXPORT;
    if (!cloud_online(message, sizeof(message))) {
        err = ESP_ERR_INVALID_STATE;
    } else {
        err = cloud_apply_config();
        if (err != ESP_OK) snprintf(message, sizeof(message), "账号配置无效，请检查后重试");
    }
    if (err == ESP_OK) {
        switch (job) {
            case CLOUD_JOB_TEST: {
                char reply[96] = {0};
                cloud_status_message("正在连接服务器…");
                err = webdav_test(reply, sizeof(reply));
                if (err == ESP_OK) snprintf(message, sizeof(message), "%s", reply[0] ? reply : "连接成功");
                else snprintf(message, sizeof(message), "连接失败：%.96s",
                              cloud_error_text(err, error_text, sizeof(error_text)));
                break;
            }
            case CLOUD_JOB_LIST:
                cloud_status_message("正在读取目录…");
                err = webdav_list(s_remote_dir, cloud_list_visit, NULL, &s_cancel);
                if (err == ESP_OK) qsort(s_entries, s_list_count, sizeof(webdav_entry_t), cloud_entry_order);
                else snprintf(message, sizeof(message), "目录读取失败：%.96s",
                              cloud_error_text(err, error_text, sizeof(error_text)));
                break;
            case CLOUD_JOB_DOWNLOAD:
                cloud_status_message("正在下载…");
                err = webdav_download(s_job_remote, s_job_local, cloud_progress_cb, NULL, &s_cancel);
                if (err == ESP_OK) snprintf(message, sizeof(message), "已上书架");
                else snprintf(message, sizeof(message), "下载失败：%.96s",
                              cloud_error_text(err, error_text, sizeof(error_text)));
                break;
            case CLOUD_JOB_EXPORT: {
                char parent[WEBDAV_PATH_MAX] = {0};
                cloud_status_message("正在上传笔记…");
                if (webdav_parent(s_job_remote, parent, sizeof(parent)) == ESP_OK) (void)webdav_mkdir(parent);
                err = webdav_upload(s_job_remote, s_job_local, cloud_progress_cb, NULL, &s_cancel);
                if (s_job_remove_local) (void)remove(s_job_local);
                if (err == ESP_OK) snprintf(message, sizeof(message), "已导出到同步文件夹");
                else snprintf(message, sizeof(message), "上传失败：%.96s",
                              cloud_error_text(err, error_text, sizeof(error_text)));
                break;
            }
            case CLOUD_JOB_PROGRESS: {
                char folder[WEBDAV_PATH_MAX] = {0};
                cloud_status_message("正在同步阅读进度…");
                if (!cloud_remote_root(folder, sizeof(folder))) {
                    snprintf(message, sizeof(message), "同步文件夹路径无效，请检查设置");
                    err = ESP_ERR_INVALID_ARG;
                    break;
                }
                err = book_progress_sync_run(folder, &progress_result, &s_cancel);
                if (err == ESP_OK) {
                    snprintf(message, sizeof(message), "%s", progress_result.message);
                } else if (!message[0]) {
                    snprintf(message, sizeof(message), "%s",
                             progress_result.message[0] ? progress_result.message
                                                        : "同步失败，请重试");
                }
                break;
            }
            default:
                err = ESP_ERR_INVALID_STATE;
                break;
        }
    }
    if (s_worker_network_owned) {
        read_pico_transfer_stop();
        s_worker_network_owned = false;
    }
    const bool cancelled = __atomic_load_n(&s_cancel, __ATOMIC_SEQ_CST);
    bool ok = err == ESP_OK && !cancelled;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    s_status.busy = false;
    s_status.done = true;
    s_status.ok = ok;
    s_status.error = err;
    if (job == CLOUD_JOB_LIST) {
        s_status.entries = s_list_count;
        s_status.hidden = s_list_hidden;
    }
    if (job == CLOUD_JOB_PROGRESS) s_status.progress = progress_result;
    if (cancelled) snprintf(s_status.message, sizeof(s_status.message), "已取消");
    else if (message[0]) snprintf(s_status.message, sizeof(s_status.message), "%s", message);
    else if (!ok) snprintf(s_status.message, sizeof(s_status.message), "任务未完成，请重试");
    xSemaphoreGive(s_mutex);
    ESP_LOGI(TAG, "job=%d ok=%d err=%s", (int)job, (int)ok, esp_err_to_name(err));
    xSemaphoreGive(s_done);
    vTaskDelete(NULL);
}

// 页面发起任务；缓冲区与网络由任务自己建立，失败通过快照回报。
// The page starts a job; the worker owns the network and reports failures through the snapshot.
static bool cloud_job_start(cloud_job_t job) {
    if (!cloud_sync_init()) return false;
    if (job == CLOUD_JOB_LIST && !cloud_entries_ensure()) return false;
    __atomic_store_n(&s_cancel, false, __ATOMIC_SEQ_CST);
    s_running_job = job;
    s_job_remove_local = job == CLOUD_JOB_EXPORT;
    cloud_status_reset(job, "正在连接网络…");
    s_poll_ms = 0;
    if (xTaskCreate(cloud_worker, "cloud_sync", CLOUD_WORKER_STACK, NULL, 4, NULL) != pdPASS) {
        xSemaphoreTake(s_mutex, portMAX_DELAY);
        s_status.busy = false;
        s_status.done = true;
        s_status.ok = false;
        snprintf(s_status.message, sizeof(s_status.message), "内存不足，无法启动网络任务");
        xSemaphoreGive(s_mutex);
        return false;
    }
    s_joinable = true;
    return true;
}

// 取消并等任务收尾；离页、锁屏、媒体移除都必须先走这里。
// Cancel and join the worker; page exit, locking and media loss must all pass through here.
static void cloud_job_join(void) {
    if (!s_joinable) return;
    __atomic_store_n(&s_cancel, true, __ATOMIC_SEQ_CST);
    xSemaphoreTake(s_done, portMAX_DELAY);
    s_joinable = false;
}

static void cloud_job_cancel(void) {
    // 还没建任务时直接撤销启动请求；已在跑就置原子位等它自己退出。
    // Drop a queued start before the task exists; otherwise raise the atomic flag and let the worker exit.
    s_start_pending = CLOUD_JOB_NONE;
    if (s_joinable) __atomic_store_n(&s_cancel, true, __ATOMIC_SEQ_CST);
}

/* ================= 文本与小工具 / Text helpers ================= */

// 固定长度的安全拷贝：调用方缓冲区可能小于源串，不用 snprintf 以免 format-truncation 误报。
// Bounded copy; avoids snprintf so format-truncation analysis never has to see variable sizes.
static void cloud_copy(char *out, size_t cap, const char *text) {
    if (!out || !cap) return;
    if (!text) {
        out[0] = 0;
        return;
    }
    size_t length = strlen(text);
    if (length >= cap) length = cap - 1;
    memcpy(out, text, length);
    out[length] = 0;
}

static void cloud_fit_text(char *text, int px, int width) {
    while (text[0] && ui_text_fixed_width_px(ui_text_effective_px(px), text) > width) {
        size_t n = strlen(text) - 1;
        while (n && ((unsigned char)text[n] & 0xc0) == 0x80) --n;
        text[n] = 0;
    }
}

// 列表行用固定字号：行高固定，放大系统字号时不会互相压字。
// List rows keep a fixed size so a large system font cannot make rows overlap.
static void cloud_fit_fixed(char *text, int px, int width) {
    while (text[0] && ui_text_fixed_width_px(px, text) > width) {
        size_t n = strlen(text) - 1;
        while (n && ((unsigned char)text[n] & 0xc0) == 0x80) --n;
        text[n] = 0;
    }
}

static void cloud_format_size(uint32_t bytes, char *out, size_t cap) {
    char text[48];
    if (bytes < 1024) snprintf(text, sizeof(text), "%lu B", (unsigned long)bytes);
    else if (bytes < 1048576)
        snprintf(text, sizeof(text), "%lu.%lu KB", (unsigned long)(bytes / 1024),
                 (unsigned long)((bytes % 1024) * 10 / 1024));
    else
        snprintf(text, sizeof(text), "%lu.%lu MB", (unsigned long)(bytes / 1048576),
                 (unsigned long)((bytes % 1048576) * 10 / 1048576));
    cloud_copy(out, cap, text);
}

static void cloud_format_time(int64_t seconds, char *out, size_t cap) {
    if (!out || !cap) return;
    out[0] = 0;
    if (seconds <= 0) return;
    time_t local = (time_t)seconds + 8 * 3600;
    struct tm value;
    if (!gmtime_r(&local, &value)) return;
    char text[96];
    snprintf(text, sizeof(text), "%04d-%02d-%02d %02d:%02d", value.tm_year + 1900,
             value.tm_mon + 1, value.tm_mday, value.tm_hour, value.tm_min);
    cloud_copy(out, cap, text);
}

// 无 RTC 电池，联网校时前时间无效；导出文件里写“未知”，不写 1970。
// There is no RTC battery, so time is invalid before an online sync; write "unknown" instead of 1970.
static bool cloud_local_tm(struct tm *out) {
    time_t now = time(NULL);
    if (!out || now < 1704067200) return false;
    time_t local = now + 8 * 3600;
    return gmtime_r(&local, out) != NULL;
}

// href 含服务器根路径前缀（例如 /dav），面包屑只显示相对部分。
// href carries the server root path prefix (e.g. /dav); the breadcrumb shows the relative part only.
static void cloud_relative(const char *absolute, char *out, size_t cap) {
    if (!out || !cap) return;
    out[0] = 0;
    if (!absolute) return;
    const char *base = webdav_base();
    const char *prefix = NULL;
    if (base) {
        const char *host = !strncmp(base, "https://", 8) ? base + 8
                         : !strncmp(base, "http://", 7) ? base + 7 : NULL;
        if (host) prefix = strchr(host, '/');
    }
    size_t skip = 0;
    if (prefix) {
        size_t length = strlen(prefix);
        if (!strncmp(absolute, prefix, length) &&
            (absolute[length] == 0 || absolute[length] == '/')) skip = length;
    }
    cloud_copy(out, cap, absolute[skip] ? absolute + skip : "/");
}

static bool cloud_path_below(const char *path, const char *root) {
    if (!root || !root[0]) return true;
    size_t length = strlen(root);
    return !strncmp(path, root, length) && (path[length] == 0 || path[length] == '/');
}

static bool cloud_file_supported(const char *name) {
    const char *dot = strrchr(name, '.');
    return dot && (!strcasecmp(dot, ".md") || !strcasecmp(dot, ".markdown") ||
                   !strcasecmp(dot, ".txt") || !strcasecmp(dot, ".epub"));
}

static void cloud_extension(const char *name, char *out, size_t cap) {
    const char *dot = strrchr(name, '.');
    size_t used = 0;
    if (dot && dot[1]) {
        for (const char *p = dot + 1; *p && used + 1 < cap; ++p)
            out[used++] = (char)(*p >= 'a' && *p <= 'z' ? *p - 32 : *p);
    }
    out[used] = 0;
}

static void md_put(md_writer_t *writer, const char *text) {
    if (!writer || !text) return;
    size_t length = strlen(text);
    if (writer->used + length >= writer->cap) {
        writer->truncated = true;
        return;
    }
    memcpy(writer->buf + writer->used, text, length);
    writer->used += length;
    writer->buf[writer->used] = 0;
}

static void md_printf(md_writer_t *writer, const char *format, ...) {
    char line[512];
    va_list args;
    va_start(args, format);
    int length = vsnprintf(line, sizeof(line), format, args);
    va_end(args);
    if (length < 0) return;
    if ((size_t)length >= sizeof(line)) {
        writer->truncated = true;
        return;
    }
    md_put(writer, line);
}

// front matter 的元数据行去掉引号和换行，避免破坏 YAML。/ Strip quotes and newlines from YAML metadata.
static void cloud_meta_text(const char *source, char *out, size_t cap) {
    size_t used = 0;
    if (!out || !cap) return;
    out[0] = 0;
    for (const char *p = source; p && *p && used + 1 < cap; ++p) {
        unsigned char ch = (unsigned char)*p;
        out[used++] = ch < 0x20 || ch == '"' ? (char)'\'' : *p;
    }
    out[used] = 0;
}

static void cloud_safe_name(const char *source, char *out, size_t cap) {
    size_t used = 0;
    if (!out || !cap) return;
    out[0] = 0;
    for (const char *p = source; p && *p && used + 1 < cap && used < 72;) {
        unsigned char lead = (unsigned char)*p;
        size_t bytes = lead < 0x80 ? 1 : lead < 0xe0 ? 2 : lead < 0xf0 ? 3 : 4;
        if (bytes > strlen(p)) break;
        if (lead < 0x20 || lead == 0x7f) { ++p; continue; }
        if (bytes == 1 && strchr("/\\:*?\"<>|", (char)lead)) {
            out[used++] = '_';
        } else {
            memcpy(out + used, p, bytes);
            used += bytes;
        }
        p += bytes;
    }
    while (used && (out[used - 1] == ' ' || out[used - 1] == '.')) out[--used] = 0;
    out[used] = 0;
    if (!used) snprintf(out, cap, "book");
}

// 按 UTF-8 字符换行；返回下一个可用的 y。/ Wrap by UTF-8 characters and return the next free y.
static int cloud_wrap(uint8_t *fb, int x, int y, int px, int line_height, int width,
                      const char *text, int max_lines) {
    if (!text || !text[0] || max_lines <= 0) return y;
    char line[192];
    size_t used = 0;
    int row = 0;
    const char *p = text;
    line[0] = 0;
    while (*p && row < max_lines) {
        unsigned char lead = (unsigned char)*p;
        size_t bytes = lead < 0x80 ? 1 : lead < 0xe0 ? 2 : lead < 0xf0 ? 3 : 4;
        size_t remain = strlen(p);
        if (bytes > remain) bytes = remain;
        if (used + bytes + 1 > sizeof(line)) { p += bytes; continue; }
        memcpy(line + used, p, bytes);
        used += bytes;
        line[used] = 0;
        if (used > bytes && ui_text_fixed_width_px(ui_text_effective_px(px), line) > width) {
            line[used - bytes] = 0;
            ui_text(fb, x, y + row * line_height, px, line, EPD_DRAW_ALIGN_LEFT, false);
            ++row;
            used = 0;
            line[0] = 0;
            continue;
        }
        p += bytes;
    }
    if (used && row < max_lines) {
        if (*p && row == max_lines - 1) {
            size_t trim = strlen(line);
            while (trim && (trim + 4 > sizeof(line) ||
                            ui_text_fixed_width_px(ui_text_effective_px(px), line) > width - 24)) {
                do { --trim; } while (trim && ((unsigned char)line[trim] & 0xc0) == 0x80);
                line[trim] = 0;
                if (!trim) break;
            }
            size_t length = strlen(line);
            if (length + 4 < sizeof(line)) memcpy(line + length, "…", 4);
        }
        ui_text(fb, x, y + row * line_height, px, line, EPD_DRAW_ALIGN_LEFT, false);
        ++row;
    }
    return y + row * line_height;
}

/* ================= 界面公共部件 / Shared UI pieces ================= */

// 后段函数的前向声明（分段维护定义顺序）。/ Declarations for functions defined in the later sections.
static app_redraw_t cloud_export_open(void);

static bool cloud_busy(void) { return s_joinable || s_start_pending != CLOUD_JOB_NONE; }

static app_redraw_t cloud_paint(EpdRect area, bool gl16) {
    if (area.width <= 0 || area.height <= 0) return APP_REDRAW_NONE;
    s_paint_area = area;
    s_paint_gl16 = gl16;
    s_paint_settle = false;
    return APP_REDRAW_AREA;
}

static void cloud_header(uint8_t *fb, const char *title) {
    ui_nav_status(fb);
    ui_nav_back(fb, 36, 79);
    ui_text_vc(fb, 342, 107, 34, title, EPD_DRAW_ALIGN_CENTER, false);
    ui_hairline(fb, 174, 36, 612, UI_GRAY_LIGHT);
}

static EpdRect cloud_progress_rect(void) { return (EpdRect){40, 316, 604, 224}; }

static EpdRect cloud_field_rect(int field) {
    static const EpdRect rects[3] = {{36, 236, 612, 72}, {36, 348, 612, 72}, {36, 460, 612, 72}};
    return field >= 0 && field < 3 ? rects[field] : (EpdRect){0};
}

static EpdRect cloud_crumb_rect(void) { return (EpdRect){36, 186, 612, 54}; }

static int cloud_entry_pages(void) {
    int pages = ((int)s_entry_count + CLOUD_LIST_ROWS - 1) / CLOUD_LIST_ROWS;
    return pages > 0 ? pages : 1;
}

static void cloud_entry_clamp(void) {
    if (s_entry_page < 0) s_entry_page = 0;
    if (s_entry_page >= cloud_entry_pages()) s_entry_page = cloud_entry_pages() - 1;
}

static int cloud_book_pages(void) {
    int pages = ((int)s_book_count + CLOUD_BOOK_ROWS - 1) / CLOUD_BOOK_ROWS;
    return pages > 0 ? pages : 1;
}

static void cloud_book_clamp(void) {
    if (s_book_page < 0) s_book_page = 0;
    if (s_book_page >= cloud_book_pages()) s_book_page = cloud_book_pages() - 1;
}

// 按钮 id 按视图分配：1-3 配置、11-14 浏览/覆盖、21 传输、31-33 导出。
// Button ids by view: 1-3 config, 11-14 browse/overwrite, 21 transfer, 31-33 export.
static EpdRect cloud_button_rect(int id) {
    if (s_view == CLOUD_VIEW_CONFIG) {
        if (id == 1) return (EpdRect){36, 578, 296, 76};
        if (id == 2) return (EpdRect){352, 578, 296, 76};
        if (id == 3) return (EpdRect){36, 668, 612, 76};
        // 新增：阅读进度同步独立一行，不改动现有三个按钮的位置与命中区。
        // New: reading-progress sync gets its own row, leaving the three existing buttons untouched.
        if (id == 4) return (EpdRect){36, 754, 612, 76};
    } else if (s_view == CLOUD_VIEW_PROGRESS) {
        if (id == 41) return (EpdRect){36, 186, 296, 64};
        if (id == 42) return (EpdRect){352, 186, 296, 64};
    } else if (s_view == CLOUD_VIEW_BROWSE) {
        if (id == 11) return (EpdRect){36, 258, 296, 64};
        if (id == 12) return (EpdRect){352, 258, 296, 64};
        if (s_confirm_overwrite && id == 13) return (EpdRect){84, 630, 240, 76};
        if (s_confirm_overwrite && id == 14) return (EpdRect){360, 630, 240, 76};
    } else if (s_view == CLOUD_VIEW_TRANSFER) {
        if (id == 21) return (EpdRect){36, 620, 612, 84};
    } else if (s_view == CLOUD_VIEW_EXPORT) {
        if (id == 31) return (EpdRect){36, 186, 296, 64};
        if (id == 32) return (EpdRect){352, 186, 296, 64};
        if (id == 33) return (EpdRect){36, 1064, 612, 76};
    }
    return (EpdRect){0};
}

static int cloud_button_hit(uint16_t x, uint16_t y) {
    for (int id = 1; id <= 42; ++id) {
        EpdRect rect = cloud_button_rect(id);
        if (rect.width > 0 && ui_rect_hit(rect, x, y)) return id;
    }
    return -1;
}

static void cloud_draw_button(uint8_t *fb, int id) {
    EpdRect rect = cloud_button_rect(id);
    if (rect.width <= 0) return;
    const char *label = "确定";
    bool primary = false;
    switch (id) {
        case 1: label = "保存"; break;
        case 2: label = "测试连接"; break;
        case 3: label = "浏览云盘"; primary = true; break;
        case 4: label = cloud_busy() ? "同步中…" : "同步阅读进度"; primary = true; break;
        case 41: label = cloud_busy() ? "取消" : "立即同步"; primary = true; break;
        case 42: label = "返回目录"; break;
        case 11: label = "刷新"; break;
        case 12: label = "导出笔记"; break;
        case 13: label = "覆盖下载"; primary = true; break;
        case 14: label = "取消"; break;
        case 21: label = cloud_busy() ? "取消" : "返回目录"; break;
        case 31: label = "刷新"; break;
        case 32: label = "返回目录"; break;
        case 33: label = "导出所选"; primary = true; break;
        default: return;
    }
    if (primary) {
        ui_fill_round_rect(fb, rect, UI_BTN_RADIUS, s_pressed == id ? 0x60 : 0x30);
        ui_text_vc(fb, rect.x + rect.width / 2, rect.y + rect.height / 2, UI_PX_BTN, label,
                   EPD_DRAW_ALIGN_CENTER, true);
    } else {
        if (s_pressed == id) ui_draw_pressed_round_rect(fb, rect, UI_BTN_RADIUS);
        ui_draw_button(fb, rect, label, false);
    }
}

static app_redraw_t cloud_button_feedback(app_ctx_t *ctx, int id) {
    EpdRect rect = cloud_button_rect(id);
    if (rect.width <= 0) return APP_REDRAW_NONE;
    ui_clear_rect_fast(ctx->fb, rect);
    cloud_draw_button(ctx->fb, id);
    return cloud_paint(rect, true);
}

static bool cloud_back_hit(uint16_t x, uint16_t y) { return x < 140 && y < 160; }

static app_redraw_t cloud_request_leave(app_ctx_t *ctx) {
    cloud_job_cancel();
    ui_keyboard_end();
    s_field = -1;
    ctx->request_return = true;
    return APP_REDRAW_NONE;
}

// 键盘只重画输入框、拼音组字与键盘；布局切换用 GL16，普通输入用 DU。
// The keyboard repaints only the field, composition and keys; layout switches use GL16, typing uses DU.
static app_redraw_t cloud_keyboard_paint(app_ctx_t *ctx, bool force_field) {
    if (s_field < 0) return APP_REDRAW_NONE;
    ui_keyboard_update_t update = ui_keyboard_update(
        ctx->fb, UI_SYSTEM_KEYBOARD_TOP, cloud_field_rect(s_field), CLOUD_FIELD_PX,
        s_field == 1, NULL, force_field);
    if (update.area.width <= 0) return APP_REDRAW_NONE;
    s_paint_area = update.area;
    s_paint_gl16 = update.layout;
    s_paint_settle = update.settle;
    return APP_REDRAW_AREA;
}

/* ================= 账号配置 / Account setup ================= */

static void cloud_config_load(void) {
    memset(&s_config, 0, sizeof(s_config));
    (void)app_settings_cloud_get(&s_config);
    ui_text_edit_init(&s_edit_user, s_config.user, sizeof(s_config.user));
    ui_text_edit_init(&s_edit_pass, s_config.password, sizeof(s_config.password));
    ui_text_edit_init(&s_edit_dir, s_config.folder, sizeof(s_config.folder));
}

static void cloud_field_begin(int field) {
    ui_keyboard_end();
    s_field = field >= 0 && field < 3 ? field : -1;
    if (s_field < 0) return;
    s_edit_active = s_field == 0 ? &s_edit_user : s_field == 1 ? &s_edit_pass : &s_edit_dir;
    // 账号与应用密码只用英文键盘；目录允许拼音。/ Account and app password use ASCII; the folder may use Pinyin.
    ui_keyboard_begin(s_edit_active, s_field != 2);
}

static void cloud_field_end(void) {
    ui_keyboard_end();
    s_field = -1;
}

static bool cloud_config_dirty(void) {
    app_cloud_config_t saved;
    memset(&saved, 0, sizeof(saved));
    (void)app_settings_cloud_get(&saved);
    return strcmp(saved.user, s_config.user) || strcmp(saved.password, s_config.password) ||
           strcmp(saved.folder, s_config.folder);
}

static app_redraw_t cloud_config_save(void) {
    if (!s_config.user[0] || !s_config.password[0]) {
        snprintf(s_notice, sizeof(s_notice), "账号和应用密码不能为空");
        return APP_REDRAW_PAGE;
    }
    esp_err_t err = app_settings_cloud_set(&s_config);
    if (err == ESP_OK) {
        cloud_config_load();
        snprintf(s_notice, sizeof(s_notice), "已保存，可以测试连接或浏览云盘");
    } else if (err == ESP_ERR_INVALID_SIZE) {
        snprintf(s_notice, sizeof(s_notice), "内容过长，请缩短后重试");
    } else {
        snprintf(s_notice, sizeof(s_notice), "保存失败，请检查设置存储空间");
    }
    return APP_REDRAW_PAGE;
}

static app_redraw_t cloud_config_test(void) {
    if (!s_config.user[0] || !s_config.password[0]) {
        snprintf(s_notice, sizeof(s_notice), "请先填写账号和应用密码");
        return APP_REDRAW_PAGE;
    }
    s_notice[0] = 0;
    memset(&s_ui, 0, sizeof(s_ui));
    snprintf(s_ui.message, sizeof(s_ui.message), "正在测试连接…");
    s_start_pending = CLOUD_JOB_TEST;
    return APP_REDRAW_PAGE;
}

static app_redraw_t cloud_config_browse(void) {
    if (!app_settings_cloud_configured()) {
        snprintf(s_notice, sizeof(s_notice), "请先保存账号和应用密码");
        return APP_REDRAW_PAGE;
    }
    if (cloud_config_dirty()) {
        snprintf(s_notice, sizeof(s_notice), "配置有修改，请先点「保存」");
        return APP_REDRAW_PAGE;
    }
    cloud_config_load();
    cloud_browse_open();
    return APP_REDRAW_PAGE;
}

/* ================= 阅读进度同步 / Reading-progress sync ================= */

// 进入进度页：只读本机记录数与上次同步时间，真正联网在「立即同步」之后。
// Open the progress page: read the local record count and last-sync time; networking starts only
// when the user presses "立即同步".
static app_redraw_t cloud_progress_open(void) {
    if (!app_settings_cloud_configured()) {
        snprintf(s_notice, sizeof(s_notice), "请先保存账号和应用密码");
        return APP_REDRAW_PAGE;
    }
    if (cloud_config_dirty()) {
        snprintf(s_notice, sizeof(s_notice), "配置有修改，请先点「保存」");
        return APP_REDRAW_PAGE;
    }
    s_view = CLOUD_VIEW_PROGRESS;
    s_notice[0] = 0;
    memset(&s_ui, 0, sizeof(s_ui));
    s_progress_local = 0;
    (void)book_progress_sync_local_count(&s_progress_local);
    s_progress_last = book_progress_sync_last_time();
    return APP_REDRAW_PAGE;
}

static void cloud_progress_start(void) {
    memset(&s_ui, 0, sizeof(s_ui));
    snprintf(s_ui.message, sizeof(s_ui.message), "正在同步阅读进度…");
    s_notice[0] = 0;
    s_start_pending = CLOUD_JOB_PROGRESS;
}

static void cloud_draw_progress(uint8_t *fb) {
    cloud_header(fb, "同步阅读进度");
    cloud_draw_button(fb, 41);
    cloud_draw_button(fb, 42);
    EpdRect card = {36, 300, 612, 420};
    ui_fill_round_rect(fb, card, 24, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, card, 24, 0x70);
    char line[CLOUD_MESSAGE_MAX];
    snprintf(line, sizeof(line), "本机阅读进度：%u 本", (unsigned)s_progress_local);
    ui_text_fixed(fb, 60, 344, 24, line, EPD_DRAW_ALIGN_LEFT, false);
    char when[64];
    cloud_format_time(s_progress_last, when, sizeof(when));
    if (when[0]) snprintf(line, sizeof(line), "上次同步：%s", when);
    else snprintf(line, sizeof(line), "上次同步：尚未同步");
    ui_text_fixed(fb, 60, 392, 20, line, EPD_DRAW_ALIGN_LEFT, false);
    ui_text_fixed(fb, 60, 432, 19, "云端文件：" BOOK_PROGRESS_SYNC_FILE, EPD_DRAW_ALIGN_LEFT, false);
    if (cloud_busy()) {
        const char *message = s_ui.message[0] ? s_ui.message : "正在同步阅读进度…";
        cloud_wrap(fb, 60, 490, 20, 28, 560, message, 2);
    } else {
        cloud_wrap(fb, 60, 490, 19, 26, 560,
                   "按书籍逐本比较；两边都改过的书保留本机进度。只同步章节、页内位置、字号与百分比，"
                   "不含书中文字。", 2);
        if (s_ui.message[0]) cloud_wrap(fb, 60, 620, 20, 28, 560, s_ui.message, 3);
        else if (s_notice[0]) cloud_wrap(fb, 60, 620, 20, 28, 560, s_notice, 3);
    }
    if (!cloud_busy() && !s_progress_local && !s_ui.message[0])
        cloud_wrap(fb, 60, 700, 18, 24, 560,
                   "本机还没有阅读进度，可点「立即同步」从云端恢复（需要书架上有同名同大小的书）。", 2);
    const book_progress_sync_result_t *stats = &s_ui.progress;
    if (!cloud_busy() && (stats->uploaded || stats->applied_ok || stats->conflicts ||
                          stats->removed || stats->remote_only || stats->stale)) {
        char detail[CLOUD_MESSAGE_MAX];
        snprintf(detail, sizeof(detail),
                 "上传 %u · 恢复 %u · 冲突 %u · 删除 %u · 仅云端 %u · 大小不符 %u · 无变化 %u",
                 (unsigned)stats->uploaded, (unsigned)stats->applied_ok,
                 (unsigned)stats->conflicts, (unsigned)stats->removed,
                 (unsigned)stats->remote_only, (unsigned)stats->stale,
                 (unsigned)stats->unchanged);
        cloud_wrap(fb, 36, 760, 18, 26, 612, detail, 2);
        if (!stats->meta_saved)
            cloud_wrap(fb, 36, 820, 18, 26, 612, "同步快照保存失败，下次可能重复合并。", 1);
    }
    ui_text_fixed(fb, 36, 1050, 18, "进度只含位置信息，不含书籍内容。", EPD_DRAW_ALIGN_LEFT, false);
    ui_text_fixed(fb, 36, 1082, 18, "两台设备请避免同时点同步。", EPD_DRAW_ALIGN_LEFT, false);
}

static app_redraw_t cloud_progress_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type == UI_GESTURE_PRESS) {
        int id = cloud_button_hit(ev->x0, ev->y0);
        if (id < 0) return APP_REDRAW_NONE;
        s_pressed = id;
        return cloud_button_feedback(ctx, id);
    }
    int old = s_pressed;
    s_pressed = -1;
    if (ev->type == UI_GESTURE_TAP) {
        int x = ev->x0, y = ev->y0;
        if (cloud_back_hit(x, y)) return cloud_request_leave(ctx);
        int id = cloud_button_hit(x, y);
        if (id == 41) {
            if (cloud_busy()) {
                cloud_job_cancel();
                snprintf(s_notice, sizeof(s_notice), "正在取消…");
            } else {
                cloud_progress_start();
            }
            return APP_REDRAW_PAGE;
        }
        if (id == 42 && !cloud_busy()) {
            cloud_browse_open();
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (old >= 0) return cloud_button_feedback(ctx, old);
    return APP_REDRAW_NONE;
}

static void cloud_draw_config(uint8_t *fb) {
    cloud_header(fb, "坚果云同步");
    char line[CLOUD_MESSAGE_MAX];
    snprintf(line, sizeof(line), "服务器  %.128s", webdav_base());
    cloud_fit_fixed(line, 19, 612);
    ui_text_fixed(fb, 36, 188, 19, line, EPD_DRAW_ALIGN_LEFT, false);
    static const char *const labels[3] = {
        "账号（坚果云登录邮箱）",
        "应用密码（网页端「安全选项」添加）",
        "同步文件夹（留空表示服务器根目录）",
    };
    for (int field = 0; field < 3; ++field) {
        EpdRect rect = cloud_field_rect(field);
        ui_text_fixed(fb, 42, rect.y - 24, 19, labels[field], EPD_DRAW_ALIGN_LEFT, false);
        ui_text_input_draw(fb, field == 0 ? &s_edit_user : field == 1 ? &s_edit_pass : &s_edit_dir,
                           rect, CLOUD_FIELD_PX, field == 1, NULL);
    }
    if (s_field >= 0) {
        ui_keyboard_draw(fb, UI_SYSTEM_KEYBOARD_TOP);
        return;
    }
    char state[CLOUD_MESSAGE_MAX];
    if (app_settings_cloud_configured())
        snprintf(state, sizeof(state), "已保存账号：%s", s_config.user);
    else
        snprintf(state, sizeof(state), "尚未保存账号，填写后点「保存」");
    cloud_fit_fixed(state, 18, 612);
    ui_text_fixed(fb, 36, 544, 18, state, EPD_DRAW_ALIGN_LEFT, false);
    for (int id = 1; id <= 4; ++id) cloud_draw_button(fb, id);
    const char *notice = s_notice;
    if (cloud_busy()) notice = s_ui.message[0] ? s_ui.message : "正在同步阅读进度…";
    if (notice[0]) cloud_wrap(fb, 36, 850, 20, 28, 612, notice, 3);
    static const char *const hints[] = {
        "应用密码在坚果云网页「账户信息 → 安全选项 → 添加应用密码」生成。",
        "下载的书籍保存到书架「云同步」目录，并自动出现在书架分类中。",
        "导出的笔记是 Obsidian 可读的 Markdown，会上传到同步文件夹。",
        "同步阅读进度：在同步文件夹写 " BOOK_PROGRESS_SYNC_FILE "，换设备后点一次即可合并续读位置。",
    };
    for (int i = 0; i < 4; ++i)
        ui_text_fixed(fb, 36, 960 + i * 30, 18, hints[i], EPD_DRAW_ALIGN_LEFT, false);
}

static app_redraw_t cloud_config_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type == UI_GESTURE_PRESS) {
        if (cloud_busy()) return APP_REDRAW_NONE;
        int id = cloud_button_hit(ev->x0, ev->y0);
        if (id < 0) return APP_REDRAW_NONE;
        s_pressed = id;
        return cloud_button_feedback(ctx, id);
    }
    int old = s_pressed;
    s_pressed = -1;
    if (ev->type == UI_GESTURE_TAP) {
        int x = ev->x0, y = ev->y0;
        if (cloud_back_hit(x, y)) return cloud_request_leave(ctx);
        if (!cloud_busy()) {
            for (int field = 0; field < 3; ++field) {
                if (ui_rect_hit(cloud_field_rect(field), x, y)) {
                    cloud_field_begin(field);
                    return APP_REDRAW_PAGE;
                }
            }
            int id = cloud_button_hit(x, y);
            if (id == 1) return cloud_config_save();
            if (id == 2) return cloud_config_test();
            if (id == 3) return cloud_config_browse();
            if (id == 4) return cloud_progress_open();
        }
    }
    if (old >= 0) return cloud_button_feedback(ctx, old);
    return APP_REDRAW_NONE;
}

static app_redraw_t cloud_keyboard_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type == UI_GESTURE_PRESS) {
        return ui_keyboard_press(ev->x0, ev->y0, UI_SYSTEM_KEYBOARD_TOP, ctx->now_ms)
                   ? cloud_keyboard_paint(ctx, false)
                   : APP_REDRAW_NONE;
    }
    bool feedback = ev->type != UI_GESTURE_LONG_PRESS && ui_keyboard_release();
    if (ev->type == UI_GESTURE_SWIPE_L || ev->type == UI_GESTURE_SWIPE_R) {
        bool page = ui_keyboard_page(ev->type == UI_GESTURE_SWIPE_L ? 1 : -1);
        return page || feedback ? cloud_keyboard_paint(ctx, false) : APP_REDRAW_NONE;
    }
    if (ev->type != UI_GESTURE_TAP) return feedback ? cloud_keyboard_paint(ctx, false) : APP_REDRAW_NONE;
    int x = ev->x0, y = ev->y0;
    if (cloud_back_hit(x, y)) return cloud_request_leave(ctx);
    for (int field = 0; field < 3; ++field) {
        if (field != s_field) {
            if (ui_rect_hit(cloud_field_rect(field), x, y)) {
                cloud_field_begin(field);
                return APP_REDRAW_PAGE;
            }
            continue;
        }
        ui_text_edit_t *edit = field == 0 ? &s_edit_user : field == 1 ? &s_edit_pass : &s_edit_dir;
        if (ui_text_input_tap(edit, cloud_field_rect(field), CLOUD_FIELD_PX, field == 1, NULL, x, y))
            return cloud_keyboard_paint(ctx, true);
    }
    ui_keyboard_result_t result = ui_keyboard_tap(x, y, UI_SYSTEM_KEYBOARD_TOP, ctx->now_ms);
    if (result == UI_KEYBOARD_CHANGED) return cloud_keyboard_paint(ctx, false);
    if (result == UI_KEYBOARD_DONE) {
        cloud_field_end();
        return APP_REDRAW_PAGE;
    }
    return feedback ? cloud_keyboard_paint(ctx, false) : APP_REDRAW_NONE;
}

/* ================= 目录浏览 / Remote browsing ================= */

// 服务器根 = webdav_base() 的路径前缀 + 设置里的相对文件夹；与 entry->href 同形，可直接 list。
// Server root = the base path prefix plus the configured relative folder, shaped like entry->href.
static bool cloud_remote_root(char *out, size_t cap) {
    if (!out || cap < 2) return false;
    const char *base = webdav_base();
    char prefix[WEBDAV_BASE_MAX] = {0};
    if (base) {
        const char *host = !strncmp(base, "https://", 8) ? base + 8
                         : !strncmp(base, "http://", 7) ? base + 7 : base;
        const char *slash = strchr(host, '/');
        if (slash) {
            size_t length = strlen(slash);
            while (length > 1 && slash[length - 1] == '/') --length;
            if (length >= sizeof(prefix)) length = sizeof(prefix) - 1;
            memcpy(prefix, slash, length);
            prefix[length] = 0;
        }
    }
    app_cloud_config_t saved;
    memset(&saved, 0, sizeof(saved));
    (void)app_settings_cloud_get(&saved);
    cloud_copy(out, cap, prefix);
    size_t used = strlen(out);
    const char *folder = saved.folder;
    while (folder[0] == '/') ++folder;
    if (folder[0]) {
        if (used + 1 < cap) out[used++] = '/';
        cloud_copy(out + used, cap - used, folder);
    } else if (!used) {
        cloud_copy(out, cap, "/");
    }
    return out[0] == '/';
}

static void cloud_browse_open(void) {
    if (!cloud_remote_root(s_root_dir, sizeof(s_root_dir))) {
        snprintf(s_notice, sizeof(s_notice), "同步文件夹路径无效，请检查设置");
        s_view = CLOUD_VIEW_CONFIG;
        return;
    }
    snprintf(s_remote_dir, sizeof(s_remote_dir), "%s", s_root_dir);
    s_entry_count = s_entry_hidden = 0;
    s_entry_page = 0;
    s_confirm_overwrite = false;
    s_notice[0] = 0;
    memset(&s_ui, 0, sizeof(s_ui));
    snprintf(s_ui.message, sizeof(s_ui.message), "正在读取目录…");
    s_view = CLOUD_VIEW_BROWSE;
    s_start_pending = CLOUD_JOB_LIST;
}

static app_redraw_t cloud_browse_up(void) {
    if (!strcmp(s_remote_dir, s_root_dir)) return APP_REDRAW_NONE;
    char parent[WEBDAV_PATH_MAX];
    if (webdav_parent(s_remote_dir, parent, sizeof(parent)) != ESP_OK) return APP_REDRAW_NONE;
    if (!strcmp(parent, s_remote_dir)) return APP_REDRAW_NONE;
    if (!cloud_path_below(parent, s_root_dir)) snprintf(parent, sizeof(parent), "%s", s_root_dir);
    snprintf(s_remote_dir, sizeof(s_remote_dir), "%s", parent);
    s_entry_count = s_entry_hidden = 0;
    s_entry_page = 0;
    s_notice[0] = 0;
    memset(&s_ui, 0, sizeof(s_ui));
    snprintf(s_ui.message, sizeof(s_ui.message), "正在读取目录…");
    s_start_pending = CLOUD_JOB_LIST;
    return APP_REDRAW_PAGE;
}

static app_redraw_t cloud_transfer_begin(void) {
    s_upload = false;
    s_job_remove_local = false;
    s_confirm_overwrite = false;
    s_view = CLOUD_VIEW_TRANSFER;
    s_start_pending = CLOUD_JOB_DOWNLOAD;
    memset(&s_ui, 0, sizeof(s_ui));
    snprintf(s_ui.message, sizeof(s_ui.message), "正在准备下载…");
    return APP_REDRAW_PAGE;
}

static app_redraw_t cloud_download_begin(const webdav_entry_t *entry) {
    if (!entry) return APP_REDRAW_NONE;
    book_store_root_t root;
    memset(&root, 0, sizeof(root));
    if (book_store_upload_root(&root) != ESP_OK) {
        snprintf(s_notice, sizeof(s_notice), "书架存储不可用，请插入 TF 卡");
        return APP_REDRAW_PAGE;
    }
    size_t limit = book_store_file_limit(&root);
    if (limit != SIZE_MAX && (size_t)entry->size > limit) {
        snprintf(s_notice, sizeof(s_notice), "内置存储单文件上限 1 MB，请插入 TF 卡");
        return APP_REDRAW_PAGE;
    }
    char directory[CLOUD_FILE_MAX];
    if (snprintf(directory, sizeof(directory), "%s/云同步", root.path) >= (int)sizeof(directory)) {
        snprintf(s_notice, sizeof(s_notice), "目录路径过长");
        return APP_REDRAW_PAGE;
    }
    struct stat state;
    if (stat(directory, &state) != 0 || !S_ISDIR(state.st_mode)) (void)mkdir(directory, 0775);
    if (stat(directory, &state) != 0 || !S_ISDIR(state.st_mode)) {
        snprintf(s_notice, sizeof(s_notice), "无法创建「云同步」目录，请检查存储卡");
        return APP_REDRAW_PAGE;
    }
    uint64_t free_bytes = book_store_free_bytes(&root);
    if (entry->size && free_bytes < entry->size) {
        snprintf(s_notice, sizeof(s_notice), "存储空间不足，请清理后重试");
        return APP_REDRAW_PAGE;
    }
    if (snprintf(s_job_local, sizeof(s_job_local), "%s/%s", directory, entry->name) >=
            (int)sizeof(s_job_local) ||
        strlen(s_job_local) >= CLOUD_LOCAL_LIMIT) {
        snprintf(s_notice, sizeof(s_notice), "文件名或路径过长，请重命名后重试");
        return APP_REDRAW_PAGE;
    }
    if (strlen(entry->href) >= sizeof(s_job_remote)) {
        snprintf(s_notice, sizeof(s_notice), "远程路径过长");
        return APP_REDRAW_PAGE;
    }
    snprintf(s_job_remote, sizeof(s_job_remote), "%s", entry->href);
    snprintf(s_job_name, sizeof(s_job_name), "%s", entry->name);
    if (stat(s_job_local, &state) == 0) {
        s_confirm_overwrite = true;
        s_confirm_size = entry->size;
        snprintf(s_confirm_name, sizeof(s_confirm_name), "%s", entry->name);
        return APP_REDRAW_PAGE;
    }
    return cloud_transfer_begin();
}

static app_redraw_t cloud_browse_row(size_t index) {
    if (index >= s_entry_count) return APP_REDRAW_NONE;
    const webdav_entry_t *entry = &s_entries[index];
    if (!entry->is_dir) return cloud_download_begin(entry);
    if (strlen(entry->href) >= sizeof(s_remote_dir)) {
        snprintf(s_notice, sizeof(s_notice), "目录路径过长");
        return APP_REDRAW_PAGE;
    }
    snprintf(s_remote_dir, sizeof(s_remote_dir), "%s", entry->href);
    s_entry_count = s_entry_hidden = 0;
    s_entry_page = 0;
    memset(&s_ui, 0, sizeof(s_ui));
    snprintf(s_ui.message, sizeof(s_ui.message), "正在读取目录…");
    s_start_pending = CLOUD_JOB_LIST;
    return APP_REDRAW_PAGE;
}

static void cloud_draw_browse(uint8_t *fb) {
    cloud_header(fb, "同步目录");
    EpdRect crumb = cloud_crumb_rect();
    ui_fill_round_rect(fb, crumb, 12, 0xe8);
    ui_draw_control_frame(fb, crumb, 12, 0x60);
    char relative[WEBDAV_PATH_MAX];
    cloud_relative(s_remote_dir, relative, sizeof(relative));
    cloud_fit_text(relative, 22, 520);
    ui_text_vc(fb, 54, crumb.y + crumb.height / 2, 22, relative, EPD_DRAW_ALIGN_LEFT, false);
    ui_draw_icon(fb, 626, crumb.y + crumb.height / 2, 24, UI_ICON_CHEVRON_UP, 0x40);
    cloud_draw_button(fb, 11);
    cloud_draw_button(fb, 12);
    char summary[64];
    snprintf(summary, sizeof(summary), "文件 · %u 项%s", (unsigned)s_entry_count,
             cloud_busy() ? " · 读取中" : "");
    ui_text_fixed(fb, 36, 336, 19, summary, EPD_DRAW_ALIGN_LEFT, false);
    EpdRect list = {36, CLOUD_LIST_TOP, 612, CLOUD_LIST_ROWS * CLOUD_LIST_ROW_H};
    ui_fill_round_rect(fb, list, 22, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, list, 22, 0x70);
    if (cloud_busy()) {
        cloud_wrap(fb, 60, 500, 22, 30, 560,
                   s_ui.message[0] ? s_ui.message : "正在读取目录…", 2);
    } else if (!s_entry_count) {
        ui_text_vc(fb, 342, 500, 24, "此目录没有可下载的文件", EPD_DRAW_ALIGN_CENTER, false);
        ui_text_vc(fb, 342, 542, 19, "仅显示子目录与 MD/TXT/EPUB 文件", EPD_DRAW_ALIGN_CENTER, false);
    }
    for (int row = 0; row < CLOUD_LIST_ROWS; ++row) {
        size_t index = (size_t)s_entry_page * CLOUD_LIST_ROWS + (size_t)row;
        if (index >= s_entry_count) break;
        const webdav_entry_t *entry = &s_entries[index];
        int y = CLOUD_LIST_TOP + row * CLOUD_LIST_ROW_H;
        if (row) ui_hairline(fb, y, 94, 554, 0xc0);
        ui_draw_icon(fb, 62, y + CLOUD_LIST_ROW_H / 2, 28,
                     entry->is_dir ? UI_ICON_FOLDER : UI_ICON_FILE, 0x20);
        char name[WEBDAV_NAME_MAX];
        snprintf(name, sizeof(name), "%s", entry->name);
        cloud_fit_fixed(name, 23, 450);
        ui_text_fixed(fb, 94, y + 8, 23, name, EPD_DRAW_ALIGN_LEFT, false);
        char detail[112];
        if (entry->is_dir) {
            snprintf(detail, sizeof(detail), "文件夹");
            ui_text_fixed(fb, 94, y + 50, 17, detail, EPD_DRAW_ALIGN_LEFT, false);
            ui_text_fixed_vc(fb, 648, y + 43, 26, "›", EPD_DRAW_ALIGN_RIGHT, false);
        } else {
            char size[24], when[24], extension[8];
            cloud_format_size(entry->size, size, sizeof(size));
            cloud_format_time(entry->modified, when, sizeof(when));
            cloud_extension(entry->name, extension, sizeof(extension));
            snprintf(detail, sizeof(detail), "%s · %s%s%s", extension, size,
                     when[0] ? " · " : "", when);
            cloud_fit_fixed(detail, 17, 470);
            ui_text_fixed(fb, 94, y + 50, 17, detail, EPD_DRAW_ALIGN_LEFT, false);
            ui_draw_icon(fb, 628, y + CLOUD_LIST_ROW_H / 2, 26, UI_ICON_DOWNLOAD, 0x30);
        }
    }
    char pager[32];
    snprintf(pager, sizeof(pager), "%u/%u", (unsigned)(s_entry_page + 1),
             (unsigned)cloud_entry_pages());
    ui_pager_draw(fb, pager, s_entry_page, cloud_entry_pages(), false, UI_PAGER_NONE);
    if (s_notice[0]) cloud_wrap(fb, 36, 1072, 19, 26, 612, s_notice, 2);
    if (s_entry_hidden) {
        char hidden[64];
        snprintf(hidden, sizeof(hidden), "已隐藏 %u 个不支持的文件", (unsigned)s_entry_hidden);
        ui_text_fixed(fb, 36, 1136, 17, hidden, EPD_DRAW_ALIGN_LEFT, false);
    }
    cloud_draw_confirm(fb);
}

static void cloud_draw_confirm(uint8_t *fb) {
    if (!s_confirm_overwrite) return;
    EpdRect card = {54, 380, 576, 360};
    ui_fill_round_rect(fb, card, 24, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, card, 24, 0x50);
    ui_text_vc(fb, 342, 424, 30, "文件已存在", EPD_DRAW_ALIGN_CENTER, false);
    char name[WEBDAV_NAME_MAX];
    snprintf(name, sizeof(name), "%s", s_confirm_name);
    cloud_fit_text(name, 21, 500);
    ui_text_vc(fb, 342, 474, 21, name, EPD_DRAW_ALIGN_CENTER, false);
    char size[24], detail[96];
    cloud_format_size(s_confirm_size, size, sizeof(size));
    snprintf(detail, sizeof(detail), "继续下载将覆盖同名文件（%s）", size);
    ui_text_vc(fb, 342, 522, 19, detail, EPD_DRAW_ALIGN_CENTER, false);
    cloud_draw_button(fb, 13);
    cloud_draw_button(fb, 14);
}

static app_redraw_t cloud_browse_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (s_confirm_overwrite) {
        if (ev->type == UI_GESTURE_PRESS) {
            int id = cloud_button_hit(ev->x0, ev->y0);
            if (id < 0) return APP_REDRAW_NONE;
            s_pressed = id;
            return cloud_button_feedback(ctx, id);
        }
        int old = s_pressed;
        s_pressed = -1;
        if (ev->type == UI_GESTURE_TAP) {
            int id = cloud_button_hit(ev->x0, ev->y0);
            if (id == 13) return cloud_transfer_begin();
            if (id == 14) {
                s_confirm_overwrite = false;
                return APP_REDRAW_PAGE;
            }
        }
        if (old >= 0) return cloud_button_feedback(ctx, old);
        return APP_REDRAW_NONE;
    }
    if (ev->type == UI_GESTURE_PRESS) {
        int id = cloud_button_hit(ev->x0, ev->y0);
        if (id < 0) return APP_REDRAW_NONE;
        s_pressed = id;
        return cloud_button_feedback(ctx, id);
    }
    int old = s_pressed;
    s_pressed = -1;
    if (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D) {
        if (cloud_busy()) return APP_REDRAW_NONE;
        int next = s_entry_page + (ev->type == UI_GESTURE_SWIPE_U ? 1 : -1);
        if (next < 0 || next >= cloud_entry_pages()) return APP_REDRAW_NONE;
        s_entry_page = next;
        return APP_REDRAW_PAGE;
    }
    if (ev->type == UI_GESTURE_TAP) {
        int x = ev->x0, y = ev->y0;
        if (cloud_back_hit(x, y)) return cloud_request_leave(ctx);
        if (cloud_busy()) return APP_REDRAW_NONE;
        if (ui_rect_hit(cloud_crumb_rect(), x, y)) return cloud_browse_up();
        int id = cloud_button_hit(x, y);
        if (id == 11) {
            memset(&s_ui, 0, sizeof(s_ui));
            snprintf(s_ui.message, sizeof(s_ui.message), "正在读取目录…");
            s_start_pending = CLOUD_JOB_LIST;
            return APP_REDRAW_PAGE;
        }
        if (id == 12) return cloud_export_open();
        int pager = ui_pager_hit(x, y);
        if (pager != UI_PAGER_NONE) {
            int next = ui_pager_target(pager, s_entry_page, cloud_entry_pages());
            if (next == s_entry_page) return APP_REDRAW_NONE;
            s_entry_page = next;
            return APP_REDRAW_PAGE;
        }
        int row = (y - CLOUD_LIST_TOP) / CLOUD_LIST_ROW_H;
        if (y >= CLOUD_LIST_TOP && row >= 0 && row < CLOUD_LIST_ROWS) {
            size_t index = (size_t)s_entry_page * CLOUD_LIST_ROWS + (size_t)row;
            if (index < s_entry_count) return cloud_browse_row(index);
        }
    }
    if (old >= 0) return cloud_button_feedback(ctx, old);
    return APP_REDRAW_NONE;
}

/* ================= 笔记导出 / Note export ================= */

static bool cloud_export_visit(const char *path, const book_progress_t *progress, void *ctx) {
    (void)progress;
    (void)ctx;
    if (!path || !s_books) return false;
    if (s_book_count >= CLOUD_BOOK_MAX) return false;
    if (!book_highlight_load(path)) {
        book_highlight_unload();
        return true;
    }
    int count = book_highlight_count();
    book_highlight_unload();
    if (count <= 0) return true;
    cloud_book_t *book = &s_books[s_book_count];
    memset(book, 0, sizeof(*book));
    snprintf(book->path, sizeof(book->path), "%s", path);
    (void)book_title_get(path, book->title, sizeof(book->title));
    if (!book->title[0]) (void)book_title_from_path(path, book->title, sizeof(book->title));
    if (!book->title[0]) snprintf(book->title, sizeof(book->title), "未命名");
    book->count = (uint16_t)(count > 0xffff ? 0xffff : count);
    ++s_book_count;
    return true;
}

static int cloud_book_order(const void *left, const void *right) {
    const cloud_book_t *a = left;
    const cloud_book_t *b = right;
    return strcasecmp(a->title, b->title);
}

static void cloud_export_collect(void) {
    s_book_count = 0;
    s_book_page = 0;
    s_book_selected = -1;
    if (!cloud_books_ensure()) {
        snprintf(s_notice, sizeof(s_notice), "内存不足，无法读取笔记列表");
        return;
    }
    esp_err_t err = book_progress_list(cloud_export_visit, NULL);
    if (s_book_count > 1) qsort(s_books, s_book_count, sizeof(cloud_book_t), cloud_book_order);
    cloud_book_clamp();
    if (s_book_count) {
        s_book_selected = 0;
        s_notice[0] = 0;
    } else if (err != ESP_OK) {
        snprintf(s_notice, sizeof(s_notice), "读取阅读记录失败，请重试");
    } else {
        snprintf(s_notice, sizeof(s_notice), "还没有划线或笔记，在阅读页长按正文即可划线");
    }
}

static app_redraw_t cloud_export_open(void) {
    s_view = CLOUD_VIEW_EXPORT;
    s_export_pending = true;
    s_book_count = 0;
    s_book_page = 0;
    s_book_selected = -1;
    s_notice[0] = 0;
    return APP_REDRAW_PAGE;
}

static size_t cloud_export_build(const cloud_book_t *book) {
    if (!s_md || !book) return 0;
    if (!book_highlight_load(book->path)) return 0;
    int count = book_highlight_count();
    if (count <= 0) {
        book_highlight_unload();
        return 0;
    }
    md_writer_t writer = {.buf = s_md, .cap = CLOUD_MD_MAX, .used = 0, .truncated = false};
    s_md[0] = 0;
    char title[96], source[BOOK_STORE_PATH_MAX], device[64], exported[64];
    cloud_meta_text(book->title, title, sizeof(title));
    cloud_meta_text(book->path, source, sizeof(source));
    cloud_meta_text(app_settings_device_name(), device, sizeof(device));
    struct tm local;
    if (cloud_local_tm(&local))
        snprintf(exported, sizeof(exported), "%04d-%02d-%02d %02d:%02d", local.tm_year + 1900,
                 local.tm_mon + 1, local.tm_mday, local.tm_hour, local.tm_min);
    else
        snprintf(exported, sizeof(exported), "未知");
    md_put(&writer, "---\n");
    md_printf(&writer, "source: \"%s\"\n", source);
    md_printf(&writer, "exported: %s\n", exported);
    md_printf(&writer, "device: \"%s\"\n", device);
    md_put(&writer, "---\n\n");
    md_printf(&writer, "# %s 笔记\n\n## 划线\n\n", title);
    static const char *const tags[] = {"", "重要", "待读", "疑问"};
    for (int i = 0; i < count; ++i) {
        uint16_t chapter = 0;
        uint32_t start = 0, end = 0;
        const char *excerpt = NULL;
        if (!book_highlight_at(i, &chapter, &start, &end, &excerpt)) continue;
        (void)start;
        (void)end;
        md_put(&writer, "> ");
        md_put(&writer, excerpt ? excerpt : "");
        md_put(&writer, "\n");
        const char *note = book_highlight_note(i);
        if (note && note[0]) md_printf(&writer, "- 笔记：%s\n", note);
        md_printf(&writer, "- 位置：第%u章", (unsigned)chapter + 1);
        uint8_t tag = book_highlight_tag(i);
        if (tag > 0 && tag < 4) md_printf(&writer, " · 标签：%s", tags[tag]);
        md_put(&writer, "\n\n");
    }
    md_put(&writer, "\n");
    if (writer.truncated) md_put(&writer, "> 笔记过多，本次导出已截断\n");
    book_highlight_unload();
    return writer.used;
}

// 生成 Markdown 临时文件并解析远程路径；真正上传交给后台任务。
// Build the temporary Markdown and resolve the remote path; the worker performs the upload.
static bool cloud_export_prepare(void) {
    if (s_book_selected < 0 || s_book_selected >= (int)s_book_count) {
        snprintf(s_notice, sizeof(s_notice), "请先选择一本书");
        return false;
    }
    const cloud_book_t *book = &s_books[s_book_selected];
    if (!s_md) s_md = heap_caps_malloc(CLOUD_MD_MAX, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!s_md) {
        snprintf(s_notice, sizeof(s_notice), "内存不足，无法生成笔记");
        return false;
    }
    size_t length = cloud_export_build(book);
    if (length == 0) {
        heap_caps_free(s_md);
        s_md = NULL;
        snprintf(s_notice, sizeof(s_notice), "没有可导出的划线或笔记，或文件读取失败");
        return false;
    }
    struct stat state;
    if (stat("/sdcard", &state) != 0 || !S_ISDIR(state.st_mode)) {
        heap_caps_free(s_md);
        s_md = NULL;
        snprintf(s_notice, sizeof(s_notice), "TF 卡不可用，无法生成临时文件");
        return false;
    }
    if (mkdir("/sdcard/.readpico", 0775) != 0 && errno != EEXIST) {
        heap_caps_free(s_md);
        s_md = NULL;
        snprintf(s_notice, sizeof(s_notice), "无法创建临时目录");
        return false;
    }
    char safe[96], date[40] = {0}, clock[24] = {0};
    cloud_safe_name(book->title, safe, sizeof(safe));
    struct tm local;
    if (cloud_local_tm(&local)) {
        snprintf(date, sizeof(date), "%04d%02d%02d", local.tm_year + 1900, local.tm_mon + 1,
                 local.tm_mday);
        snprintf(clock, sizeof(clock), "%02d%02d", local.tm_hour, local.tm_min);
        snprintf(s_job_name, sizeof(s_job_name), "%s-notes-%s-%s.md", safe, date, clock);
    } else {
        snprintf(s_job_name, sizeof(s_job_name), "%s-notes-unknown.md", safe);
    }
    if (snprintf(s_job_local, sizeof(s_job_local), "/sdcard/.readpico/%s", s_job_name) >=
            (int)sizeof(s_job_local) ||
        strlen(s_job_local) >= CLOUD_LOCAL_LIMIT) {
        heap_caps_free(s_md);
        s_md = NULL;
        snprintf(s_notice, sizeof(s_notice), "文件名过长，请缩短书名");
        return false;
    }
    FILE *handle = fopen(s_job_local, "wb");
    if (!handle) {
        heap_caps_free(s_md);
        s_md = NULL;
        snprintf(s_notice, sizeof(s_notice), "无法写入临时文件");
        return false;
    }
    size_t written = fwrite(s_md, 1, length, handle);
    bool close_failed = fclose(handle) != 0;
    heap_caps_free(s_md);
    s_md = NULL;
    if (written != length || close_failed) {
        (void)remove(s_job_local);
        snprintf(s_notice, sizeof(s_notice), "临时文件写入不完整，请重试");
        return false;
    }
    char folder_path[WEBDAV_PATH_MAX] = {0};
    if (!cloud_remote_root(folder_path, sizeof(folder_path))) {
        (void)remove(s_job_local);
        snprintf(s_notice, sizeof(s_notice), "同步文件夹路径无效，请检查设置");
        return false;
    }
    const char *separator = folder_path[strlen(folder_path) - 1] == '/' ? "" : "/";
    char remote[CLOUD_LOCAL_MAX];
    snprintf(remote, sizeof(remote), "%s%s%s", folder_path, separator, s_job_name);
    if (strlen(remote) >= sizeof(s_job_remote)) {
        (void)remove(s_job_local);
        snprintf(s_notice, sizeof(s_notice), "远程路径过长，请缩短书名或文件夹");
        return false;
    }
    cloud_copy(s_job_remote, sizeof(s_job_remote), remote);
    s_upload = true;
    s_view = CLOUD_VIEW_TRANSFER;
    s_job_remove_local = true;
    memset(&s_ui, 0, sizeof(s_ui));
    snprintf(s_ui.message, sizeof(s_ui.message), "正在生成笔记…");
    s_start_pending = CLOUD_JOB_EXPORT;
    return true;
}

static void cloud_draw_export(uint8_t *fb) {
    cloud_header(fb, "导出笔记");
    cloud_draw_button(fb, 31);
    cloud_draw_button(fb, 32);
    ui_text_fixed(fb, 36, 268, 19, "选择一本书，导出划线、笔记与标签为 Obsidian Markdown。",
                  EPD_DRAW_ALIGN_LEFT, false);
    EpdRect list = {36, CLOUD_BOOK_TOP, 612, CLOUD_BOOK_ROWS * CLOUD_BOOK_ROW_H};
    ui_fill_round_rect(fb, list, 22, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, list, 22, 0x70);
    if (s_export_pending) {
        ui_text_vc(fb, 342, 560, 23, "正在收集有笔记的书…", EPD_DRAW_ALIGN_CENTER, false);
    } else if (!s_book_count) {
        ui_text_vc(fb, 342, 540, 23, "还没有划线或笔记", EPD_DRAW_ALIGN_CENTER, false);
        ui_text_vc(fb, 342, 584, 18, "在阅读页长按正文划线后，这里会出现可导出的书。",
                   EPD_DRAW_ALIGN_CENTER, false);
    }
    for (int row = 0; row < CLOUD_BOOK_ROWS; ++row) {
        size_t index = (size_t)s_book_page * CLOUD_BOOK_ROWS + (size_t)row;
        if (index >= s_book_count) break;
        int y = CLOUD_BOOK_TOP + row * CLOUD_BOOK_ROW_H;
        bool selected = (int)index == s_book_selected;
        if (selected) ui_fill_rect_fast((EpdRect){38, y + 2, 608, CLOUD_BOOK_ROW_H - 4}, 0xd8, fb);
        else if (row) ui_hairline(fb, y, 94, 554, 0xc0);
        epd_draw_circle(64, y + CLOUD_BOOK_ROW_H / 2, 12, UI_GRAY_BLACK, fb);
        if (selected) epd_fill_circle(64, y + CLOUD_BOOK_ROW_H / 2, 7, UI_GRAY_BLACK, fb);
        char title[96];
        snprintf(title, sizeof(title), "%s", s_books[index].title);
        cloud_fit_fixed(title, 23, 470);
        ui_text_fixed(fb, 94, y + 10, 23, title, EPD_DRAW_ALIGN_LEFT, false);
        char detail[64];
        snprintf(detail, sizeof(detail), "%u 条划线/笔记", (unsigned)s_books[index].count);
        ui_text_fixed(fb, 94, y + 52, 17, detail, EPD_DRAW_ALIGN_LEFT, false);
    }
    char pager[32];
    snprintf(pager, sizeof(pager), "%u/%u", (unsigned)(s_book_page + 1),
             (unsigned)cloud_book_pages());
    ui_pager_draw(fb, pager, s_book_page, cloud_book_pages(), false, UI_PAGER_NONE);
    cloud_draw_button(fb, 33);
    if (s_notice[0]) cloud_wrap(fb, 36, 1156, 17, 24, 612, s_notice, 2);
}

static app_redraw_t cloud_export_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type == UI_GESTURE_PRESS) {
        int id = cloud_button_hit(ev->x0, ev->y0);
        if (id < 0) return APP_REDRAW_NONE;
        s_pressed = id;
        return cloud_button_feedback(ctx, id);
    }
    int old = s_pressed;
    s_pressed = -1;
    if (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D) {
        if (s_export_pending) return APP_REDRAW_NONE;
        int next = s_book_page + (ev->type == UI_GESTURE_SWIPE_U ? 1 : -1);
        if (next < 0 || next >= cloud_book_pages()) return APP_REDRAW_NONE;
        s_book_page = next;
        return APP_REDRAW_PAGE;
    }
    if (ev->type == UI_GESTURE_TAP) {
        int x = ev->x0, y = ev->y0;
        if (cloud_back_hit(x, y)) return cloud_request_leave(ctx);
        if (s_export_pending) return APP_REDRAW_NONE;
        int id = cloud_button_hit(x, y);
        if (id == 31) {
            s_export_pending = true;
            s_notice[0] = 0;
            return APP_REDRAW_PAGE;
        }
        if (id == 32) {
            cloud_browse_open();
            return APP_REDRAW_PAGE;
        }
        if (id == 33) {
            if (s_book_selected < 0 || s_book_selected >= (int)s_book_count) {
                snprintf(s_notice, sizeof(s_notice), "请先选择一本书");
                return APP_REDRAW_PAGE;
            }
            s_notice[0] = 0;
            s_start_pending = CLOUD_JOB_EXPORT;
            return APP_REDRAW_PAGE;
        }
        int pager = ui_pager_hit(x, y);
        if (pager != UI_PAGER_NONE) {
            int next = ui_pager_target(pager, s_book_page, cloud_book_pages());
            if (next == s_book_page) return APP_REDRAW_NONE;
            s_book_page = next;
            return APP_REDRAW_PAGE;
        }
        int row = (y - CLOUD_BOOK_TOP) / CLOUD_BOOK_ROW_H;
        if (y >= CLOUD_BOOK_TOP && row >= 0 && row < CLOUD_BOOK_ROWS) {
            size_t index = (size_t)s_book_page * CLOUD_BOOK_ROWS + (size_t)row;
            if (index < s_book_count) {
                s_book_selected = (int)index;
                return APP_REDRAW_PAGE;
            }
        }
    }
    if (old >= 0) return cloud_button_feedback(ctx, old);
    return APP_REDRAW_NONE;
}

/* ================= 传输进度 / Transfer progress ================= */

static void cloud_draw_transfer_progress(uint8_t *fb) {
    ui_clear_rect_fast(fb, cloud_progress_rect());
    uint32_t done = s_ui.done_bytes, total = s_ui.total_bytes;
    uint32_t percent = total ? (uint32_t)(((uint64_t)done * 100) / total) : 0;
    if (percent > 100) percent = 100;
    char text[24];
    snprintf(text, sizeof(text), "%lu%%", (unsigned long)percent);
    ui_text_vc(fb, 342, 372, 72, text, EPD_DRAW_ALIGN_CENTER, false);
    EpdRect track = {60, 452, 564, 22};
    ui_draw_round_rect(fb, track, 11, 0x50);
    ui_fill_round_rect(fb, (EpdRect){62, 454, 560, 18}, 9, UI_GRAY_WHITE);
    int width = (int)((uint64_t)560 * percent / 100);
    if (width > 0) ui_fill_round_rect(fb, (EpdRect){62, 454, width, 18}, 9, UI_GRAY_BLACK);
    char bytes[80] = {0};
    if (total) {
        char left[24], right[24];
        cloud_format_size(done, left, sizeof(left));
        cloud_format_size(total, right, sizeof(right));
        snprintf(bytes, sizeof(bytes), "%s / %s", left, right);
    } else if (done) {
        char left[24];
        cloud_format_size(done, left, sizeof(left));
        snprintf(bytes, sizeof(bytes), "已传输 %s", left);
    }
    if (bytes[0]) ui_text_vc(fb, 342, 500, 21, bytes, EPD_DRAW_ALIGN_CENTER, false);
}

static void cloud_draw_transfer(uint8_t *fb) {
    cloud_header(fb, s_upload ? "导出笔记" : "下载到书架");
    ui_text(fb, 36, 186, 18, "文件", EPD_DRAW_ALIGN_LEFT, false);
    char name[WEBDAV_NAME_MAX];
    snprintf(name, sizeof(name), "%s", s_job_name[0] ? s_job_name : "（未命名）");
    cloud_fit_text(name, 23, 612);
    ui_text(fb, 36, 210, 23, name, EPD_DRAW_ALIGN_LEFT, false);
    const char *message = s_ui.message[0] ? s_ui.message : "正在准备…";
    cloud_wrap(fb, 36, 250, 21, 26, 612, message, 2);
    cloud_draw_transfer_progress(fb);
    cloud_draw_button(fb, 21);
    const char *hint;
    if (cloud_busy()) hint = "取消后不会保留未完成的文件。";
    else if (s_ui.ok && s_upload) hint = "笔记已上传到服务器的同步文件夹。";
    else if (s_ui.ok) hint = "已通知书架刷新，可在书架「云同步」分类中查看。";
    else hint = "可返回目录重试，或检查账号、网络与同步文件夹。";
    ui_text(fb, 36, 740, 18, hint, EPD_DRAW_ALIGN_LEFT, false);
}

static app_redraw_t cloud_transfer_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type == UI_GESTURE_PRESS) {
        int id = cloud_button_hit(ev->x0, ev->y0);
        if (id < 0) return APP_REDRAW_NONE;
        s_pressed = id;
        return cloud_button_feedback(ctx, id);
    }
    int old = s_pressed;
    s_pressed = -1;
    if (ev->type == UI_GESTURE_TAP) {
        int x = ev->x0, y = ev->y0;
        if (cloud_back_hit(x, y)) return cloud_request_leave(ctx);
        int id = cloud_button_hit(x, y);
        if (id == 21) {
            if (cloud_busy()) {
                bool running = s_joinable;
                cloud_job_cancel();
                memset(&s_ui, 0, sizeof(s_ui));
                s_ui.done = running ? false : true;
                s_ui.busy = running;
                s_ui.ok = false;
                snprintf(s_ui.message, sizeof(s_ui.message), "%s", running ? "正在取消…" : "已取消");
                return APP_REDRAW_PAGE;
            }
            cloud_browse_open();
            return APP_REDRAW_PAGE;
        }
    }
    if (old >= 0) return cloud_button_feedback(ctx, old);
    return APP_REDRAW_NONE;
}

/* ================= 页面主循环与生命周期 / Page loop and lifecycle ================= */

static app_redraw_t cloud_job_finished(app_ctx_t *ctx, const cloud_status_t *status) {
    (void)ctx;
    switch (status->job) {
        case CLOUD_JOB_TEST:
            snprintf(s_notice, sizeof(s_notice), "%s", status->message);
            break;
        case CLOUD_JOB_LIST:
            s_entry_count = status->entries;
            s_entry_hidden = status->hidden;
            cloud_entry_clamp();
            if (status->ok) s_notice[0] = 0;
            else snprintf(s_notice, sizeof(s_notice), "%s", status->message);
            break;
        case CLOUD_JOB_DOWNLOAD:
            if (status->ok) book_store_notify_changed();
            break;
        case CLOUD_JOB_PROGRESS:
            s_progress_local = 0;
            (void)book_progress_sync_local_count(&s_progress_local);
            s_progress_last = book_progress_sync_last_time();
            snprintf(s_notice, sizeof(s_notice), "%s", status->message);
            break;
        default:
            break;
    }
    return APP_REDRAW_PAGE;
}

static void render(app_ctx_t *ctx, uint8_t *fb) {
    (void)ctx;
    ui_clear_page(fb);
    switch (s_view) {
        case CLOUD_VIEW_CONFIG: cloud_draw_config(fb); break;
        case CLOUD_VIEW_BROWSE: cloud_draw_browse(fb); break;
        case CLOUD_VIEW_EXPORT: cloud_draw_export(fb); break;
        case CLOUD_VIEW_PROGRESS: cloud_draw_progress(fb); break;
        default: cloud_draw_transfer(fb); break;
    }
}

static bool present(app_ctx_t *ctx, app_redraw_t redraw) {
    if (redraw != APP_REDRAW_AREA) return false;
    EpdRect area = s_paint_area;
    if (area.width <= 0) area = ui_content_refresh_area();
    if (s_paint_settle) {
        guard_draw_result(ctx->hl, update_display_area_full_with(ctx->hl, &E0470_WAVEFORM,
                                                                  MODE_GL16, area));
    } else {
        guard_draw_result(ctx->hl, update_display_area_diff_with(
            ctx->hl, s_paint_gl16 ? &E0470_WAVEFORM : &E0470_FOLLOW_WAVEFORM,
            s_paint_gl16 ? MODE_GL16 : MODE_DU, area));
    }
    s_paint_settle = false;
    s_paint_area = (EpdRect){0};
    return true;
}

static EpdRect area_hint(app_ctx_t *ctx) {
    (void)ctx;
    return s_paint_area.width > 0 ? s_paint_area : ui_content_refresh_area();
}

static app_redraw_t on_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (s_view == CLOUD_VIEW_CONFIG && s_field >= 0) return cloud_keyboard_gesture(ctx, ev);
    switch (s_view) {
        case CLOUD_VIEW_CONFIG: return cloud_config_gesture(ctx, ev);
        case CLOUD_VIEW_BROWSE: return cloud_browse_gesture(ctx, ev);
        case CLOUD_VIEW_EXPORT: return cloud_export_gesture(ctx, ev);
        case CLOUD_VIEW_PROGRESS: return cloud_progress_gesture(ctx, ev);
        default: return cloud_transfer_gesture(ctx, ev);
    }
}

static app_redraw_t on_key(app_ctx_t *ctx, int key) {
    if (key == UI_KEY_2) return APP_REDRAW_FULL;
    return cloud_request_leave(ctx);
}

static app_redraw_t on_tick(app_ctx_t *ctx) {
    if (s_view == CLOUD_VIEW_CONFIG && s_field >= 0) {
        if (ctx->consumed) return APP_REDRAW_NONE;
        bool held = !ctx->released && ctx->touch && ctx->touch->touched && ctx->touch->count == 1;
        if (ui_keyboard_hold_tick(held, ctx->touch ? ctx->touch->x : 0,
            ctx->touch ? ctx->touch->y : 0, ctx->now_ms) == UI_KEYBOARD_CHANGED)
            return cloud_keyboard_paint(ctx, false);
        if (ui_keyboard_idle_tick(ctx->touch && ctx->touch->touched, ctx->now_ms) == UI_KEYBOARD_CHANGED)
            return cloud_keyboard_paint(ctx, false);
    }
    if (s_export_pending) {
        s_export_pending = false;
        cloud_export_collect();
        return APP_REDRAW_PAGE;
    }
    if (s_start_pending != CLOUD_JOB_NONE) {
        cloud_job_t job = s_start_pending;
        if (job == CLOUD_JOB_EXPORT && !cloud_export_prepare()) {
            s_start_pending = CLOUD_JOB_NONE;
            return APP_REDRAW_PAGE;
        }
        s_start_pending = CLOUD_JOB_NONE;
        ttf_font_cache_clear();
        if (!cloud_job_start(job)) {
            memset(&s_ui, 0, sizeof(s_ui));
            s_ui.done = true;
            s_ui.ok = false;
            snprintf(s_ui.message, sizeof(s_ui.message), "任务启动失败，请稍后重试");
            snprintf(s_notice, sizeof(s_notice), "任务启动失败，请稍后重试");
            return APP_REDRAW_PAGE;
        }
        cloud_status_get(&s_ui);
        return APP_REDRAW_PAGE;
    }
    if (!s_joinable) return APP_REDRAW_NONE;
    cloud_status_t status;
    cloud_status_get(&status);
    if (status.done && !status.busy) {
        if (xSemaphoreTake(s_done, 0) == pdTRUE) {
            s_joinable = false;
            s_ui = status;
            return cloud_job_finished(ctx, &status);
        }
    }
    if (ctx->now_ms - s_poll_ms < CLOUD_POLL_MS) return APP_REDRAW_NONE;
    s_poll_ms = ctx->now_ms;
    const bool message_changed = strcmp(status.message, s_ui.message) != 0;
    const bool bytes_changed = status.done_bytes != s_ui.done_bytes ||
                               status.total_bytes != s_ui.total_bytes;
    s_ui = status;
    if (message_changed) return APP_REDRAW_PAGE;
    if (bytes_changed && s_view == CLOUD_VIEW_TRANSFER) {
        cloud_draw_transfer_progress(ctx->fb);
        return cloud_paint(cloud_progress_rect(), false);
    }
    return APP_REDRAW_NONE;
}

static void cloud_on_enter(app_ctx_t *ctx) {
    (void)ctx;
    s_view = CLOUD_VIEW_CONFIG;
    s_pressed = -1;
    s_field = -1;
    s_start_pending = CLOUD_JOB_NONE;
    s_joinable = false;
    __atomic_store_n(&s_cancel, false, __ATOMIC_SEQ_CST);
    s_confirm_overwrite = false;
    s_entry_count = s_entry_hidden = 0;
    s_entry_page = 0;
    s_book_count = 0;
    s_book_page = 0;
    s_book_selected = -1;
    s_export_pending = false;
    s_upload = false;
    s_progress_local = 0;
    s_progress_last = 0;
    s_job_remote[0] = s_job_local[0] = s_job_name[0] = 0;
    s_job_remove_local = false;
    s_notice[0] = 0;
    s_root_dir[0] = s_remote_dir[0] = 0;
    memset(&s_ui, 0, sizeof(s_ui));
    memset(&s_status, 0, sizeof(s_status));
    cloud_config_load();
    if (!cloud_sync_init()) snprintf(s_notice, sizeof(s_notice), "内存不足，无法建立网络任务锁");
    ESP_LOGI(TAG, "enter open_request=%d configured=%d", (int)s_open_requested,
             (int)app_settings_cloud_configured());
    s_open_requested = false;
}

// 离页必须等网络任务退出：任务里引用的都是静态状态，但仍不能让它在页面关闭后继续碰 WiFi。
// Leaving joins the worker first: it only touches static state, but it must not own WiFi after the page closes.
static void cloud_on_exit(app_ctx_t *ctx) {
    (void)ctx;
    cloud_field_end();
    bool had_job = s_joinable;
    cloud_job_join();
    read_pico_transfer_stop();
    if (had_job) {
        cloud_status_t final;
        cloud_status_get(&final);
        if (final.done && final.ok && final.job == CLOUD_JOB_DOWNLOAD) book_store_notify_changed();
    }
    s_start_pending = CLOUD_JOB_NONE;
    s_joinable = false;
    heap_caps_free(s_entries);
    s_entries = NULL;
    heap_caps_free(s_books);
    s_books = NULL;
    heap_caps_free(s_md);
    s_md = NULL;
    s_confirm_overwrite = false;
    ESP_LOGI(TAG, "exit heap=%u", (unsigned)heap_caps_get_free_size(MALLOC_CAP_8BIT));
}

static void cloud_before_lock(app_ctx_t *ctx) {
    (void)ctx;
    cloud_field_end();
    bool had_job = s_joinable;
    cloud_job_join();
    read_pico_transfer_stop();
    if (had_job && s_view == CLOUD_VIEW_TRANSFER) {
        memset(&s_ui, 0, sizeof(s_ui));
        s_ui.done = true;
        s_ui.ok = false;
        snprintf(s_ui.message, sizeof(s_ui.message), "已取消，可返回目录重试");
    }
}

static void cloud_media_lost(app_ctx_t *ctx) {
    (void)ctx;
    cloud_job_join();
    read_pico_transfer_stop();
    snprintf(s_notice, sizeof(s_notice), "存储卡已移除，同步已中断");
    if (s_view == CLOUD_VIEW_TRANSFER) {
        memset(&s_ui, 0, sizeof(s_ui));
        s_ui.busy = false;
        s_ui.done = true;
        s_ui.ok = false;
        snprintf(s_ui.message, sizeof(s_ui.message), "存储卡已移除，同步已中断");
    }
}

static bool cloud_menu_handle(app_ctx_t *ctx) {
    (void)ctx;
    return false;
}

static bool cloud_edge_back(app_ctx_t *ctx) {
    (void)ctx;
    return true;
}

static bool cloud_back_swipe_area(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    (void)ctx;
    return s_field < 0 || (ev && ev->y0 < UI_SYSTEM_KEYBOARD_TOP);
}

void app_cloud_request_open(void) { s_open_requested = true; }

bool app_cloud_busy(void) { return s_joinable || s_start_pending != CLOUD_JOB_NONE; }

const app_desc_t app_cloud = {
    .title = "坚果云同步",
    .detail = "WebDAV 拉取与笔记导出",
    .enter_full = true,
    .owns_keys = true,
    .menu_handle_enabled = cloud_menu_handle,
    .edge_back_enabled = cloud_edge_back,
    .back_swipe_area = cloud_back_swipe_area,
    .on_enter = cloud_on_enter,
    .on_exit = cloud_on_exit,
    .on_before_lock = cloud_before_lock,
    .on_media_lost = cloud_media_lost,
    .render = render,
    .present = present,
    .on_gesture = on_gesture,
    .on_key = on_key,
    .on_tick = on_tick,
    .area_hint = area_hint,
};
