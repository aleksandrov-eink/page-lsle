/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 图书书架、阅读、目录与页内进度；文件解析和排版由book模块负责。
 * Book shelf, reader, TOC and progress; book modules own parsing and pagination.
 *
 * 用户修订：阅读设置采用已确认的半屏双列排版；自动全刷与翻页效果点按轮换，保留按键控制二级页。
 * User revision: use the approved compact two-column reading sheet; tap cycles refresh/effect and key controls retain their secondary page.
 * 冻结：Phase4b统一手势入口并接管三键为上页/工具条/下页；工具条保留强刷。屏幕翻页在抬起提交，不画按下态。
 * 用户修订：图文混排原样采用 PR9 的 book_layout；调用侧只适配图片缓存与上下文生命周期。
 * 晃动默认关；横向左晃上一页、右晃下一页，触摸与回弹不触发；离页恢复加速度配置并休眠。render只绘图。
 * 预渲染与同步推屏重叠、按行可停；推屏返回前交还字体与章节资源。
 * 普通翻页只刷新正文与页脚；手动或周期清残影整屏全刷。
 * 用户修订：阅读手动与周期全刷恢复 rc90 的原表 GC16 目标页输出，不先擦白再补文字。
 * User revision: restore rc90's original-table GC16 target-page output for manual and periodic refresh, without a white pre-clear and text pass.
 * 用户2026-10-21修订：Pico进入阅读页单次完整GC16清理；普通文字翻页保留校准GL16前导擦除及等灰保持，沿用预读与单轮合并进度。
 * User revision 2026-10-21: Pico reader entry uses one complete GC16; ordinary text retains calibrated GL16 erasure and equal-gray holds, prefetch and one fused progress output.
 * 用户修订：正文中间双击固定切换全屏，单击左右各半或上1/3下2/3翻页，不受按键配置影响。
 * 三键单击及中键长按可自定义，提供翻页/工具栏及首页/全屏/工具栏两套推荐；中键长按默认返回主页，阅读页不画右下角菜单图标。
 * 用户修订：正文手势（双击/长按/上滑/下滑/左滑/右滑/双指轻点）可逐槽位配置并持久化，
 * 经典预设逐条复现旧行为；上下翻页模式保留上下滑动翻页，左右模式下映射为不操作即不翻页。
 * 用户修订：书架扫描、开书与阅读页接入 Markdown（.md/.markdown），走 TXT 通道、无插图，
 * 进度仍是章节号加章内输出文本偏移；题头与图片逻辑保持只对 EPUB 生效。
 * User revision: body gestures (double tap, long press, four swipes, two-finger tap) are
 * configurable and persisted slot by slot, with the classic preset reproducing the old behaviour;
 * vertical-turn mode keeps up/down paging while a NONE slot really does nothing in the default
 * horizontal mode. The shelf and reader accept Markdown (.md/.markdown) through the TXT path
 * without illustrations, keeping chapter plus output-text-offset progress; chapter headings and
 * illustrations stay EPUB-only.
 * 用户授权基础管理：长按书架先看完整详情，清进度与删文件分别确认；失败保留待重试记录，不自动回收其他书进度。
 * 用户修订：单本管理为书架弹窗；管理页用于批量操作。分页和排序保留勾选，筛选/应用搜索及重扫清除勾选。
 * 失败进度仅按变更路径失效；删除后的清理重试保留到本次开机结束，不随切页释放。
 * 卡失效时先保存进度并关闭阅读资源，再由主循环回退字体；禁止自动续读失效挂载。
 * 用户最新修订：书架只保留深色书轨与亚克力，每页九本；收录导入及读过的书，移出仅隐藏，再读重新上架。
 * 底栏保留首页/书架/文件/设置，设置直接进入设置页。
 * 用户修订：长按图书可用本机拼音输入编辑书名；阅读时长与翻页真实记录，供票根锁屏使用。
 * 用户最新修订：书名编辑可点选插入位置并用左右键微调，支持在文字中间插入和删除。
 * 用户授权新输入法：书名和搜索共用九宫格/全键盘、中英文及离线词语候选，不改正文排版。
 * 用户修订：首页、书架、文件、设置四栏导航；切换界面采用 GL16，章节首页单独排标题。
 * 用户修订：EPUB 章节首页以书内目录标题为准，正文题头仅在相同时折叠，避免引言误判。
 * 用户修订：阅读进度条无外伸刻度并使用圆角；继续阅读区显示最近书籍封面。
 * 用户修订：书架整页读取成品缓存后一次显示；首次生成有界分批处理，但整页封面一起显现，不逐本推屏。
 * User revision: read the page's finished caches before its first frame; cold generation is bounded, but cover artwork is revealed together.
 * 用户修订：字号和间距重排只保存最终进度，字号使用现有闲置灰阶整理。
 * 用户修订：阅读设置滑杆可拖动并在松手后重排；字体选择可纵向翻页；统计入口显示真实明细与近30天数据。
 * 用户修复：间距滑杆点按和拖动共用完整档位，字间距每次1px，段距按显示档位递进。
 * User fix: spacing taps and drags share the full ladders; tracking steps by 1px and paragraph spacing follows the displayed stops.
 * 用户修订：前后均为纯文字的普通翻页采用柔和 GL16 差分，仅白底灰边提前少量回浅，不改字形或灰度目标；插图、混排、周期全刷及水波纹保留原规则。
 * User revision: soften ordinary pure-text GL16 turns by advancing a few white-to-gray settling pulses; preserve glyph targets, images, mixed pages, cleanup and ripple.
 * 用户修订：目录由独立模块整页绘制与命中；目录标题清理换行并限制为单行，翻页不再沿用书架的局部刷新。
 * 用户修订：书架封面抽出与取消仅驱动变化像素，保持灰阶，不在点按时强制清屏。
 * 用户修订：列表封面上弹8px，松手先回位再开书；只重画两位置的并集，复用缓存，不触碰文字/边框/分隔线。快刷用跟随DU，其他模式保留灰阶差分。
 * User revision: list covers bounce up 8px and settle before opening; repaint only the position union using cached artwork, preserving text, frames and separators. Fast uses FOLLOW DU; other modes retain gray differentials.
 * 用户确认：列表封面缩至120×156，保留原中心点与右侧文字位置，等比填充并居中裁切。
 * User approval: list covers use 120×156 boxes, retaining their center and right-side text positions with aspect fill and centered cropping.
 * 用户修订：快刷亚克力采用规则一像素棋盘格，与已缓存封面合并输出，不注册灰区或等待框架先显示；未缓存封面继续有界延后解码。普通及水波纹保留灰阶，切页/锁屏取消旧目标。
 * 用户修订：书架读取最多当前整页缓存；未缓存封面限时准备，整组显现后才确认待刷标记，文件间检查导航，不新增整页缓存。
 * 用户修订：阅读背景先列pictures图片、忽略隐藏文件，点开预览上下切换，返回目录；背景按整屏坐标固定，不随文字边距或全屏状态缩放。
 * User revision: fast acrylic uses a regular one-pixel checkerboard in the same output as cached covers, without gray registration or a furniture-first wait; uncached covers retain bounded lazy decoding. Ordinary/water retain grays; page/lock changes cancel stale targets.
 * 用户要求采用PR17的快速水波纹，并最新指定8条带、每拍11090us；每次显式设置，结束恢复先前节拍，避免影响主页动画。全刷、插图及失败恢复保留原优先级。
 * User requests PR17 fast ripple with the latest 8 bands at 11090us; explicitly select pacing per turn and restore it afterward so main animations remain independent. Retain cleanup, image and recovery priority.
 * 用户2026-10-20授权S31独立文字水波纹实验包：纯文字水波纹可选四级/22相/8带并合并尾带，合并页脚且最多十页GC48。
 * 用户最新指定本地普通文字也用与水波纹相同的四级22相，同步整页；速读黑白保留DU20。
 * Latest user request: local ordinary text shares ripple's four-level22 phases in one synchronous output; FastBW retainsDU20.
 * 两个短灰阶路径均最多十页GC48；未启用实验、缺相或本次开机扫描失败时回到完整GL48，图片/背景与手动全刷保持。
 * Both short-gray paths useGC48 within ten turns; builds without the experiment,missing phases or boot-local scan failures retain fullGL48, as do images/backgrounds and manual cleanup.
 * User authorizes a separate S31 text-ripple experiment on2026-10-20: four target levels/22 phases/eight bands with a paired tail and fused footer and GC48 within ten turns. Regular builds, main pages, images and manual cleanup retain their paths.
 * 用户随后要求借鉴原厂普通阅读的干净过渡：普通字缘仍保留16级，仅跳过本次所有像素都保持的前导相，不裁有效脉冲。
 * The user then requests clean vendor-like ordinary turns: retain16-level text targets, omitting only actual all-hold leading phases without trimming active pulses.
 * 用户增加管理/导入按压态：复用现有抬起确认流程，按下灰底加深并下沉2px，只推按钮区域。
 * User adds management/import feedback: retain release-confirmed actions, darken and depress controls 2px on press, presenting only their region.
 * 用户修订：快刷封面保留轻量减黑并按最新要求略增黑点密度，在PSRAM缓存最多九张1位缩略图（约40KiB）；进度未改变时不重复丢弃封面。缓存只画封面，收藏与界面文字实时绘制，开书或卡失效时释放。
 * Frozen: Phase4b uses the shared gesture entry and owns previous/tools/next keys; the toolbar keeps full refresh. Screen turns commit on release without pressed decoration.
 * User revision: adopt PR9's book_layout unchanged; callers only adapt bitmap caching and context lifetimes.
 * Authorized keyboard revision: titles and search share T9/QWERTY, bilingual offline phrase candidates; body layout stays intact.
 * 用户修订：输入不重画题头、封面或正文，只刷新输入变化区域，退出后释放查字缓存。
 * 用户修订：新开书默认全屏；双击中间切换，翻页关闭工具栏并回全屏；重排以已选目标页的文字位置为锚，不跳过未读文字。
 * User revision: new books open full screen; center double taps toggle it, turns dismiss tools and return to full screen; reflow anchors the selected destination before changing geometry so unread text is not skipped.
 * 用户修订：字重用横向减/加胶囊，每次微调1/16像素覆盖率；保持字形比例/字宽，不加载额外整份字库。
 * User revision: a horizontal minus/plus pill adjusts coverage by 1/16 pixel per tap, preserving advances/proportions without another font.
 * 用户修订：阅读背景入口放回「阅读设置」，与竖排一起排成每页十个功能的整齐双列；
 * 图片选择做成三级菜单（阅读背景 → 目录/子目录 → 预览），并套用透明书封的自动去白算法。
 * User revision: the background entry returns to Reading settings, laid out with the vertical switch as
 * ten tidy half-width cells per page; image picking is a three-level menu (background -> folder/subfolder
 * -> preview) and the background uses the transparent-cover auto-white-removal algorithm.
 * 用户增加阅读抗锯齿开关，默认开；书架整页封面合并显示；正文底部上滑固定呼出工具栏，不受翻页/按键设置影响。
 * User adds default-on reading AA and grouped shelf artwork; upward swipes from the body bottom always open tools independently of tap/key modes.
 * 用户修订：底部上滑固定呼出工具栏，不随按键及翻页模式变化；取消短按或长按必须保留工具栏的限制。
 * User revision: bottom-edge swipes always open tools independently of key/tap modes; short and hold actions no longer require a toolbar mapping.
 * User revision: input refreshes changed regions without repainting headers, covers or body; release lookup caches on exit.
 * Shake is off by default: left/right impulses turn back/forward, suppressing touch and rebound; exit restores the sensor and sleeps it. Render only paints.
 * Prefetch overlaps synchronous output and stops between rows; no font/chapter resources survive presentation.
 * Ordinary turns refresh only body and footer; manual and periodic ghost cleanup refresh the entire screen.
 * User revision: center body double taps always toggle full screen; single taps use halves or upper 1/3/lower 2/3 independently of key mappings.
 * Short key actions are configurable with two presets; middle holds are configurable and default to home. The reader has no bottom-right menu icon.
 * User-authorized management shows full details before separate clear/delete confirmations; retain failed saves for retry without pruning other books.
 * User revision: single-book actions use a shelf dialog; full management is for batches. Paging/sorting preserve selection; filtering/applied search and rescanning clear it.
 * Invalidate failed progress only for changed paths; retain deletion cleanup retries across page exits for this boot.
 * Lost media saves progress and closes reader resources before global font fallback; never auto-resume an invalid mount.
 * Latest user revision: the two retained shelf styles hold nine imported or read books; retired styles restore as acrylic, and removal hides until reread.
 * The fourth tab opens Settings directly.
 * User revision: book details lead to an on-device Pinyin title editor; measured reading time and turns feed the ticket lock face.
 * Latest user revision: the title editor can place and move an insertion caret for edits in the middle of text.
 * 用户统一修订：书名与搜索采用共用常亮光标；点文字或箭头定位，按系统字体测量。
 * User-wide revision: title/search share a steady caret, text/arrow positioning and system-font measurement.
 * User revision: home, shelf, files and settings have four-tab navigation; view changes use GL16 and chapter starts have a title lead.
 * User revision: EPUB chapter leads use navigation titles; body headings are folded only when matching, preventing front matter from being mislabeled.
 * User revision: the reader bar is rounded without protruding ticks; continue reading displays the latest cover.
 * User revision: the shelf retains its title layout, reads a complete cached page before painting, and reveals cold artwork only after the page is prepared.
 * User revision: size and spacing reflow saves final progress only; size uses the existing idle grayscale settle.
 * User revision: reader sliders drag and reflow on release; font selection pages vertically; statistics entries show real details and recent-30-day data.
 * User revision: pure-text turns use softened gray-edge differential GL16; images/mixed pages, periodic cleanup and water turns retain their policies.
 * User revision: a standalone module owns full-page TOC rendering and hit testing; normalized single-line titles cannot leak into another row.
 * User revision: cover lift and cancellation drive changed pixels in grayscale, without forced cleanup during a tap.
 * 用户修订：快刷仅常驻黑白缩略图；灰阶解码缓冲转好即释放，灰阶模式按需重建，收藏白边单独记录。
 * User revision: fast mode retains only packed monochrome thumbnails, frees gray decoding buffers immediately after conversion, rebuilds gray on demand, and stores favorite-edge contrast separately.
 * User revision: fast covers retain a light white lift with slightly denser blacks per the latest request and cache at most nine 1-bit thumbnails in PSRAM (about 40 KiB); unchanged progress no longer discards covers. Cache artwork only, draw favorites and UI text live, and release on book opening or media loss.
 * 用户最新修订：阅读书名与章节标题复用当前阅读字体，以原32/48px直接光栅化；首页另用其活动系统字体，不同时加载两份字库。
 * Latest user revision: book/chapter titles reuse the current reader face at the original 32/48px; Home uses its active system face, never retaining both fonts.
 * 用户确认：题头下拉选择 books 子目录，各类别/布局记住页码；去掉题头横线，主体在确认位置基础上下移8px。
 * User approval: choose books subfolders in the title menu, retain per-category/layout pages, remove the header rule and lower the approved body by 8px.
 */
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <stdatomic.h>
#include <unistd.h>

#include "app.h"
#include "app_book.h"
#include "app_content_open.h"
#include "boot_state.h"
#include "app_registry.h"
#include "ble_page_turner.h"
#include "book_layout.h"
#include "book_cover.h"
#include "book_cover_jobs.h"
#include "book_lock_collage.h"
#include "book_epub.h"
#include "book_policy.h"
#include "book_file_path.h"
#include "book_progress.h"
#include "book_font_size.h"
#include "book_title.h"
#include "book_ticket.h"
#include "book_excerpt.h"
#include "book_toc.h"
#include "book_highlight.h"
#include "app_font_context.h"
#include "book_source.h"
#include "book_md.h"
#include "book_store.h"
#include "book_shelf_categories.h"
#include "display.h"
#include "display_main_waveform.h"
#include "display_reader_waveform.h"
// 插图缩放的跟手帧在离开现场时要丢弃未完成的连续 DU 相位。
// Zoom frames discard unfinished continuous-DU phases when the context is left.
#include "continuous_du.h"
#include "e0470_epaper_waveform.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "nvs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "read_pico_init.h"
#include "read_pico_board.h"
#include "read_pico_sd.h"
#include "read_pico_transfer.h"
#include "read_pico_search.h"
#include "settings.h"
#include "sleep.h"
#include "book/book_reader_input.h"
#include "ttf_font.h"
#include "ui_kit.h"
#include "ui_text_input.h"
#include "ui_keyboard.h"
#include "ui_image_dither.h"
#include "ui_reader_background.h"
#include "ui_gesture.h"
#include "ui_menu.h"
#include "ui_nav.h"
#include "ui_click_feedback.h"
#include "app_transfer_mode.h"

// 阅读工具栏图标盒边长；行内图标在 1096..1216 的工具条里以 1138 为中心。
// Reader toolbar icon box; the row centres on y=1138 inside the 1096..1216 bar.
#define READER_TOOL_ICON_PX 40
// 二级面板返回键里的箭头边长；圆底半径 24，原来的箭头是 20 像素高。
// Chevron box inside a secondary panel's back control; the old arrow was 20 px tall.
#define READER_SHEET_BACK_PX 52

#define BOOK_ROWS 13
#define BOOK_GRID_ROWS 9
#define BOOK_BULK_ROWS 6
#define BOOK_PX_MIN BOOK_READER_PX_MIN
#define BOOK_PX_MAX BOOK_READER_PX_MAX
#define BOOK_PX_STEP 1
#define BOOK_MARGIN_MIN 0
#define BOOK_MARGIN_MAX 48
#define BOOK_MARGIN_CHOICES 9
#define BOOK_TOOL_COUNT 6
// 水波纹节拍：快刷档在 present 里显式 11.09ms/拍，高清档不覆盖、走组件默认 12ms/拍。
// Ripple pacing: the fast step sets 11.09 ms per tick in present(); HD leaves the component
// default at 12 ms per tick. Both steps use the same rc100 ripple algorithm.
#define BOOK_FONT_PAGE 9
#define BOOKMARK_MAX 24
#define BOOKMARK_ROWS 6

typedef enum { SHELF, READING, TOC, MANAGE, BULK, IMPORT, SEARCH, EDIT } book_view_t;
typedef enum {
    READER_PANEL_NONE,
    READER_PANEL_TOOLS,
    READER_PANEL_FONT_SETTINGS,
    READER_PANEL_LAYOUT_SETTINGS,
    READER_PANEL_WEIGHT_SETTINGS,
    READER_PANEL_RULE_SETTINGS,
    READER_PANEL_FONT_PICKER,
    READER_PANEL_BACKGROUND,
    READER_PANEL_BACKGROUND_PREVIEW,
    READER_PANEL_BACKGROUND_MENU,
    READER_PANEL_STATS,
    READER_PANEL_BOOKMARKS,
    READER_PANEL_STATS_RECENT,
    READER_PANEL_CHAPTER_JUMP,
    READER_PANEL_REFRESH_SETTINGS,
    READER_PANEL_TURN_SETTINGS,
    READER_PANEL_KEY_SETTINGS,
    READER_PANEL_KEY_PICKER,
    READER_PANEL_GESTURE,
    READER_PANEL_GESTURE_PICKER,
    READER_PANEL_HIGHLIGHTS,
    READER_PANEL_FONT_RECOVERY, ///< 书内字体反复回退时的「立即重启/暂不重启」提示
} reader_panel_t;
typedef struct {
    char name[256];
    char author[128];
    char path[BOOK_STORE_PATH_MAX];
    uint32_t size;
    uint16_t chapter;
    bool is_flash;
    bool has_progress;
    uint8_t pct;
    uint32_t recent;
    bool selected, removed, search_match, favorite;
} shelf_entry_t;

static const char* TAG = "book";
static book_view_t s_view;
static int s_presented_view = -1;
static bool s_reader_image_refresh_pending;
static bool s_reader_turn_pending;
// 只记录成功推屏的纯正文基准，避免跨章或退出插图时误用文字波形。
// Track only successfully presented text-only bodies, protecting chapter and image transitions.
static bool s_reader_text_frame;
static char s_requested_open[BOOK_STORE_PATH_MAX];
static bool s_requested_open_home;
static bool s_requested_fullscreen = true;
static bool s_reader_return_home;
static bool s_requested_manage;
static shelf_entry_t* s_shelf;
static struct {
    int index;
    uint8_t *gray, *fast_bits;
    unsigned width, height;
    uint8_t fast_contrast, fast_phase;
    bool fast_white_edge;
} s_covers[BOOK_ROWS];
static unsigned s_cover_pending_mask, s_cover_decode_mask, s_cover_warm_mask;
// 相邻书架页封面预取：当前页完全落屏后，把下一页封面解到缓存里，翻页时直接命中。
// Neighbouring shelf page preload: after the current page is complete, decode the next page's
// covers into the cache so a page turn hits it directly.
static unsigned s_pf_cover_generation, s_pf_cover_pending_mask;
static int s_pf_cover_leaf = -1;
static int s_pf_cover_dir = 1;  // 预取方向交替：先下一页，再上一页，来回翻都能命中缓存
static int64_t s_pf_cover_next_ms;
static unsigned s_cover_dirty_mask, s_cover_present_mask;
static int64_t s_cover_warm_after_ms;
static size_t s_shelf_capacity;
static int s_count, s_visible_count, s_filter;
static bool s_recent_sort;
// 目录记录有界增长；同一开机周期按完整路径保存两种布局的页码。
// Bounded folder records retain pages by full path for the two layouts during this boot.
#define SHELF_CATEGORY_LIMIT 128
#define SHELF_CATEGORY_ROWS 7
typedef struct { char path[BOOK_STORE_PATH_MAX]; int pages[2], count; bool available; } shelf_category_t;
static shelf_category_t *s_categories;
static int s_category_count, s_category_capacity, s_category_selected, s_category_menu_page;
static bool s_category_menu;
static char s_category_root[BOOK_STORE_PATH_MAX];
static void shelf_category_init(void);
static void shelf_category_remember(app_ctx_t *ctx);
static void shelf_category_restore(app_ctx_t *ctx);
static void shelf_categories_recount(void);
static void draw_category_menu(uint8_t *fb);
static const char *shelf_category_name(int index);
static bool shelf_category_matches(const char *path);
static int shelf_category_add(const char *path);
static app_redraw_t shelf_category_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev);
static bool s_reader_favorite;
static shelf_entry_t s_managed;
static bool s_delete_confirm, s_file_removed;
static char s_shelf_warning[128], s_manage_message[128];
static char s_query[65], s_search_draft[65], s_batch_message[128];
static ui_text_edit_t s_search_input;
static book_view_t s_search_parent;
// 批量操作需要二次确认的三类：删文件、清进度、从书架移除。前两类动数据，后一类只动书架。
// Three batch actions need confirmation: delete files, clear progress, remove from the shelf.
// The first two touch stored data; the last one only touches shelf membership.
typedef enum {
    BATCH_DELETE,
    BATCH_CLEAR,
    BATCH_UNSHELF,
} batch_kind_t;
static bool s_batch_confirm;
static batch_kind_t s_batch_kind;
typedef struct pending_progress {
    char path[BOOK_STORE_PATH_MAX];
    book_progress_t value;
    bool dirty, progress_saved;
    book_progress_watch_t* watch;
    struct pending_progress* next;
} pending_progress_t;
static pending_progress_t* s_pending;
typedef struct delete_retry {
    shelf_entry_t entry;
    struct delete_retry* next;
} delete_retry_t;
static delete_retry_t* s_delete_retries;
static char s_latest_path[BOOK_STORE_PATH_MAX];
static char s_editor_title[121], s_editor_notice[96];
// 划线笔记复用书名编辑器：同一套键盘与输入框，只是保存对象换成划线 sidecar。
// Highlight notes reuse the title editor: same keyboard/field, but the target is the highlight file.
static bool s_edit_note_mode;
static int s_edit_note_index = -1;
static ui_text_edit_t s_editor_input;
static uint8_t* s_editor_cover;
static bool s_save_failed;
static bool s_pending_invalidated;
static int64_t s_save_retry_ms;
static unsigned s_store_revision;
static uint32_t s_progress_revision=UINT32_MAX;
static bool s_shelf_cache_valid, s_cache_sd_present, s_cache_sd_mounted;
static uint8_t s_cache_shelf_style;
static bool s_scan_pending, s_clear_confirm;
static reader_panel_t s_reader_panel;
// 微调长按只更新预览，松手后统一重排和保存；离开控件即取消。
// Held indent adjustments update the preview only; release reflows/saves once and leaving the control cancels.
static struct {
    bool active, cancelled, repeated;
    int control, value;
    int64_t next_ms, last_ms;
} s_indent_hold;
static bool s_indent_feedback_pending;
static void reader_indent_hold_cancel(void);
static bool s_reader_fullscreen;
// Adaptive reading direction: gravity-driven orientation for the reader body page only.
// Panels, menus and every other view stay portrait.
static bool s_reader_landscape;
static int s_reader_rot = EPD_ROT_INVERTED_PORTRAIT;
// Markdown 表格列宽按解析时的正文宽/字号/字距固化在正文空格里；记录当前 s_text 是按哪个
// 旋转方向解析的，旋转时只在该值落后时重载一次，避免 rotation tick 里反复读卡解析。
// Markdown table widths are baked into the text at parse time; remember which rotation the
// current s_text was parsed for, so a rotation reloads once instead of on every tick.
static int s_md_tables_rot = -1;
// 触摸回调里不能直接重载章节：字体页那类路径曾实测把主任务栈顶穿，所以重排类的 Markdown
// 重解析只在回调里登记“重排前的页首偏移”，下一轮 on_tick 的浅栈上执行并统一推屏。
// Chapter reloads must not run inside touch callbacks: the font page path once overran the main
// task stack (measured). Re-layout paths therefore only record the pre-layout page-start offset
// here and run the re-parse from on_tick, on the shallow stack, presenting once.
static bool s_md_reload_pending;
static size_t s_md_reload_offset = SIZE_MAX;
// 登记时的章节号：若两轮之间已换章，丢弃这次重解析，避免把旧偏移套到新章上。
// The chapter the request was made for; drop it if a chapter turn happened in between, so an old
// offset can never be applied to a new chapter.
static size_t s_md_reload_chapter = SIZE_MAX;
static int s_orient_desired = EPD_ROT_INVERTED_PORTRAIT;
static int64_t s_orient_next_ms;
static int s_orient_ref_x, s_orient_ref_y;
static bool s_orient_ref_ready;
// Set when a deliberate tap says "I am looking at this screen": that is the only moment
// the reference vector may be captured, so a sideways grip can never poison it.
static bool s_orient_calibrate;
static int s_orient_seen_idx = -1, s_orient_seen_n;
// 旋转锚点：记录旋转前这一页的起始字符偏移。来回切换横竖屏时复用它，避免每次
// 都从映射后页首重新取偏移，导致来回切换一次就向后漂一页、几次后偏好几页。
// Rotation anchor: the page-start character offset captured before rotating. Reuse it for
// orientation round trips so every switch does not re-anchor on the mapped page start and drift
// backwards by a page (several pages after a few toggles).
static size_t s_orient_anchor_off = SIZE_MAX;
static size_t s_orient_anchor_page = SIZE_MAX;
// 旋转锚点只服务于“没有翻页、没有重排时来回旋转”。任何重排、换章、换书都会移动页边界，
// 旧偏移不再代表当前阅读位置，必须失效，否则来回旋转会落到错误的位置。
// The rotation anchor only serves orientation round trips without a page turn or reflow. Any
// reflow, chapter change or book switch moves page boundaries, so the saved offset must be
// dropped or an orientation flip would land somewhere else.
static void reader_anchor_invalidate(void) {
    s_orient_anchor_off = SIZE_MAX;
    s_orient_anchor_page = SIZE_MAX;
}
static bool s_shelf_key_mode,s_shelf_key_paint_pending;
static int s_shelf_key_pressed,s_shelf_key_delta;
static int64_t s_shelf_key_until;
static int64_t s_reader_clock_minute = -1, s_reader_clock_painted_minute = -1;
static bool s_reader_clock_pending;
static char s_message[128], s_storage[128], s_path[BOOK_STORE_PATH_MAX], s_title[128];
static char s_book_title[128];
static char s_chapter_heading_title[128], s_chapter_heading_label[32];
static size_t s_chapter_lead_skip;
static unsigned s_chapter_lead_height;
// 横排题头该占的行高，与当前模式无关地记着：首块是插图时它是 0，
// 切回横排要用它，而不是拿竖排留下的 0 去算。
// The row height a horizontal heading should take, remembered independently of the current mode:
// it is zero when the chapter opens with an illustration, and switching back must use it rather
// than the zero a vertical heading left behind.
static unsigned s_chapter_lead_row_height;
// 竖排首页为题头预留的列宽；横排为 0。/ Columns reserved for a vertical heading; 0 horizontally.
static unsigned s_chapter_lead_width;
static char s_font_path[192];
static char* s_text;
bool app_book_reader_body_visible(void) {
    return s_view == READING && s_text && s_reader_panel == READER_PANEL_NONE && !s_clear_confirm;
}
static blk_t* s_blocks;
// 书内字体的 run 表与块表同生共死：都来自同一次 html_text 解析，排版直接借用。
// The face run table lives and dies with the block table: both come from the same html_text
// parse, and the layout borrows them.
static html_run_t* s_runs;
static size_t s_run_count;
// 上一次排版用的书内字体开关：字体页改过之后，回阅读页要重排当前章才看得出来。
// The embedded-face setting the current layout was built with: after the font page changes
// it, the reader must re-typeset the chapter before the change is visible.
static bool s_book_fonts_applied;
// 字体开关改了之后要重排当前章，但那次重排不能在触摸回调里做：栈太深。
// The font switch needs the current chapter re-typeset, but not from the touch callback: the
// stack there is too deep.
static bool s_fonts_reload_pending;
// 用户主动换字体后连续回退到内建字体的次数；3 次后提示可重启再选（预览/后台重试不计数）。
// Fallbacks after explicit font choices; three in a row offer the restart dialog (previews and
// background retries do not count).
static unsigned s_font_fallbacks;
static bool s_font_choice_pending, s_font_recovery_pending, s_font_restart_pending;
static bool s_font_recovery_save_failed;
static void reader_font_choice_begin(const char *path) {
    if (ttf_font_path_is_builtin(path)) {
        s_font_fallbacks = 0;
        s_font_choice_pending = s_font_recovery_pending = false;
    } else s_font_choice_pending = true;
}
static void reader_font_choice_finish(void) {
    if (!s_font_choice_pending) return;
    s_font_choice_pending = false;
    if (ttf_font_is_builtin()) {
        if (s_font_fallbacks < 3) ++s_font_fallbacks;
        if (s_font_fallbacks == 3) s_font_recovery_pending = true;
    } else if (ttf_font_ready()) s_font_fallbacks = 0;
}
static void reader_font_recovery_reset(void) {
    s_font_fallbacks = 0;
    s_font_choice_pending = s_font_recovery_pending = s_font_restart_pending = false;
    s_font_recovery_save_failed = false;
}
static char** s_images;
static size_t s_image_count;
// PR #7 的当前页图片集合：只保留显示页的灰阶，不限制为八张。
// PR #7's current-page image set retains visible grayscale only, without an eight-image limit.
typedef struct { uint8_t *gray; int width, height; } reader_image_t;
static reader_image_t *s_page_images;
static int s_page_image_count;
static size_t s_page_images_for = SIZE_MAX;
static uint32_t s_page_images_generation;
// 整页插图与正文插图的双指缩放：1000 为原始大小；缩放与位置只属于当时那一页。
// 图像中心用屏幕坐标保存，双指中点既是缩放锚点也是平移把手；单指拖动同样平移。
// Two-finger zoom for whole-page and inline illustrations: 1000 is the original size, and the
// scale plus position belong to the page they were made on. The image centre is kept in screen
// coordinates; the contact midpoint anchors the scale and doubles as the pan handle, and a
// one-finger drag pans as well.
#define READER_IMAGE_ZOOM_MAX 4000
#define READER_IMAGE_ZOOM_MIN 1000
static int s_image_zoom = READER_IMAGE_ZOOM_MIN;
static size_t s_image_zoom_page = SIZE_MAX;
// 正文插图缩放模式：双击正文里的一张图后，单独按整页方式缩放它。
// Inline image zoom mode: after double-tapping an illustration inside the text, that image is
// zoomed as if it were a whole-page sheet.
static bool s_zoom_active;
static int s_zoom_slot = -1;
static int s_image_zoom_cx, s_image_zoom_cy;
static uint32_t s_image_zoom_start_distance;
static int s_image_zoom_start_scale = READER_IMAGE_ZOOM_MIN;
static int s_image_zoom_start_cx, s_image_zoom_start_cy;
static int s_image_zoom_anchor_dx, s_image_zoom_anchor_dy;
static int64_t s_image_zoom_draw_ms;
static bool s_image_zoom_bw;
static bool s_image_pan_active;
static uint16_t s_image_pan_x, s_image_pan_y;
static uint8_t *s_zoom_bits;
static size_t s_zoom_bits_bytes;
// 图文书的相邻页插图预加载：主任务空闲时逐张解码下一页插图到 PSRAM，翻到该页直接接管。
// Illustrated-book preload: decode the neighbouring page's illustrations into PSRAM while idle so a
// turn adopts them instead of reading/decoding media on the spot.
static reader_image_t *s_prefetch_images;
static int s_prefetch_image_count, s_prefetch_image_index;
static size_t s_prefetch_for = SIZE_MAX;
static uint32_t s_prefetch_generation;
static size_t s_prefetch_pixels_left;
static int64_t s_prefetch_next_ms;
static size_t s_block_count;
static size_t s_text_len, s_chapter, s_page;
static size_t s_selected_toc = SIZE_MAX;
static bool s_toc_jump_open, s_toc_jump_drag;
static int s_toc_jump_percent;
static size_t s_jump_offset = SIZE_MAX, s_jump_page;
// 本章跳转草稿：−/+ 与数字键盘只改草稿，按「跳转」才移动阅读位置；撤销保存文字锚点，重排后仍能回到原文。
// Chapter-jump draft: -/+ and the keypad only edit the draft; the reader moves on Jump, and undo keeps
// a text anchor so a reflow still returns to the original text.
static size_t s_chapter_jump_page;
static char s_chapter_jump_digits[16];
static bool s_chapter_jump_replace, s_chapter_jump_error;
static struct {
    bool valid;
    size_t chapter, offset;
    int64_t until_ms;
} s_chapter_jump_undo;
static uint32_t s_file_size;
static int s_px, s_margin, s_line_spacing, s_turns, s_unsaved;
// 当前上下边距，进阅读页时从设置载入；与左右边距 s_margin 分开保存。
// Current vertical margin, loaded from settings on entering the reader; kept apart from the horizontal s_margin.
static int s_margin_v;
static int64_t s_poll_ms, s_last_turn_ms;
static int64_t s_stats_last_ms, s_stats_activity_ms;
static uint32_t s_stats_pending_ms, s_stats_pending_turns;
static uint32_t s_session_read_ms, s_session_turns;
static int s_font_page;
static int s_reader_slider = -1;
static bool s_reader_slider_endpoint;
static int s_reader_preview_px, s_reader_preview_margin, s_reader_preview_line, s_reader_preview_para;
// 拖动第 5 条滑杆时的上下边距预览值，提交后才写设置。
// Vertical-margin preview while the fifth rail is dragged; only the commit writes settings.
static int s_reader_preview_margin_v;
static int s_reader_preview_tracking;
static uint32_t s_recent_days[30];
static bool s_recent_days_valid;
// 本月每日阅读秒数（0..30 对应 1..31 号），用于阅读统计里的月热力图。
// Per-day seconds for the current month (index 0..30 = day 1..31) for the stats heatmap.
static uint32_t s_month_days[31];
static int s_month_year, s_month_month;
static bool s_month_valid;
static char s_reader_notice[64];
static int64_t s_reader_notice_until;
static int s_bookmark_page;
static bool s_bookmark_edit, s_bookmark_delete_confirm, s_bookmark_delete_error;
static uint32_t s_bookmark_selected;
typedef struct { char path[288]; bool is_dir; } reader_background_item_t;
static reader_background_item_t *s_backgrounds;
static int s_background_count, s_background_selected, s_background_page;
#define READER_BACKGROUND_ROWS 7
#define READER_BACKGROUND_MAX 160
static bool s_background_ready;
static char s_background_notice[96];
static char s_background_preview_notice[96];
static bool s_background_prepare_pending;
// 三级菜单：阅读设置 → 阅读背景 → pictures（可进子文件夹）→ 预览。目录用固定深度栈记录，
// 最深 4 层；返回键退一级，根目录再返回回到阅读设置。
// Three-level menu: reading settings -> reading background -> pictures (nested folders allowed)
// -> preview. Folders live in a fixed 4-deep stack; Back pops one level and leaves to the
// reading-settings page from the root.
#define READER_BACKGROUND_DEPTH 4
static char s_background_dir[288] = "/sdcard/pictures";
static char s_background_parent[READER_BACKGROUND_DEPTH][288];
static int s_background_depth;
static EpdRect s_area;
static enum EpdDrawMode s_mode = MODE_GL16;
static bool s_input_settle;
static bool s_reader_cleanup;
static bool s_reader_footer_pending;
static bool s_water_turn_pending;
static e0470_turn_dir_t s_water_turn_dir;
static int s_pressed_control = -1;
static bool s_shelf_feedback_pending;
static bool s_cover_batch_present_pending;
static bool s_shelf_page_pending;
// 长按划线拖动：整行锚点、按整行扩展，松手才写入正式记录；预渲染必须先停。
// Long-press highlight drag: whole-line anchor, whole-line extension, commit on release.
static bool s_hl_drag_active;
static uint32_t s_hl_drag_anchor_start, s_hl_drag_anchor_len;
static uint32_t s_hl_drag_start, s_hl_drag_end;
static int64_t s_hl_drag_next_ms;
// 划线长按在通用 LONG_PRESS（500 ms）之后再等一小会儿才生效，减少误触。
// The highlight starts a little after the generic 500 ms long press to avoid accidental taps.
#define READER_HIGHLIGHT_HOLD_EXTRA_MS 220
static bool s_hl_hold_pending;
static int64_t s_hl_hold_due_ms;
static uint16_t s_hl_hold_x, s_hl_hold_y;
// 从划线列表跳到某条记录前的阅读位置；阅读页底部可一键返回。
// Reading position before jumping from the highlight list; a bottom button returns to it.
static bool s_hl_return_valid;
static uint16_t s_hl_return_chapter;
static uint32_t s_hl_return_offset;
static int s_async_turn;  ///< 推屏期间缓存的阅读页翻页方向（-1 上/左，1 下/右）
// 工具栏「划线」列表页码。/ Page index of the toolbar highlight list.
static int s_highlight_page;
// 书架点书后先给反馈、把打开图书的重活留给 on_tick。
// Shelf taps acknowledge immediately; the heavy book open moves to on_tick.
static bool s_open_pending;
static char s_open_pending_path[BOOK_STORE_PATH_MAX];
static book_reader_tap_t s_reader_tap;
static unsigned s_reader_key_pick;
static char s_reader_key_error[64];
// 手势设置：正在选择动作的槽位与保存失败提示；双指轻点、轻点时间窗与位移容差。
// Gesture sheet: the slot being picked and its save-failure notice, plus the two-finger tap
// recogniser state and its time window / movement tolerance.
static app_gesture_slot_t s_gesture_slot;
static char s_gesture_error[64];
#define READER_TWO_FINGER_MS 600
#define READER_TWO_FINGER_SLOP 24
typedef struct {
    bool armed;      ///< 已见到两指同时按下 / Both fingers seen down together
    bool moved;      ///< 任一手指位移超过容差 / A point moved past the tap tolerance
    int64_t down_ms; ///< 两指按下的时刻 / Timestamp of the two-finger press
    int x0[2], y0[2]; ///< 两指按下起点（逻辑坐标） / Per-point origins in logical coordinates
} reader_two_finger_tap_t;
static reader_two_finger_tap_t s_two_finger_tap;
static int64_t s_du_ms;
static unsigned s_du_count;
static EpdRect s_du_area;
static SemaphoreHandle_t s_draw_lock, s_prep_done;
static TaskHandle_t s_prep_task;
static atomic_bool s_prep_stop;
static book_layout_draw_cursor_t s_prep_cursor;
static uint32_t s_next_generation;
static uint8_t* s_next_fb;
static int s_next_page = -1, s_prep_page = -1;
// 第二页预渲染：主缓冲排好后，空闲时把再下一页排进第二块缓冲，连翻两次都能命中。
// 第二块只在 PSRAM 余量明显足够时分配，离书时释放，不挤占插图与书内字体。
// Second-page prefetch: once the primary buffer is ready, lay the page after next into a second
// buffer while idle so two rapid turns both hit. It is allocated only with generous PSRAM headroom
// and released when the book closes, so illustrations and embedded faces keep their room.
static book_layout_draw_cursor_t s_prep_cursor2;
static uint32_t s_next_generation2;
static uint8_t* s_next_fb2;
static int s_next_page2 = -1, s_prep_page2 = -1;
// 下次翻页方向：预渲染按最近一次翻页方向准备，往回翻也能命中缓存。
// Direction of the next turn: prefetch follows the last turn so backward moves also hit the cache.
static int s_turn_dir = 1;
// 后台预渲染是否已被通知且尚未 join；长按划线前必须停掉它，避免共用布局状态。
// Whether the background prefetcher was notified and not yet joined; highlight drag stops it first.
static bool s_prep_running;

#define s_toolbar (s_reader_panel != READER_PANEL_NONE)

static void render(app_ctx_t* ctx, uint8_t* fb);
static void draw_reader_panel(uint8_t* fb);
static EpdRect reader_slider_rect(int slider);
static void scan_shelf(app_ctx_t* ctx);
static void copy_text(char* dst, size_t cap, const char* src);
static void fit_text(char* text, int px, int width);
static void free_book(void);
static void save_progress(void);
static void invalidate_prep(void);
static void prepare_inline_image(void);
static void draw_panel_sheet_landscape(uint8_t* fb, const char* title);
static EpdRect reading_done_rect(void);
static void release_page_images(void);
static void release_prefetch_images(void);
static void reader_prefetch_stop(void);
static uint8_t *alloc_page_bitmap(int *width, int *height, size_t *pixels);
static void sort_shelf(app_ctx_t* ctx);
static void prepare_covers(app_ctx_t* ctx);
static int leaves(void);
// 首页预热在打开图书/退出应用/换卡时必须立刻收手（定义在书架扫描一节）。
// Home prewarm must stand down immediately when a book opens, the app exits or the card changes
// (defined in the shelf-scan section).
static void shelf_prewarm_abort(void);
static app_redraw_t toggle_reader_fullscreen(app_ctx_t* ctx);
// 手势动作派发与正文滑动映射：定义在按键动作附近，先声明给 panel 点击与手势入口使用。
// Gesture action dispatch and body-swipe mapping; forward-declared for the panel tap handler
// and the gesture entry, which are defined earlier in the file.
static app_redraw_t reader_gesture_action(app_ctx_t *ctx, app_gesture_action_t action);
static app_redraw_t reader_gesture_swipe(app_ctx_t *ctx, const ui_gesture_event_t *ev);
// 手势入口卡画在按键控制页里，绘制定义在手势页附近，先声明给它用。
// The gesture entry card is painted inside the key sheet but defined beside the gesture sheets.
static void draw_gesture_entry(uint8_t *fb);
// Markdown 重排即重解析：按重排前的页首输出偏移重载本章（仅 Markdown 生效，定义在 load_chapter 后）。
// Markdown re-layout re-parse: reload the chapter at the pre-layout page-start output offset;
// Markdown only, defined next to load_chapter.
static bool reader_md_reload_at(app_ctx_t *ctx, size_t offset);
// 字体异常提示：绘制/手势/定时器都定义在页面主循环附近，这里先声明给 render/gesture/on_key 用。
// Font-recovery dialog: drawing, gestures and tick live near the page loop; forward-declared for
// render/gesture/on_key.
static void draw_font_recovery(uint8_t *fb);
static app_redraw_t reader_font_recovery_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev);
static app_redraw_t reader_font_recovery_tick(app_ctx_t *ctx);
static void before_lock(app_ctx_t *ctx);
// 插图缩放状态收尾：定义在插图绘制一节，切视图/锁屏/离页等入口要先声明。
// Tear down the illustration-zoom state; defined beside the illustration painting code and
// forward-declared for the view/lock/exit entries that run earlier in the file.
static void reader_zoom_reset(void);
bool app_book_request_open(const char* path) {
    if (!path || !path[0] || strnlen(path, sizeof(s_requested_open)) >= sizeof(s_requested_open)) return false;
    if (!book_file_path_supported(path)) return false;
    copy_text(s_requested_open, sizeof(s_requested_open), path);
    s_requested_open_home = false;
    s_requested_fullscreen = true;
    return true;
}
bool app_book_request_open_from_home(const char* path) {
    if (!app_book_request_open(path)) return false;
    s_requested_open_home = true;
    return true;
}
bool app_book_request_resume(const char *path, bool fullscreen) {
    if (!app_book_request_open_from_home(path)) return false;
    s_requested_fullscreen = fullscreen;
    return true;
}
bool app_book_resume_context(char *path, size_t capacity, bool *fullscreen) {
    if (!s_text || !s_path[0] || s_view == SHELF || s_view == MANAGE || s_view == BULK ||
        !path || !fullscreen || strlen(s_path) >= capacity || s_save_failed) return false;
    copy_text(path, capacity, s_path);
    *fullscreen = s_reader_fullscreen;
    return true;
}
// 自动恢复 SD 前的静默判断：SD 上的书还开着时 book_txt/zip 会一直持有 FILE*，不能卸载重挂。
// Media-recovery gate: while an SD book is open, book_txt/zip keeps a FILE handle, so the card
// must not be unmounted for an automatic remount.
bool app_book_media_idle(void) {
    return !s_text || !s_path[0] || strncmp(s_path, "/sdcard/", 8) != 0;
}
void app_book_request_manage(void) { s_requested_manage = true; }
static void draw_control(uint8_t* fb, EpdRect rect, const char* label, int id) {
    if (id == 112 && s_query[0]) {
        ui_fill_round_rect(fb, rect, UI_BTN_RADIUS, UI_GRAY_BLACK);
        ui_text_vc(fb, rect.x + rect.width / 2, rect.y + rect.height / 2,
                   UI_PX_BTN, label, EPD_DRAW_ALIGN_CENTER, true);
        return;
    }
    if (s_pressed_control == id) ui_draw_pressed_round_rect(fb, rect, UI_BTN_RADIUS);
    ui_draw_button(fb, rect, label, false);
}
static void lock_draw(void) { if (s_draw_lock) xSemaphoreTake(s_draw_lock, portMAX_DELAY); }
static void unlock_draw(void) { if (s_draw_lock) xSemaphoreGive(s_draw_lock); }
static size_t fb_bytes(void) { return (size_t)epd_width() * epd_height() / 2; }
#define READER_FULLSCREEN_PROGRESS_TOP (UI_LOCK_HEIGHT - 12)
// 横屏阅读页 chrome：顶部系统状态带 / 阅读题头带 / 底部章节页码进度带。
// Landscape reader chrome: system status band, reader header band, footer info band.
#define READER_LANDSCAPE_STATUS_H 48
#define READER_LANDSCAPE_HEADER_H 48
#define READER_LANDSCAPE_FOOTER_H 56
// chrome 与正文之间的呼吸空间。
// Breathing space between chrome and the body band.
#define READER_LANDSCAPE_CHROME_GAP 12
// ---- adaptive reading direction ----
// In landscape the logical canvas becomes 1216x684. Touch still reports portrait
// logical coordinates, so hit tests map them onto the current orientation first.
static int reader_scr_w(void) { return epd_rotated_display_width(); }
static int reader_scr_h(void) { return epd_rotated_display_height(); }
// Full canvas in the live orientation. Every reader refresh that used to hard-code the
// portrait screen must go through this, otherwise landscape drives only part of the panel.
static EpdRect reader_full_rect(void) { return (EpdRect){0, 0, reader_scr_w(), reader_scr_h()}; }
// ---- 横屏阅读页 chrome 几何 / Landscape reader chrome geometry ----
// 横屏全屏且沉浸时状态栏隐藏（与 reader_status_visible 的规则一致）。
// The status band hides in landscape full screen + immersive, matching reader_status_visible.
static bool reader_landscape_status_hidden(void) {
    return s_reader_fullscreen && app_settings_reader_immersive();
}
// 横屏顶部需要让出的 chrome 高度：状态带 + （非全屏时）题头带。与面板是否打开无关，
// 保证排版几何在开/关面板时稳定，不会因面板状态改变分页。
// Top chrome height in landscape: status band plus the header band when not full screen. It does
// not depend on any panel, so pagination stays stable while sheets open and close.
static int reader_landscape_chrome_height(void) {
    int h = 0;
    if (!reader_landscape_status_hidden()) h += READER_LANDSCAPE_STATUS_H;
    if (!s_reader_fullscreen) h += READER_LANDSCAPE_HEADER_H;
    return h;
}
static EpdRect reader_landscape_status_rect(void) {
    return (EpdRect){0, 0, reader_scr_w(), READER_LANDSCAPE_STATUS_H};
}
static EpdRect reader_landscape_header_rect(void) {
    return (EpdRect){0, READER_LANDSCAPE_STATUS_H, reader_scr_w(), READER_LANDSCAPE_HEADER_H};
}
static EpdRect reader_landscape_footer_rect(void) {
    return (EpdRect){0, reader_scr_h() - READER_LANDSCAPE_FOOTER_H,
                     reader_scr_w(), READER_LANDSCAPE_FOOTER_H};
}
// 命中区与绘制/点击反馈区同源：横屏返回键调用 ui_nav_back(fb, 24, 38)，
// 其点击反馈区 = (24-10, 38+3, 64, 64) = {14, 41, 64, 64}。
// Hit rects share the paint/click-feedback origin: ui_nav_back(fb, 24, 38) registers
// (24-10, 38+3, 64, 64).
static EpdRect reader_landscape_back_hit(void) { return (EpdRect){14, 41, 64, 64}; }
static EpdRect reader_landscape_favorite_hit(void) {
    return (EpdRect){reader_scr_w() - 96, READER_LANDSCAPE_STATUS_H - 4, 64, 56};
}
static bool reader_landscape_rot(int mode) {
    return mode == EPD_ROT_LANDSCAPE || mode == EPD_ROT_INVERTED_LANDSCAPE;
}
// Only a body page that owns the whole screen follows gravity; the landscape-aware sheets below
// follow it too, since each one now lays itself out from the live canvas. Panels outside the
// whitelist keep the portrait sheet.
// 只有占满屏幕的正文页跟随重力；下面列出的已适配面板也会跟随，因为它们都按当前画布排版。
// 不在白名单里的面板仍保持竖屏抽屉。
static bool reader_orient_body(void) {
    // The tool bar, every converted reader sheet and the background pickers stay in landscape;
    // their paint and hit-test geometry is orientation-aware.
    // 工具栏、所有已转换的阅读面板和背景选择页保持横屏，绘制与命中几何都区分方向。
    return app_settings_reader_adaptive() && s_view == READING && s_text &&
           (s_reader_panel == READER_PANEL_NONE || s_reader_panel == READER_PANEL_TOOLS ||
            s_reader_panel == READER_PANEL_REFRESH_SETTINGS || s_reader_panel == READER_PANEL_STATS ||
            s_reader_panel == READER_PANEL_BOOKMARKS || s_reader_panel == READER_PANEL_STATS_RECENT ||
            s_reader_panel == READER_PANEL_CHAPTER_JUMP ||
            s_reader_panel == READER_PANEL_HIGHLIGHTS ||
            s_reader_panel == READER_PANEL_FONT_SETTINGS ||
            s_reader_panel == READER_PANEL_TURN_SETTINGS ||
            s_reader_panel == READER_PANEL_KEY_SETTINGS ||
            s_reader_panel == READER_PANEL_KEY_PICKER ||
            s_reader_panel == READER_PANEL_GESTURE ||
            s_reader_panel == READER_PANEL_GESTURE_PICKER ||
            s_reader_panel == READER_PANEL_WEIGHT_SETTINGS ||
            s_reader_panel == READER_PANEL_LAYOUT_SETTINGS ||
            s_reader_panel == READER_PANEL_RULE_SETTINGS ||
            s_reader_panel == READER_PANEL_FONT_PICKER ||
            s_reader_panel == READER_PANEL_BACKGROUND ||
            s_reader_panel == READER_PANEL_BACKGROUND_PREVIEW ||
            s_reader_panel == READER_PANEL_BACKGROUND_MENU) &&
           !s_clear_confirm && !s_category_menu && !s_scan_pending;
}
static void reader_touch_map(int* x, int* y) {
    const int tx = *x, ty = *y;
    switch (s_reader_rot) {
        case EPD_ROT_LANDSCAPE:          *x = ty;        *y = 683 - tx;  break;
        case EPD_ROT_INVERTED_LANDSCAPE: *x = 1215 - ty; *y = tx;        break;
        case EPD_ROT_PORTRAIT:           *x = 683 - tx;  *y = 1215 - ty; break;
        default: break;  // INVERTED_PORTRAIT: factory portrait, touch is already logical
    }
}
// 触摸芯片上报的是工厂竖屏逻辑坐标；只要当前旋转不是工厂竖屏（横屏或 180° 倒置竖屏），
// 都必须先映射到当前逻辑坐标再做命中，否则 180° 时上下/左右翻页方向会整体反掉。
// Touch reports factory-portrait logical coordinates; any rotation other than the factory
// portrait (landscape or 180-degree portrait) must be mapped before hit testing, otherwise every
// page-turn direction flips when the device is held upside down.
static bool reader_touch_needs_map(void) {
    return s_reader_rot != EPD_ROT_INVERTED_PORTRAIT;
}
// 正文上方留出一致的呼吸空间，下沿靠近进度区；两种模式共用排版与刷新边界。
// Give the body a consistent top inset and extend it toward the progress strip in both modes.
static EpdRect reader_area(void) {
    if (s_reader_landscape)
        return reader_full_rect();
    const int top = s_reader_fullscreen ? (app_settings_reader_immersive() ? 0 : 80) : 160;
    // Keep text layout outside the progress strip; a fused text turn drives only changed progress pixels.
    const int bottom = s_reader_fullscreen ? READER_FULLSCREEN_PROGRESS_TOP : UI_BAR_TOP + 8;
    return (EpdRect){0, top, UI_LOCK_WIDTH, bottom - top};
}
static EpdRect reader_fullscreen_progress_area(void) {
    if (s_reader_landscape)
        return (EpdRect){0, reader_scr_h() - 12, reader_scr_w(), 12};
    return (EpdRect){0, READER_FULLSCREEN_PROGRESS_TOP,
                     UI_LOCK_WIDTH, UI_LOCK_HEIGHT - READER_FULLSCREEN_PROGRESS_TOP};
}
static EpdRect body_rect_for_tracking(int tracking_index) {
    // 先按方向和全屏状态求出基准上下沿，最后统一套一次上下边距。
    // Derive the baseline top/bottom edges from orientation and full-screen mode, then apply the
    // vertical margin once at the end.
    int left, right, top, bottom;
    if (s_reader_landscape) {
        // Same margin ladder and type size as portrait; the narrower height simply fits fewer
        // lines per page and each line is wider. Pagination, antialiasing and refresh are the
        // untouched original paths.
        int margin = s_margin < 24 ? 24 : s_margin;
        // 非全屏：状态带+题头带之后留 12px；全屏：只让出可见状态带或完全让出（沉浸）。
        // Not full screen: status + header bands plus 12 px; full screen: status only, or nothing
        // in immersive mode.
        const int chrome = reader_landscape_chrome_height();
        top = chrome ? chrome + READER_LANDSCAPE_CHROME_GAP : 32;
        // 非全屏底部有页码/章节/进度带，正文止于其上 8px；全屏沿用原来的底边。
        // Not full screen reserves the footer info band above the bottom edge; full screen keeps
        // the original bottom edge.
        bottom = s_reader_fullscreen ? reader_scr_h() - 14
                                     : reader_scr_h() - READER_LANDSCAPE_FOOTER_H - 8;
        left = margin;
        right = reader_scr_w() - margin;
    } else {
        int margin = s_margin;
        top = s_reader_fullscreen ? (app_settings_reader_immersive() ? 24 : 96) : 188;
        // Leave only a narrow strip for the full-book progress line in full screen.
        bottom = s_reader_fullscreen ? READER_FULLSCREEN_PROGRESS_TOP - 2 : UI_BAR_TOP + 8;
        (void)tracking_index;
        if (app_settings_book_vertical()) {
            // 竖排沿用左右边距当作上下内缩，再叠加独立的上下边距。
            // Vertical text keeps the old margin as a top/bottom inset, with the vertical margin on top.
            top += margin;
            bottom -= margin;
            left = 24;
            right = UI_LOCK_WIDTH - 24;
        } else {
            // Preserve each margin in pixels; justification distributes the remaining line width.
            left = margin;
            right = UI_LOCK_WIDTH - margin;
        }
    }
    // 上下边距夹到正文带一半以内，至少保留 1 像素高度，极端档位也压不没正文。
    // Clamp the vertical margin below half the band so at least one pixel row survives at every stop.
    int v = s_margin_v;
    int span = bottom - top;
    if (v > (span - 1) / 2) v = (span - 1) / 2;
    if (v < 0) v = 0;
    return (EpdRect){left, top + v, right - left, span - 2 * v};
}
static EpdRect body_rect(void) {
    return body_rect_for_tracking(app_settings_book_tracking());
}
static int reader_margin_width(int margin, int px, int tracking_px) {
    (void)px; (void)tracking_px;
    return UI_LOCK_WIDTH - 2 * margin;
}
static int reader_margin_levels(int px, int tracking_px,
                                int widths[BOOK_MARGIN_CHOICES], int values[BOOK_MARGIN_CHOICES]) {
    int count = 0;
    for (int i = 0; i < BOOK_MARGIN_CHOICES; ++i) {
        int value = BOOK_MARGIN_MIN + i * 6;
        int width = reader_margin_width(value, px, tracking_px);
        if (!count || widths[count-1] != width) {
            widths[count] = width;
            values[count++] = value;
        } else if (count > 1 && abs(value - 24) < abs(values[count-1] - 24)) {
            values[count-1] = value;
        }
    }
    // 同字格宽度只显示一个档位；极值仍到0/48，已有边距不因重画滑杆改写。
    // Show one stop per distinct column width, retaining the 0/48 extremes and existing saved margins.
    values[0] = BOOK_MARGIN_MIN;
    if (count > 1) values[count-1] = BOOK_MARGIN_MAX;
    return count;
}
static int reader_margin_level_for(int margin, int px, int tracking_px) {
    if (margin < BOOK_MARGIN_MIN) margin = BOOK_MARGIN_MIN;
    if (margin > BOOK_MARGIN_MAX) margin = BOOK_MARGIN_MAX;
    int widths[BOOK_MARGIN_CHOICES], values[BOOK_MARGIN_CHOICES];
    int count = reader_margin_levels(px, tracking_px, widths, values);
    int width = reader_margin_width(margin, px, tracking_px);
    for (int i = 0; i < count; ++i) if (width >= widths[i]) return i;
    return count - 1;
}
static int reader_margin_for_level(int level, int current, int px, int tracking_px) {
    int widths[BOOK_MARGIN_CHOICES], values[BOOK_MARGIN_CHOICES];
    int count = reader_margin_levels(px, tracking_px, widths, values);
    if (level < 0) level = 0;
    if (level >= count) level = count - 1;
    return level == reader_margin_level_for(current, px, tracking_px) ? current : values[level];
}
static EpdRect progress_rect(void) {
    // 阅读页没有右侧菜单按钮；进度信息应和页眉分隔线一样铺满内容宽度。
    // The reader has no right-hand menu button; the footer spans the full content width.
    return (EpdRect){36, UI_BAR_TOP, UI_LOCK_WIDTH - 72, UI_BAR_H};
}
static int shelf_rows(void) { return s_view == SHELF && app_settings_shelf_style() == 5 ? 4 : BOOK_GRID_ROWS; }
#define SHELF_BOOK_LIFT_PX 16
#define SHELF_LIST_BOUNCE_PX 8
#define SHELF_FAST_COVER_WIDTH 164
#define SHELF_FAST_COVER_HEIGHT 214
#define SHELF_FAST_COVER_STRIDE ((SHELF_FAST_COVER_WIDTH + 7) / 8)
#define SHELF_FAST_COVER_BYTES (SHELF_FAST_COVER_STRIDE * SHELF_FAST_COVER_HEIGHT)
#define SHELF_FAST_CACHE_RESERVE (512u * 1024u)
#define SHELF_GUARD_CACHE_BYTES (644u * 90u / 2u)
typedef struct { EpdRect rect; int rotation, contrast; bool binary, valid; } shelf_guard_key_t;
static uint8_t *s_guard_cache;
static shelf_guard_key_t s_guard_keys[3];
static bool s_guard_cache_attempted;
static void release_guard_cache(void) {
    free(s_guard_cache); s_guard_cache=NULL; s_guard_cache_attempted=false;
    memset(s_guard_keys,0,sizeof(s_guard_keys));
}
// 缓存精确的输入和成品；逐行比对底图，任何封面、位置或模式变化均重绘。
// Cache exact inputs and finished pixels; compare every input row so art, position and mode changes redraw.
static void draw_shelf_guard(uint8_t *fb,EpdRect rect,int slot) {
    const bool binary=s_view==SHELF&&app_settings_main_fast_refresh();
    EpdRect p=ui_rotate_rect_to_fb(rect);
    const bool fits=slot>=0&&slot<3&&!(p.x&1)&&!(p.width&1)&&p.x>=0&&p.y>=0&&
        p.x+p.width<=epd_width()&&p.y+p.height<=epd_height()&&
        (size_t)p.width*p.height/2<=SHELF_GUARD_CACHE_BYTES;
    if(fits&&!s_guard_cache&&!s_guard_cache_attempted) {
        s_guard_cache_attempted=true;
        size_t bytes=6u*SHELF_GUARD_CACHE_BYTES;
        if(heap_caps_get_free_size(MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)>=bytes+2u*1024u*1024u)
            s_guard_cache=heap_caps_malloc(bytes,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    }
    if(!fits||!s_guard_cache){ui_draw_acrylic_guard(fb,rect);if(binary)ui_acrylic_bw_rect(fb,rect);return;}
    shelf_guard_key_t *key=&s_guard_keys[slot];
    size_t stride=(size_t)epd_width()/2,span=(size_t)p.width/2;
    uint8_t *input=s_guard_cache+2u*slot*SHELF_GUARD_CACHE_BYTES,*output=input+SHELF_GUARD_CACHE_BYTES;
    bool same=key->valid&&key->rotation==epd_get_rotation()&&key->contrast==app_settings_system_contrast()&&
        key->binary==binary&&!memcmp(&key->rect,&rect,sizeof(rect));
    for(int y=0;same&&y<p.height;++y)
        same=!memcmp(fb+(size_t)(p.y+y)*stride+p.x/2,input+(size_t)y*span,span);
    if(!same) {
        key->valid=false;
        for(int y=0;y<p.height;++y)memcpy(input+(size_t)y*span,fb+(size_t)(p.y+y)*stride+p.x/2,span);
        ui_draw_acrylic_guard(fb,rect);if(binary)ui_acrylic_bw_rect(fb,rect);
        for(int y=0;y<p.height;++y)memcpy(output+(size_t)y*span,fb+(size_t)(p.y+y)*stride+p.x/2,span);
        *key=(shelf_guard_key_t){.rect=rect,.rotation=epd_get_rotation(),.contrast=app_settings_system_contrast(),.binary=binary,.valid=true};
    } else for(int y=0;y<p.height;++y)memcpy(fb+(size_t)(p.y+y)*stride+p.x/2,output+(size_t)y*span,span);
}
static EpdRect row_rect(int row) {
    if (s_view == SHELF && app_settings_shelf_style() == 5)
        return (EpdRect){36, 184 + row * 197, 612, 197};
    if (s_view != BULK) {
        int col = row % 3, line = row / 3;
        int cell = (ui_content_width() - 2 * UI_GAP) / 3;
        return (EpdRect){UI_MARGIN + col * (cell + UI_GAP), (s_view == SHELF ? 192 : 224) + line * 282, cell, 260};
    }
    return (EpdRect){UI_MARGIN, 308 + row * (UI_BTN_H + UI_GAP), ui_content_width(), UI_BTN_H};
}
static EpdRect shelf_cover_image(int row) {
    EpdRect card = row_rect(row);
    if (s_view != SHELF || app_settings_shelf_style() != 5)
        return (EpdRect){card.x + (card.width - 164) / 2, card.y, 164, 214};
    // 列表所有封面统一尺寸；原图按比例铺满并居中裁切。/ Uniform list boxes use aspect fill and center crop.
    return (EpdRect){71, card.y + (197-156)/2, 120, 156};
}
static unsigned s_cover_generation;
static void invalidate_covers(void) {
    book_cover_jobs_cancel(s_cover_generation);s_cover_generation=0;
    release_guard_cache();
    s_cover_pending_mask = s_cover_decode_mask = s_cover_warm_mask = 0;
    s_cover_dirty_mask = s_cover_present_mask = 0;
    for (int i = 0; i < BOOK_ROWS; ++i) {
        free(s_covers[i].gray);
        free(s_covers[i].fast_bits);
        s_covers[i].gray = NULL;
        s_covers[i].fast_bits = NULL;
        s_covers[i].index = -1;
    }
}
static void release_fast_covers(void) {
    for (int i=0;i<BOOK_ROWS;++i) {
        free(s_covers[i].fast_bits);
        s_covers[i].fast_bits=NULL;
    }
}
static bool fast_cover_matches(int row, EpdRect image) {
    return s_covers[row].fast_bits && s_covers[row].fast_contrast==app_settings_system_contrast() &&
        s_covers[row].fast_phase==((image.x&3)|((image.y&3)<<2));
}
static bool cover_favorite_needs_white_edge(const uint8_t *gray, EpdRect image, unsigned sw, unsigned sh);
static void prepare_fast_covers(void) {
    // 转换成功即释放灰阶；不释放仍有效的黑白缓存，避免重复切页重新解码。
    // Release gray immediately after conversion, retaining valid packed artwork across tab changes.
    if (s_view != SHELF || !app_settings_main_fast_refresh()) { release_fast_covers(); return; }
    for (int row = 0; row < BOOK_ROWS; ++row) {
        if (!s_covers[row].gray) continue;
        EpdRect image = shelf_cover_image(row);
        if (row < shelf_rows() && row < BOOK_GRID_ROWS && !fast_cover_matches(row, image)) {
            free(s_covers[row].fast_bits); s_covers[row].fast_bits = NULL;
            // 转换后回收的灰阶空间也计入保留量；内存不足时显示标题，不长期保留灰阶副本。
            // Count reclaimed gray toward the reserve; on OOM show a title rather than retain a gray duplicate.
            size_t free_after = heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT) + BOOK_COVER_W * BOOK_COVER_H;
            uint8_t *bits = free_after >= SHELF_FAST_CACHE_RESERVE + SHELF_FAST_COVER_BYTES
                ? heap_caps_calloc(1, SHELF_FAST_COVER_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT) : NULL;
            if (bits) {
                unsigned sw = app_settings_shelf_style() == 5 ? s_covers[row].width : BOOK_COVER_W;
                unsigned sh = app_settings_shelf_style() == 5 ? s_covers[row].height : BOOK_COVER_H;
                book_crop_t crop = book_cover_crop(sw, sh, image.width, image.height);
                unsigned sample_x[SHELF_FAST_COVER_WIDTH];
                uint8_t tones[256];
                for(int x=0;x<image.width;++x)sample_x[x]=crop.x+(uint64_t)(unsigned)x*crop.width/(unsigned)image.width;
                for(unsigned v=0;v<256;++v)tones[v]=(ui_contrast_gray((uint8_t)v)>>4)*17u;
                for (int y = 0; y < image.height; ++y) {
                    const unsigned sy = crop.y + (uint64_t)(unsigned)y * crop.height / (unsigned)image.height;
                    for (int x = 0; x < image.width; ++x) {
                        const unsigned sx = sample_x[x];
                        uint8_t tone = tones[s_covers[row].gray[sy * sw + sx]];
                        if (ui_image_dither_cover_bw(tone, image.x + x, image.y + y))
                            bits[y * SHELF_FAST_COVER_STRIDE + x / 8] |= (uint8_t)(1u << (x & 7));
                    }
                }
                s_covers[row].fast_white_edge = cover_favorite_needs_white_edge(s_covers[row].gray, image, sw, sh);
                s_covers[row].fast_bits = bits;
                s_covers[row].fast_contrast = app_settings_system_contrast();
                s_covers[row].fast_phase = (image.x & 3) | ((image.y & 3) << 2);
            }
        }
        free(s_covers[row].gray); s_covers[row].gray = NULL;
    }
}
void app_book_cover_mode_changed(void) { invalidate_covers(); }
static uint8_t* load_cover_gray(const char* source, const char* title, const char* author,
                                bool decode, bool* pending) {
    *pending = false;
    if (!pico_boot_asset_allowed(source)) return NULL;
    uint8_t* gray = heap_caps_malloc(BOOK_COVER_W * BOOK_COVER_H, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!gray) return NULL;
    if (!book_cover_load_gray(source, title, author, gray, decode, pending)) {
        free(gray); return NULL;
    }
    return gray;
}
static uint8_t *load_shelf_cover_gray(int row, const char *source, const char *title,
                                      const char *author, bool decode, bool *pending) {
    if (s_view != SHELF || app_settings_shelf_style() != 5)
        return load_cover_gray(source, title, author, decode, pending);
    *pending = false;
    if (!pico_boot_asset_allowed(source)) return NULL;
    s_covers[row].width = BOOK_COVER_W; s_covers[row].height = BOOK_COVER_H;
    uint8_t *gray = heap_caps_malloc(BOOK_COVER_W * BOOK_COVER_H, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (gray && !book_cover_load_list_gray(source, title, author, gray, decode, pending,
                                          &s_covers[row].width, &s_covers[row].height)) {
        free(gray); gray = NULL;
    }
    return gray;
}

// 直接读最终点阵：不分配灰阶工作区，也不在每次书架切页重新转换。
// Read the finished raster: no gray workspace or repeated conversion on shelf paging.
static bool load_shelf_cover_fast(int row, int index) {
    if (s_view != SHELF || !app_settings_main_fast_refresh() || row >= BOOK_GRID_ROWS ||
        !pico_boot_asset_allowed(s_shelf[index].path)) return false;
    EpdRect image = shelf_cover_image(row);
    size_t bytes = (size_t)SHELF_FAST_COVER_STRIDE * image.height;
    if (bytes > SHELF_FAST_COVER_BYTES || heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)
        < SHELF_FAST_CACHE_RESERVE + SHELF_FAST_COVER_BYTES) return false;
    uint8_t *bits = heap_caps_calloc(1, SHELF_FAST_COVER_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!bits) return false;
    book_fast_cover_key_t key = {(unsigned)image.width, (unsigned)image.height, SHELF_FAST_COVER_STRIDE,
        app_settings_system_contrast(), (image.x&3)|((image.y&3)<<2)};
    bool edge;
    if (!book_cover_fast_cache_read(s_shelf[index].path, s_shelf[index].name, s_shelf[index].author,
                                   key, bits, &edge)) { free(bits); return false; }
    s_covers[row].fast_bits = bits; s_covers[row].fast_white_edge = edge;
    s_covers[row].fast_contrast = key.contrast; s_covers[row].fast_phase = key.phase;
    return true;
}
static void save_shelf_cover_fast(int row, int index) {
    if (!s_covers[row].fast_bits) return;
    EpdRect image = shelf_cover_image(row);
    book_fast_cover_key_t key = {(unsigned)image.width, (unsigned)image.height, SHELF_FAST_COVER_STRIDE,
        s_covers[row].fast_contrast, s_covers[row].fast_phase};
    book_cover_fast_cache_write(s_shelf[index].path, s_shelf[index].name, s_shelf[index].author,
                                key, s_covers[row].fast_bits, s_covers[row].fast_white_edge);
}

static unsigned prepare_cover_batch(app_ctx_t *ctx,bool cache_only) {
    if((s_view!=SHELF&&s_view!=MANAGE)||(!cache_only&&ctx->touch&&ctx->touch->touched))return 0;
    unsigned changed=0;
    for(int row=0;row<shelf_rows();++row){
        unsigned bit=1u<<row;if(!(s_cover_pending_mask&bit))continue;
        if(s_view==SHELF&&app_poll_main_navigation(ctx))return changed;
        int index=ctx->leaf*shelf_rows()+row;
        if(index<0||index>=s_visible_count||s_covers[row].index!=index||s_shelf[index].removed){s_cover_pending_mask&=~bit;continue;}
        EpdRect image=shelf_cover_image(row);
        book_cover_job_t request={.list=s_view==SHELF&&app_settings_shelf_style()==5,
            .fast=s_view==SHELF&&app_settings_main_fast_refresh(),.width=image.width,.height=image.height,
            .stride=SHELF_FAST_COVER_STRIDE,.contrast=app_settings_system_contrast(),
            .phase=(image.x&3)|((image.y&3)<<2),.x=image.x,.y=image.y};
        copy_text(request.path,sizeof(request.path),s_shelf[index].path);
        copy_text(request.title,sizeof(request.title),s_shelf[index].name);
        copy_text(request.author,sizeof(request.author),s_shelf[index].author);
        if(!s_cover_generation)s_cover_generation=book_cover_jobs_begin();
        if(!book_cover_jobs_submit(s_cover_generation,row,&request)){
            s_cover_generation=book_cover_jobs_begin();
            if(!book_cover_jobs_submit(s_cover_generation,row,&request)){s_cover_pending_mask&=~bit;continue;}
        }
        book_cover_result_t result={0};int state=book_cover_jobs_take(s_cover_generation,row,&result);
        if(!state)continue;
        s_cover_pending_mask&=~bit;s_cover_decode_mask&=~bit;
        if(state<0)continue;
        free(s_covers[row].gray);free(s_covers[row].fast_bits);
        s_covers[row].gray=result.fast?NULL:result.pixels;
        s_covers[row].fast_bits=result.fast?result.pixels:NULL;
        s_covers[row].width=result.width;s_covers[row].height=result.height;
        s_covers[row].fast_white_edge=result.white_edge;
        s_covers[row].fast_contrast=request.contrast;s_covers[row].fast_phase=request.phase;
        changed|=bit;s_cover_dirty_mask|=bit;
    }
    return changed;
}

// 逐行显示：某一行封面解码完成就画那一行，不再等整页全部解码完。
// 二级书架切换时冷解码慢，整组等待会让用户盯着占位图很久。
// Reveal row by row: a decoded cover appears immediately instead of waiting for the whole page
// group (secondary-shelf switches used to stare at placeholders while every cover decoded).
static unsigned shelf_cover_reveal_mask(void) {
    const unsigned ready_rows = s_cover_dirty_mask & ~s_cover_pending_mask;
    return s_view == SHELF ? ready_rows : s_cover_dirty_mask;
}

static void prepare_covers(app_ctx_t* ctx) {
    if (s_view != SHELF && s_view != MANAGE) return;
    int rows = shelf_rows();
    if (s_covers[0].index != ctx->leaf * rows) {
        book_cover_jobs_cancel(s_cover_generation);s_cover_generation=book_cover_jobs_begin();
        // 换页先退掉相邻页预取，别和本页封面抢解码任务。
        // Cancel the neighbouring-page preload so it cannot compete with this page's covers.
        if (s_pf_cover_generation) { book_cover_jobs_cancel(s_pf_cover_generation); s_pf_cover_generation=0; }
        s_pf_cover_pending_mask = 0; s_pf_cover_leaf = -1;
        s_cover_pending_mask = s_cover_decode_mask = s_cover_warm_mask = 0;
        s_cover_dirty_mask = s_cover_present_mask = 0;
    }
    for (int row = 0; row < rows; ++row) {
        int index = ctx->leaf * rows + row;
        EpdRect image = shelf_cover_image(row);
        bool packed = s_view == SHELF && app_settings_main_fast_refresh();
        if (s_covers[row].index == index &&
            (packed ? fast_cover_matches(row, image) : s_covers[row].gray != NULL)) continue;
        if (s_covers[row].index == index && !s_covers[row].gray && !s_covers[row].fast_bits) continue;
        free(s_covers[row].gray); free(s_covers[row].fast_bits);
        s_covers[row].gray = s_covers[row].fast_bits = NULL;
        s_covers[row].index = index;
        s_cover_dirty_mask &= ~(1u<<row);
        if (index >= s_visible_count || index < 0 || s_shelf[index].removed) continue;
        // Queue each slot, then gather cheap disk-cache hits before painting; decode misses later.
        s_cover_pending_mask |= 1u << row;
        s_cover_warm_mask |= 1u << row;
        s_cover_warm_after_ms = ctx->now_ms + 1500;
    }
    prepare_fast_covers();
    (void)prepare_cover_batch(ctx, true);
}

// 首帧短暂汇合TF缓存命中，让题头、书架和封面一起显示；冷解码不无限阻塞。
// Briefly gather warm TF hits for a complete first frame; never wait indefinitely for cold decoding.
static void gather_cover_entry(app_ctx_t *ctx) {
    if(s_view!=SHELF||!s_cover_pending_mask||ctx->request_app||
       (s_presented_view==(int)SHELF&&!s_shelf_page_pending))return;
    const int64_t deadline=esp_timer_get_time()+60000;
    while(s_cover_pending_mask&&esp_timer_get_time()<deadline){
        if(app_poll_main_navigation(ctx))return;
        vTaskDelay(1);
        (void)prepare_cover_batch(ctx,true);
        if(ctx->request_app)return;
    }
}

// 画面和操作优先，预生成只在封面加载完、无触摸的空闲书架运行一次一本。
// Present and input take priority; warm one cover only on an idle shelf after visible loading completes.
static void warm_shelf_lock_cover(app_ctx_t *ctx) {
    if (s_view != SHELF || app_settings_lock_style() != 2 || s_clear_confirm || s_batch_confirm ||
        s_cover_pending_mask || !s_cover_warm_mask || ctx->now_ms < s_cover_warm_after_ms ||
        (ctx->touch && ctx->touch->touched) || ctx->request_app || ctx->request_return || ctx->request_menu) return;
    if (app_poll_main_navigation(ctx)) return;
    for (int row = 0; row < shelf_rows(); ++row) {
        const unsigned bit = 1u << row;
        if (!(s_cover_warm_mask & bit)) continue;
        s_cover_warm_mask &= ~bit; s_cover_warm_after_ms = ctx->now_ms + 1000;
        int index = ctx->leaf * shelf_rows() + row;
        if (index >= 0 && index < s_visible_count && s_covers[row].index == index && !s_shelf[index].removed)
            (void)book_lock_collage_warm_cover(s_shelf[index].path);
        (void)app_poll_main_navigation(ctx);
        break;
    }
}

// 书架空闲时预取相邻页封面：先让当前页完整显示，再用后台解码把下一页的 fast 封面写进
// SD 缓存；之后翻页直接命中，不再当场解码。来回翻只预取一个方向，不常驻占内存。
// Preload the neighbouring shelf page while idle: after the current page is complete, the
// background decoder fills the fast-cover cache for the next page, so turning to it hits the
// cache instead of decoding on the spot. One direction only; no extra resident pixels.
static void shelf_cover_prefetch_tick(app_ctx_t *ctx) {
    if (s_view != SHELF || s_clear_confirm || s_batch_confirm || ctx->request_app ||
        ctx->request_menu || ctx->request_return || (ctx->touch && ctx->touch->touched)) {
        if (s_pf_cover_generation) { book_cover_jobs_cancel(s_pf_cover_generation); s_pf_cover_generation = 0; }
        s_pf_cover_pending_mask = 0;
        s_pf_cover_leaf = -1;
        return;
    }
    if (s_cover_pending_mask || s_scan_pending || ctx->now_ms < s_pf_cover_next_ms) return;
    const int rows = shelf_rows();
    if (!s_pf_cover_generation) {
        int target = ctx->leaf + s_pf_cover_dir;
        if (target >= leaves() || target < 0) target = ctx->leaf - s_pf_cover_dir;
        if (target < 0 || target >= leaves() || target == ctx->leaf) return;
        const int base = target * rows;
        int count = s_visible_count - base;
        if (count <= 0) return;
        if (count > rows) count = rows;
        s_pf_cover_generation = book_cover_jobs_begin();
        s_pf_cover_leaf = target;
        s_pf_cover_pending_mask = 0;
        for (int row = 0; row < count; ++row) {
            int index = base + row;
            if (index < 0 || index >= s_visible_count || s_shelf[index].removed) continue;
            EpdRect image = shelf_cover_image(row);
            book_cover_job_t request = {.list = app_settings_shelf_style() == 5,
                .fast = true, .width = image.width, .height = image.height,
                .stride = SHELF_FAST_COVER_STRIDE, .contrast = app_settings_system_contrast(),
                .phase = (image.x & 3) | ((image.y & 3) << 2), .x = image.x, .y = image.y};
            copy_text(request.path, sizeof(request.path), s_shelf[index].path);
            copy_text(request.title, sizeof(request.title), s_shelf[index].name);
            copy_text(request.author, sizeof(request.author), s_shelf[index].author);
            if (book_cover_jobs_submit(s_pf_cover_generation, (unsigned)row, &request))
                s_pf_cover_pending_mask |= 1u << row;
        }
        s_pf_cover_next_ms = ctx->now_ms + 40;
        return;
    }
    for (int row = 0; row < rows; ++row) {
        const unsigned bit = 1u << row;
        if (!(s_pf_cover_pending_mask & bit)) continue;
        book_cover_result_t result = {0};
        const int state = book_cover_jobs_take(s_pf_cover_generation, (unsigned)row, &result);
        if (!state) continue;  // 还没解完，下一轮再看
        free(result.pixels);   // 预取只要 sidecar 缓存，不需要常驻像素
        s_pf_cover_pending_mask &= ~bit;
    }
    if (!s_pf_cover_pending_mask) {
        book_cover_jobs_cancel(s_pf_cover_generation);
        s_pf_cover_generation = 0;
        s_pf_cover_leaf = -1;
        s_pf_cover_dir = -s_pf_cover_dir;
        s_pf_cover_next_ms = ctx->now_ms + 2500;
    } else {
        s_pf_cover_next_ms = ctx->now_ms + 40;
    }
}
static void draw_favorite_icon(uint8_t *fb, int x, int y, int w, int h, bool filled, uint8_t ink) {
    // 只绘制标记本身，封面上不加矩形衬底。/ Draw only the glyph, without a rectangular cover underlay.
    const int notch_y = y + h - 9;
    if (filled) {
        // 把 V 形尾部也填满，避免选中后只剩矩形黑块、尾部仍是空心。
        // Fill the V-shaped tail as well so the selected glyph is solid throughout.
        for (int py = y; py <= y + h; ++py) {
            int arm = py <= notch_y ? w / 2 : (w / 2) * (y + h - py) / 9;
            ui_fill_rect_fast((EpdRect){x, py, arm + 1, 1}, ink, fb);
            ui_fill_rect_fast((EpdRect){x + w - arm, py, arm + 1, 1}, ink, fb);
        }
        return;
    }
    // 空心态使用与阅读工具栏相近的两像素线宽。
    // Keep the outline close to the other reader toolbar icons in visual weight.
    ui_fill_rect_fast((EpdRect){x, y, w + 1, 2}, ink, fb);
    ui_fill_rect_fast((EpdRect){x, y, 2, h - 1}, ink, fb);
    ui_fill_rect_fast((EpdRect){x + w - 1, y, 2, h - 1}, ink, fb);
    epd_draw_line(x, y + h, x + w / 2, notch_y, ink, fb);
    epd_draw_line(x + 1, y + h - 1, x + w / 2, notch_y + 1, ink, fb);
    epd_draw_line(x + w / 2, notch_y, x + w, y + h, ink, fb);
    epd_draw_line(x + w / 2, notch_y + 1, x + w - 1, y + h - 1, ink, fb);
}
static void draw_shelf_favorite_icon(uint8_t *fb, int x, int y, int w, int h, bool white_edge) {
    if (white_edge) {
        // 仅沿书签轮廓扩两像素白边，深封面上也不出现白色矩形底块。
        // Dilate only the bookmark silhouette by two pixels, never a white backing box.
        const int notch_y = y + h - 9;
        for (int py = y; py <= y + h; ++py) {
            int arm = py <= notch_y ? w / 2 : (w / 2) * (y + h - py) / 9;
            ui_fill_rect_fast((EpdRect){x - 2, py - 2, arm + 5, 5}, UI_GRAY_WHITE, fb);
            ui_fill_rect_fast((EpdRect){x + w - arm - 2, py - 2, arm + 5, 5}, UI_GRAY_WHITE, fb);
        }
    }
    draw_favorite_icon(fb, x, y, w, h, true, UI_GRAY_BLACK);
}
static bool cover_favorite_needs_white_edge(const uint8_t *gray, EpdRect image, unsigned sw, unsigned sh) {
    if (!gray || !sw || !sh || image.width <= 0 || image.height <= 0) return false;
    unsigned sum = 0, count = 0;
    const book_crop_t crop = book_cover_crop(sw, sh, image.width, image.height);
    // 只在标记周围采样；图标始终为黑色，深封面才加白边。
    // Sample the badge area; keep the glyph black and outline it only on dark covers.
    for (int y = 9; y < 39; y += 5) {
        for (int x = 11; x < 35; x += 4) {
            unsigned sx = crop.x + (uint64_t)(unsigned)x * crop.width / (unsigned)image.width;
            unsigned sy = crop.y + (uint64_t)(unsigned)y * crop.height / (unsigned)image.height;
            if (sx >= sw) sx = sw - 1;
            if (sy >= sh) sy = sh - 1;
            sum += ui_contrast_gray(gray[sy * sw + sx]);
            ++count;
        }
    }
    return sum < count * 145;
}
static void draw_shelf_cover(uint8_t* fb, EpdRect card, int row, const char* name, bool favorite) {
    EpdRect image = shelf_cover_image(row);
    image.y += card.y - row_rect(row).y;
    // 本行封面已解码（不再等待整页其他行）就直接绘制；未完成的继续占位。
    // Paint this row as soon as its own cover is decoded, without waiting for the page group.
    const bool artwork = s_view != SHELF || !(s_cover_pending_mask & (1u << row));
    ui_fill_rect_fast(image, UI_GRAY_LIGHT, fb);
    if (artwork && app_settings_main_fast_refresh() && s_view==SHELF && fast_cover_matches(row,image)) {
        ui_blit_mono_bitmap(fb,image,s_covers[row].fast_bits,SHELF_FAST_COVER_STRIDE);
    } else if (artwork && s_covers[row].gray) {

        const uint8_t *gray = s_covers[row].gray;
        // 封面缓冲是 176×240、这一格是 164×214；按长边铺满 + 居中裁剪，避免被压扁。
        // The cover buffer is 176x240 and this frame is 164x214; fill by the longer side and
        // centre-crop so the artwork is not squashed.
        const unsigned frame_width = (unsigned)image.width, frame_height = (unsigned)image.height;
        unsigned sw = s_view == SHELF && app_settings_shelf_style() == 5 ? s_covers[row].width : BOOK_COVER_W;
        unsigned sh = s_view == SHELF && app_settings_shelf_style() == 5 ? s_covers[row].height : BOOK_COVER_H;
        const book_crop_t crop = book_cover_crop(sw, sh, frame_width, frame_height);
        unsigned sample_x[SHELF_FAST_COVER_WIDTH];
        uint8_t tones[256];
        const bool sampled=image.width<=SHELF_FAST_COVER_WIDTH;
        const bool binary=app_settings_main_fast_refresh()&&s_view==SHELF;
        if(sampled)for(int x=0;x<image.width;++x)sample_x[x]=crop.x+(uint64_t)(unsigned)x*crop.width/frame_width;
        for(unsigned v=0;v<256;++v)tones[v]=ui_contrast_gray((uint8_t)v);
        for (int y = 0; y < image.height; ++y) {
            const int sy = (int)(crop.y + (uint64_t)(unsigned)y * crop.height / frame_height);
            for (int x = 0; x < image.width; ++x) {
                const unsigned sx = sampled?sample_x[x]:crop.x+(uint64_t)(unsigned)x*crop.width/frame_width;
                const uint8_t tone = tones[gray[sy * sw + sx]];
                epd_draw_pixel(image.x + x, image.y + y,
                               binary
                                   ? ui_image_dither_cover_bw((tone>>4)*17u, image.x + x, image.y + y)
                                   : ui_image_dither_gray(tone, image.x + x, image.y + y), fb);
            }
        }
    } else {
        char title[80]; copy_text(title, sizeof(title), name);
        char *dot = strrchr(title, '.'); if (dot) *dot = 0;
        fit_text(title, 26, image.width - 22);
        ui_text_vc(fb, image.x + image.width / 2, image.y + image.height / 2, 26,
                   title, EPD_DRAW_ALIGN_CENTER, false);
    }
    // 反色模式下封面保持原图：先按原灰阶画完，再只把封面这块翻一次，扫描反色时正好抵消。
    // Under inversion covers keep their original tones: draw them normally, flip the cover rect
    // once, and the global scan inversion cancels out.
    if (artwork) display_invert_area(fb, image);
    ui_draw_round_rect(fb, image, 0, UI_GRAY_BLACK);
    if (favorite && image.width >= 28 && image.height >= 42) {
        draw_shelf_favorite_icon(fb, image.x + 10, image.y + 8, 24, 31,
                                 artwork && ((app_settings_main_fast_refresh() && s_view == SHELF && fast_cover_matches(row, image))
                                     ? s_covers[row].fast_white_edge : cover_favorite_needs_white_edge(s_covers[row].gray, image,
                                         app_settings_shelf_style() == 5 ? s_covers[row].width : BOOK_COVER_W,
                                         app_settings_shelf_style() == 5 ? s_covers[row].height : BOOK_COVER_H)));
    }
}
static EpdRect paint_list_cover_feedback(app_ctx_t *ctx, int row) {
    EpdRect image = shelf_cover_image(row);
    EpdRect area = image;
    area.y -= SHELF_LIST_BOUNCE_PX;
    area.height += SHELF_LIST_BOUNCE_PX;
    // 两位置均位于白色列表卡片内；不清整行，也不绘制额外反馈框。
    // Both positions stay within the white list card; never clear a whole row or add a feedback frame.
    ui_fill_rect_fast(area, UI_GRAY_WHITE, ctx->fb);
    EpdRect card = row_rect(row);
    if (s_pressed_control == row) card.y -= SHELF_LIST_BOUNCE_PX;
    int index = ctx->leaf * shelf_rows() + row;
    if (index >= 0 && index < s_visible_count)
        draw_shelf_cover(ctx->fb, card, row, s_shelf[index].name, s_shelf[index].favorite);
    return area;
}
static void draw_list_title(uint8_t *fb, const char *name, int top) {
    char lines[2][128] = {{0}};
    int px = ttf_em_height_px(27);
    const unsigned char *at = (const unsigned char *)name;
    for (int line = 0; line < 2 && *at; ++line) {
        size_t used = 0;
        while (*at && used < sizeof(lines[line])-5) {
            unsigned n = *at < 128 ? 1 : (*at & 0xe0)==0xc0 ? 2 : (*at & 0xf0)==0xe0 ? 3 : 4;
            if (strlen((const char *)at) < n) break;
            memcpy(lines[line]+used, at, n); lines[line][used+n] = 0;
            if (ui_text_fixed_width_px(px, lines[line]) > 378) { lines[line][used] = 0; break; }
            used += n; at += n;
        }
        if (line == 1 && *at) fit_text(lines[line], px, 352);
        ui_text_fixed_vc(fb, 244, top + line*35, px, lines[line], EPD_DRAW_ALIGN_LEFT, false);
    }
}
static void draw_list_row(uint8_t *fb, int row, const shelf_entry_t *item) {
    EpdRect card = row_rect(row);
    draw_list_title(fb, item->name, card.y + 42);
    char author[128]; copy_text(author, sizeof(author), item->author[0] ? item->author : "作者未知");
    int author_px = ttf_em_height_px(21), progress_px = ttf_em_height_px(19);
    fit_text(author, author_px, 378);
    int author_y = ui_text_fixed_width_px(ttf_em_height_px(27), item->name) > 378 ? 106 : 83;
    ui_text_fixed_ink_vc(fb, 244, card.y + author_y, author_px, author, EPD_DRAW_ALIGN_LEFT, 0x60);
    unsigned progress = item->has_progress ? item->pct : 0;
    if (progress > 100) progress = 100;
    char label[48]; snprintf(label, sizeof(label), progress == 100 ? "已读完 · %u%%" :
                              progress ? "已读 %u%%" : "未开始 · %u%%", progress);
    ui_text_fixed_vc(fb, 244, card.y + 143, progress_px, label, EPD_DRAW_ALIGN_LEFT, false);
    EpdRect bar = {244, card.y + 163, 378, 11};
    ui_fill_round_rect(fb, bar, 5, 0xd0);
    if (progress) {
        EpdRect fill = bar; fill.width = bar.width * progress / 100;
        if (fill.width < 1) fill.width = 1;
        ui_fill_round_rect(fb, fill, 5, 0x40);
    }
    ui_draw_control_frame(fb, bar, 5, 0x50);
    if (row < 3) ui_draw_separator(fb, card.y + 196, 50, 584, 0x60);
}
static void draw_shelf_furniture(uint8_t* fb) {
    uint8_t style = app_settings_shelf_style();
    if (!style || style == 5) return;
    for (int row = 0; row < 3; ++row) {
        int top = (s_view == SHELF ? 192 : 224) + row * 282;
        if (style == 1) {
            ui_fill_rect_fast((EpdRect){36, top + 214, 612, 12}, 0x30, fb);
            ui_hairline(fb, top + 214, 36, 612, 0x58);
            ui_hairline(fb, top + 225, 36, 612, 0x10);
        } else if (style == 2) {
            EpdRect acrylic = {20, top + 136, 644, 90};
            draw_shelf_guard(fb, acrylic, row);

        }
    }
}
// Bottom tool bar edge: the portrait sheet keeps its place, landscape puts the same bar
// along its own bottom edge so the text page never has to rotate for the toolbar.
static int reader_tool_bar_top(void) {
    return s_reader_landscape ? reader_scr_h() - 120 : 1096;
}
static EpdRect tool_rect(int i) {
    const int width = reader_scr_w();
    int x0 = i * width / BOOK_TOOL_COUNT;
    int x1 = (i + 1) * width / BOOK_TOOL_COUNT;
    return (EpdRect){x0, reader_tool_bar_top(), x1 - x0, 120};
}
static int leaves(void) {
    if (s_view == TOC) return book_toc_pages(book_navigation_count());
    int count = s_visible_count;
    int rows = s_view == BULK ? BOOK_BULK_ROWS : shelf_rows();
    return count ? 1 + (count - 1) / rows : 1;
}
static EpdRect shelf_manage_rect(void) { return (EpdRect){442, 94, 97, 54}; }
static EpdRect shelf_import_rect(void) { return (EpdRect){551, 94, 97, 54}; }
// 书架搜索入口放在“管理”左边：输入后只在内存里过滤当前书架/二级书架，不扫卡，快。
// Shelf search sits left of Manage: it filters the in-memory shelf (or current category) only,
// never rescans the card, so results appear immediately.
static EpdRect shelf_search_rect(void) { return (EpdRect){333, 94, 97, 54}; }
static void draw_shelf_header_button(uint8_t *fb, EpdRect r, int kind) {
    bool pressed = s_pressed_control == (kind == 2 ? 113 : kind == 1 ? 115 : 114);
    ui_fill_round_rect(fb, r, 18, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, r, 18, 0x70);
    if (pressed) ui_draw_pressed_round_rect(fb, r, 18);
    ui_text_vc(fb, r.x + r.width / 2, r.y + r.height / 2 + (pressed ? 2 : 0), 20,
               kind == 2 ? "搜索" : kind == 1 ? "+ 导入" : "管理", EPD_DRAW_ALIGN_CENTER, false);
}
static EpdRect shelf_page_arrow_rect(int direction) {
    return ui_pager_rect(direction<0?UI_PAGER_PREVIOUS:UI_PAGER_NEXT);
}
static void draw_shelf_pager(uint8_t *fb, int count, int page, int pages) {
    char label[64];
    snprintf(label, sizeof(label), "%d本书 · %02d/%02d", count, page + 1, pages);
    int pressed=s_shelf_key_mode&&s_shelf_key_pressed?
        (s_shelf_key_pressed<0?UI_PAGER_PREVIOUS:UI_PAGER_NEXT):UI_PAGER_NONE;
    if(s_pressed_control>=116&&s_pressed_control<=119)pressed=s_pressed_control-116;
    ui_pager_draw(fb,label,page,pages,s_shelf_key_mode,pressed);
}
// 只推分页小区；按压不重绘封面，翻页在下一轮输入后执行，可被切页打断。
// Update only the pager; presses do not redraw covers. Page work follows on the next input tick and is cancellable by navigation.
static app_redraw_t shelf_key_paint(app_ctx_t *ctx) {
    s_area=ui_pager_area();
    ui_fill_rect_fast(s_area,UI_GRAY_WHITE,ctx->fb);
    draw_shelf_pager(ctx->fb,s_visible_count,ctx->leaf,leaves());
    s_shelf_key_paint_pending=true;
    return APP_REDRAW_AREA;
}
static bool shelf_main_key(app_ctx_t *ctx,int key,app_redraw_t *redraw) {
    if(s_view!=SHELF || s_clear_confirm || s_batch_confirm)return false;
    if(key==UI_KEY_2){
        s_shelf_key_mode=!s_shelf_key_mode;s_shelf_key_delta=s_shelf_key_pressed=0;
        s_category_menu=false;*redraw=shelf_key_paint(ctx);return true;
    }
    if(!s_shelf_key_mode || (key!=UI_KEY_1 && key!=UI_KEY_3))return false;
    int dir=key==UI_KEY_1?-1:1;
    s_shelf_key_pressed=dir;s_shelf_key_delta+=dir;
    if(s_shelf_key_delta>8)s_shelf_key_delta=8;
    if(s_shelf_key_delta< -8)s_shelf_key_delta= -8;
    s_shelf_key_until=ctx->now_ms+35;
    *redraw=shelf_key_paint(ctx);return true;
}
static app_redraw_t shelf_turn_page(app_ctx_t *ctx, int direction);
static EpdRect import_rect(int index) { return (EpdRect){36, 230 + index * 164, 612, 136}; }
static void clean_filename(char *dst, size_t cap, const char *filename) {
    copy_text(dst, cap, filename);
    char *ext = strrchr(dst, '.');
    if (ext) *ext = 0;
    char *start = dst;
    while (*start == ' ' || *start == '\t') ++start;
    if (start != dst) memmove(dst, start, strlen(start) + 1);
    size_t len = strlen(dst);
    while (len && (dst[len - 1] == ' ' || dst[len - 1] == '\t')) dst[--len] = 0;
}

// 截断必须停在UTF8字符边界。/ Truncation must stop at a UTF8 character boundary.
static void copy_text(char* dst, size_t cap, const char* src) {
    if (!cap) return;
    size_t n = strlen(src);
    if (n >= cap) {
        n = cap - 1;
        while (n && ((unsigned char)src[n] & 0xc0) == 0x80) --n;
    }
    memcpy(dst, src, n);
    dst[n] = 0;
}
static void fit_text(char* text, int px, int width) {
    while (*text && ttf_text_width_px(ui_text_effective_px(px), text) > width) {
        size_t n = strlen(text) - 1;
        while (n && ((unsigned char)text[n] & 0xc0) == 0x80) --n;
        text[n] = 0;
    }
}

static void fit_fixed_text(char* text, int px, int width) {
    while (*text && ui_text_fixed_width_px(px, text) > width) {
        size_t n = strlen(text) - 1;
        while (n && ((unsigned char)text[n] & 0xc0) == 0x80) --n;
        text[n] = 0;
    }
}

static void reader_footer_strip_number(char *dst, size_t cap, const char *source) {
    char title[128];
    copy_text(title, sizeof(title), source ? source : "");
// name 只被读取，但下面会把字符串字面量赋给它。CI 的 sdkconfig.ci 开了
// CONFIG_COMPILER_WARN_WRITE_STRINGS，字面量因此是 const char[]，赋给 char* 会丢 const 并在
// -Werror 下报错。声明成 const 指针即可。
// name is only read from, but it is assigned a string literal below. CI's sdkconfig.ci enables
// CONFIG_COMPILER_WARN_WRITE_STRINGS, which makes literals const char[], so assigning one to a
// char* discards the qualifier and fails under -Werror. A const pointer is enough.
    const char *name = title;
    while (*name == ' ' || *name == '\t') ++name;
    char *chapter_mark = !strncmp(name, "第", strlen("第")) ? strstr(name, "章") : NULL;
    if (chapter_mark && chapter_mark - name < 24) {
        char *after = chapter_mark + strlen("章");
        while (*after == ' ' || *after == '\t' || *after == ':' || *after == '-' ||
               !strncmp(after, "：", strlen("：")) || !strncmp(after, "、", strlen("、")) ||
               !strncmp(after, "·", strlen("·"))) {
            if (*after == ' ' || *after == '\t' || *after == ':' || *after == '-') ++after;
            else after += strlen("：");
        }
        name = after;
    }
    if (!*name || !strcmp(name, "本章") || !strcmp(name, "章节")) name = "未命名章节";
    copy_text(dst, cap, name);
}
static void reader_footer_chapter_name(char *dst, size_t cap) {
    char source[128] = {0};
    bool selected = s_selected_toc < book_navigation_count() &&
        book_navigation_chapter(s_selected_toc) == s_chapter &&
        book_navigation_title(s_selected_toc, source, sizeof(source)) == ESP_OK && source[0];
    if (!selected) {
        if (s_chapter_heading_title[0]) copy_text(source, sizeof(source), s_chapter_heading_title);
        else if (book_chapter_title(s_chapter, source, sizeof(source)) != ESP_OK) source[0] = 0;
    }
    reader_footer_strip_number(dst, cap, source);
}
static uint32_t chapter_end(void) {
    return s_chapter + 1 < book_chapter_count()
        ? book_chapter_byte_offset(s_chapter + 1) : book_total_bytes();
}
static size_t reader_page_offset(size_t page) {
    size_t off = book_layout_page_start_offset(page);
    if (s_jump_offset != SIZE_MAX && page == s_jump_page && s_jump_offset > off)
        off = s_jump_offset;
    return off;
}
static unsigned percent(size_t page) {
    uint32_t total = book_total_bytes();
    if (!total) return 0;
    if (s_chapter + 1 == book_chapter_count() && page + 1 == book_layout_page_count()) return 100;
    uint32_t off = book_position_bytes(book_chapter_byte_offset(s_chapter), chapter_end(),
                                       reader_page_offset(page), s_text_len);
    return (unsigned)((uint64_t)off * 100 / total);
}
static pending_progress_t* pending_find(const char* path) {
    for (pending_progress_t* p = s_pending; p; p = p->next) if (!strcmp(p->path, path)) return p;
    return NULL;
}
static int layout_name(uint8_t* fb, const char* name, int y, bool draw);
static EpdRect manage_panel(void) {
    int height = layout_name(NULL, s_managed.name, 0, false) + 495;
    return (EpdRect){UI_MARGIN - 16, 190 + (876 - height) / 2, ui_content_width() + 32, height};
}
static EpdRect manage_rect(int index, int count) {
    EpdRect panel = manage_panel();
    return ui_row_rect(index, count, panel.y + panel.height - 94, 76);
}
// 六个批量按钮排成两行各三格：上排选择与重扫，下排三个需要二次确认的操作。
// Six batch controls in two rows of three: selection and rescan on top, the three actions that
// ask for confirmation below.
static EpdRect batch_rect(int id) {
    return (EpdRect){36 + (id % 3) * 208, id < 3 ? 918 : 988, 196, 58};
}
static EpdRect manage_back_rect(void) { return (EpdRect){36, 92, 44, 44}; }
static EpdRect bulk_filter_rect(int id) { return (EpdRect){36 + id * 208, 216, 196, 70}; }
static EpdRect search_rect(int id) {
    if (id < 40) {
        int width = (ui_content_width() - 54) / 10;
        return (EpdRect){UI_MARGIN + id % 10 * (width + 6), 388 + id / 10 * 100, width, 88};
    }
    if (id < 43) return ui_row_rect(id - 40, 3, 808, 80);
    return ui_bar_rect(id - 43, 2);
}
static size_t selected_count(void) {
    size_t selected = 0;
    for (int i = 0; i < s_count; ++i) if (s_shelf[i].selected) ++selected;
    return selected;
}
static void clear_selection(void) {
    for (int i = 0; i < s_count; ++i) s_shelf[i].selected = false;
}
static void toggle_selection(int index) {
    if (index >= 0 && index < s_visible_count) s_shelf[index].selected = !s_shelf[index].selected;
}
static void select_page(int page) {
    for (int i = page * BOOK_BULK_ROWS; i < s_visible_count && i < (page + 1) * BOOK_BULK_ROWS; ++i) s_shelf[i].selected = true;
}

static void search_begin(void) {
    s_search_parent = s_view;
    memcpy(s_search_draft, s_query, sizeof(s_query));
    ui_text_edit_init(&s_search_input, s_search_draft, sizeof(s_search_draft));
    ui_keyboard_begin(&s_search_input, false);
    s_view = SEARCH;
}
static bool shelf_search_match(const shelf_entry_t* item) {
    return item && (read_pico_search_match(item->name, s_query) ||
                    (item->author[0] && read_pico_search_match(item->author, s_query)));
}
static void refresh_search_matches(void) {
    for (int i = 0; i < s_count; ++i)
        s_shelf[i].search_match = shelf_search_match(&s_shelf[i]);
}
static void search_finish(app_ctx_t* ctx, bool apply) {
    ui_keyboard_end();
    s_view = s_search_parent;
    if (apply) {
        memcpy(s_query, s_search_draft, sizeof(s_query));
        refresh_search_matches();
        clear_selection();
        sort_shelf(ctx);
        s_batch_message[0] = 0;
    }
    memset(s_search_draft, 0, sizeof(s_search_draft));
    ui_text_edit_init(&s_search_input, s_search_draft, sizeof(s_search_draft));
}

static bool pending_reserve(const char* path) {
    if (pending_find(path)) return true;
    pending_progress_t* p = heap_caps_malloc(sizeof(*p), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!p) p = malloc(sizeof(*p));
    if (!p) return false;
    memset(p, 0, sizeof(*p));
    copy_text(p->path, sizeof(p->path), path);
    // 阅读页内注册；传书 HTTP 尚未启动，退出后也不注销失败项。
    // Register in reading before transfer HTTP starts; failed records survive page exit.
    p->watch = book_progress_watch_create(path);
    if (!p->watch) { free(p); return false; }
    pending_progress_t** tail = &s_pending;
    while (*tail) tail = &(*tail)->next;
    *tail = p;
    return true;
}
static bool pending_restore(const char* path, uint32_t size, book_progress_t* out) {
    pending_progress_t* pending = pending_find(path);
    if (!pending || !pending->dirty || pending->value.file_size != size) return false;
    *out = pending->value;
    return true;
}
static void pending_discard(const char* path) {
    pending_progress_t** p = &s_pending;
    while (*p) {
        if (!strcmp((*p)->path, path)) {
            pending_progress_t* old = *p;
            *p = old->next;
            book_progress_watch_destroy(old->watch);
            free(old);
            break;
        }
        p = &(*p)->next;
    }
    s_save_failed = false;
    for (pending_progress_t* item = s_pending; item; item = item->next) if (item->dirty) s_save_failed = true;
}
static void pending_mark_latest(const char* path) {
    pending_progress_t** item = &s_pending;
    while (*item && strcmp((*item)->path, path)) item = &(*item)->next;
    if (*item) {
        pending_progress_t* current = *item;
        *item = current->next;
        current->next = NULL;
        pending_progress_t** tail = &s_pending;
        while (*tail) tail = &(*tail)->next;
        *tail = current;
    }
    copy_text(s_latest_path, sizeof(s_latest_path), path);
}
static void pending_drop_invalidated(void) {
    pending_progress_t* p = s_pending;
    while (p) {
        pending_progress_t* next = p->next;
        if (book_progress_watch_invalidated(p->watch)) {
            if (p->dirty) s_pending_invalidated = true;
            pending_discard(p->path);
        }
        p = next;
    }
}
static delete_retry_t* delete_retry_find(const char* path) {
    for (delete_retry_t* p = s_delete_retries; p; p = p->next)
        if (!strcmp(p->entry.path, path)) return p;
    return NULL;
}
static bool pending_flush(pending_progress_t* p) {
    if (!p->dirty) return true;
    if (!p->progress_saved) {
        if (book_progress_save(p->path, &p->value) != ESP_OK) return false;
        p->progress_saved = true;
    }
    if (!strcmp(p->path, s_latest_path) && book_progress_set_last_path(p->path) != ESP_OK) return false;
    p->dirty = false;
    return true;
}
static void retry_progress(void) {
    s_save_failed = false;
    bool had_dirty = false;
    pending_progress_t* p = s_pending;
    while (p) {
        pending_progress_t* next = p->next;
        bool dirty = p->dirty;
        had_dirty |= dirty;
        if (s_text && !strcmp(p->path, s_path)) { p = next; continue; }
        if (!pending_flush(p)) s_save_failed = true;
        else if (strcmp(p->path, s_path)) pending_discard(p->path);
        else if (dirty) s_unsaved = 0;
        p = next;
    }
    if (s_text && (s_unsaved || had_dirty)) save_progress();
    s_save_failed = false;
    for (pending_progress_t* item = s_pending; item; item = item->next) if (item->dirty) s_save_failed = true;
}

/* ---- 管理详情 / Management details ---- */
static int layout_name(uint8_t* fb, const char* name, int y, bool draw) {
    const char* at = name;
    while (*at) {
        char line[256];
        size_t used = 0;
        while (at[used]) {
            unsigned char first = (unsigned char)at[used];
            size_t n = first < 0x80 ? 1 : first < 0xe0 ? 2 : first < 0xf0 ? 3 : 4;
            size_t remain = strlen(at + used);
            if (n > remain) n = 1;
            if (used + n >= sizeof(line)) break;
            memcpy(line + used, at + used, n);
            line[used + n] = 0;
            if (ttf_text_width_px(UI_PX_CAPTION, line) > ui_content_width() && used) break;
            used += n;
        }
        if (!used) break;
        line[used] = 0;
        if (draw) ui_text(fb, UI_MARGIN, y, UI_PX_CAPTION, line, EPD_DRAW_ALIGN_LEFT, false);
        y += 36;
        at += used;
    }
    return y;
}
static int draw_wrapped_name(uint8_t* fb, const char* name, int y) {
    return layout_name(fb, name, y, true);
}
static void draw_manage(uint8_t* fb) {
    EpdRect panel = manage_panel();
    ui_fill_round_rect(fb, panel, UI_BTN_RADIUS, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, panel, UI_BTN_RADIUS, UI_GRAY_BLACK);
    ui_text(fb, UI_MARGIN, panel.y + 18, UI_PX_BODY,
            s_clear_confirm ? (s_delete_confirm ? "确认删除文件？" : "确认清除进度？") : "图书详情", EPD_DRAW_ALIGN_LEFT, false);
    int y = draw_wrapped_name(fb, s_managed.name, panel.y + 74) + 12;
    char info[96];
    snprintf(info, sizeof(info), "%s · %s · %.2f MB", s_managed.is_flash ? "内置存储" : "TF 卡",
             strrchr(s_managed.name, '.') ? strrchr(s_managed.name, '.') + 1 : "", s_managed.size / 1048576.0);
    ui_text(fb, UI_MARGIN, y, UI_PX_CAPTION, info, EPD_DRAW_ALIGN_LEFT, false);
    snprintf(info, sizeof(info), s_managed.has_progress ? "阅读进度 %u%%" : "尚无阅读进度", s_managed.pct);
    ui_text(fb, UI_MARGIN, y + 44, UI_PX_CAPTION, info, EPD_DRAW_ALIGN_LEFT, false);
    ui_text(fb, UI_MARGIN, y + 88, UI_PX_CAPTION,
            s_managed.is_flash ? "/flash/books" : !strncmp(s_managed.path, "/sdcard/book/", 13) ? "/sdcard/book" : app_settings_books_dir(),
            EPD_DRAW_ALIGN_LEFT, false);
    if (s_manage_message[0]) ui_text(fb, UI_MARGIN, panel.y + panel.height - 270, UI_PX_CAPTION, s_manage_message, EPD_DRAW_ALIGN_LEFT, false);
    if (s_clear_confirm) {
        ui_text(fb, UI_MARGIN, panel.y + panel.height - 142, UI_PX_CAPTION, s_delete_confirm ? "删除后文件无法恢复" : "仅清阅读进度，保留图书文件", EPD_DRAW_ALIGN_LEFT, false);
        draw_control(fb, manage_rect(0, 2), "取消", 300);
        draw_control(fb, manage_rect(1, 2), s_delete_confirm ? "确认删除" : "确认清除", 301);
    } else if (s_file_removed) {
        draw_control(fb, manage_rect(0, 2), "关闭", 400);
        draw_control(fb, manage_rect(1, 2), "重试清理", 403);
    } else {
        draw_control(fb, (EpdRect){UI_MARGIN, panel.y + panel.height - 190, ui_content_width(), 68}, "前往文件管理重命名", 404);
        draw_control(fb, manage_rect(0, 3), "关闭", 400);
        draw_control(fb, manage_rect(1, 3), "清进度", 401);
        draw_control(fb, manage_rect(2, 3), "删除文件", 402);
    }
}

static void editor_start(void) {
    free(s_editor_cover);
    bool pending = false;
    s_editor_cover = load_cover_gray(s_managed.path, s_managed.name, "", false, &pending);
    copy_text(s_editor_title, sizeof(s_editor_title), s_managed.name);
    ui_text_edit_init(&s_editor_input, s_editor_title, sizeof(s_editor_title));
    s_editor_notice[0] = 0;
    s_edit_note_mode = false;
    s_edit_note_index = -1;
    ui_keyboard_begin(&s_editor_input, false);
    s_view = EDIT;
}

static void editor_start_note(int index) {
    free(s_editor_cover); s_editor_cover = NULL;
    const char *note = book_highlight_note(index);
    copy_text(s_editor_title, sizeof(s_editor_title), note ? note : "");
    ui_text_edit_init(&s_editor_input, s_editor_title, sizeof(s_editor_title));
    s_editor_notice[0] = 0;
    s_edit_note_mode = true;
    s_edit_note_index = index;
    ui_keyboard_begin(&s_editor_input, false);
    s_view = EDIT;
}



static void draw_editor(uint8_t* fb) {
    ui_clear_page(fb);
    ui_nav_status(fb);
    ui_nav_back(fb, 36, 79);
    if (s_edit_note_mode) {
        ui_text_vc(fb, UI_LOCK_WIDTH / 2, 107, 31, "划线笔记", EPD_DRAW_ALIGN_CENTER, false);
        ui_text_vc(fb, 646, 107, 26, "完成", EPD_DRAW_ALIGN_RIGHT, false);
        ui_hairline(fb, 133, 36, 612, UI_GRAY_LIGHT);
        uint16_t chapter = 0;
        uint32_t start = 0, end = 0;
        const char *excerpt = NULL;
        (void)book_highlight_at(s_edit_note_index, &chapter, &start, &end, &excerpt);
        char head[128];
        if (book_chapter_title(chapter, head, sizeof(head)) != ESP_OK || !head[0])
            snprintf(head, sizeof(head), "第 %u 节", (unsigned)chapter + 1);
        fit_text(head, 24, 560);
        ui_text(fb, 36, 168, 24, head, EPD_DRAW_ALIGN_LEFT, false);
        char body[BOOK_HIGHLIGHT_EXCERPT];
        copy_text(body, sizeof(body), excerpt ? excerpt : "");
        fit_text(body, 20, 612);
        ui_text_fixed_vc(fb, 36, 214, 20, body[0] ? body : "（原文摘录不可用）", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 36, 356, 24, "笔记", EPD_DRAW_ALIGN_LEFT, false);
        ui_text_fixed_vc(fb, 36, 392, 18, "只保存在本机，随这本书的划线记录一起保存", EPD_DRAW_ALIGN_LEFT, false);
        EpdRect field = {36, 424, 612, 83};
        ui_text_input_draw(fb, &s_editor_input, field, 30, false, NULL);
        if (s_editor_notice[0]) ui_text_fixed_vc(fb, 36, 530, 22, s_editor_notice, EPD_DRAW_ALIGN_LEFT, false);
        ui_keyboard_draw(fb, 560);
        return;
    }
    ui_text_vc(fb, UI_LOCK_WIDTH / 2, 107, 31, "编辑书籍", EPD_DRAW_ALIGN_CENTER, false);
    ui_text_vc(fb, 646, 107, 26, "完成", EPD_DRAW_ALIGN_RIGHT, false);
    ui_hairline(fb, 133, 36, 612, UI_GRAY_LIGHT);
    EpdRect cover = {36, 175, 112, 152};
    ui_fill_rect_fast(cover, UI_GRAY_LIGHT, fb);
    if (s_editor_cover) {

        for (int y = 0; y < cover.height; ++y) {
            for (int x = 0; x < cover.width; ++x) {
                const uint8_t tone = ui_contrast_gray(
                    s_editor_cover[(y * BOOK_COVER_H / cover.height) * BOOK_COVER_W +
                                   x * BOOK_COVER_W / cover.width]);
                epd_draw_pixel(cover.x + x, cover.y + y,
                    ui_image_dither_gray(tone, cover.x + x, cover.y + y), fb);
            }
        }
    } else {
        char title[80]; copy_text(title, sizeof(title), s_managed.name);
        fit_text(title, 22, cover.width - 16);
        ui_text_vc(fb, cover.x + cover.width / 2, cover.y + cover.height / 2, 22, title, EPD_DRAW_ALIGN_CENTER, false);
    }
    ui_draw_round_rect(fb, cover, 0, UI_GRAY_BLACK);
    char title[128]; copy_text(title, sizeof(title), s_managed.name);
    fit_text(title, 30, 460);
    ui_text(fb, 174, 192, 30, title, EPD_DRAW_ALIGN_LEFT, false);
    ui_text(fb, 174, 244, 22, "只修改书架显示名称", EPD_DRAW_ALIGN_LEFT, false);
    ui_hairline(fb, 356, 36, 612, UI_GRAY_LIGHT);
    ui_text(fb, 36, 378, 24, "书名", EPD_DRAW_ALIGN_LEFT, false);
    EpdRect field = {36, 424, 612, 83};
    ui_text_input_draw(fb, &s_editor_input, field, 31, false, NULL);
    if (s_editor_notice[0]) ui_text_fixed_vc(fb, 36, 530, 22, s_editor_notice, EPD_DRAW_ALIGN_LEFT, false);
    ui_keyboard_draw(fb, 560);
}
static void draw_search(uint8_t* fb) {
    ui_clear_page(fb); ui_nav_status(fb);
    ui_nav_back(fb, 36, 79);
    ui_text_vc(fb, 342, 107, 34, "搜索图书", EPD_DRAW_ALIGN_CENTER, false);
    ui_text_vc(fb, 646, 107, 25, "应用", EPD_DRAW_ALIGN_RIGHT, false);
    ui_text_input_draw(fb, &s_search_input, (EpdRect){UI_MARGIN, 200, ui_content_width(), 88}, UI_PX_BODY, false, NULL);
    ui_text_fixed_vc(fb, 36, 337, 23, "可输入中文、完整拼音、首字母或英文", EPD_DRAW_ALIGN_LEFT, false);
    ui_draw_button(fb, (EpdRect){36, 392, 180, 66}, "清空", false);
    ui_keyboard_draw(fb, 560);
}
static void draw_import(uint8_t* fb) {
    ui_clear_page(fb);
    ui_nav_status(fb);
    ui_nav_back(fb, 36, 79);
    ui_text_vc(fb, 342, 107, 34, "导入图书", EPD_DRAW_ALIGN_CENTER, false);
    ui_text(fb, 36, 166, 20, "选择导入方式", EPD_DRAW_ALIGN_LEFT, false);
    ui_hairline(fb, 207, 36, 612, UI_GRAY_LIGHT);
    static const char *titles[] = {"浏览 TF 卡", "WiFi 传书", "热点传书", "USB 读卡"};
    static const char *details[] = {
        "查看目录，打开或管理已有图书", "手机与墨水屏连接同一网络",
        "连接 kiikoread 热点后上传图书", "连接电脑，把图书放入 books 文件夹"
    };
    for (int i = 0; i < 4; ++i) {
        EpdRect r = import_rect(i);
        ui_fill_round_rect(fb, r, 22, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, r, 22, 0xb0);
        ui_text(fb, r.x + 24, r.y + 25, 27, titles[i], EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, r.x + 24, r.y + 78, 19, details[i], EPD_DRAW_ALIGN_LEFT, false);
        ui_text_vc(fb, r.x + r.width - 24, r.y + r.height / 2, 26, "›", EPD_DRAW_ALIGN_RIGHT, false);
    }
    ui_text(fb, 36, 925, 19, "图书放入 TF 卡的 books 文件夹后会自动出现在书架。",
            EPD_DRAW_ALIGN_LEFT, false);
    ui_nav_draw(fb, 1);
}
static void draw_batch_confirmation(uint8_t* fb) {
    if (!s_batch_confirm) return;
    EpdRect panel = {54, 406, 576, 330};
    ui_fill_round_rect(fb, panel, 25, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, panel, 25, 0x48);
    char title[96];
    const char* verb = s_batch_kind == BATCH_DELETE ? "删除" :
                       s_batch_kind == BATCH_CLEAR ? "清除进度：" : "从书架移除";
    const char* note = s_batch_kind == BATCH_DELETE ? "删除文件不可撤销，失败项可重试" :
                       s_batch_kind == BATCH_CLEAR ? "仅清阅读进度，所有文件保留" :
                       "只移出书架，文件与阅读进度都保留";
    snprintf(title, sizeof(title), "%s %u 本图书？", verb, (unsigned)selected_count());
    ui_text_vc(fb, 342, 477, 28, title, EPD_DRAW_ALIGN_CENTER, false);
    ui_text_vc(fb, 342, 541, 19, note, EPD_DRAW_ALIGN_CENTER, false);
    draw_control(fb, ui_row_rect(0, 2, 620, UI_BTN_H), "取消", 600);
    draw_control(fb, ui_row_rect(1, 2, 620, UI_BTN_H), "确认", 601);
}

static EpdRect bulk_nav_rect(int i) { return (EpdRect){36 + i * 208, UI_BAR_TOP, 196, UI_BAR_H}; }
static int bulk_nav_hit(int x, int y) {
    for (int i=0;i<3;++i) if(ui_rect_hit(bulk_nav_rect(i),x,y)) return i;
    return -1;
}
static void draw_bulk(uint8_t* fb, int leaf) {
    ui_clear_page(fb);
    ui_nav_status(fb);
    ui_nav_back(fb, 36, 79);
    ui_text_vc(fb, 342, 107, 34, "管理书架", EPD_DRAW_ALIGN_CENTER, false);
    char summary[96];
    snprintf(summary, sizeof(summary), "%d 本图书 · 已选 %u 本", s_visible_count, (unsigned)selected_count());
    ui_text(fb, 36, 166, 20, s_batch_message[0] ? s_batch_message : summary, EPD_DRAW_ALIGN_LEFT, false);
    ui_hairline(fb, 200, 36, 612, 0x70);
    const char *filters[] = {s_filter == 0 ? "全部来源" : s_filter == 1 ? "TF 卡" : "内置",
                             s_recent_sort ? "按最近" : "按名称", s_query[0] ? "搜索中" : "搜索"};
    for (int i = 0; i < 3; ++i) {
        EpdRect r = bulk_filter_rect(i);
        ui_fill_round_rect(fb, r, 20, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, r, 20, 0x70);
        ui_text_vc(fb, r.x + r.width / 2, r.y + 35, 21, filters[i], EPD_DRAW_ALIGN_CENTER, false);
    }
    for (int row = 0; row < BOOK_BULK_ROWS; ++row) {
        int index = leaf * BOOK_BULK_ROWS + row;
        if (index >= s_visible_count) break;
        EpdRect r = row_rect(row);
        bool selected = s_shelf[index].selected;
        ui_fill_round_rect(fb, r, 18, selected ? 0xd0 : UI_GRAY_WHITE);
        ui_draw_control_frame(fb, r, 18, selected ? 0x60 : 0x70);
        char title[128]; copy_text(title, sizeof(title), s_shelf[index].name);
        fit_text(title, 26, 495);
        ui_text_vc(fb, r.x + 22, r.y + 31, 26, title, EPD_DRAW_ALIGN_LEFT, false);
        char detail[48];
        snprintf(detail, sizeof(detail), "%s · %s", s_shelf[index].is_flash ? "内置" : "TF 卡",
                 s_shelf[index].has_progress ? "已有阅读进度" : "未开始阅读");
        ui_text_vc(fb, r.x + 22, r.y + 62, 20, detail, EPD_DRAW_ALIGN_LEFT, false);
        epd_draw_circle(r.x + r.width - 37, r.y + 42, 12, 0x58, fb);
        if (selected) epd_fill_circle(r.x + r.width - 37, r.y + 42, 7, 0x38, fb);
    }
    if (!s_visible_count)
        ui_text_vc(fb, 342, 570, 26, s_message[0] ? s_message : "当前筛选没有图书", EPD_DRAW_ALIGN_CENTER, false);
    // 三列格宽只有 193 像素，标签控制在四字以内，放大系统字号也不会顶出按钮。
    // A three-column cell is 193 px wide, so labels stay within four characters and still fit
    // once the system font scale is turned up.
    static const char *labels[] = {"本页全选", "清除勾选", "重新扫描",
                                   "删除所选", "清进度", "移出书架"};
    for (int i = 0; i < 6; ++i) {
        EpdRect r = batch_rect(i);
        ui_fill_round_rect(fb, r, 18, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, r, 18, 0x70);
        ui_text_vc(fb, r.x + r.width / 2, r.y + r.height / 2, 20, labels[i], EPD_DRAW_ALIGN_CENTER, false);
    }
    const char *nav[] = {"上一页", "完成", "下一页"};
    char page[48];
    snprintf(page, sizeof(page), "%d / %d 页", leaf + 1, leaves());
    ui_text_vc(fb, 342, 1072, 20, page, EPD_DRAW_ALIGN_CENTER, false);
    for (int i = 0; i < 3; ++i) {
        EpdRect r = bulk_nav_rect(i);
        bool available = i == 1 || (i == 0 ? leaf > 0 : leaf + 1 < leaves());
        ui_fill_round_rect(fb, r, 20, i == 1 ? 0x20 : UI_GRAY_WHITE);
        ui_draw_control_frame(fb, r, 20, available ? 0x70 : 0xb0);
        ui_text_vc(fb, r.x + r.width / 2, r.y + r.height / 2, 25, nav[i], EPD_DRAW_ALIGN_CENTER, i == 1);
    }
    draw_batch_confirmation(fb);
}
static void save_progress(void) {
    if (!s_text || !s_path[0] || !book_layout_page_count()) return;
    bool was_failed = s_save_failed;
    pending_progress_t* pending = pending_find(s_path);
    if (!pending) { s_save_failed = true; return; }
    book_progress_t p = {
        .file_size = s_file_size, .chapter = (uint16_t)s_chapter,
        .byte_off = (uint32_t)reader_page_offset(s_page),
        .px = (uint8_t)s_px, .pct = (uint8_t)percent(s_page),
        .last_open_s = 0,
    };
    if (!pending->dirty || pending->value.file_size != p.file_size || pending->value.chapter != p.chapter ||
        pending->value.byte_off != p.byte_off || pending->value.px != p.px || pending->value.pct != p.pct) {
        pending->value = p;
        pending->progress_saved = false;
    }
    pending->dirty = true;
    if (pending_flush(pending)) {
        s_unsaved = 0;
        s_save_failed = false;
        for (pending_progress_t* item = s_pending; item; item = item->next) if (item->dirty) s_save_failed = true;
    }
    else { if (!s_unsaved) s_unsaved = 1; s_save_failed = true; }
    if (was_failed != s_save_failed) invalidate_prep();
}
static void invalidate_prep(void) {
    s_next_page = s_prep_page = -1;
    s_next_generation = 0;
    memset(&s_prep_cursor, 0, sizeof(s_prep_cursor));
    s_next_page2 = s_prep_page2 = -1;
    s_next_generation2 = 0;
    memset(&s_prep_cursor2, 0, sizeof(s_prep_cursor2));
}

// 目录使用系统字体；切换前等待预渲染结束，回正文时恢复阅读字体与字形缓存。
// The directory uses the system face; join painting before switching and restore the reader face on return.
static void set_reader_view(book_view_t view) {
    reader_indent_hold_cancel();
    reader_zoom_reset();
    s_reader_tap.pending = false;
    s_hl_hold_pending = false;
    lock_draw();
    invalidate_prep();
    if (view == READING) app_font_activate_reading();
    else app_font_activate_system();
    s_view = view;
    unlock_draw();
}

/* ---- 阅读工具层 / Reader overlays ---- */
typedef struct {
    uint32_t magic, file_size, byte_off;
    uint16_t chapter;
    char path[BOOK_STORE_PATH_MAX];
} legacy_reader_bookmark_t;

typedef struct {
    uint16_t chapter;
    uint16_t reserved;
    uint32_t byte_off;
    uint32_t saved_s;
    uint8_t tag;          ///< 0 无标签，1..3 预设标签
    uint8_t reserved2[3];
} reader_bookmark_entry_t;

// v2 书签没有标签字段；读入时统一迁移成 v3（标签默认 0）。
// V2 bookmarks had no tag; loaded records migrate to v3 with tag = 0.
typedef struct {
    uint16_t chapter;
    uint16_t reserved;
    uint32_t byte_off;
    uint32_t saved_s;
} reader_bookmark_entry_v2_t;
typedef struct {
    uint32_t magic, file_size;
    uint16_t count, reserved;
    char path[BOOK_STORE_PATH_MAX];
    reader_bookmark_entry_v2_t entries[BOOKMARK_MAX];
} reader_bookmarks_v2_t;
#define BOOKMARK_MAGIC_V2 UINT32_C(0x52504d32)
#define BOOKMARK_MAGIC_V3 UINT32_C(0x52504d33)

typedef struct {
    uint32_t magic, file_size;
    uint16_t count, reserved;
    char path[BOOK_STORE_PATH_MAX];
    reader_bookmark_entry_t entries[BOOKMARK_MAX];
} reader_bookmarks_t;

static void bookmark_key(const char* path, char key[11]) {
    uint32_t hash = UINT32_C(2166136261);
    for (const unsigned char* p = (const unsigned char*)path; *p; ++p)
        hash = (hash ^ *p) * UINT32_C(16777619);
    snprintf(key, 11, "m_%08lx", (unsigned long)hash);
}
// 收藏按完整路径持久化，与章节书签分别存放。/ Persist whole-book favorites separately from page bookmarks.
static void favorite_key(const char *path, char key[11]) {
    uint32_t hash = UINT32_C(2166136261);
    for (const unsigned char *p = (const unsigned char *)path; *p; ++p)
        hash = (hash ^ *p) * UINT32_C(16777619);
    snprintf(key, 11, "f_%08lx", (unsigned long)hash);
}
static bool favorite_read_handle(nvs_handle_t h, const char *path) {
    uint8_t value = 0;
    char key[11]; favorite_key(path, key);
    return nvs_get_u8(h, key, &value) == ESP_OK && value == 1;
}
static bool favorite_load(const char *path) {
    nvs_handle_t h;
    if (nvs_open("rp_favs", NVS_READONLY, &h) != ESP_OK) return false;
    bool value = favorite_read_handle(h, path);
    nvs_close(h);
    return value;
}
static bool favorite_save(const char *path, bool value) {
    nvs_handle_t h;
    if (nvs_open("rp_favs", NVS_READWRITE, &h) != ESP_OK) return false;
    char key[11]; favorite_key(path, key);
    esp_err_t err = value ? nvs_set_u8(h, key, 1) : nvs_erase_key(h, key);
    if (err == ESP_ERR_NVS_NOT_FOUND && !value) err = ESP_OK;
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    return err == ESP_OK;
}

// 从书架移除只隐藏条目，不动文件也不清进度；再次打开这本书会重新上书架。
// Removing from the shelf hides the entry only: no file or progress is touched, and opening the
// book again puts it back. 值为完整路径，命中的同键记录属于别的书时拒绝覆盖。
// The value is the full path, so a colliding key owned by a different book is never overwritten.
#define SHELF_HIDDEN_NS "rp_shelf"
static void shelf_hidden_key(const char *path, char key[11]) {
    uint32_t hash = UINT32_C(2166136261);
    for (const unsigned char *p = (const unsigned char *)path; *p; ++p)
        hash = (hash ^ *p) * UINT32_C(16777619);
    snprintf(key, 11, "h_%08lx", (unsigned long)hash);
}
static bool shelf_hidden_read_handle(nvs_handle_t h, const char *path) {
    char stored[BOOK_STORE_PATH_MAX];
    char key[11];
    shelf_hidden_key(path, key);
    size_t len = sizeof(stored);
    return nvs_get_str(h, key, stored, &len) == ESP_OK && strcmp(stored, path) == 0;
}
static bool shelf_hidden_load(const char *path) {
    nvs_handle_t h;
    if (nvs_open(SHELF_HIDDEN_NS, NVS_READONLY, &h) != ESP_OK) return false;
    bool hidden = shelf_hidden_read_handle(h, path);
    nvs_close(h);
    return hidden;
}
static bool shelf_hidden_save(const char *path, bool hidden) {
    nvs_handle_t h;
    if (nvs_open(SHELF_HIDDEN_NS, NVS_READWRITE, &h) != ESP_OK) return false;
    char key[11];
    shelf_hidden_key(path, key);
    char stored[BOOK_STORE_PATH_MAX];
    size_t len = sizeof(stored);
    esp_err_t existing = nvs_get_str(h, key, stored, &len);
    esp_err_t err = existing == ESP_ERR_NVS_NOT_FOUND ? ESP_OK : existing;
    if (existing == ESP_OK && strcmp(stored, path) != 0) err = ESP_ERR_INVALID_STATE;
    // 恢复上架也校验路径，避免擦掉碰撞键属于另一书的隐藏记录。
    // Check ownership when unhiding too, so a collision cannot erase a different book removal.
    if (err == ESP_OK && hidden) err = nvs_set_str(h, key, path);
    else if (err == ESP_OK) {
        err = nvs_erase_key(h, key);
        if (err == ESP_ERR_NVS_NOT_FOUND) err = ESP_OK;
    }
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    if(err==ESP_OK)book_lock_collage_invalidate();
    return err == ESP_OK;
}
static bool bookmark_read_handle(nvs_handle_t h, reader_bookmarks_t* marks) {
    if (!marks || !s_path[0]) return false;
    memset(marks, 0, sizeof(*marks));
    char key[11]; bookmark_key(s_path, key);
    size_t size = 0;
    if (nvs_get_blob(h, key, NULL, &size) != ESP_OK) return false;
    if (size == sizeof(legacy_reader_bookmark_t)) {
        legacy_reader_bookmark_t old;
        size = sizeof(old);
        if (nvs_get_blob(h, key, &old, &size) != ESP_OK ||
            old.magic != UINT32_C(0x52504d31) || old.file_size != s_file_size ||
            strcmp(old.path, s_path)) return false;
        marks->magic = BOOKMARK_MAGIC_V3;
        marks->file_size = old.file_size;
        marks->count = 1;
        copy_text(marks->path, sizeof(marks->path), old.path);
        marks->entries[0] = (reader_bookmark_entry_t){
            .chapter = old.chapter, .byte_off = old.byte_off,
        };
        return true;
    }
    if (size == sizeof(reader_bookmarks_v2_t)) {
        reader_bookmarks_v2_t old;
        size = sizeof(old);
        if (nvs_get_blob(h, key, &old, &size) != ESP_OK ||
            old.magic != BOOKMARK_MAGIC_V2 || old.file_size != s_file_size ||
            old.count > BOOKMARK_MAX || strcmp(old.path, s_path)) return false;
        memset(marks, 0, sizeof(*marks));
        marks->magic = BOOKMARK_MAGIC_V3;
        marks->file_size = old.file_size;
        marks->count = old.count;
        copy_text(marks->path, sizeof(marks->path), old.path);
        for (uint16_t i = 0; i < old.count; ++i) {
            marks->entries[i].chapter = old.entries[i].chapter;
            marks->entries[i].byte_off = old.entries[i].byte_off;
            marks->entries[i].saved_s = old.entries[i].saved_s;
        }
        return true;
    }
    if (size != sizeof(*marks) || nvs_get_blob(h, key, marks, &size) != ESP_OK) return false;
    return marks->magic == BOOKMARK_MAGIC_V3 && marks->file_size == s_file_size &&
        marks->count <= BOOKMARK_MAX && !strcmp(marks->path, s_path);
}

static bool bookmark_load(reader_bookmarks_t* marks) {
    if (!marks || !s_path[0]) return false;
    nvs_handle_t h;
    if (nvs_open("rp_marks", NVS_READONLY, &h) != ESP_OK) return false;
    bool ok = bookmark_read_handle(h, marks);
    nvs_close(h);
    return ok;
}
static bool bookmark_is_current(void) {
    reader_bookmarks_t marks;
    if (!bookmark_load(&marks)) return false;
    size_t offset = book_layout_page_start_offset(s_page);
    for (size_t i = 0; i < marks.count; ++i)
        if (marks.entries[i].chapter == s_chapter && marks.entries[i].byte_off == offset) return true;
    return false;
}
static size_t bookmark_count(void) {
    reader_bookmarks_t marks;
    return bookmark_load(&marks) ? marks.count : 0;
}
static int bookmark_row_step(void) {
    int scale=app_settings_system_font_size();
    if(scale<100)scale=100;
    if(scale>200)scale=200;
    return 82+(scale-100)/2;
}
static int bookmark_rows(void) { return (s_bookmark_edit?424:492)/bookmark_row_step(); }
static EpdRect bookmark_row_rect(int row) {
    int step=bookmark_row_step();
    if (s_reader_landscape) return (EpdRect){20,140+row*step,1176,step-10};
    return (EpdRect){36,656+row*step,612,step-10};
}
// 书签预设标签：0 无、1 重要、2 待读、3 疑问；点标签块循环并立即写回。
// Bookmark preset tags: 0 none, 1 important, 2 to-read, 3 question; the chip cycles and saves.
static const char *const bookmark_tag_names[] = {"标签", "重要", "待读", "疑问"};
static EpdRect bookmark_tag_rect(int row) {
    EpdRect r = bookmark_row_rect(row);
    return (EpdRect){r.x + r.width - 96, r.y + (r.height - 44) / 2, 88, 44};
}
static bool bookmark_store(reader_bookmarks_t *marks) {
    nvs_handle_t h;
    if (nvs_open("rp_marks", NVS_READWRITE, &h) != ESP_OK) return false;
    char key[11]; bookmark_key(s_path, key);
    marks->magic = BOOKMARK_MAGIC_V3;
    esp_err_t err = marks->count ? nvs_set_blob(h, key, marks, sizeof(*marks)) : nvs_erase_key(h, key);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    return err == ESP_OK;
}
static bool bookmark_set_tag(int index, uint8_t tag) {
    if (tag > 3) return false;
    reader_bookmarks_t marks;
    if (!bookmark_load(&marks) || index < 0 || index >= (int)marks.count) return false;
    if (marks.entries[index].tag == tag) return true;
    marks.entries[index].tag = tag;
    return bookmark_store(&marks);
}
static EpdRect bookmark_manage_rect(void) {
    return s_reader_landscape ? (EpdRect){reader_scr_w()-124,14,104,54}
                              : (EpdRect){544,590,104,54};
}
static EpdRect bookmark_select_all_rect(void) {
    return s_reader_landscape ? (EpdRect){20,566,420,64} : (EpdRect){36,1080,258,64};
}
static EpdRect bookmark_remove_rect(void) {
    return s_reader_landscape ? (EpdRect){460,566,500,64} : (EpdRect){312,1080,336,64};
}
static int bookmark_page_label_y(void) { return s_reader_landscape ? 636 : 1166; }
static EpdRect bookmark_confirm_rect(void) {
    return s_reader_landscape ? (EpdRect){320,190,576,240} : (EpdRect){54,756,576,240};
}
static int bookmark_confirm_center_x(void) { return s_reader_landscape ? 608 : 342; }
static int bookmark_pages(size_t count) {
    return count ? ((int)count + bookmark_rows() - 1) / bookmark_rows() : 1;
}
static unsigned bookmark_selected_count(void) {
    unsigned count = 0;
    for (unsigned i = 0; i < BOOKMARK_MAX; ++i) if (s_bookmark_selected & (UINT32_C(1) << i)) ++count;
    return count;
}
static void bookmark_compact(reader_bookmarks_t* marks, uint32_t selected) {
    size_t write = 0;
    for (size_t i = 0; i < marks->count; ++i)
        if (!(selected & (UINT32_C(1) << i))) marks->entries[write++] = marks->entries[i];
    marks->count = (uint16_t)write;
}
static bool bookmark_delete_selected(void) {
    if (!s_bookmark_selected || !s_path[0]) return false;
    nvs_handle_t h;
    if (nvs_open("rp_marks", NVS_READWRITE, &h) != ESP_OK) return false;
    reader_bookmarks_t marks;
    bool valid = bookmark_read_handle(h, &marks);
    esp_err_t err = valid ? ESP_OK : ESP_ERR_NOT_FOUND;
    if (valid) {
        bookmark_compact(&marks, s_bookmark_selected);
        char key[11]; bookmark_key(s_path, key);
        err = marks.count ? nvs_set_blob(h, key, &marks, sizeof(marks)) : nvs_erase_key(h, key);
        if (err == ESP_OK) err = nvs_commit(h);
    }
    nvs_close(h);
    if (err != ESP_OK) return false;
    s_bookmark_selected = 0;
    s_bookmark_page = 0;
    s_bookmark_edit = marks.count != 0;
    return true;
}
static bool bookmark_toggle(void) {
    if (!s_path[0]) return false;
    nvs_handle_t h;
    if (nvs_open("rp_marks", NVS_READWRITE, &h) != ESP_OK) return false;
    char key[11]; bookmark_key(s_path, key);
    reader_bookmarks_t marks;
    bool valid = bookmark_read_handle(h, &marks);
    if (!valid) {
        memset(&marks, 0, sizeof(marks));
        marks.magic = BOOKMARK_MAGIC_V3;
        marks.file_size = s_file_size;
        copy_text(marks.path, sizeof(marks.path), s_path);
    }
    uint32_t offset = (uint32_t)book_layout_page_start_offset(s_page);
    size_t found = marks.count;
    for (size_t i = 0; i < marks.count; ++i)
        if (marks.entries[i].chapter == s_chapter && marks.entries[i].byte_off == offset) { found = i; break; }
    bool remove = found < marks.count;
    if (remove) {
        memmove(&marks.entries[found], &marks.entries[found + 1],
                (marks.count - found - 1) * sizeof(marks.entries[0]));
        --marks.count;
    } else {
        if (marks.count == BOOKMARK_MAX) {
            memmove(&marks.entries[0], &marks.entries[1],
                    (BOOKMARK_MAX - 1) * sizeof(marks.entries[0]));
            --marks.count;
        }
        time_t now = time(NULL);
        marks.entries[marks.count++] = (reader_bookmark_entry_t){
            .chapter = (uint16_t)s_chapter, .byte_off = offset,
            .saved_s = now >= 1704067200 ? (uint32_t)now : 0,
        };
    }
    esp_err_t err = marks.count ? nvs_set_blob(h, key, &marks, sizeof(marks)) : nvs_erase_key(h, key);
    if (err == ESP_ERR_NVS_NOT_FOUND && !marks.count) err = ESP_OK;
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    if (err == ESP_OK) {
        copy_text(s_reader_notice, sizeof(s_reader_notice), remove ? "书签已移除" : "书签已添加");
        s_reader_notice_until = esp_timer_get_time() / 1000 + 1600;
    } else {
        copy_text(s_reader_notice, sizeof(s_reader_notice), "书签保存失败");
        s_reader_notice_until = esp_timer_get_time() / 1000 + 2200;
    }
    return err == ESP_OK;
}

static void draw_reader_tool_icon(uint8_t* fb, int cx, int cy, int kind, bool selected) {
    // 阅读工具栏图标全部来自 Lucide；已保存的书签用带勾的一档区分未保存。
    // Reader toolbar icons all come from Lucide; a saved bookmark uses the check variant.
    static const ui_icon_t tools[] = {
        UI_ICON_LIST,          // 0 目录
        UI_ICON_BOOKMARK,      // 1 书签
        UI_ICON_CHART_COLUMN,  // 2 阅读统计
        UI_ICON_BOOK_OPEN,     // 3 阅读设置 / Reading settings
        UI_ICON_TYPE,          // 4 字体设置
        UI_ICON_TEXT_ALIGN_START, // 5 划线 / highlighter mode
    };
    if (kind < 0 || kind >= (int)(sizeof(tools) / sizeof(tools[0]))) return;
    const ui_icon_t icon = (kind == 1 && selected) ? UI_ICON_BOOKMARK_CHECK : tools[kind];
    ui_draw_icon(fb, cx, cy, READER_TOOL_ICON_PX, icon, 0x38);
}

// 单行辅助文字保持在当前控件内；本机只使用当前活动字库，按原轮廓重新光栅化。
// Keep one-line UI text inside its slot, rasterizing native outlines in the existing active font.
static void reader_panel_text_vc(uint8_t *fb,int x,int cy,int px,const char *text,
                                  enum EpdFontFlags align,bool inverted) {
    int width=align==EPD_DRAW_ALIGN_LEFT?642-x:align==EPD_DRAW_ALIGN_RIGHT?x-42:
              2*(x<342?x-42:642-x);
    int left=align==EPD_DRAW_ALIGN_LEFT?x:align==EPD_DRAW_ALIGN_RIGHT?x-width:x-width/2;
    ui_text_box(fb,(EpdRect){left,cy-22,width,44},px,text,align,inverted);
}
static void reader_panel_text(uint8_t *fb,int x,int y,int px,const char *text,
                               enum EpdFontFlags align,bool inverted) {
    int height=ui_text_effective_px(px);if(height>44)height=44;
    reader_panel_text_vc(fb,x,y+height/2,px,text,align,inverted);
}

static void draw_sheet(uint8_t* fb, int top, const char* title) {
    EpdRect sheet = {0, top, UI_LOCK_WIDTH, UI_LOCK_HEIGHT - top + 28};
    ui_fill_round_rect(fb, sheet, 28, UI_GRAY_WHITE);
    ui_fill_rect_fast((EpdRect){0, top + 28, UI_LOCK_WIDTH, UI_LOCK_HEIGHT - top - 28}, UI_GRAY_WHITE, fb);
    ui_draw_control_frame(fb, sheet, 28, 0x58);
    ui_fill_round_rect(fb, (EpdRect){292, top + 14, 100, 7}, 3, 0x48);
    ui_text_box(fb,(EpdRect){110,top+26,464,66},30,title,EPD_DRAW_ALIGN_CENTER,false);
}

// 二级面板共用 AnimateIcons circle-chevron-left，含圆环与箭头，避免叠加手画框线。
// Secondary panels share the complete AnimateIcons circle-chevron-left without an extra hand-drawn ring.
static void draw_sheet_back(uint8_t* fb, int top) {
    ui_click_feedback_register(fb,(EpdRect){32,top+25,64,64},UI_CLICK_BACK,UI_ICON_ANIMATE_CIRCLE_CHEVRON_LEFT);
    ui_draw_icon(fb,64,top+57,READER_SHEET_BACK_PX,UI_ICON_ANIMATE_CIRCLE_CHEVRON_LEFT,0x30);
}

static void draw_pill_slider(uint8_t* fb, EpdRect r, const char* left, const char* right,
                             const char* value, int index, int count, int left_px, int right_px) {
    ui_fill_round_rect(fb, r, r.height / 2, 0xb8);
    ui_draw_control_frame(fb, r, r.height / 2, 0x50);
    int cy = r.y + r.height / 2;
    ui_text_box(fb,(EpdRect){r.x+12,cy-26,40,52},left_px,left,EPD_DRAW_ALIGN_CENTER,false);
    ui_text_box(fb,(EpdRect){r.x+r.width-52,cy-26,40,52},right_px,right,EPD_DRAW_ALIGN_CENTER,false);
    int span = r.width - 128;
    int cx = r.x + 64 + (count > 1 ? span * index / (count - 1) : 0);
    EpdRect track = {r.x + 59, cy - 3, r.width - 118, 6};
    ui_fill_round_rect(fb, track, 3, 0x78);
    track.width = cx - track.x;
    if (track.width > 0) ui_fill_round_rect(fb, track, 3, 0x40);
    epd_fill_circle(cx, cy, 37, UI_GRAY_WHITE, fb);
    epd_draw_circle(cx, cy, 37, 0x48, fb);
    ui_text_box(fb,(EpdRect){cx-31,cy-28,62,56},22,value,EPD_DRAW_ALIGN_CENTER,false);
}

static EpdRect reader_slider_refresh_rect(int slider) {
    EpdRect r = reader_slider_rect(slider);
    // The knob extends four pixels outside the pill. Include that margin so
    // moving it restores the old white footprint and the rail beneath it.
    r.x -= 8; r.y -= 8; r.width += 16; r.height += 16;
    return r;
}

static const char* font_friendly_name(const ttf_font_item_t* item) {
    return item ? ttf_font_localized_name(item->name) : "";
}

static void draw_font_name_with_current_face(uint8_t* fb, int x, int y, const char* name, int width) {
    int above = 0, below = 0;
    int px=ui_text_effective_px(25);
    while (px>1 && ttf_text_width_px(px,name)>width) --px;
    ttf_measure_line_px(px, name, &above, &below);
    ttf_draw_text_px(fb, x, y + (above - below) / 2, px, name,
                     EPD_DRAW_ALIGN_CENTER, UI_INK_BLACK, UI_INK_WHITE);
}

// 用户确认双列：字体/字重在第一行，书内字体/排版在第二行；绘制与命中共用矩形。
// Approved paired rows: face/weight, then embedded faces/layout; paint and touch share rectangles.
// 放大文字时向上展开面板，保持双列与底部完成键的位置；命中也使用这些矩形。
// Expand sheets upward for larger UI text, retaining paired columns and the Done button; hits share these rectangles.
static int reader_ui_extra(int maximum) {
    int scale = app_settings_system_font_size();
    if (scale < 100) scale = 100;
    if (scale > 200) scale = 200;
    return (scale-100)*maximum/100;
}
static int reader_font_top(void) {
    return s_reader_landscape ? 60 : 580-reader_ui_extra(112);
}
static EpdRect reader_font_done_rect(void) {
    return s_reader_landscape ? (EpdRect){20, 604, 1176, 60} : (EpdRect){36, 1141, 612, 58};
}
static EpdRect reader_font_card(int index) {
    if (s_reader_landscape) {
        // 横屏：三列两行，卡片等宽铺满画布。
        // Landscape: three columns by two rows, equal cards across the canvas.
        return (EpdRect){20 + (index % 3) * 396, 190 + (index / 3) * 200, 376, 176};
    }
    int extra=reader_ui_extra(48), footer=reader_ui_extra(16);
    if (index>=4) return (EpdRect){index==4?36:350,1054-footer,298,72+footer};
    int row=index/2;
    return (EpdRect){index%2?350:36,796+row*132-(2-row)*extra-footer,
                     298,(row?110:116)+extra};
}
#define s_font_card reader_font_card(0)
#define s_weight_card reader_font_card(1)
#define s_bookfont_card reader_font_card(2)
#define s_layout_card reader_font_card(3)
#define s_rule_card reader_font_card(4)
#define s_antialias_card reader_font_card(5)
static void draw_reading_switch(uint8_t *fb, EpdRect track, bool on);

static bool background_image_name(const char *name) {
    const char *ext = strrchr(name, '.');
    return ext && (!strcasecmp(ext, ".jpg") || !strcasecmp(ext, ".jpeg") || !strcasecmp(ext, ".png"));
}
static int background_compare(const void *a, const void *b) {
    const reader_background_item_t *left = a, *right = b;
    // 文件夹排前面，其余按名称不区分大小写；预览页左右翻动时顺序稳定。
    // Folders come first; the rest sort case-insensitively, keeping preview stepping stable.
    if (left->is_dir != right->is_dir) return left->is_dir ? -1 : 1;
    return strcasecmp(left->path, right->path);
}
static void reader_background_reset(void) {
    free(s_backgrounds); s_backgrounds = NULL;
    s_background_count = s_background_selected = s_background_page = 0;
    s_background_notice[0] = 0; s_background_ready = false;
    s_background_preview_notice[0] = 0; s_background_prepare_pending = false;
}
// 扫描当前目录：子文件夹可进入（三级菜单的中间层），图片直接进预览；目录不存在时给出原因，
// 不把空列表当成“没有图片”。
// Scan the current folder: subfolders are enterable (the middle level of the three-level menu) and
// images open the preview. A missing folder reports the real cause instead of "no pictures".
static void reader_background_scan(void) {
    reader_background_reset();
    DIR *dir = opendir(s_background_dir);
    if (!dir) {
        copy_text(s_background_notice, sizeof(s_background_notice),
                  s_background_depth ? "无法读取该文件夹" : "请在 pictures 中放入 JPG 或 PNG 图片");
        return;
    }
    // A bounded catalogue, independent of book count. No image data in the catalogue.
    s_backgrounds = heap_caps_calloc(READER_BACKGROUND_MAX, sizeof(*s_backgrounds), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!s_backgrounds) copy_text(s_background_notice, sizeof(s_background_notice), "内存不足，请关闭图书后重试");
    struct dirent *ent;
    while (s_backgrounds && (ent = readdir(dir))) {
        // AppleDouble ._ files and other hidden metadata are never images or folders to show.
        if (ent->d_name[0] == '.') continue;
        char path[288]; struct stat st;
        int n = snprintf(path, sizeof(path), "%s/%s", s_background_dir, ent->d_name);
        if (n < 0 || n >= (int)sizeof(path) || stat(path, &st)) continue;
        const bool folder = S_ISDIR(st.st_mode);
        if (!folder && (!S_ISREG(st.st_mode) || st.st_size <= 0 || !background_image_name(ent->d_name))) continue;
        if (s_background_count == READER_BACKGROUND_MAX) {
            copy_text(s_background_notice, sizeof(s_background_notice), "本目录只显示前 160 项");
            break;
        }
        strcpy(s_backgrounds[s_background_count].path, path);
        s_backgrounds[s_background_count].is_dir = folder;
        ++s_background_count;
    }
    closedir(dir);
    if (s_background_count) qsort(s_backgrounds, s_background_count, sizeof(*s_backgrounds), background_compare);
    for (int i = 0; i < s_background_count; ++i)
        if (!s_backgrounds[i].is_dir && !strcmp(s_backgrounds[i].path, app_settings_book_background_path()))
            s_background_selected = i;
    s_background_page = s_background_selected / READER_BACKGROUND_ROWS;
    if (!s_background_count && !s_background_notice[0])
        copy_text(s_background_notice, sizeof(s_background_notice),
                  s_background_depth ? "此文件夹为空" : "pictures 中暂无图片，可放入 JPG 或 PNG");
}
// 目录进出：进入时把当前路径压栈，返回时弹栈；根目录再返回就落到阅读背景菜单。
// Folder walk: entering pushes the current path, Back pops it, and the root's Back returns to the menu.
static bool reader_background_enter(const char *path) {
    if (s_background_depth >= READER_BACKGROUND_DEPTH) return false;
    copy_text(s_background_parent[s_background_depth], sizeof(s_background_parent[0]), s_background_dir);
    ++s_background_depth;
    copy_text(s_background_dir, sizeof(s_background_dir), path);
    reader_background_scan();
    return true;
}
static bool reader_background_up(void) {
    if (s_background_depth <= 0) return false;
    --s_background_depth;
    copy_text(s_background_dir, sizeof(s_background_dir), s_background_parent[s_background_depth]);
    reader_background_scan();
    return true;
}
static const char *reader_background_dir_label(void) {
    const char *base = strrchr(s_background_dir, '/');
    return base && base[1] ? base + 1 : "pictures";
}
static int reader_background_pages(void) {
    return s_background_count ? (s_background_count + READER_BACKGROUND_ROWS - 1) / READER_BACKGROUND_ROWS : 1;
}
// 背景目录的行与分页/动作键：绘制与命中共用。竖屏保持原底部一排，横屏把列表铺满画布、
// 动作挪到列表下方一条底栏，行高按可用高度收窄。
// Background directory rows and keys are shared by paint and hit testing. Portrait keeps its footer
// row; landscape fills the canvas with the list and moves the actions into a bar beneath it.
static EpdRect reader_background_row(int row) {
    if (s_reader_landscape) return (EpdRect){20, 104 + row * 66, 1176, 60};
    return (EpdRect){36, 344 + row * 96, 612, 96};
}
static EpdRect reader_background_pager_rect(int direction) {
    if (s_reader_landscape)
        return direction < 0 ? (EpdRect){20,580,190,64} : (EpdRect){430,580,190,64};
    return direction < 0 ? (EpdRect){36,1040,190,52} : (EpdRect){458,1040,190,52};
}
static EpdRect reader_background_clear_rect(void) {
    return s_reader_landscape ? (EpdRect){700,580,240,64} : (EpdRect){36,1120,294,72};
}
static EpdRect reader_background_back_rect(void) {
    return s_reader_landscape ? (EpdRect){976,580,220,64} : (EpdRect){354,1120,294,72};
}
// 预览页的整幅预览框：竖屏 9:16 满幅；横屏保持同一比例，缩短以给右侧信息与按键列留位。
// The preview frame: a full 9:16 box in portrait, the same ratio shortened in landscape for the info/action column.
static EpdRect reader_background_preview_rect(void) {
    if (s_reader_landscape) return (EpdRect){60, 96, 270, 480};
    return (EpdRect){157, 316, 369, 656};
}
// 预览页三个动作键：竖屏底部一排，横屏右侧竖排。
// The three preview actions: one footer row in portrait, a vertical column on the right in landscape.
static EpdRect reader_background_preview_action_rect(int index) {
    if (s_reader_landscape) return (EpdRect){480, 250 + index * 106, 716, 88};
    const EpdRect buttons[] = {{36,1100,190,76},{246,1100,192,76},{458,1100,190,76}};
    return buttons[index];
}
static void draw_background_directory(uint8_t *fb) {
    const bool land = s_reader_landscape;
    if (land) draw_panel_sheet_landscape(fb, "阅读背景");
    else { draw_sheet(fb, 200, "阅读背景"); draw_sheet_back(fb, 200); }
    char count[32]; snprintf(count, sizeof(count), "%d 项", s_background_count);
    if (land) {
        ui_text_box(fb,(EpdRect){20, 62, 420, 30}, 20, reader_background_dir_label(), EPD_DRAW_ALIGN_LEFT, false);
        ui_text_box(fb,(EpdRect){896, 62, 300, 30}, 21, count, EPD_DRAW_ALIGN_RIGHT, false);
        ui_fill_round_rect(fb, (EpdRect){20,100,1176,464}, 20, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, (EpdRect){20,100,1176,464}, 20, 0x58);
    } else {
        reader_panel_text(fb, 42, 303, 23, reader_background_dir_label(), EPD_DRAW_ALIGN_LEFT, false);
        reader_panel_text(fb, 642, 303, 22, count, EPD_DRAW_ALIGN_RIGHT, false);
        ui_fill_round_rect(fb, (EpdRect){36,344,612,672}, 20, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, (EpdRect){36,344,612,672}, 20, 0x58);
    }
    for (int row = 0; row < READER_BACKGROUND_ROWS; ++row) {
        int index = s_background_page * READER_BACKGROUND_ROWS + row;
        if (index >= s_background_count) break;
        EpdRect r = reader_background_row(row);
        const bool folder = s_backgrounds[index].is_dir;
        bool active = !folder && !strcmp(s_backgrounds[index].path, app_settings_book_background_path());
        if (active) ui_fill_round_rect(fb, (EpdRect){r.x+6,r.y+6,r.width-12,r.height-12}, 16, 0xe0);
        if (row) ui_hairline(fb, r.y, r.x+20, r.width-40, 0x78);
        ui_draw_icon(fb, r.x+42, r.y+r.height/2, 30, folder ? UI_ICON_FOLDER : UI_ICON_FILE, 0x38);
        const char *base = strrchr(s_backgrounds[index].path, '/');
        char name[128]; copy_text(name, sizeof(name), base ? base+1 : s_backgrounds[index].path);
        fit_text(name, 25, r.width-142);
        // 横屏行更宽，左对齐文字用整行可用宽度，不再受竖屏辅助函数的 642 列限制。
        // Landscape rows are wider: left-aligned names use the full row width instead of the portrait
        // helper's 642-column limit.
        if (land) ui_text_box(fb,(EpdRect){r.x+76, r.y+r.height/2-22, r.width-142, 44},
                              25, name, EPD_DRAW_ALIGN_LEFT, false);
        else reader_panel_text_vc(fb, r.x+76, r.y+r.height/2, 25, name, EPD_DRAW_ALIGN_LEFT, false);
        if (active) epd_fill_circle(r.x+r.width-53, r.y+r.height/2, 4, UI_GRAY_BLACK, fb);
        ui_draw_icon(fb, r.x+r.width-25, r.y+r.height/2, 23, UI_ICON_CHEVRON_RIGHT, 0x38);
    }
    if (s_background_notice[0]) {
        char notice[96]; copy_text(notice, sizeof(notice), s_background_notice);
        if (land) {
            if (s_background_count) {
                fit_text(notice, 18, 600);
                ui_text_box(fb,(EpdRect){320, 62, 576, 30}, 18, notice, EPD_DRAW_ALIGN_CENTER, false);
            } else {
                fit_text(notice, 21, 1100);
                ui_text_box(fb,(EpdRect){20, 320, 1176, 44}, 21, notice, EPD_DRAW_ALIGN_CENTER, false);
            }
        } else {
            fit_text(notice, 21, 572);
            reader_panel_text_vc(fb, 342, s_background_count ? 1098 : 655, 21, notice, EPD_DRAW_ALIGN_CENTER, false);
        }
    }
    char page[32]; snprintf(page, sizeof(page), "%d / %d", s_background_page+1, reader_background_pages());
    ui_draw_button(fb, reader_background_pager_rect(-1), "上一页", false);
    if (land) ui_text_box(fb,(EpdRect){210,580,220,64}, 22, page, EPD_DRAW_ALIGN_CENTER, false);
    else reader_panel_text_vc(fb, 342, 1066, 22, page, EPD_DRAW_ALIGN_CENTER, false);
    ui_draw_button(fb, reader_background_pager_rect(1), "下一页", false);
    ui_draw_button(fb, reader_background_clear_rect(), "无背景", false);
    ui_draw_button(fb, reader_background_back_rect(), s_background_depth ? "上一级" : "返回", false);
}
// 三级菜单第一层：当前背景 + 选择图片 / 无背景 / 返回。
// Level one of the three-level menu: current background plus Choose / Clear / Back.
static EpdRect reader_background_menu_button(int index) {
    if (s_reader_landscape) {
        const EpdRect buttons[] = {{20,300,370,88},{453,300,370,88},{886,300,290,88}};
        return buttons[index];
    }
    const EpdRect buttons[] = {{36,560,612,92},{36,676,612,92},{36,792,612,92}};
    return buttons[index];
}
static void draw_background_menu(uint8_t *fb) {
    const bool land = s_reader_landscape;
    if (land) draw_panel_sheet_landscape(fb, "阅读背景");
    else { draw_sheet(fb, 200, "阅读背景"); draw_sheet_back(fb, 200); }
    char line[160];
    const char *current = app_settings_book_background_path();
    if (current[0]) {
        const char *base = strrchr(current, '/');
        snprintf(line, sizeof(line), "当前：%s", base ? base + 1 : current);
    } else copy_text(line, sizeof(line), "当前：无背景（白底）");
    if (land) {
        ui_fill_round_rect(fb, (EpdRect){20,100,1176,140}, 20, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, (EpdRect){20,100,1176,140}, 20, 0x58);
        fit_text(line, 24, 1100);
        ui_text_box(fb,(EpdRect){40,116,1136,44}, 24, line, EPD_DRAW_ALIGN_LEFT, false);
        ui_text_box(fb,(EpdRect){40,170,1136,40}, 19,
                    "选择 pictures 里的图片；图片白底会自动去掉，正文仍然清晰",
                    EPD_DRAW_ALIGN_LEFT, false);
    } else {
        ui_fill_round_rect(fb, (EpdRect){36,344,612,176}, 20, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, (EpdRect){36,344,612,176}, 20, 0x58);
        fit_text(line, 23, 560);
        reader_panel_text(fb, 60, 368, 23, line, EPD_DRAW_ALIGN_LEFT, false);
        reader_panel_text(fb, 60, 418, 18, "图片白底会自动去掉，正文仍然清晰", EPD_DRAW_ALIGN_LEFT, false);
        reader_panel_text(fb, 60, 454, 18, "支持 JPG / PNG，可进入子文件夹", EPD_DRAW_ALIGN_LEFT, false);
    }
    ui_draw_button(fb, reader_background_menu_button(0), "选择图片", true);
    ui_draw_button(fb, reader_background_menu_button(1), "无背景", false);
    ui_draw_button(fb, reader_background_menu_button(2), "返回", false);
}
static void draw_background_picker(uint8_t *fb) {
    const bool land = s_reader_landscape;
    if (land) draw_panel_sheet_landscape(fb, "背景预览");
    else { draw_sheet(fb, 200, "背景预览"); draw_sheet_back(fb, 200); }
    EpdRect preview = reader_background_preview_rect(); // 9:16, matching the complete wallpaper canvas.
    ui_fill_rect_fast(preview, UI_GRAY_WHITE, fb);
    if (s_background_ready) ui_reader_background_paint(fb, preview, false);
    ui_draw_control_frame(fb, preview, 0, UI_GRAY_BLACK);
    char name[128] = "暂无图片", position[48];
    if (s_background_count) {
        const char *base = strrchr(s_backgrounds[s_background_selected].path, '/');
        copy_text(name, sizeof(name), base ? base + 1 : "背景");
    }
    snprintf(position, sizeof(position), "%d/%d · 上下滑动预览", s_background_count ? s_background_selected + 1 : 0, s_background_count);
    const char *caption = s_background_preview_notice[0] ? s_background_preview_notice : position;
    if (land) {
        fit_text(name, 24, 700);
        ui_text_box(fb,(EpdRect){480, 96, 716, 44}, 24, name, EPD_DRAW_ALIGN_CENTER, false);
        ui_text_box(fb,(EpdRect){480, 152, 716, 36}, 21, caption, EPD_DRAW_ALIGN_CENTER, false);
    } else {
        fit_text(name, 24, 584);
        reader_panel_text_vc(fb, 342, 1002, 24, name, EPD_DRAW_ALIGN_CENTER, false);
        reader_panel_text_vc(fb, 342, 1046, 21, caption, EPD_DRAW_ALIGN_CENTER, false);
    }
    ui_draw_button(fb, reader_background_preview_action_rect(0), "无背景", false);
    ui_draw_button(fb, reader_background_preview_action_rect(1), "返回", false);
    ui_draw_button(fb, reader_background_preview_action_rect(2), "使用背景", true);
}
static void reader_background_preview(int index) {
    if (index < 0 || index >= s_background_count || s_backgrounds[index].is_dir) return;
    s_background_selected = index; s_background_page = index / READER_BACKGROUND_ROWS;
    s_reader_panel = READER_PANEL_BACKGROUND_PREVIEW;
    s_background_ready = false; s_background_prepare_pending = true;
    s_background_preview_notice[0] = 0;
}
static app_redraw_t reader_background_step(int dir) {
    if (s_reader_panel == READER_PANEL_BACKGROUND) {
        int next = s_background_page + dir;
        if (next < 0 || next >= reader_background_pages()) return APP_REDRAW_NONE;
        s_background_page = next; return APP_REDRAW_PAGE;
    }
    if (s_reader_panel == READER_PANEL_BACKGROUND_PREVIEW) {
        // 预览上下翻动时跳过子文件夹，只在图片之间走。
        // Preview stepping skips folders and only moves between images.
        int next = s_background_selected + dir;
        while (next >= 0 && next < s_background_count && s_backgrounds[next].is_dir) next += dir;
        if (next >= 0 && next < s_background_count) reader_background_preview(next);
    }
    return APP_REDRAW_NONE; // Preview decoding is deferred to the shallow tick stack.
}
static app_redraw_t reader_background_action(uint16_t x, uint16_t y) {
    const EpdRect back = {32,225,64,64};
    if (s_reader_panel == READER_PANEL_BACKGROUND_PREVIEW) {
        // 横屏靠画布顶部标题带返回，竖屏仍是抽屉题头与左上返回图钉。
        // Landscape returns through the canvas header; portrait keeps its sheet header and back pin.
        bool close = s_reader_landscape ? (y < 96) : (y < 200 || ui_rect_hit(back, x, y));
        for (int i = 0; i < 3 && !close; ++i) {
            if (!ui_rect_hit(reader_background_preview_action_rect(i), x, y)) continue;
            if (i == 0) {
                if (!app_settings_set_book_background_path("")) return APP_REDRAW_NONE;
                close = true;
            } else if (i == 1) close = true;
            else {
                if (!s_background_count || !s_background_ready ||
                    !app_settings_set_book_background_path(s_backgrounds[s_background_selected].path)) return APP_REDRAW_NONE;
                close = true;
            }
        }
        if (!close) return APP_REDRAW_NONE;
        s_background_prepare_pending = false; s_background_ready = false;
        s_reader_panel = READER_PANEL_BACKGROUND;
        invalidate_prep(); return APP_REDRAW_PAGE;
    }
    const bool close_directory = s_reader_landscape ? (y < 96) : (y < 200 || ui_rect_hit(back, x, y));
    if (close_directory || ui_rect_hit(reader_background_back_rect(), x, y)) {
        // 目录页返回：先退一层文件夹；根目录再返回就回到阅读背景菜单（三级菜单的第一层）。
        // Directory Back: pop one folder first; from the root it returns to the background menu.
        s_background_prepare_pending = false;
        if (reader_background_up()) { invalidate_prep(); return APP_REDRAW_PAGE; }
        s_reader_panel = READER_PANEL_BACKGROUND_MENU;
        invalidate_prep(); return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(reader_background_clear_rect(), x, y)) {
        if (!app_settings_set_book_background_path("")) return APP_REDRAW_NONE;
        ui_reader_background_release();
        invalidate_prep(); return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(reader_background_pager_rect(-1), x, y)) return reader_background_step(-1);
    if (ui_rect_hit(reader_background_pager_rect(1), x, y)) return reader_background_step(1);
    for (int row = 0; row < READER_BACKGROUND_ROWS; ++row) {
        int index = s_background_page * READER_BACKGROUND_ROWS + row;
        if (index < s_background_count && ui_rect_hit(reader_background_row(row), x, y)) {
            if (s_backgrounds[index].is_dir) {
                if (!reader_background_enter(s_backgrounds[index].path)) return APP_REDRAW_NONE;
                invalidate_prep(); return APP_REDRAW_PAGE;
            }
            reader_background_preview(index); invalidate_prep(); return APP_REDRAW_NONE;
        }
    }
    return APP_REDRAW_NONE;
}
static app_redraw_t reader_background_menu_action(uint16_t x, uint16_t y) {
    const EpdRect back = {32,225,64,64};
    const bool close = s_reader_landscape ? (y < 96) : (y < 200 || ui_rect_hit(back, x, y));
    if (close || ui_rect_hit(reader_background_menu_button(2), x, y)) {
        s_reader_panel = READER_PANEL_REFRESH_SETTINGS;
        invalidate_prep(); return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(reader_background_menu_button(0), x, y)) {
        s_background_depth = 0;
        copy_text(s_background_dir, sizeof(s_background_dir), "/sdcard/pictures");
        reader_background_scan();
        s_reader_panel = READER_PANEL_BACKGROUND;
        invalidate_prep(); return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(reader_background_menu_button(1), x, y)) {
        if (!app_settings_set_book_background_path("")) return APP_REDRAW_NONE;
        ui_reader_background_release();
        invalidate_prep(); return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}
static app_redraw_t reader_background_tick(void) {
    if (s_view != READING || s_reader_panel != READER_PANEL_BACKGROUND_PREVIEW || !s_background_prepare_pending)
        return APP_REDRAW_NONE;
    s_background_prepare_pending = false;
    s_background_ready = s_background_count && s_background_selected >= 0 &&
        s_background_selected < s_background_count && ui_reader_background_prepare(s_backgrounds[s_background_selected].path);
    if (!s_background_ready) {
        // 把「无法预览」按真实原因拆开：格式/隔行、尺寸、内存、解码损坏各自给不同提示。
        // Split "cannot preview" by real cause: format, size, memory or corrupt data.
        const char *notice = "无法预览该图片，请换一张";
        switch (ui_reader_background_last_status()) {
            case UI_READER_BACKGROUND_ERR_FORMAT: notice = "图片格式不支持或文件已损坏"; break;
            case UI_READER_BACKGROUND_ERR_TOO_LARGE: notice = "图片尺寸过大（最大 8192×8192）"; break;
            case UI_READER_BACKGROUND_ERR_MEMORY: notice = "内存不足，请关闭图书后再试"; break;
            case UI_READER_BACKGROUND_ERR_DECODE: notice = "图片解码失败（文件可能损坏）"; break;
            case UI_READER_BACKGROUND_ERR_OPEN: notice = "无法读取图片文件"; break;
            default: break;
        }
        copy_text(s_background_preview_notice, sizeof(s_background_preview_notice), notice);
    }
    invalidate_prep(); return APP_REDRAW_PAGE;
}
// 字体名称复用已加载的阅读字库；不让UI字体选择规则把它换成内建界面字形。
// Preview the name in the loaded reader face, bypassing the built-in UI-face preference.
static void draw_reading_font_name(uint8_t *fb,EpdRect box,const char *name) {
    char shown[TTF_FONT_NAME_MAX];copy_text(shown,sizeof(shown),name);
    int prior_slot=ttf_font_select(TTF_FONT_SLOT_SYSTEM);
    bool prior_aa=ttf_get_antialias();ttf_set_antialias(true);
    int px=ui_text_effective_px(27),above=0,below=0;
    while(px>1){
        ttf_measure_line_px(px,shown,&above,&below);
        if(above+below+2<=box.height)break;
        --px;
    }
    while(*shown && ttf_text_width_px(px,shown)>box.width){
        size_t n=strlen(shown)-1;
        while(n && ((unsigned char)shown[n]&0xc0)==0x80)--n;
        shown[n]=0;
    }
    ttf_measure_line_px(px,shown,&above,&below);
    ttf_draw_text_px(fb,box.x,box.y+box.height/2+(above-below)/2,px,shown,
                     EPD_DRAW_ALIGN_LEFT,UI_INK_BLACK,UI_INK_WHITE);
    ttf_set_antialias(prior_aa);ttf_font_select(prior_slot);
}
static void draw_font_pair(uint8_t *fb, EpdRect card, const char *title, const char *value) {
    ui_fill_round_rect(fb, card, 20, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, card, 20, 0x70);
    ui_text_box(fb,(EpdRect){card.x+21,card.y+6,card.width-42,card.height/2-12},23,title,EPD_DRAW_ALIGN_LEFT,false);
    char shown[64]; copy_text(shown, sizeof(shown), value);
    EpdRect value_box={card.x+21,card.y+card.height/2,card.width-76,card.height/2-8};
    if (!strcmp(title,"阅读字体"))draw_reading_font_name(fb,value_box,shown);
    else ui_text_box(fb,value_box,27,shown,EPD_DRAW_ALIGN_LEFT,false);
    ui_draw_icon(fb,card.x+card.width-23,card.y+3*card.height/4,26,UI_ICON_CHEVRON_RIGHT,0x38);
}
static void reader_weight_value(char *out,size_t size,int steps){
    if(!steps){snprintf(out,size,"标准");return;}
    unsigned amount=steps<0?-steps:steps,whole=amount/16,fraction=(amount%16)*625;
    snprintf(out,size,"%c%u.%04u",steps<0?'-':'+',whole,fraction);
    size_t n=strlen(out);while(n&&out[n-1]=='0')out[--n]=0;if(n&&out[n-1]=='.')out[--n]=0;
}
static void draw_font_settings(uint8_t* fb) {
    // 界面标签独立于正文AA开关，退出后恢复正文设置。/ UI labels stay smooth independently of body AA; restore it afterward.
    bool prior_aa=ttf_get_antialias();ttf_set_antialias(true);
    if (s_reader_landscape) draw_panel_sheet_landscape(fb, "字体设置");
    else draw_sheet(fb, reader_font_top(), "字体设置");
    int shown_px = s_reader_slider >= 0 ? s_reader_preview_px : s_px;
    char value[16]; snprintf(value, sizeof(value), "%d", shown_px);
    draw_pill_slider(fb, reader_slider_rect(0), "A", "A", value,
                     shown_px - BOOK_PX_MIN, BOOK_PX_MAX - BOOK_PX_MIN + 1, 20, 31);
    draw_font_pair(fb, s_font_card, "阅读字体", ttf_font_display_name());
    char weight_value[20];reader_weight_value(weight_value,sizeof(weight_value),app_settings_book_weight_fine());
    draw_font_pair(fb, s_weight_card, "字重", weight_value);
    draw_font_pair(fb, s_layout_card, "排版设置", "边距 · 行距");
    const bool book_fonts = app_settings_book_fonts();
    EpdRect card = s_bookfont_card;
    ui_fill_round_rect(fb, card, 20, UI_GRAY_WHITE); ui_draw_control_frame(fb, card, 20, 0x70);
    ui_text_box(fb,(EpdRect){card.x+21,card.y+6,card.width-42,card.height/2-12},23,"书内自带字体",EPD_DRAW_ALIGN_LEFT,false);
    ui_text_box(fb,(EpdRect){card.x+21,card.y+card.height/2,card.width-122,card.height/2-8},27,book_fonts?"开启":"关闭",EPD_DRAW_ALIGN_LEFT,false);
    EpdRect toggle = {card.x+card.width-89,card.y+3*card.height/4-19,69,39};
    ui_fill_round_rect(fb, toggle, 19, book_fonts ? 0x38 : 0xd0);
    int knob = toggle.x + (book_fonts ? 49 : 20);
    epd_fill_circle(knob, toggle.y + 19, 16, UI_GRAY_WHITE, fb);
    epd_draw_circle(knob, toggle.y + 19, 16, 0x78, fb);
    EpdRect rule = s_rule_card;
    ui_fill_round_rect(fb, rule, 20, UI_GRAY_WHITE); ui_draw_control_frame(fb, rule, 20, 0x70);
    static const char *const rule_names[] = {"无", "虚线", "点线"};
    int selected_rule = app_settings_book_reading_line();
    ui_text_box(fb,(EpdRect){rule.x+22,rule.y+10,142,rule.height-20},25,"阅读线",EPD_DRAW_ALIGN_LEFT,false);
    ui_text_box(fb,(EpdRect){rule.x+172,rule.y+10,77,rule.height-20},25,rule_names[selected_rule],EPD_DRAW_ALIGN_RIGHT,false);
    ui_draw_icon(fb,rule.x+rule.width-24,rule.y+rule.height/2,27,UI_ICON_CHEVRON_RIGHT,0x38);
    EpdRect aa = s_antialias_card;
    ui_fill_round_rect(fb, aa, 20, UI_GRAY_WHITE); ui_draw_control_frame(fb, aa, 20, 0x70);
    ui_text_box(fb,(EpdRect){aa.x+21,aa.y+10,aa.width-122,aa.height-20},25,"抗锯齿",EPD_DRAW_ALIGN_LEFT,false);
    draw_reading_switch(fb,(EpdRect){aa.x+aa.width-89,aa.y+aa.height/2-19,69,39},app_settings_book_antialias());
    const EpdRect done = reader_font_done_rect();
    ui_fill_round_rect(fb, done, 20, UI_GRAY_BLACK);
    reader_panel_text_vc(fb, done.x + done.width / 2, done.y + done.height / 2, 28,
                        "完成", EPD_DRAW_ALIGN_CENTER, true);
    ttf_set_antialias(prior_aa);
}

static EpdRect reader_weight_rect(int index) {
    // 横屏：两个大圆钮分列左右下角，中间留给预览和数值。
    // Landscape: two large round buttons in the lower corners with the preview and value between them.
    if (s_reader_landscape) return (EpdRect){index ? 956 : 100, 350, 160, 160};
    return (EpdRect){index?542:56,909,86,86};
}
static int reader_weight_step(int x,int y) {
    if(ui_rect_hit(reader_weight_rect(0),x,y))return -1;
    if(ui_rect_hit(reader_weight_rect(1),x,y))return 1;
    return 0;
}
static void draw_weight_settings(uint8_t *fb) {
    const bool land = s_reader_landscape;
    if (land) draw_panel_sheet_landscape(fb, "字重");
    else { draw_sheet(fb, 580, "字重"); draw_sheet_back(fb, 580); }
    if (land) ui_text_box(fb,(EpdRect){20, 62, 1176, 44}, 21, "调整阅读文字粗细", EPD_DRAW_ALIGN_CENTER, false);
    else reader_panel_text_vc(fb, 342, 730, 22, "调整阅读文字粗细", EPD_DRAW_ALIGN_CENTER, false);
    ttf_font_select(TTF_FONT_SLOT_SYSTEM);
    int weight=app_settings_book_weight_fine(),prior_weight=ttf_get_stroke_adjust_fine();
    ttf_set_stroke_adjust_fine(weight);
    ttf_draw_text_px(fb, land ? 608 : 342, land ? 185 : 833, 48,
                     "阅读文字 Aa 123", EPD_DRAW_ALIGN_CENTER, 0, 15);
    ttf_set_stroke_adjust_fine(prior_weight);
    if (!land) {
        ui_fill_round_rect(fb,(EpdRect){36,895,612,114},57,0xe0);
        ui_draw_control_frame(fb,(EpdRect){36,895,612,114},57,0x30);
    }
    // 横杠按圆钮大小放大；竖屏 24×3 的像素与原实现完全一致。
    // Bars scale with the button size; the portrait 24×3 pixels are unchanged from the original.
    const int arm = land ? 36 : 24, arm_thick = land ? 5 : 3;
    for(int i=0;i<2;++i){
        EpdRect control=reader_weight_rect(i);
        int cx=control.x+control.width/2, cy=control.y+control.height/2, radius=control.height/2;
        epd_fill_circle(cx,cy,radius,UI_GRAY_WHITE,fb);
        ui_draw_control_frame(fb,control,radius,0x30);
        if (i == 0) ui_fill_rect_fast((EpdRect){cx-arm/2,cy-arm_thick/2,arm,arm_thick},
                                      weight<=-APP_BOOK_WEIGHT_FINE_MAX?0xa0:0x20,fb);
        else {
            ui_fill_rect_fast((EpdRect){cx-arm/2,cy-arm_thick/2,arm,arm_thick},
                              weight>=APP_BOOK_WEIGHT_FINE_MAX?0xa0:0x20,fb);
            ui_fill_rect_fast((EpdRect){cx-arm_thick/2,cy-arm/2,arm_thick,arm},
                              weight>=APP_BOOK_WEIGHT_FINE_MAX?0xa0:0x20,fb);
        }
    }
    char value[20];reader_weight_value(value,sizeof(value),weight);
    if (land) {
        ui_text_box(fb,(EpdRect){408, 238, 400, 64}, 44, value, EPD_DRAW_ALIGN_CENTER, false);
        ui_text_box(fb,(EpdRect){308, 304, 600, 36}, 19, "像素 · 每次 1/16", EPD_DRAW_ALIGN_CENTER, false);
        ui_text_box(fb,(EpdRect){20, 520, 1176, 30}, 17, "标准保留字体原始笔画", EPD_DRAW_ALIGN_CENTER, false);
        ui_text_box(fb,(EpdRect){20, 552, 1176, 30}, 17, "同时适用于导入字体和书内字体", EPD_DRAW_ALIGN_CENTER, false);
    } else {
        reader_panel_text_vc(fb,342,936,44,value,EPD_DRAW_ALIGN_CENTER,false);
        reader_panel_text_vc(fb,342,975,20,"像素 · 每次 1/16",EPD_DRAW_ALIGN_CENTER,false);
        reader_panel_text_vc(fb, 342, 1030, 20, "标准保留字体原始笔画", EPD_DRAW_ALIGN_CENTER, false);
        reader_panel_text_vc(fb, 342, 1070, 20, "同时适用于导入字体和书内字体", EPD_DRAW_ALIGN_CENTER, false);
    }
    const EpdRect done = reading_done_rect();
    ui_fill_round_rect(fb, done, 20, UI_GRAY_BLACK);
    if (land) ui_text_box(fb, done, 26, "完成", EPD_DRAW_ALIGN_CENTER, true);
    else reader_panel_text_vc(fb, 342, 1170, 26, "完成", EPD_DRAW_ALIGN_CENTER, true);
}

static EpdRect rule_style_rect(int index) {
    if (s_reader_landscape) {
        // 横屏：三张样式卡并排铺满画布，上下位置控件对齐到各自卡片下方。
        // Landscape: three style cards across the canvas with the offset controls aligned beneath them.
        return (EpdRect){20 + index * 396, 96, 376, 180};
    }
    return (EpdRect){36 + index * 208, 788, 196, 120};
}
// 阅读线上下位置三键：绘制与命中共用；竖屏沿用原来的 190/192/190×88。
// The three reading-line offset keys are shared by paint and hit testing; portrait keeps its original row.
static EpdRect rule_offset_rect(int index) {
    if (s_reader_landscape) return (EpdRect){20 + index * 396, 316, 376, 84};
    const EpdRect controls[] = {{36,980,190,88}, {246,980,192,88}, {458,980,190,88}};
    return controls[index];
}
static EpdRect reader_rule_done_rect(void) {
    return s_reader_landscape ? reading_done_rect() : (EpdRect){36, 1113, 612, 72};
}

static void draw_rule_settings(uint8_t *fb) {
    const bool land = s_reader_landscape;
    const int top = 580;
    if (land) draw_panel_sheet_landscape(fb, "阅读线");
    else { draw_sheet(fb, top, "阅读线"); draw_sheet_back(fb, top); }
    if (land) ui_text_box(fb,(EpdRect){20, 64, 1176, 30},21,"选择样式",EPD_DRAW_ALIGN_LEFT,false);
    else reader_panel_text(fb, 42, 741, 21, "选择样式", EPD_DRAW_ALIGN_LEFT, false);
    static const char *const names[] = {"无", "虚线", "点线"};
    int selected = app_settings_book_reading_line();
    for (int i = 0; i < 3; ++i) {
        EpdRect card = rule_style_rect(i);
        ui_fill_round_rect(fb, card, 20, selected == i ? 0xc8 : 0xe8);
        ui_draw_control_frame(fb, card, 20, selected == i ? 0x40 : 0x78);
        // 横屏卡片中心远在竖屏辅助函数的 642 列限之外，居中文字改用卡片自身的框。
        // Landscape card centres sit past the portrait helper's 642-column limit, so centre text in the card box.
        if (land) ui_text_box(fb,(EpdRect){card.x, card.y + 40, card.width, 44}, 24,
                              names[i], EPD_DRAW_ALIGN_CENTER, false);
        else reader_panel_text_vc(fb, card.x + card.width / 2, card.y + 37, 24,
                                  names[i], EPD_DRAW_ALIGN_CENTER, false);
        const int rule_y = card.y + (land ? 128 : 83);
        if (i) {
            int span = i == 1 ? 14 : 3, step = i == 1 ? 24 : 13;
            int start = card.x + 25, end = card.x + card.width - 25;
            for (int x = start; x < end; x += step)
                ui_fill_rect_fast((EpdRect){x, rule_y, x + span <= end ? span : end - x, 2}, 0x48, fb);
        } else if (land) ui_text_box(fb,(EpdRect){card.x, rule_y - 22, card.width, 44}, 17,
                                     "不显示", EPD_DRAW_ALIGN_CENTER, false);
        else reader_panel_text_vc(fb, card.x + card.width / 2, rule_y, 17, "不显示", EPD_DRAW_ALIGN_CENTER, false);
    }
    char offset[36];
    snprintf(offset, sizeof(offset), "上下位置  %+d", app_settings_book_reading_line_offset());
    if (land) ui_text_box(fb,(EpdRect){20, 280, 700, 32},21,offset,EPD_DRAW_ALIGN_LEFT,false);
    else reader_panel_text(fb, 42, 936, 21, offset, EPD_DRAW_ALIGN_LEFT, false);
    const char *const labels[] = {"上移 2px", "恢复居中", "下移 2px"};
    for (int i = 0; i < 3; ++i) {
        EpdRect control = rule_offset_rect(i);
        ui_fill_round_rect(fb, control, 20, selected ? 0xe0 : 0xf0);
        ui_draw_control_frame(fb, control, 20, selected ? 0x60 : 0xa0);
        if (land) ui_text_box(fb, control, 22, labels[i], EPD_DRAW_ALIGN_CENTER, false);
        else reader_panel_text_vc(fb, control.x + control.width / 2,
                   control.y + control.height / 2, 22, labels[i], EPD_DRAW_ALIGN_CENTER, false);
    }
    if (!selected) {
        if (land) ui_text_box(fb,(EpdRect){20, 424, 1176, 36},18,"选择虚线或点线后可调整位置",EPD_DRAW_ALIGN_LEFT,false);
        else reader_panel_text(fb, 42, 1080, 18, "选择虚线或点线后可调整位置", EPD_DRAW_ALIGN_LEFT, false);
    }
    const EpdRect done = reader_rule_done_rect();
    ui_fill_round_rect(fb, done, 20, UI_GRAY_BLACK);
    if (land) ui_text_box(fb, done, 23, "返回字体设置", EPD_DRAW_ALIGN_CENTER, true);
    else reader_panel_text_vc(fb, 342, 1149, 23, "返回字体设置", EPD_DRAW_ALIGN_CENTER, true);
}

static EpdRect indent_adjust_rect(int index) {
    if (s_reader_landscape) {
        // 横屏：缩进微调与首行缩进同一行高，三个控件横向排开；上移后让出第 5 条滑杆。
        // Landscape: the indent-fine controls share the indent row's pitch and sit below the fifth rail.
        const EpdRect wide[] = {{170,528,160,60}, {346,528,360,60}, {722,528,160,60}};
        return wide[index];
    }
    const EpdRect controls[] = {{214,1044,100,72}, {322,1044,208,72}, {538,1044,100,72}};
    return controls[index];
}
// 缩进微调的局部刷新区：竖屏保持原来的 424×72，横屏覆盖同一组三个控件。
// Area refresh for the indent-fine row: the original 424×72 in portrait, the three controls in landscape.
static EpdRect reader_indent_adjust_area(void) {
    if (s_reader_landscape) return (EpdRect){166,522,720,72};
    return (EpdRect){214,1044,424,72};
}
// 首行缩进四选一：绘制与点击共用；竖屏保持原 100×64 列表。
// First-line-indent tabs shared by paint and hit testing; portrait keeps its 100×64 row.
static EpdRect reader_indent_choice_rect(int index) {
    if (s_reader_landscape) return (EpdRect){170 + index * 244, 460, 228, 60};
    return (EpdRect){214 + index * 108, 970, 100, 64};
}
static EpdRect reader_layout_back_rect(void) {
    // 横屏返回键专用一行，位于缩进微调与首行缩进之下；竖屏保持原位置。
    // 横屏缩进微调的按住热区会向外扩 6/16 像素，返回键从 598 起排避免抢走顶部 2 像素。
    // Landscape gets a dedicated back row below the indent-fine controls; portrait keeps its old one.
    // The landscape indent-fine hold zone expands by 6/16 px, so the back row starts at 598 to keep
    // its top two pixels out of the indent hit band.
    return s_reader_landscape ? (EpdRect){20,598,1176,58} : (EpdRect){36,1132,612,72};
}
static int indent_adjust_hit(int x, int y) {
    for(int i=0;i<3;++i){
        EpdRect r=indent_adjust_rect(i);
        r.x-=4;r.width+=8;r.y-=6;r.height+=16;
        if(ui_rect_hit(r,x,y))return i;
    }
    return -1;
}
static void reader_indent_hold_cancel(void) {
    memset(&s_indent_hold,0,sizeof(s_indent_hold));
    s_indent_feedback_pending=false;
}
static void draw_indent_adjustments(uint8_t *fb) {
    bool preview=s_indent_hold.active&&!s_indent_hold.cancelled;
    int value=preview?s_indent_hold.value:app_settings_book_indent_adjust();
    char adjustment[28];snprintf(adjustment,sizeof(adjustment),"%+d px · 复位",value);
    const char *labels[]={"−",adjustment,"+"};
    for(int i=0;i<3;++i){
        EpdRect control=indent_adjust_rect(i);
        bool pressed=preview&&s_indent_hold.control==i;
        ui_fill_round_rect(fb,control,16,pressed?UI_GRAY_BLACK:0xf0);
        ui_draw_control_frame(fb,control,16,0x50);
        ui_text_box(fb,(EpdRect){control.x+8,control.y+5,control.width-16,control.height-10},i==1?22:31,labels[i],EPD_DRAW_ALIGN_CENTER,pressed);
    }
}
static app_redraw_t reader_indent_feedback(app_ctx_t *ctx) {
    ui_text_set_system_scale(true);draw_indent_adjustments(ctx->fb);ui_text_set_system_scale(false);
    s_area=reader_indent_adjust_area();s_mode=MODE_DU;s_indent_feedback_pending=true;
    return APP_REDRAW_AREA;
}
static bool reader_indent_present(app_ctx_t *ctx,app_redraw_t redraw) {
    bool pending=s_indent_feedback_pending;s_indent_feedback_pending=false;
    if(!pending||redraw!=APP_REDRAW_AREA||s_view!=READING||s_reader_panel!=READER_PANEL_LAYOUT_SETTINGS||ctx->request_app)return false;
    guard_draw_result(ctx->hl,update_display_area_diff_with(ctx->hl,&E0470_FOLLOW_WAVEFORM,MODE_DU,s_area));
    return true;
}
static void draw_layout_settings(uint8_t* fb) {
    const bool land = s_reader_landscape;
    // 竖屏抽屉上移 120 像素，给新增的第 5 条「上下边距」滑杆腾出整行；横屏不用该值。
    // The portrait drawer rises 120 px to fit the new fifth vertical-margin rail; landscape ignores it.
    const int top = 380;
    if (land) draw_panel_sheet_landscape(fb, "排版设置");
    else { draw_sheet(fb, top, "排版设置"); draw_sheet_back(fb, top); }
    int shown_margin = s_reader_slider >= 0 ? s_reader_preview_margin : s_margin;
    int shown_margin_v = s_reader_slider >= 0 ? s_reader_preview_margin_v : s_margin_v;
    int shown_line = s_reader_slider >= 0 ? s_reader_preview_line : app_settings_book_line_spacing();
    int shown_para = s_reader_slider >= 0 ? s_reader_preview_para : app_settings_book_paragraph_spacing();
    int shown_tracking = s_reader_slider >= 0 ? s_reader_preview_tracking : app_settings_book_tracking();
    int margin_widths[BOOK_MARGIN_CHOICES], margin_values[BOOK_MARGIN_CHOICES];
    int margin_count = reader_margin_levels(s_px, (shown_tracking + APP_BOOK_TRACK_MIN),
                                             margin_widths, margin_values);
    draw_pill_slider(fb, reader_slider_rect(1), "小", "大", "边距",
                     reader_margin_level_for(shown_margin, s_px, (shown_tracking + APP_BOOK_TRACK_MIN)),
                     margin_count, 21, 21);
    // 行距放宽到 100% 起，用户还能再往紧调一档；滑杆档位 100..150。
    // Line spacing starts at 100% so it can go one step tighter; the rail covers 100..150.
    int line_i = shown_line - 100;
    if (line_i < 0) line_i = 0;
    if (line_i > 50) line_i = 50;
    draw_pill_slider(fb, reader_slider_rect(2), "紧", "松", "行距", line_i, 51, 21, 21);
    if (land) ui_text_box(fb,(EpdRect){24,192,136,76},21,"段距",EPD_DRAW_ALIGN_LEFT,false);
    else reader_panel_text(fb, 42, 595, 21, "段距", EPD_DRAW_ALIGN_LEFT, false);
    char value[16]; snprintf(value, sizeof(value), "%d%%", shown_para);
    draw_pill_slider(fb, reader_slider_rect(3), "紧", "松", value, app_settings_book_paragraph_level((uint8_t)shown_para), APP_BOOK_PARAGRAPH_COUNT, 21, 21);
    if (land) ui_text_box(fb,(EpdRect){24,284,136,76},21,"字间距",EPD_DRAW_ALIGN_LEFT,false);
    else reader_panel_text(fb, 42, 715, 21, "字间距", EPD_DRAW_ALIGN_LEFT, false);
    char track_name[24];snprintf(track_name,sizeof(track_name),"%+d px",shown_tracking+APP_BOOK_TRACK_MIN);
    draw_pill_slider(fb, reader_slider_rect(4), "紧", "松", track_name, shown_tracking, APP_BOOK_TRACK_COUNT, 21, 21);
    // 第 5 条滑杆：上下边距，9 档、每档 6 像素；标签沿用通栏滑杆的左侧说明。
    // Fifth rail: vertical margin in nine 6-px stops; the caption matches the other full-width rails.
    if (land) ui_text_box(fb,(EpdRect){24,376,136,76},21,"上下边距",EPD_DRAW_ALIGN_LEFT,false);
    else reader_panel_text(fb, 42, 835, 21, "上下边距", EPD_DRAW_ALIGN_LEFT, false);
    char margin_v_name[16]; snprintf(margin_v_name, sizeof(margin_v_name), "%d px", shown_margin_v);
    int margin_v_level = shown_margin_v / 6;
    if (margin_v_level < 0) margin_v_level = 0;
    if (margin_v_level > 8) margin_v_level = 8;
    draw_pill_slider(fb, reader_slider_rect(5), "小", "大", margin_v_name, margin_v_level, 9, 21, 21);
    if (land) ui_text_box(fb,(EpdRect){24,460,140,60},24,"首行缩进",EPD_DRAW_ALIGN_LEFT,false);
    else ui_text_box(fb,(EpdRect){42,970,154,64},24,"首行缩进",EPD_DRAW_ALIGN_LEFT,false);
    static const char* indent_names[] = {"无", "1字", "2字", "3字"};
    int indent = app_settings_book_indent();
    for (int i = 0; i < 4; ++i) {
        EpdRect choice = reader_indent_choice_rect(i);
        bool selected = i == indent;
        ui_fill_round_rect(fb, choice, 16, selected ? UI_GRAY_BLACK : 0xe4);
        ui_draw_control_frame(fb, choice, 16, selected ? UI_GRAY_BLACK : 0x98);
        ui_text_box(fb,(EpdRect){choice.x+8,choice.y+5,choice.width-16,choice.height-10},23,indent_names[i],EPD_DRAW_ALIGN_CENTER,selected);
    }
    if (land) ui_text_box(fb,(EpdRect){24,528,140,60},24,"缩进微调",EPD_DRAW_ALIGN_LEFT,false);
    else ui_text_box(fb,(EpdRect){42,1044,154,72},24,"缩进微调",EPD_DRAW_ALIGN_LEFT,false);
    draw_indent_adjustments(fb);
    EpdRect back = reader_layout_back_rect();
    ui_fill_round_rect(fb, back, 20, UI_GRAY_BLACK);
    if (land) ui_text_box(fb, back, 24, "返回字体设置", EPD_DRAW_ALIGN_CENTER, true);
    else reader_panel_text_vc(fb, 342, 1168, 24, "返回字体设置", EPD_DRAW_ALIGN_CENTER, true);
}

// 用户确认半屏双列布局；绘制与点击共用同一矩形，间隙不穿透。/ Approved two-column half sheet; paint and hit testing share rectangles with inert gaps.
static EpdRect reading_setting_rect(int index) {
    if (index < 0 || index >= 10) return (EpdRect){0, 0, 0, 0};
    if (s_reader_landscape) {
        // 横屏：五列两行铺满画布，十个功能正好一页；卡片高度恢复原来的 208。
        // Landscape: five columns by two rows fill the canvas with the original 208-px card height.
        const int col = index % 5, row = index / 5;
        return (EpdRect){20 + col * 238, 108 + row * 232, 226, 208};
    }
    int extra = reader_ui_extra(56), footer = reader_ui_extra(36);
    int row = index / 2;
    // 竖屏五行双列：行高/行距恢复原来的 98/104，只把抽屉整体上移，十个功能仍排一页。
    // Portrait five two-column rows: restore the original 98/104 card height/pitch and raise the
    // whole sheet instead, so all ten functions still fit on one page.
    return (EpdRect){36 + (index % 2) * 314, 560 + row * 104 - (4 - row) * extra - footer, 298, 98 + extra};
}
static int reading_settings_top(void) {
    if (s_reader_landscape) return 60;
    // 抽屉题头仍给首行留 122px，和原来的视觉间距一致。
    // Keep the 122-px header gap above the first row, matching the original look.
    const int extra = reader_ui_extra(56), footer = reader_ui_extra(36);
    const int first = 560 - 4 * extra - footer;
    const int top = first - 122;
    return top > 0 ? top : 0;
}
static EpdRect reading_done_rect(void) {
    return s_reader_landscape ? (EpdRect){20, 588, 1176, 62} : (EpdRect){36, 1141, 612, 58};
}
static EpdRect reading_toggle_rect(int index) {
    static const int slots[] = {3, 5, 6, 7, 8};
    if (index < 0 || index >= (int)(sizeof(slots) / sizeof(slots[0]))) return (EpdRect){0, 0, 0, 0};
    return reading_setting_rect(slots[index]);
}
static void draw_reading_switch(uint8_t *fb, EpdRect track, bool on) {
    ui_fill_round_rect(fb, track, 19, on ? 0x38 : 0xc4);
    int cx = track.x + (on ? 49 : 20);
    epd_fill_circle(cx, track.y + 19, 16, UI_GRAY_WHITE, fb);
    epd_draw_circle(cx, track.y + 19, 16, 0x78, fb);
}
static void draw_reading_card(uint8_t *fb, int index, const char *title,
                              const char *value, bool cycle) {
    EpdRect card = reading_setting_rect(index);
    ui_fill_round_rect(fb, card, 20, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, card, 20, 0x68);
    char heading[48]; copy_text(heading, sizeof(heading), title);
    fit_text(heading, 23, card.width - 42);
    ui_text_box(fb,(EpdRect){card.x+21,card.y+6,card.width-42,card.height/2-12},23,heading,EPD_DRAW_ALIGN_LEFT,false);
    char shown[48]; copy_text(shown,sizeof(shown),value);
    fit_text(shown, 26, card.width - 76);
    ui_text_box(fb,(EpdRect){card.x+21,card.y+card.height/2,card.width-76,card.height/2-8},26,shown,EPD_DRAW_ALIGN_LEFT,false);
    ui_draw_icon(fb,card.x+card.width-26,card.y+3*card.height/4,26,
                 cycle ? UI_ICON_ROTATE_CW : UI_ICON_CHEVRON_RIGHT, 0x38);
}
static void draw_reading_toggle(uint8_t *fb, int index, const char *title,
                                const char *detail, bool on) {
    EpdRect row = reading_toggle_rect(index);
    ui_fill_round_rect(fb, row, 20, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, row, 20, 0x68);
    if (index == 2) {
        // 半宽格放两行：标题与说明各降一号字，开关仍留在右端；横屏格子变窄时按宽度收字。
        // A half-width cell carries two lines: title and detail step down a size and the switch stays
        // right; narrow landscape cells trim both to the cell width.
        char heading[32]; copy_text(heading, sizeof(heading), title);
        fit_text(heading, 21, row.width - 40);
        ui_text_box(fb,(EpdRect){row.x+20,row.y+10,row.width-40,row.height/2-16},21,heading,EPD_DRAW_ALIGN_LEFT,false);
        char note[64]; copy_text(note, sizeof(note), detail ? detail : "");
        fit_text(note, 17, row.width - 40);
        ui_text_box(fb,(EpdRect){row.x+20,row.y+row.height/2,row.width-40,row.height/2-10},17,note,EPD_DRAW_ALIGN_LEFT,false);
        draw_reading_switch(fb,(EpdRect){row.x+row.width-90,row.y+3*row.height/4-19,69,39},on);
    } else {
        char heading[32]; copy_text(heading, sizeof(heading), title);
        fit_text(heading, 23, row.width - 42);
        ui_text_box(fb,(EpdRect){row.x+21,row.y+6,row.width-42,row.height/2-12},23,heading,EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){row.x+21,row.y+row.height/2,row.width-132,row.height/2-8},26,on?"开启":"关闭",EPD_DRAW_ALIGN_LEFT,false);
        draw_reading_switch(fb,(EpdRect){row.x+row.width-90,row.y+3*row.height/4-19,69,39},on);
    }
}
// 工具栏「划线」列表右上角：长按正文的动作开关（划线 / 打开目录）。
// 用户要求把这个开关从「阅读设置」挪到划线二级页，和它服务的功能放在一起。
// Highlights sheet, top-right: long-press action switch (highlight / open directory). The user
// asked to move it out of the reading-settings panel so it sits next to the feature it drives.
// 竖屏放在抽屉题头那一行的右侧（题头文字居中，短标题不会碰到开关）；横屏放在标题栏下方的
// 右侧空带里；两个方向的命中区都与绘制区完全一致。
// Portrait sits on the sheet header row to the right of the centred title; landscape uses the
// free band under its title bar. Both orientations hit-test exactly what they paint.
static EpdRect highlight_hold_toggle_rect(void) {
    return s_reader_landscape ? (EpdRect){reader_scr_w() - 300, 60, 280, 42}
                              : (EpdRect){430, 560 + 46, 218, 40};
}
static void draw_highlight_hold_toggle(uint8_t *fb) {
    const bool on = app_settings_reader_long_press_highlight();
    const EpdRect row = highlight_hold_toggle_rect();
    // 短标签右对齐：给抽屉标题留出位置，开关仍占最右端。
    // Short right-aligned label leaves room for the sheet title; the switch stays at the right edge.
    ui_text_box(fb, (EpdRect){row.x, row.y + 2, row.width - 82, 34}, 18,
                on ? "划线" : "目录", EPD_DRAW_ALIGN_RIGHT, false);
    draw_reading_switch(fb, (EpdRect){row.x + row.width - 76, row.y, 69, 39}, on);
}
static void draw_reading_settings(uint8_t* fb) {
    if (s_reader_landscape) {
        ui_fill_rect_fast(reader_full_rect(), UI_GRAY_WHITE, fb);
        reader_panel_text(fb, 28, 20, 30, "阅读设置", EPD_DRAW_ALIGN_LEFT, true);
        reader_panel_text(fb, reader_scr_w() - 28, 22, 22, "返回", EPD_DRAW_ALIGN_RIGHT, false);
    } else {
        draw_sheet(fb, reading_settings_top(), "阅读设置");
    }
    char interval[24];
    unsigned pages = app_settings_reader_full_pages();
    if (pages) snprintf(interval, sizeof(interval), "每 %u 页", pages);
    else copy_text(interval, sizeof(interval), "不强制");
    draw_reading_card(fb, 0, "自动全刷", interval, true);
    const uint8_t turn_effect = app_settings_reader_turn_effect();
    draw_reading_card(fb, 1, "翻页效果",
                      turn_effect == 0 ? "普通·快刷" : turn_effect == 1 ? "普通·高清" :
                      turn_effect == 2 ? "水波纹·快刷" : "水波纹·高清", true);
    draw_reading_card(fb, 2, "翻页模式", app_settings_reader_vertical_turn() ? "上下翻页" : "左右翻页", false);
    draw_reading_toggle(fb, 0, "电源键翻页", NULL, app_settings_reader_power_turn());
    draw_reading_card(fb, 4, "按键控制", "自定义三键", false);
    draw_reading_toggle(fb, 1, "全屏沉浸", NULL, app_settings_reader_immersive());
    draw_reading_toggle(fb, 2, "关闭书内图片", "跳过正文插图，保留原书文件", app_settings_reader_hide_images());
    draw_reading_toggle(fb, 3, "自适应阅读方向", NULL, app_settings_reader_adaptive());
    draw_reading_toggle(fb, 4, "竖排（从右到左）", NULL, app_settings_book_vertical());
    // 第十格：阅读背景（三级菜单入口），与竖排同页排满五行双列、十个功能。
    // Tenth cell: the reading-background entry (the three-level menu), completing five tidy
    // two-column rows with ten functions on this page.
    char background_value[64];
    const char *background_path = app_settings_book_background_path();
    if (background_path[0]) {
        const char *base = strrchr(background_path, '/');
        copy_text(background_value, sizeof(background_value), base ? base + 1 : background_path);
    } else copy_text(background_value, sizeof(background_value), "无背景");
    fit_text(background_value, 26, 170);
    draw_reading_card(fb, 9, "阅读背景", background_value, false);
    const EpdRect done = reading_done_rect();
    ui_fill_round_rect(fb, done, 20, UI_GRAY_BLACK);
    reader_panel_text_vc(fb, done.x + done.width / 2, done.y + done.height / 2, 26,
                        "完成", EPD_DRAW_ALIGN_CENTER, true);
}

static void draw_turn_settings(uint8_t *fb) {
    const bool land = s_reader_landscape;
    if (land) draw_panel_sheet_landscape(fb, "翻页模式");
    else { draw_sheet(fb, 270, "翻页模式"); draw_sheet_back(fb, 270); }
    bool vertical = app_settings_reader_vertical_turn();
    for (int i = 0; i < 2; ++i) {
        int y = land ? 110 : 370 + i * 322;
        bool selected = vertical == (i != 0);
        EpdRect card = land ? (EpdRect){36 + i * 592, y, 560, 420}
                            : (EpdRect){36, y, 612, 292};
        ui_fill_round_rect(fb, card, 22, selected ? 0xe0 : 0xf0);
        ui_draw_control_frame(fb, card, 22, 0x50);
        ui_draw_control_frame(fb, (EpdRect){37, y + 1, 610, 290}, 21, 0x50);
        const int card_x = card.x;
        EpdRect diagram = {card_x + 28, y + 37, 182, 220};
        ui_fill_round_rect(fb, diagram, 12, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, diagram, 12, 0x58);
        if (i) {
            ui_hairline(fb, diagram.y + 73, 65, 180, 0x58);
            reader_panel_text_vc(fb, diagram.x + 91, diagram.y + 36, 21, "上一页", EPD_DRAW_ALIGN_CENTER, false);
            reader_panel_text_vc(fb, diagram.x + 91, diagram.y + 147, 21, "下一页", EPD_DRAW_ALIGN_CENTER, false);
        } else {
            ui_fill_rect_fast((EpdRect){diagram.x + 91, diagram.y + 1, 1, 218}, 0x58, fb);
            ui_text_box(fb,(EpdRect){diagram.x + 46 - 39,diagram.y+94-15,78,30},21,"上一",EPD_DRAW_ALIGN_CENTER,false);
            ui_text_box(fb,(EpdRect){diagram.x + 46 - 39,diagram.y+126-15,78,30},21,"页",EPD_DRAW_ALIGN_CENTER,false);
            ui_text_box(fb,(EpdRect){diagram.x + 137 - 39,diagram.y+94-15,78,30},21,"下一",EPD_DRAW_ALIGN_CENTER,false);
            ui_text_box(fb,(EpdRect){diagram.x + 137 - 39,diagram.y+126-15,78,30},21,"页",EPD_DRAW_ALIGN_CENTER,false);
        }
        const int text_x = card_x + 238;
        ui_text_box(fb,(EpdRect){text_x,y+43,350,44},32,i ? "上下翻页" : "左右翻页",EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){text_x,y+112,350,44},23,i ? "上 1/3：上一页" : "左 1/2：上一页",EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){text_x,y+158,350,44},23,i ? "下 2/3：下一页" : "右 1/2：下一页",EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){text_x,y+213,330,44},21,"滑动翻页可在手势设置里改",EPD_DRAW_ALIGN_LEFT,false);
        epd_draw_circle(card_x + 574, y + 61, 12, 0x38, fb);
        if (selected) epd_fill_circle(card_x + 574, y + 61, 7, UI_GRAY_BLACK, fb);
    }
    // 横屏用整幅 text box：reader_panel_text_vc 只按竖屏 684 画布算宽度。
    // Landscape uses a full-width text box because reader_panel_text_vc sizes for portrait only.
    if (land) ui_text_box(fb, (EpdRect){20, 530, 1176, 44}, 21,
                          "中间双击默认切换全屏，可在按键控制的手势设置里修改",
                          EPD_DRAW_ALIGN_CENTER, false);
    else reader_panel_text_vc(fb, 342, 1051, 21,
                              "中间双击默认切换全屏，可在按键控制的手势设置里修改",
                              EPD_DRAW_ALIGN_CENTER, false);
    const EpdRect done = reading_done_rect();
    ui_fill_round_rect(fb, done, 20, UI_GRAY_BLACK);
    reader_panel_text_vc(fb, done.x + done.width / 2, done.y + done.height / 2, 26,
                        "完成", EPD_DRAW_ALIGN_CENTER, true);
}

static const char *reader_key_label(app_reader_key_action_t action) {
    static const char *const labels[] = {"上一页", "下一页", "阅读工具栏", "切换全屏", "返回主页", "手动全刷", "不操作"};
    return labels[action >= 0 && action < APP_READER_KEY_COUNT ? action : APP_READER_KEY_NONE];
}
static EpdRect reader_key_card(unsigned key) {
    if (s_reader_landscape) return (EpdRect){20 + (int)key * 396, 172, 376, 116};
    return (EpdRect){36 + (int)key * 208, 506, 196, 114};
}
static EpdRect reader_key_preset_card(unsigned preset) {
    if (s_reader_landscape) return (EpdRect){20 + (int)(preset - 1) * 596, 396, 580, 130};
    return (EpdRect){36, 810 + (int)(preset - 1) * 148, 612, 136};
}
static EpdRect reader_key_hold_rect(void) {
    return s_reader_landscape ? (EpdRect){20, 300, 1176, 78} : (EpdRect){36, 646, 612, 96};
}
static bool reader_key_preset_selected(unsigned preset) {
    static const app_reader_key_action_t actions[2][3] = {
        {APP_READER_KEY_PREV, APP_READER_KEY_TOOLS, APP_READER_KEY_NEXT},
        {APP_READER_KEY_HOME, APP_READER_KEY_FULLSCREEN, APP_READER_KEY_TOOLS}
    };
    for (unsigned i = 0; i < 3; ++i) if (app_settings_reader_key_action(i) != actions[preset - 1][i]) return false;
    return app_settings_reader_hold_action() == (preset == 1 ? APP_READER_KEY_HOME : APP_READER_KEY_REFRESH);
}
static void draw_key_settings(uint8_t *fb) {
    const bool land = s_reader_landscape;
    if (land) draw_panel_sheet_landscape(fb, "按键控制");
    else { draw_sheet(fb, 270, "按键控制"); draw_sheet_back(fb, 270); }
    static const char *const names[] = {"左键", "中键", "右键"};
    for (unsigned i = 0; i < 3; ++i) {
        int cx = land ? reader_key_card(i).x + 188 : 134 + (int)i * 208;
        int icon_y = land ? 118 : 418;
        if (i == 1) {
            epd_draw_circle(cx, icon_y, 25, UI_GRAY_BLACK, fb);
            epd_draw_circle(cx, icon_y, 24, UI_GRAY_BLACK, fb);
        } else ui_fill_round_rect(fb, (EpdRect){cx - 26, icon_y - 3, 52, 6}, 3, UI_GRAY_BLACK);
        reader_panel_text_vc(fb, cx, land ? 92 : 473, 22, names[i], EPD_DRAW_ALIGN_CENTER, false);
        EpdRect card = reader_key_card(i);
        ui_fill_round_rect(fb, card, 20, 0xf0);
        ui_draw_control_frame(fb, card, 20, 0x58);
        ui_text_box(fb,(EpdRect){card.x+17,card.y+7,card.width-57,36},20,"单击",EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){card.x+12,card.y+52,card.width-24,52},24,reader_key_label(app_settings_reader_key_action(i)),EPD_DRAW_ALIGN_CENTER,false);
        ui_draw_icon(fb, card.x + card.width - 23, card.y + 24, 20, UI_ICON_CHEVRON_DOWN, 0x38);
    }
    EpdRect hold = reader_key_hold_rect();
    ui_fill_round_rect(fb, hold, 20, 0xf0); ui_draw_control_frame(fb, hold, 20, 0x58);
    ui_text_box(fb,(EpdRect){hold.x+22,hold.y+14,238,48},26,"中键长按",EPD_DRAW_ALIGN_LEFT,false);
    ui_text_box(fb,(EpdRect){hold.x+286,hold.y+14,hold.width-382,48},25,
                reader_key_label(app_settings_reader_hold_action()),EPD_DRAW_ALIGN_RIGHT,false);
    ui_draw_icon(fb, hold.x + hold.width - 27, hold.y + hold.height / 2, 20, UI_ICON_CHEVRON_DOWN, 0x38);
    if (!land)
        reader_panel_text(fb, 58, 710, 19, "点击选择长按功能，例如返回主页", EPD_DRAW_ALIGN_LEFT, false);
    else
        reader_panel_text(fb, hold.x + 22, hold.y + 58, 19, "点击选择长按功能，例如返回主页", EPD_DRAW_ALIGN_LEFT, false);
    // 双击/滑动/长按/双指轻点现在都可配置：原来的双击全屏提示改成手势设置入口卡。
    // Double tap, swipes, long press and two-finger taps are configurable now, so the old
    // double-tap hint becomes the gesture-sheet entry card instead of a second control.
    draw_gesture_entry(fb);
    for (unsigned preset = 1; preset <= 2; ++preset) {
        EpdRect card = reader_key_preset_card(preset);
        bool selected = reader_key_preset_selected(preset);
        ui_fill_round_rect(fb, card, 20, selected ? 0xd8 : UI_GRAY_WHITE);
        ui_draw_control_frame(fb, card, 20, 0x58);
        char title[32]; snprintf(title, sizeof(title), "推荐设置 %u", preset);
        ui_text_box(fb,(EpdRect){58,card.y+7,344,49},26,title,EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){435,card.y+7,186,49},20,selected?"已应用":"点击应用",EPD_DRAW_ALIGN_RIGHT,false);
        ui_text_box(fb,(EpdRect){58,card.y+59,564,40},21,preset==1?"左上一页 · 中工具栏 · 右下一页":"左回首页 · 中全屏 · 右工具栏",EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){58,card.y+103,564,34},19,preset==1?"中键长按：返回主页":"中键长按：手动全刷",EPD_DRAW_ALIGN_LEFT,false);
    }
    const EpdRect done = reading_done_rect();
    ui_fill_round_rect(fb, done, 20, UI_GRAY_BLACK);
    reader_panel_text_vc(fb, done.x + done.width / 2, done.y + done.height / 2, 26,
                        "完成", EPD_DRAW_ALIGN_CENTER, true);
}
// 按键选择行：竖屏保持原列表，横屏七行通栏铺满画布并给底部返回键留位。
// Key-pick rows: the portrait list stays as before; landscape uses seven full-width rows
// with a tighter pitch so the bottom Done button still fits.
static EpdRect reader_key_pick_row(int index) {
    if (s_reader_landscape) return (EpdRect){20, 96 + index * 66, 1176, 60};
    return (EpdRect){36, 390 + index * 94, 612, 78};
}
static void draw_key_picker(uint8_t *fb) {
    const bool land = s_reader_landscape;
    static const char *const titles[] = {"左键功能", "中键功能", "右键功能", "中键长按功能"};
    if (land) draw_panel_sheet_landscape(fb, titles[s_reader_key_pick < 4 ? s_reader_key_pick : 0]);
    else { draw_sheet(fb, 270, titles[s_reader_key_pick < 4 ? s_reader_key_pick : 0]); draw_sheet_back(fb, 270); }
    for (int i = 0; i < APP_READER_KEY_COUNT; ++i) {
        EpdRect card = reader_key_pick_row(i);
        bool selected = (s_reader_key_pick == 3 ? app_settings_reader_hold_action() : app_settings_reader_key_action(s_reader_key_pick)) == i;
        ui_fill_round_rect(fb, card, 20, selected ? 0xd8 : UI_GRAY_WHITE);
        ui_draw_control_frame(fb, card, 20, 0x58);
        reader_panel_text_vc(fb, card.x + 22, card.y + card.height / 2, land ? 26 : 27,
                             reader_key_label(i), EPD_DRAW_ALIGN_LEFT, false);
        int cx = card.x + card.width - 40;
        epd_draw_circle(cx, card.y + card.height / 2, 11, 0x38, fb);
        if (selected) epd_fill_circle(cx, card.y + card.height / 2, 6, UI_GRAY_BLACK, fb);
    }
    const char *hint = s_reader_key_error[0] ? s_reader_key_error : "从底部上滑可随时打开阅读工具栏";
    if (land) ui_text_box(fb,(EpdRect){20, 554, 1176, 28}, 18, hint, EPD_DRAW_ALIGN_CENTER, false);
    else reader_panel_text_vc(fb, 342, 1112, 20, hint, EPD_DRAW_ALIGN_CENTER, false);
    const EpdRect done = reading_done_rect();
    ui_fill_round_rect(fb, done, 20, UI_GRAY_BLACK);
    if (land) ui_text_box(fb, done, 26, "返回", EPD_DRAW_ALIGN_CENTER, true);
    else reader_panel_text_vc(fb, 342, 1170, 26, "返回", EPD_DRAW_ALIGN_CENTER, true);
}
// 选择结果保存失败与成功都回到按键设置页；两种方向共用，避免两处判断漂移。
// A pick returns to the key sheet whether or not saving succeeds; both orientations share it.
static app_redraw_t reader_key_pick_apply(int index) {
    bool saved = s_reader_key_pick == 3 ? app_settings_set_reader_hold_action(index)
        : app_settings_set_reader_key_action(s_reader_key_pick, index);
    if (!saved) {
        copy_text(s_reader_key_error, sizeof(s_reader_key_error), "保存失败，请重试");
        return APP_REDRAW_PAGE;
    }
    s_reader_panel = READER_PANEL_KEY_SETTINGS;
    return APP_REDRAW_PAGE;
}

/* ---- 手势设置页 / Gesture sheets ---- */
// 入口卡画在按键控制页里：占住原来"屏幕中间双击切换全屏"的提示位置，不再新增底栏或工具栏图标。
// The entry card lives in the key sheet, replacing the old double-tap hint, so no toolbar or
// bottom-bar icon is added.
static EpdRect reader_gesture_entry_rect(void) {
    // 横屏放在预设卡下方的空带里，竖屏放在长按卡与预设卡之间，两张方向都避开既有控件。
    // Landscape uses the free band under the presets; portrait sits between the hold card and the
    // preset cards. Neither orientation moves an existing control.
    return s_reader_landscape ? (EpdRect){20, 528, 1176, 48} : (EpdRect){36, 760, 612, 46};
}
static void draw_gesture_entry(uint8_t *fb) {
    const EpdRect entry = reader_gesture_entry_rect();
    const uint8_t current = app_settings_gesture_preset();
    ui_fill_round_rect(fb, entry, 18, 0xf0);
    ui_draw_control_frame(fb, entry, 18, 0x58);
    ui_text_box(fb, (EpdRect){entry.x + 22, entry.y + 4, 300, entry.height - 8},
                s_reader_landscape ? 24 : 23, "手势设置", EPD_DRAW_ALIGN_LEFT, false);
    ui_text_box(fb, (EpdRect){entry.x + entry.width - 330, entry.y + 4, 270, entry.height - 8},
                19, app_settings_gesture_preset_name(current), EPD_DRAW_ALIGN_RIGHT, false);
    ui_draw_icon(fb, entry.x + entry.width - 26, entry.y + entry.height / 2, 18,
                 UI_ICON_CHEVRON_RIGHT, 0x38);
}
// 槽位行：竖屏七行通栏（从抽屉题头下方 370 起）；横屏分两列（4+3），给预设卡与完成键留位。
// Slot rows: seven full-width portrait rows below the sheet header; landscape splits them 4+3
// into two columns so the preset cards and Done bar still fit.
static EpdRect reader_gesture_slot_row(int slot) {
    if (s_reader_landscape)
        return (EpdRect){20 + (slot / 4) * 596, 96 + (slot % 4) * 62, 580, 54};
    return (EpdRect){36, 370 + slot * 74, 612, 64};
}
// 预设卡 2×2；竖屏与横屏共用行列规则，只有尺寸和起点不同。
// Preset cards form a 2x2 grid; both orientations share the column/row rule and differ in size.
static EpdRect reader_gesture_preset_card(unsigned preset) {
    const unsigned column = (preset - 1) % 2, row = (preset - 1) / 2;
    if (s_reader_landscape)
        return (EpdRect){20 + (int)column * 596, 350 + (int)row * 78, 580, 70};
    return (EpdRect){36 + (int)column * 306, 890 + (int)row * 76, 298, 70};
}
static void draw_gesture_settings(uint8_t *fb) {
    const bool land = s_reader_landscape;
    if (land) draw_panel_sheet_landscape(fb, "手势设置");
    else { draw_sheet(fb, 270, "手势设置"); draw_sheet_back(fb, 270); }
    for (int i = 0; i < APP_GESTURE_COUNT; ++i) {
        const EpdRect row = reader_gesture_slot_row(i);
        ui_fill_round_rect(fb, row, 18, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, row, 18, 0x58);
        reader_panel_text_vc(fb, row.x + 22, row.y + row.height / 2, land ? 24 : 25,
                             app_settings_gesture_slot_name((app_gesture_slot_t)i),
                             EPD_DRAW_ALIGN_LEFT, false);
        reader_panel_text_vc(fb, row.x + row.width - 56, row.y + row.height / 2, 22,
                             app_settings_gesture_action_name(
                                 app_settings_gesture_action((app_gesture_slot_t)i)),
                             EPD_DRAW_ALIGN_RIGHT, false);
        ui_draw_icon(fb, row.x + row.width - 28, row.y + row.height / 2, 18,
                     UI_ICON_CHEVRON_RIGHT, 0x38);
    }
    const uint8_t current = app_settings_gesture_preset();
    for (unsigned preset = 1; preset <= 4; ++preset) {
        const EpdRect card = reader_gesture_preset_card(preset);
        const bool selected = current == preset;
        ui_fill_round_rect(fb, card, 18, selected ? 0xd8 : UI_GRAY_WHITE);
        ui_draw_control_frame(fb, card, 18, 0x58);
        char title[48];
        snprintf(title, sizeof(title), "推荐 %u · %s", preset,
                 app_settings_gesture_preset_name((uint8_t)preset));
        ui_text_box(fb, (EpdRect){card.x + 18, card.y + 4, card.width - 36, land ? 32 : 36},
                    land ? 23 : 21, title, EPD_DRAW_ALIGN_LEFT, false);
        ui_text_box(fb, (EpdRect){card.x + 18, card.y + (land ? 38 : 44), card.width - 36, 26},
                    18, selected ? "已应用" : "点击应用", EPD_DRAW_ALIGN_LEFT, false);
    }
    const char *hint = s_gesture_error[0] ? s_gesture_error
                                          : "点按槽位选择动作，推荐设置一键套用";
    // 横屏用整幅 text box：reader_panel_text_vc 的宽度公式写死竖屏 684 画布，横屏会缩到看不清。
    // Landscape uses a full-width text box: reader_panel_text_vc hard-codes the 684 portrait canvas,
    // so a centred landscape hint would be squeezed to an unreadable size.
    if (land) ui_text_box(fb, (EpdRect){20, 500, 1176, 44}, 20, hint, EPD_DRAW_ALIGN_CENTER, false);
    else reader_panel_text_vc(fb, 342, 1075, 20, hint, EPD_DRAW_ALIGN_CENTER, false);
    const EpdRect done = reading_done_rect();
    ui_fill_round_rect(fb, done, 20, UI_GRAY_BLACK);
    reader_panel_text_vc(fb, done.x + done.width / 2, done.y + done.height / 2, 26,
                         "完成", EPD_DRAW_ALIGN_CENTER, true);
}
// 动作选择行：竖屏九行通栏（题头下方起）；横屏按 5+4 分两列，底部返回键留出位置。
// Action rows: nine full-width portrait rows below the header; landscape uses two columns (5+4)
// above the bottom Done bar.
static EpdRect reader_gesture_pick_row(int index) {
    if (s_reader_landscape)
        return (EpdRect){20 + (index / 5) * 596, 96 + (index % 5) * 88, 580, 78};
    return (EpdRect){36, 368 + index * 78, 612, 64};
}
static void draw_gesture_picker(uint8_t *fb) {
    const bool land = s_reader_landscape;
    char title[64];
    snprintf(title, sizeof(title), "%s功能", app_settings_gesture_slot_name(s_gesture_slot));
    if (land) draw_panel_sheet_landscape(fb, title);
    else { draw_sheet(fb, 270, "手势动作"); draw_sheet_back(fb, 270); }
    const app_gesture_action_t current = app_settings_gesture_action(s_gesture_slot);
    for (int i = 0; i < APP_GESTURE_ACTION_COUNT; ++i) {
        const EpdRect row = reader_gesture_pick_row(i);
        const bool selected = (int)current == i;
        ui_fill_round_rect(fb, row, 18, selected ? 0xd8 : UI_GRAY_WHITE);
        ui_draw_control_frame(fb, row, 18, 0x58);
        reader_panel_text_vc(fb, row.x + 22, row.y + row.height / 2, land ? 25 : 26,
                             app_settings_gesture_action_name((app_gesture_action_t)i),
                             EPD_DRAW_ALIGN_LEFT, false);
        const int cx = row.x + row.width - 40;
        epd_draw_circle(cx, row.y + row.height / 2, 11, 0x38, fb);
        if (selected) epd_fill_circle(cx, row.y + row.height / 2, 6, UI_GRAY_BLACK, fb);
    }
    const char *hint = s_gesture_error[0] ? s_gesture_error
                                          : "选中即保存；「不操作」表示该手势不动作";
    // 与手势页相同：横屏提示用整幅 text box，避开只按竖屏画布计算宽度的辅助函数。
    // Same as the gesture sheet: landscape uses a full-width text box instead of the
    // portrait-only width helper.
    if (land) ui_text_box(fb, (EpdRect){20, 528, 1176, 44}, 19, hint, EPD_DRAW_ALIGN_CENTER, false);
    else reader_panel_text_vc(fb, 342, 1095, 19, hint, EPD_DRAW_ALIGN_CENTER, false);
    const EpdRect done = reading_done_rect();
    ui_fill_round_rect(fb, done, 20, UI_GRAY_BLACK);
    reader_panel_text_vc(fb, done.x + done.width / 2, done.y + done.height / 2, 26,
                         "返回", EPD_DRAW_ALIGN_CENTER, true);
}
// 保存成功与失败都留在手势页；失败只换提示，不吞掉用户的选择。
// A pick stays on the gesture sheet either way; a failure only swaps the notice.
static app_redraw_t reader_gesture_pick_apply(int index) {
    if (!app_settings_set_gesture_action(s_gesture_slot, (app_gesture_action_t)index)) {
        copy_text(s_gesture_error, sizeof(s_gesture_error), "保存失败，请重试");
        return APP_REDRAW_PAGE;
    }
    s_gesture_error[0] = 0;
    s_reader_panel = READER_PANEL_GESTURE;
    return APP_REDRAW_PAGE;
}
static app_redraw_t reader_gesture_preset_apply(unsigned preset) {
    if (!app_settings_set_gesture_preset((uint8_t)preset)) {
        copy_text(s_gesture_error, sizeof(s_gesture_error), "保存失败，请重试");
        return APP_REDRAW_PAGE;
    }
    s_gesture_error[0] = 0;
    return APP_REDRAW_PAGE;
}

static int reader_font_picker_top(void) {
    // 横屏没有抽屉式面板题头，标题直接铺在画布顶部。
    // Landscape has no sheet header; the title sits on the canvas itself.
    if (s_reader_landscape) return 64;
    return app_settings_system_font_size()>=150?270:584;
}
static EpdRect reader_font_pick_rect(int slot) {
    if (s_reader_landscape) {
        // 横屏三列三行，一页九项与竖屏相同；名称按卡片宽度自适应。
        // Landscape: three columns by three rows, the same nine items per page; names fit the card width.
        return (EpdRect){20 + (slot % 3) * 396, 160 + (slot / 3) * 152, 376, 140};
    }
    bool large=app_settings_system_font_size()>=150;
    int columns=large?2:3;
    return (EpdRect){36+(slot%columns)*(large?314:204),
                     reader_font_picker_top()+(large?150:131)+(slot/columns)*146,
                     large?298:180,126};
}
/* ---- 字体选择页预览缓存 / Font-picker preview cache ---- */
// 字体目录扫描有一次 SD 目录遍历开销；同一目录在一次开机内只需扫一次，换目录或卡重插才重扫。
// The font directory walk costs an SD readdir pass; scan once per boot per directory and rescan
// only when the configured directory changes or the card is re-inserted.
static char s_font_scan_dir[BOOK_STORE_PATH_MAX];
static bool s_font_scan_done;
static void reader_scan_fonts(void) {
    const char *dir = app_settings_fonts_dir();
    if (s_font_scan_done && !strcmp(s_font_scan_dir, dir)) return;
    (void)ttf_font_scan();
    copy_text(s_font_scan_dir, sizeof(s_font_scan_dir), dir);
    s_font_scan_done = true;
}
// 字体选择页要拿每个候选字体画出它自己的名字。原实现每次重绘都按卡片逐个
// ttf_font_open()：每个候选字库都要重读表、换掉 0 号槽，返回前还要把阅读字体再开一次，
// 一页 9 张卡就是十次字体装载，切一次字体后又来一遍。这里把名称光栅成小块覆盖率遮罩缓存：
// 首帧先用当前字体占位（打开面板不再等字体装载），空闲时每轮补一张，补满后翻页/换字体
// 重绘不再装载任何字体。离开这本书时整块释放。
// The picker renders each candidate's name in its own face. The old code called
// ttf_font_open() per card on every repaint (each call re-reads the face tables and swaps slot 0,
// then the reading face is reopened before returning): ten face loads per page and again after
// every font switch. This caches each name as a small coverage mask instead. The first frame uses
// the current face as a placeholder, so opening the picker no longer waits for face loads; idle
// ticks fill one card at a time, after which repaints need no face load at all.
#define FONT_PREVIEW_MAX BOOK_FONT_PAGE
typedef struct {
    char path[TTF_FONT_PATH_MAX];
    uint8_t *mask;          // 覆盖率遮罩，0 空，255 满墨 / coverage mask, 0 empty, 255 full ink
    unsigned width, height;
    int px;
    int8_t state;           // 0 待生成，1 就绪，-1 失败 / 0 pending, 1 ready, -1 failed
} font_preview_t;
static font_preview_t s_font_previews[FONT_PREVIEW_MAX];
static int s_font_preview_page = -1;
static int s_font_preview_slots;
static uint32_t s_font_preview_sig;
static bool s_font_preview_oom;
static uint8_t s_font_preview_gamma[256];
static bool s_font_preview_gamma_ready;

static void font_preview_clear(void) {
    for (int i = 0; i < FONT_PREVIEW_MAX; ++i) {
        free(s_font_previews[i].mask);
        memset(&s_font_previews[i], 0, sizeof(s_font_previews[i]));
    }
    s_font_preview_page = -1;
    s_font_preview_slots = 0;
    s_font_preview_sig = 0;
    s_font_preview_oom = false;
}
// 影响遮罩内容的输入：方向、界面字号、字重微调、抗锯齿与目录数量。
// Inputs that change mask content: orientation, UI type size, stroke fine-tune, AA and catalogue size.
static uint32_t font_preview_signature(void) {
    uint32_t sig = 2166136261u;
#define FONT_PREVIEW_MIX(v) (sig = (sig ^ (uint32_t)(v)) * 16777619u)
    FONT_PREVIEW_MIX((uint32_t)(s_reader_landscape ? 1 : 0));
    FONT_PREVIEW_MIX((uint32_t)app_settings_system_font_size());
    FONT_PREVIEW_MIX((uint32_t)(app_settings_book_weight_fine() + 200));
    FONT_PREVIEW_MIX((uint32_t)(ttf_get_antialias() ? 1 : 0));
    FONT_PREVIEW_MIX((uint32_t)ttf_font_count());
#undef FONT_PREVIEW_MIX
    return sig ? sig : 1u;
}
// 面板绘制期的名称字号：等价于 ui_text_effective_px(25)（面板里系统缩放是打开的）。
// Name type size as the panel sees it: equals ui_text_effective_px(25) with system scaling on.
static int font_preview_name_px(void) {
    const int base = 27;
    return (base * app_settings_system_font_size() + 50) / 100;
}
static void font_preview_ensure(int page) {
    const uint32_t sig = font_preview_signature();
    const int count = ttf_font_count();
    const int start = page * BOOK_FONT_PAGE;
    int slots = count > start ? count - start : 0;
    if (slots > FONT_PREVIEW_MAX) slots = FONT_PREVIEW_MAX;
    if (page == s_font_preview_page && sig == s_font_preview_sig && slots == s_font_preview_slots) return;
    font_preview_clear();
    s_font_preview_page = page;
    s_font_preview_sig = sig;
    s_font_preview_slots = slots;
}
static font_preview_t* font_preview_entry(int slot) {
    if (slot < 0 || slot >= s_font_preview_slots) return NULL;
    const ttf_font_item_t* item = ttf_font_item(s_font_preview_page * BOOK_FONT_PAGE + slot);
    if (!item) return NULL;
    font_preview_t* preview = &s_font_previews[slot];
    if (preview->path[0] && strcmp(preview->path, item->path)) {
        free(preview->mask);
        memset(preview, 0, sizeof(*preview));
    }
    if (!preview->path[0]) copy_text(preview->path, sizeof(preview->path), item->path);
    return preview;
}
// 混色链与原 ttf 绘制一致：掩码里是第一次覆盖率伽马，混色时再取一次；关抗锯齿时按阈值。
// Same mixing chain as the ttf draw: the mask carries one coverage gamma and mixing applies the
// second; with antialiasing off, threshold like the binary draw path.
static uint8_t font_preview_tone(uint8_t coverage) {
    if (!ttf_get_antialias()) return coverage >= 180 ? UI_INK_BLACK : UI_INK_WHITE;
    if (!s_font_preview_gamma_ready) {
        for (int i = 0; i < 256; ++i)
            s_font_preview_gamma[i] = (uint8_t)(255.0f * sqrtf((float)i / 255.0f) + 0.5f);
        s_font_preview_gamma_ready = true;
    }
    const int mixed = (int)UI_INK_WHITE - (int)s_font_preview_gamma[coverage] * (int)UI_INK_WHITE / 255;
    return (uint8_t)mixed;
}
static void font_preview_blit(uint8_t *fb, EpdRect card, const font_preview_t *preview) {
    if (!fb || !preview || !preview->mask) return;
    const int left = card.x + (card.width - (int)preview->width) / 2;
    const int top = card.y + (card.height - (int)preview->height) / 2;
    for (unsigned y = 0; y < preview->height; ++y)
        for (unsigned x = 0; x < preview->width; ++x) {
            const uint8_t coverage = preview->mask[(size_t)y * preview->width + x];
            if (!coverage) continue;
            epd_draw_pixel(left + (int)x, top + (int)y, font_preview_tone(coverage) << 4, fb);
        }
}
// 把选中的字体还给阅读正文：预览生成借用 0 号槽，返回调用的 on_tick 结尾前必须换回来。
// Hand slot 0 back to the reading face: mask generation borrows it and the caller restores it
// before returning from on_tick.
static void font_preview_restore_face(void) {
    if (ttf_font_ready() && s_font_path[0] && !strcmp(ttf_font_path(), s_font_path)) return;
    if (ttf_font_path_is_builtin(s_font_path)) (void)ttf_font_open_builtin();
    else if (s_font_path[0]) (void)ttf_font_open(s_font_path);
}
// 生成一张卡的名称遮罩。返回 true 表示这张卡已就绪（或已判定失败，不再重试）。
// Rasterize one card's name mask; true when the card is settled (ready or permanently failed).
static bool font_preview_generate(int slot) {
    font_preview_t* preview = font_preview_entry(slot);
    if (!preview || preview->state != 0) return false;
    if (s_font_preview_oom) return false;
    if (heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT) < 2u * 1024u * 1024u) {
        // 内存紧张就整页放弃，留占位名字，不反复试探。
        // Give up for the whole page under memory pressure; placeholders stay and were tried once.
        s_font_preview_oom = true;
        return false;
    }
    const ttf_font_item_t* item = ttf_font_item(s_font_preview_page * BOOK_FONT_PAGE + slot);
    const char* name = item ? font_friendly_name(item) : "";
    if (!name[0]) { preview->state = -1; return true; }
    const bool already = ttf_font_ready() && !strcmp(ttf_font_path(), item->path);
    if (!already && ttf_font_open(item->path) != ESP_OK) {
        preview->state = -1;
        font_preview_restore_face();
        return true;
    }
    const int max_w = reader_font_pick_rect(slot).width - 32;
    int px = font_preview_name_px();
    while (px > 1 && ttf_text_width_px(px, name) > max_w) --px;
    const int text_w = ttf_text_width_px(px, name);
    int above = 0, below = 0;
    ttf_measure_line_px(px, name, &above, &below);
    int width = text_w + 6;
    if (width < 1) width = 1;
    if (width > max_w + 6) width = max_w + 6;
    int height = above + below + 4;
    if (height < 1) height = 1;
    if (height > 176) height = 176;
    uint8_t *mask = heap_caps_calloc((size_t)width * (size_t)height, 1,
                                     MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    const bool ok = mask && ttf_text_mask_px(mask, (unsigned)width, (unsigned)height,
                                             3, above + 2, px, name);
    if (!already) font_preview_restore_face();
    if (!ok) {
        free(mask);
        preview->state = -1;
        return true;
    }
    free(preview->mask);
    preview->mask = mask;
    preview->width = (unsigned)width;
    preview->height = (unsigned)height;
    preview->px = px;
    preview->state = 1;
    return true;
}
// 画一张字体卡：有遮罩就用遮罩，没有就先用当前字体占位。
// Paint one font card: use the cached mask when ready, otherwise hold the slot with the current face.
static void draw_font_pick_card(uint8_t *fb, int slot, const char *active) {
    const int start = s_font_page * BOOK_FONT_PAGE;
    const ttf_font_item_t* item = ttf_font_item(start + slot);
    if (!item) return;
    EpdRect card = reader_font_pick_rect(slot);
    const bool selected = active && !strcmp(active, item->path);
    ui_fill_round_rect(fb, card, 18, selected ? 0xc2 : 0xe4);
    ui_draw_control_frame(fb, card, 18, selected ? 0x48 : 0x98);
    font_preview_t* preview = font_preview_entry(slot);
    if (preview && preview->state == 1 && preview->mask) {
        font_preview_blit(fb, card, preview);
    } else {
        char label[TTF_FONT_NAME_MAX];
        copy_text(label, sizeof(label), font_friendly_name(item));
        fit_text(label, 25, card.width - 32);
        draw_font_name_with_current_face(fb, card.x + card.width / 2, card.y + card.height / 2,
                                         label, card.width - 32);
    }
    if (selected) epd_fill_circle(card.x + card.width - 22, card.y + 22, 7, UI_GRAY_BLACK, fb);
}
// 字体选择页/字体设置页的空闲预载：一轮最多装载一个候选字库，完成一张卡；只重画那一张。
// Idle preload for the picker and font sheet: at most one candidate face load per turn; repaint
// only the card that just became ready.
static app_redraw_t font_preview_tick(app_ctx_t *ctx) {
    if (s_view != READING || !s_text || !ctx->fb) return APP_REDRAW_NONE;
    const bool picker = s_reader_panel == READER_PANEL_FONT_PICKER;
    const bool sheet = s_reader_panel == READER_PANEL_FONT_SETTINGS;
    if (!picker && !sheet) return APP_REDRAW_NONE;
    if (s_font_preview_oom || ttf_font_count() <= 0) return APP_REDRAW_NONE;
    if (ctx->consumed || (ctx->touch && ctx->touch->touched) || ctx->request_app ||
        ctx->request_menu || ctx->request_return || s_reader_tap.pending)
        return APP_REDRAW_NONE;
    int page = s_font_page;
    if (!picker) {
        // 字体设置页先按活动字体预算出选择页会停在哪一页，打开选择页时直接命中。
        // On the font sheet, preload the page the active face lives on, so the picker opens warm.
        page = 0;
        const char *active = ttf_font_path();
        for (int i = 0; i < ttf_font_count(); ++i) {
            const ttf_font_item_t *item = ttf_font_item(i);
            if (item && !strcmp(active, item->path)) { page = i / BOOK_FONT_PAGE; break; }
        }
    }
    font_preview_ensure(page);
    if (s_font_preview_slots <= 0) return APP_REDRAW_NONE;
    // 一轮多补几张再只推一次屏：此前每张卡都要一次局刷（约 150ms），9 张卡光是刷屏就
    // 1 秒多；现在一张页内最多 4 张一起生成、合并成一次区域刷新，手感快很多。
    // Generate several previews per turn and push one merged area: previously every card cost
    // its own ~150 ms area refresh, so a page of nine waited over a second just for the panel.
    char active[TTF_FONT_PATH_MAX];
    copy_text(active, sizeof(active), ttf_font_path());
    EpdRect dirty = {0};
    int done = 0;
    for (int pass = 0; pass < 4; ++pass) {
        int slot = -1;
        for (int i = 0; i < s_font_preview_slots; ++i) {
            const font_preview_t *preview = font_preview_entry(i);
            if (preview && preview->state == 0) { slot = i; break; }
        }
        if (slot < 0) break;
        (void)font_preview_generate(slot);
        if (!picker) { ++done; break; } // 字体设置页只做后台预载，不画
        font_preview_t *preview = font_preview_entry(slot);
        if (!preview || preview->state != 1 || !preview->mask) continue;
        draw_font_pick_card(ctx->fb, slot, active);
        const EpdRect r = reader_font_pick_rect(slot);
        dirty = done ? ui_rect_union(dirty, r) : r;
        ++done;
        if (ctx->consumed || (ctx->touch && ctx->touch->touched) || ctx->request_app) break;
    }
    if (!done || !picker) return APP_REDRAW_NONE;
    s_area = dirty;
    s_mode = MODE_GL16;
    s_reader_footer_pending = false;
    return APP_REDRAW_AREA;
}

static void draw_font_picker(uint8_t* fb) {
    const bool land = s_reader_landscape;
    const int top = reader_font_picker_top();
    if (land) draw_panel_sheet_landscape(fb, "字体");
    else {
        draw_sheet(fb, top, "字体");
        epd_draw_line(55, top + 49, 64, top + 58, UI_GRAY_BLACK, fb);
        epd_draw_line(64, top + 58, 73, top + 49, UI_GRAY_BLACK, fb);
    }
    int count = ttf_font_count();
    int pages = count > 0 ? (count + BOOK_FONT_PAGE - 1) / BOOK_FONT_PAGE : 1;
    char current[96];
    snprintf(current, sizeof(current), "当前选择 · %s  %d/%d", ttf_font_display_name(), s_font_page + 1, pages);
    if (land) {
        fit_text(current, 20, 1160);
        ui_text_box(fb,(EpdRect){20,top+12,1176,40},20,current,EPD_DRAW_ALIGN_CENTER,false);
    } else {
        fit_text(current, 20, 540);
        ui_text_box(fb,(EpdRect){90,top+94,504,32},20,current,EPD_DRAW_ALIGN_CENTER,false);
    }
    font_preview_ensure(s_font_page);
    const int start = s_font_page * BOOK_FONT_PAGE;
    char active[TTF_FONT_PATH_MAX]; copy_text(active, sizeof(active), ttf_font_path());
    for (int slot = 0; slot < BOOK_FONT_PAGE && start + slot < count; ++slot) {
        // 只画缓存/占位，不在这里装载候选字体：之前这里是每张卡一次 ttf_font_open()。
        // Paint cache/placeholder only; candidate faces are no longer loaded here once per card.
        draw_font_pick_card(fb, slot, active);
    }
    if (!count) {
        if (land) ui_text_box(fb,(EpdRect){20, 330, 1176, 44}, 24, "所选字体目录中没有可用字体", EPD_DRAW_ALIGN_CENTER, false);
        else reader_panel_text_vc(fb, 342, 780, 24, "所选字体目录中没有可用字体", EPD_DRAW_ALIGN_CENTER, false);
    }
}

// 横屏面板共用的整屏底板：白底铺满 + 左上标题 + 右上返回。
// Shared landscape panel background: full white canvas, title left, back hint right.
static void draw_panel_sheet_landscape(uint8_t* fb, const char* title) {
    ui_fill_rect_fast(reader_full_rect(), UI_GRAY_WHITE, fb);
    reader_panel_text(fb, 28, 18, 30, title, EPD_DRAW_ALIGN_LEFT, true);
    reader_panel_text(fb, reader_scr_w() - 28, 20, 22, "返回", EPD_DRAW_ALIGN_RIGHT, false);
}
static EpdRect stats_details_rect(void) {
    return s_reader_landscape ? (EpdRect){100, 404, 320, 74} : (EpdRect){36, 768 + 319, 194, 78};
}
static EpdRect stats_recent_rect(void) {
    return s_reader_landscape ? (EpdRect){428, 404, 320, 74} : (EpdRect){242, 768 + 319, 194, 78};
}
// 阅读统计里的第三个入口：章节内自由跳转。
// Third card in the reading-stats panel: free jump inside the current chapter.
static EpdRect stats_jump_rect(void) {
    return s_reader_landscape ? (EpdRect){756, 404, 320, 74} : (EpdRect){448, 768 + 319, 194, 78};
}
static EpdRect chapter_jump_minus_rect(void) {
    return s_reader_landscape ? (EpdRect){40, 140, 110, 64}
                              : (EpdRect){54, 620, 110, 66};
}
static EpdRect chapter_jump_plus_rect(void) {
    return s_reader_landscape ? (EpdRect){530, 140, 110, 64}
                              : (EpdRect){520, 620, 110, 66};
}
static EpdRect chapter_jump_value_rect(void) {
    return s_reader_landscape ? (EpdRect){160, 140, 360, 64}
                              : (EpdRect){174, 620, 336, 66};
}
static EpdRect chapter_jump_input_rect(void) {
    return s_reader_landscape ? (EpdRect){40, 224, 600, 78}
                              : (EpdRect){54, 706, 576, 78};
}
// 数字键盘 0..11：1–9、清空、0、退格；底部两个动作键由单独矩形给出。
// Keypad 0..11: 1-9, Clear, 0, Backspace; the two bottom actions have their own rects.
static EpdRect chapter_jump_key_rect(int key) {
    if (key < 0 || key > 11) return (EpdRect){0};
    if (s_reader_landscape)
        return (EpdRect){700 + (key % 3) * 160, 110 + (key / 3) * 70, 148, 62};
    return (EpdRect){54 + (key % 3) * 196, 826 + (key / 3) * 70, 184, 62};
}
static EpdRect chapter_jump_cancel_rect(void) {
    return s_reader_landscape ? (EpdRect){700, 420, 220, 64} : (EpdRect){54, 1116, 278, 64};
}
static EpdRect chapter_jump_commit_rect(void) {
    return s_reader_landscape ? (EpdRect){930, 420, 220, 64} : (EpdRect){352, 1116, 278, 64};
}
// 跳转后的「返回跳转前」浮标：竖屏在正文上方，横屏在标题带下；与命中区共用矩形。
// The post-jump "back to where you were" badge: above the body in portrait, below the title band in
// landscape; paint and hit testing share the rect.
static EpdRect chapter_jump_undo_rect(void) {
    return s_reader_landscape ? (EpdRect){reader_scr_w() / 2 - 160, 96, 320, 52}
                              : (EpdRect){UI_LOCK_WIDTH / 2 - 164, 172, 328, 52};
}
static bool chapter_jump_undo_visible(void) {
    return s_chapter_jump_undo.valid && s_text && s_view == READING &&
           s_chapter_jump_undo.chapter == s_chapter && s_reader_panel == READER_PANEL_NONE;
}
static void draw_chapter_jump_undo(uint8_t *fb) {
    if (!chapter_jump_undo_visible()) return;
    const EpdRect r = chapter_jump_undo_rect();
    ui_fill_round_rect(fb, r, 22, 0x30);
    ui_draw_control_frame(fb, r, 22, 0x30);
    ui_text_box(fb, ui_inset_rect(r, 10), 22, "返回跳转前", EPD_DRAW_ALIGN_CENTER, true);
}
static void draw_reader_chapter_jump(uint8_t *fb) {
    const bool land = s_reader_landscape;
    if (land) draw_panel_sheet_landscape(fb, "本章跳转");
    else draw_sheet(fb, 500, "本章跳转");
    const size_t total = book_layout_page_count();
    // 标题与页数
    char caption[160];
    snprintf(caption, sizeof(caption), "%s · 共 %u 页", s_title, (unsigned)total);
    if (land) ui_text_box(fb, (EpdRect){40, 90, 600, 34}, 20, caption, EPD_DRAW_ALIGN_LEFT, false);
    else reader_panel_text_vc(fb, 342, 585, 20, caption, EPD_DRAW_ALIGN_CENTER, false);
    // 草稿步进器
    static const EpdRect none_rect = {0};
    (void)none_rect;
    EpdRect minus = chapter_jump_minus_rect(), plus = chapter_jump_plus_rect();
    EpdRect value = chapter_jump_value_rect();
    for (int i = 0; i < 2; ++i) {
        const EpdRect r = i ? plus : minus;
        ui_fill_round_rect(fb, r, 30, 0xe8);
        ui_draw_control_frame(fb, r, 30, 0x58);
        ui_text_box(fb, r, 48, i ? "+" : "−", EPD_DRAW_ALIGN_CENTER, false);
    }
    size_t draft = total ? (s_chapter_jump_page < total ? s_chapter_jump_page : total - 1) : 0;
    char page[64];
    snprintf(page, sizeof(page), "%u / %u 页", (unsigned)(total ? draft + 1 : 0), (unsigned)total);
    ui_fill_round_rect(fb, value, 24, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, value, 24, 0x58);
    ui_text_box(fb, value, land ? 26 : 30, page, EPD_DRAW_ALIGN_CENTER, false);
    // 数字输入行
    EpdRect input = chapter_jump_input_rect();
    ui_fill_round_rect(fb, input, 18, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, input, 18, 0x58);
    const int input_px = land ? 30 : 36;
    ui_text_box(fb, (EpdRect){input.x + 14, input.y, 52, input.height}, 23, "第", EPD_DRAW_ALIGN_CENTER, false);
    ui_text_box(fb, (EpdRect){input.x + input.width - 66, input.y, 52, input.height}, 23, "页",
                EPD_DRAW_ALIGN_CENTER, false);
    ui_text_box(fb, (EpdRect){input.x + 70, input.y, input.width - 140, input.height}, input_px,
                s_chapter_jump_digits, EPD_DRAW_ALIGN_CENTER, false);
    // 错误提示
    char error[80] = {0};
    if (s_chapter_jump_error)
        snprintf(error, sizeof(error), "请输入 1—%u 之间的页码", (unsigned)total);
    if (land) ui_text_box(fb, (EpdRect){40, 310, 600, 34}, 19, error, EPD_DRAW_ALIGN_LEFT, false);
    else reader_panel_text_vc(fb, 342, 792, 19, error, EPD_DRAW_ALIGN_CENTER, false);
    // 数字键盘
    static const char *const keys[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "清空", "0", "退格"};
    for (int i = 0; i < 12; ++i) {
        const EpdRect r = chapter_jump_key_rect(i);
        ui_fill_round_rect(fb, r, 14, 0xe8);
        ui_draw_control_frame(fb, r, 14, 0x98);
        ui_text_box(fb, r, i < 9 || i == 10 ? (land ? 26 : 29) : 21, keys[i], EPD_DRAW_ALIGN_CENTER, false);
    }
    ui_draw_button(fb, chapter_jump_cancel_rect(), "取消", false);
    ui_draw_button(fb, chapter_jump_commit_rect(), "跳转", true);
}
static void draw_reader_stats(uint8_t* fb) {
    if (s_reader_landscape) {
        draw_panel_sheet_landscape(fb, "阅读统计");
        char values[3][32];
        snprintf(values[0], sizeof(values[0]), "%u%%", percent(s_page));
        snprintf(values[1], sizeof(values[1]), "%lu 分钟", (unsigned long)(s_session_read_ms / 60000));
        snprintf(values[2], sizeof(values[2]), "%lu 次", (unsigned long)s_session_turns);
        const char* labels[] = {"阅读进度", "本次阅读", "翻页"};
        const int cx[3] = {236, 608, 980};
        for (int i = 0; i < 3; ++i) {
            ui_text_box(fb,(EpdRect){cx[i]-140,150,280,54},36,values[i],EPD_DRAW_ALIGN_CENTER,false);
            ui_text_box(fb,(EpdRect){cx[i]-140,210,280,36},20,labels[i],EPD_DRAW_ALIGN_CENTER,false);
            if (i < 2) ui_fill_rect_fast((EpdRect){cx[i] + 172, 150, 1, 96}, 0x98, fb);
        }
        ui_text_box(fb,(EpdRect){80,286,300,40},21,"本书进度",EPD_DRAW_ALIGN_LEFT,false);
        EpdRect track = {80, 334, 1056, 14};
        ui_fill_round_rect(fb, track, 7, 0xd0);
        EpdRect fill = track;
        fill.width = fill.width * (int)percent(s_page) / 100;
        if (fill.width) ui_fill_round_rect(fb, fill, 7, 0x40);
        if (book_chapter_count() == 1) {
            char left[32], right[32];
            snprintf(left, sizeof(left), "第 %u 页", (unsigned)s_page + 1);
            snprintf(right, sizeof(right), "共 %u 页", (unsigned)book_layout_page_count());
            reader_panel_text(fb, 80, 358, 19, left, EPD_DRAW_ALIGN_LEFT, false);
            reader_panel_text(fb, 1136, 358, 19, right, EPD_DRAW_ALIGN_RIGHT, false);
        } else {
            reader_panel_text(fb, 80, 358, 19, "当前页 —", EPD_DRAW_ALIGN_LEFT, false);
            reader_panel_text(fb, 1136, 358, 19, "总页数 —", EPD_DRAW_ALIGN_RIGHT, false);
        }
        const EpdRect details = stats_details_rect(), recent = stats_recent_rect(), jump = stats_jump_rect();
        ui_fill_round_rect(fb, details, 20, 0xd8); ui_draw_control_frame(fb, details, 20, 0x68);
        ui_fill_round_rect(fb, recent, 20, 0xd8); ui_draw_control_frame(fb, recent, 20, 0x68);
        ui_fill_round_rect(fb, jump, 20, 0xd8); ui_draw_control_frame(fb, jump, 20, 0x68);
        char marks[32];
        snprintf(marks, sizeof(marks), "查看书签 · %u", (unsigned)bookmark_count());
        ui_text_box(fb, ui_inset_rect(details, 12), 23, marks, EPD_DRAW_ALIGN_CENTER, false);
        ui_text_box(fb, ui_inset_rect(recent, 12), 23, "阅读热力图", EPD_DRAW_ALIGN_CENTER, false);
        ui_text_box(fb, ui_inset_rect(jump, 12), 23, "章节跳转", EPD_DRAW_ALIGN_CENTER, false);
        return;
    }
    const int top = 768;
    draw_sheet(fb, top, "阅读统计");
    char values[3][32];
    snprintf(values[0], sizeof(values[0]), "%u%%", percent(s_page));
    snprintf(values[1], sizeof(values[1]), "%lu 分钟", (unsigned long)(s_session_read_ms / 60000));
    snprintf(values[2], sizeof(values[2]), "%lu 次", (unsigned long)s_session_turns);
    const char* labels[] = {"阅读进度", "本次阅读", "翻页"};
    for (int i = 0; i < 3; ++i) {
        int cx = 114 + i * 228;
        ui_text_box(fb,(EpdRect){cx-100,top+100,200,48},33,values[i],EPD_DRAW_ALIGN_CENTER,false);
        ui_text_box(fb,(EpdRect){cx-100,top+154,200,36},20,labels[i],EPD_DRAW_ALIGN_CENTER,false);
        if (i < 2) ui_fill_rect_fast((EpdRect){228 + i * 228, top + 99, 1, 74}, 0x98, fb);
    }
    ui_text_box(fb,(EpdRect){54,top+192,576,42},21,"本书进度",EPD_DRAW_ALIGN_LEFT,false);
    EpdRect track = {54, top + 245, 576, 12};
    ui_fill_round_rect(fb, track, 6, 0xd0);
    EpdRect fill = track; fill.width = fill.width * (int)percent(s_page) / 100;
    if (fill.width) ui_fill_round_rect(fb, fill, 6, 0x40);
    if (book_chapter_count() == 1) {
        char left[32], right[32];
        snprintf(left, sizeof(left), "第 %u 页", (unsigned)s_page + 1);
        snprintf(right, sizeof(right), "共 %u 页", (unsigned)book_layout_page_count());
        reader_panel_text(fb, 54, top + 272, 19, left, EPD_DRAW_ALIGN_LEFT, false);
        reader_panel_text(fb, 630, top + 272, 19, right, EPD_DRAW_ALIGN_RIGHT, false);
    } else {
        reader_panel_text(fb, 54, top + 272, 19, "当前页 —", EPD_DRAW_ALIGN_LEFT, false);
        reader_panel_text(fb, 630, top + 272, 19, "总页数 —", EPD_DRAW_ALIGN_RIGHT, false);
    }
    EpdRect details = stats_details_rect(), recent = stats_recent_rect(), jump = stats_jump_rect();
    ui_fill_round_rect(fb, details, 20, 0xd8); ui_draw_control_frame(fb, details, 20, 0x68);
    ui_fill_round_rect(fb, recent, 20, 0xd8); ui_draw_control_frame(fb, recent, 20, 0x68);
    ui_fill_round_rect(fb, jump, 20, 0xd8); ui_draw_control_frame(fb, jump, 20, 0x68);
    char marks[32]; snprintf(marks, sizeof(marks), "查看书签 · %u", (unsigned)bookmark_count());
    ui_text_box(fb, ui_inset_rect(details, 10), 19, marks, EPD_DRAW_ALIGN_CENTER, false);
    ui_text_box(fb, ui_inset_rect(recent, 10), 19, "阅读热力图", EPD_DRAW_ALIGN_CENTER, false);
    ui_text_box(fb, ui_inset_rect(jump, 10), 19, "章节跳转", EPD_DRAW_ALIGN_CENTER, false);
}

static void draw_reader_bookmarks(uint8_t* fb) {
    const bool land = s_reader_landscape;
    const int top = 560;
    if (land) draw_panel_sheet_landscape(fb, "书签");
    else {
        draw_sheet(fb, top, "书签");
        epd_draw_line(55, top + 49, 64, top + 58, UI_GRAY_BLACK, fb);
        epd_draw_line(64, top + 58, 73, top + 49, UI_GRAY_BLACK, fb);
    }
    reader_bookmarks_t marks = {0};
    bool valid = bookmark_load(&marks);
    int pages = bookmark_pages(valid ? marks.count : 0);
    if (s_bookmark_page >= pages) s_bookmark_page = pages - 1;
    if (valid && marks.count) {
        const EpdRect manage = bookmark_manage_rect();
        ui_fill_round_rect(fb, manage, 20, s_bookmark_edit ? 0xd8 : 0xe8);
        ui_draw_control_frame(fb, manage, 20, 0x78);
        reader_panel_text_vc(fb, manage.x + manage.width / 2, manage.y + manage.height / 2, 20,
                             s_bookmark_edit ? "完成" : "管理", EPD_DRAW_ALIGN_CENTER, false);
    }
    if (!valid || !marks.count) {
        reader_panel_text_vc(fb, land ? reader_scr_w() / 2 : 342, land ? 300 : top + 260, 26,
                             "还没有保存书签", EPD_DRAW_ALIGN_CENTER, false);
        reader_panel_text_vc(fb, land ? reader_scr_w() / 2 : 342, land ? 350 : top + 309, 18,
                             "阅读时点按“书签”即可保存当前位置", EPD_DRAW_ALIGN_CENTER, false);
        return;
    }
    int first = s_bookmark_page * bookmark_rows();
    for (int row = 0; row < bookmark_rows() && first + row < marks.count; ++row) {
        int newest = (int)marks.count - 1 - (first + row);
        const reader_bookmark_entry_t* mark = &marks.entries[newest];
        EpdRect item = bookmark_row_rect(row);
        bool current = mark->chapter == s_chapter && mark->byte_off == book_layout_page_start_offset(s_page);
        bool selected = s_bookmark_edit && (s_bookmark_selected & (UINT32_C(1) << newest));
        ui_fill_round_rect(fb, item, 14, selected ? 0xc0 : current ? 0xc8 : 0xe8);
        ui_draw_control_frame(fb, item, 14, current ? 0x50 : 0x98);
        char chapter[96];
        if (book_chapter_title(mark->chapter, chapter, sizeof(chapter)) != ESP_OK)
            snprintf(chapter, sizeof(chapter), "第 %u 节", (unsigned)mark->chapter + 1);
        char where[52];
        if (mark->chapter == s_chapter)
            snprintf(where, sizeof(where), "第 %u 页", (unsigned)book_layout_page_for_offset(mark->byte_off) + 1);
        else snprintf(where, sizeof(where), "章节 %u", (unsigned)mark->chapter + 1);
        int end=item.x+item.width-(s_bookmark_edit?70:120);
        int where_width=ui_text_fixed_width_px(ui_text_effective_px(20),where);
        if(where_width>220)where_width=220;
        int chapter_width=end-where_width-item.x-34;
        fit_text(chapter,24,chapter_width);
        ui_text_box(fb,(EpdRect){item.x+18,item.y+5,chapter_width,item.height/2-10},24,chapter,EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){end-where_width,item.y+5,where_width,item.height/2-10},20,where,EPD_DRAW_ALIGN_RIGHT,false);
        ui_text_box(fb,(EpdRect){item.x+18,item.y+item.height/2,item.width-130,item.height/2-5},18,
                    s_bookmark_edit?"点按选择":current?"当前阅读位置":"点按跳转到此处",EPD_DRAW_ALIGN_LEFT,false);
        if (s_bookmark_edit) {
            epd_draw_circle(item.x + item.width - 35, item.y + 36, 12, 0x48, fb);
            if (selected) epd_fill_circle(item.x + item.width - 35, item.y + 36, 7, 0x38, fb);
        } else {
            const uint8_t tag = mark->tag <= 3 ? mark->tag : 0;
            const EpdRect chip = bookmark_tag_rect(row);
            switch (tag) {
                case 1: ui_fill_round_rect(fb, chip, 16, 0x30); break;
                case 2: ui_fill_round_rect(fb, chip, 16, 0x70); break;
                case 3: ui_fill_round_rect(fb, chip, 16, 0xb0); break;
                default: ui_fill_round_rect(fb, chip, 16, 0xe0); break;
            }
            ui_draw_control_frame(fb, chip, 16, tag == 1 ? 0x20 : 0x88);
            ui_text_box(fb, (EpdRect){chip.x, chip.y, chip.width, chip.height}, 17,
                        bookmark_tag_names[tag], EPD_DRAW_ALIGN_CENTER, tag == 1);
        }
    }
    if (s_bookmark_edit) {
        ui_draw_button(fb, bookmark_select_all_rect(), "全选本页", false);
        char label[40]; snprintf(label, sizeof(label), "删除已选 · %u", bookmark_selected_count());
        ui_draw_button(fb, bookmark_remove_rect(), label, bookmark_selected_count() > 0);
    }
    char page[32]; snprintf(page, sizeof(page), "‹   %d / %d   ›", s_bookmark_page + 1, pages);
    reader_panel_text_vc(fb, land ? reader_scr_w() / 2 : 342, bookmark_page_label_y(), 22, page,
                         EPD_DRAW_ALIGN_CENTER, false);
    if (s_bookmark_delete_confirm) {
        const EpdRect panel = bookmark_confirm_rect();
        const int cx = bookmark_confirm_center_x();
        ui_fill_round_rect(fb, panel, 24, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, panel, 24, 0x48);
        reader_panel_text_vc(fb, cx, panel.y + 56, 27,
                   s_bookmark_delete_error ? "删除失败，请重试" : "删除选中的书签？", EPD_DRAW_ALIGN_CENTER, false);
        reader_panel_text_vc(fb, cx, panel.y + 102, 18, "只删除书签，不影响阅读进度", EPD_DRAW_ALIGN_CENTER, false);
        ui_draw_button(fb, (EpdRect){panel.x + 22, panel.y + 152, 244, 64}, "取消", false);
        ui_draw_button(fb, (EpdRect){panel.x + 310, panel.y + 152, 244, 64}, "确认删除", true);
    }
}

/* ---- 划线列表 / Highlight list ---- */
static int highlight_row_step(void) {
    int scale = app_settings_system_font_size();
    if (scale < 100) scale = 100;
    if (scale > 200) scale = 200;
    return 82 + (scale - 100) / 2;
}
static int highlight_rows(void) {
    // 页码位置固定，行数按当前字号能放下的数量算，大字号不会把最后一排压出面板。
    // The page label stays fixed; row count follows the type size so large fonts never overflow.
    const int available = s_reader_landscape ? (636 - 136) : (1166 - 650);
    int rows = available / highlight_row_step();
    if (rows < 1) rows = 1;
    if (rows > 6) rows = 6;
    return rows;
}
static EpdRect highlight_row_rect(int row) {
    int step = highlight_row_step();
    if (s_reader_landscape) return (EpdRect){20, 136 + row * step, 1176, step - 10};
    return (EpdRect){36, 650 + row * step, 612, step - 10};
}
static EpdRect highlight_delete_rect(int row) {
    EpdRect rect = highlight_row_rect(row);
    return (EpdRect){rect.x + rect.width - 78, rect.y + (rect.height - 46) / 2, 66, 46};
}
// 标签块：点一下循环切换 无→重要→待读→疑问；标签随书保存。
// Tag chip: one tap cycles none -> important -> to-read -> question; saved with the book.
static const char *const highlight_tag_names[] = {"标签", "重要", "待读", "疑问"};
static EpdRect highlight_tag_rect(int row) {
    EpdRect del = highlight_delete_rect(row);
    return (EpdRect){del.x - 92, del.y, 84, 46};
}
static int highlight_page_label_y(void) { return s_reader_landscape ? 636 : 1166; }
static int highlight_pages(int count) {
    return count ? (count + highlight_rows() - 1) / highlight_rows() : 1;
}
// 工具栏「划线」列表：倒序显示本书记录，点行跳转，右侧按钮删除。
// Toolbar highlight list: newest first, tap a row to jump, the right button deletes it.
static void draw_reader_highlights(uint8_t *fb) {
    const bool land = s_reader_landscape;
    const int top = 560;
    if (land) draw_panel_sheet_landscape(fb, "划线");
    else draw_sheet(fb, top, "划线");
    // 划线页右上角：长按动作开关；列表为空时也画，方便先切回“划线”。
    // Top-right of the highlights sheet: the long-press switch, painted even for an empty list so
    // the user can switch back to highlighting without leaving the panel.
    draw_highlight_hold_toggle(fb);
    const int count = book_highlight_count();
    const int pages = highlight_pages(count);
    if (s_highlight_page >= pages) s_highlight_page = pages - 1;
    if (s_highlight_page < 0) s_highlight_page = 0;
    if (!count) {
        reader_panel_text_vc(fb, land ? reader_scr_w() / 2 : 342, land ? 300 : top + 260, 26,
                             "还没有划线", EPD_DRAW_ALIGN_CENTER, false);
        reader_panel_text_vc(fb, land ? reader_scr_w() / 2 : 342, land ? 350 : top + 309, 18,
                             app_settings_gesture_action(APP_GESTURE_LONG_PRESS) !=
                                     APP_GESTURE_ACTION_HIGHLIGHT
                                 ? "长按正文的功能已在手势设置里修改"
                                 : app_settings_reader_long_press_highlight()
                                       ? "阅读时按住正文并拖动即可划线"
                                       : "长按正文将打开目录（划线已关闭）",
                             EPD_DRAW_ALIGN_CENTER, false);
        return;
    }
    for (int row = 0; row < highlight_rows(); ++row) {
        const int index = count - 1 - (s_highlight_page * highlight_rows() + row);
        if (index < 0) break;
        uint16_t chapter = 0;
        uint32_t start = 0, end = 0;
        const char *excerpt = NULL;
        if (book_highlight_at(index, &chapter, &start, &end, &excerpt) < 0) continue;
        EpdRect item = highlight_row_rect(row);
        ui_fill_round_rect(fb, item, 14, 0xe8);
        ui_draw_control_frame(fb, item, 14, 0x98);
        char chapter_name[96];
        if (book_chapter_title(chapter, chapter_name, sizeof(chapter_name)) != ESP_OK || !chapter_name[0])
            snprintf(chapter_name, sizeof(chapter_name), "第 %u 节", (unsigned)chapter + 1);
        char where[40];
        if (chapter == s_chapter)
            snprintf(where, sizeof(where), "第 %u 页", (unsigned)book_layout_page_for_offset(start) + 1);
        else snprintf(where, sizeof(where), "章 %u", (unsigned)chapter + 1);
        const EpdRect del = highlight_delete_rect(row);
        const EpdRect tag_rect = highlight_tag_rect(row);
        const int right = tag_rect.x - 12;
        const int text_left = item.x + 18;
        // 章节名和右侧“第 N 页/章 N”各自留出空间，长章节名不会再压到页码上、也不会
        // 越过行卡片边框。
        // Reserve room for the page/chapter label on the right so a long chapter name never
        // overlaps it or runs past the row card border.
        int where_px = ui_text_effective_px(20);
        int where_width = ui_text_fixed_width_px(where_px, where);
        if (where_width > 130) where_width = 130;
        int chapter_px = 23;
        int chapter_width = right - where_width - text_left - 12;
        if (chapter_width < 60) {
            chapter_width = right - text_left - 12;
            where_width = 0;
        }
        fit_text(chapter_name, chapter_px, chapter_width);
        ui_text_box(fb, (EpdRect){text_left, item.y + 4, chapter_width, item.height / 2 - 8},
                    chapter_px, chapter_name, EPD_DRAW_ALIGN_LEFT, false);
        if (where_width > 0)
            ui_text_box(fb, (EpdRect){right - where_width, item.y + 4, where_width, item.height / 2 - 8},
                        20, where, EPD_DRAW_ALIGN_RIGHT, false);
        char text[BOOK_HIGHLIGHT_EXCERPT];
        copy_text(text, sizeof(text), excerpt ? excerpt : "");
        const char *note = book_highlight_note(index);
        if (note && note[0]) {
            // 有笔记时优先展示笔记，前面加一个记号，方便一眼区分。
            // Prefer the note when present, prefixed with a marker for quick scanning.
            char line[BOOK_HIGHLIGHT_NOTE + 8];
            snprintf(line, sizeof(line), "✎ %s", note);
            copy_text(text, sizeof(text), line);
        }
        fit_text(text, 18, tag_rect.x - item.x - 18);
        ui_text_box(fb, (EpdRect){item.x + 18, item.y + item.height / 2, tag_rect.x - item.x - 18,
                                  item.height / 2 - 4}, 18,
                    text[0] ? text : "（原文摘录不可用）", EPD_DRAW_ALIGN_LEFT, false);
        const uint8_t tag = book_highlight_tag(index);
        switch (tag) {
            case 1: ui_fill_round_rect(fb, tag_rect, 16, 0x30); break;
            case 2: ui_fill_round_rect(fb, tag_rect, 16, 0x70); break;
            case 3: ui_fill_round_rect(fb, tag_rect, 16, 0xb0); break;
            default: ui_fill_round_rect(fb, tag_rect, 16, 0xe0); break;
        }
        ui_draw_control_frame(fb, tag_rect, 16, tag == 1 ? 0x20 : 0x88);
        ui_text_box(fb, (EpdRect){tag_rect.x, tag_rect.y, tag_rect.width, tag_rect.height}, 17,
                    tag <= 3 ? highlight_tag_names[tag] : "标签", EPD_DRAW_ALIGN_CENTER, tag == 1);
        ui_fill_round_rect(fb, del, 16, 0xd8);
        ui_draw_control_frame(fb, del, 16, 0x78);
        ui_text_box(fb, (EpdRect){del.x, del.y, del.width, del.height}, 18, "删除", EPD_DRAW_ALIGN_CENTER, false);
    }
    char page[64];
    snprintf(page, sizeof(page), "‹   %d / %d   ›", s_highlight_page + 1, pages);
    reader_panel_text_vc(fb, land ? reader_scr_w() / 2 : 342, highlight_page_label_y(), 22,
                         page, EPD_DRAW_ALIGN_CENTER, false);
}

// 阅读统计：本月热力图（日期格子按当天阅读时长上灰阶）+ 本月合计/连续天数 + 近 30 天趋势。
// Reading stats: a current-month heatmap (day cells shaded by reading time), month totals and
// streak, plus the 30-day trend strip.
static int stats_weekday_monday(int year, int month) {
    int y = year, m = month;
    if (m < 3) { m += 12; y--; }
    const int k = y % 100, j = y / 100;
    const int h = (1 + 13 * (m + 1) / 5 + k + k / 4 + j / 4 + 5 * j) % 7;
    return (h + 5) % 7;  // 0 = Monday, ... 6 = Sunday
}
static int stats_days_in_month(int year, int month) {
    static const int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month == 2 && ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)) return 29;
    return days[(month - 1) % 12];
}
static uint8_t stats_heat_gray(uint32_t seconds) {
    const uint32_t minutes = seconds / 60;
    if (!minutes) return 0xee;
    if (minutes < 15) return 0xd8;
    if (minutes < 30) return 0xbc;
    if (minutes < 60) return 0x88;
    return 0x30;
}
static int stats_today_of_month(void) {
    const time_t now = time(NULL);
    if (now < 1704067200) return -1;
    struct tm t;
    const time_t china = now + 8 * 3600;
    if (!gmtime_r(&china, &t) || t.tm_year + 1900 != s_month_year ||
        t.tm_mon + 1 != s_month_month) return -1;
    return t.tm_mday;
}
static void draw_stats_heatmap(uint8_t *fb, int x, int y, int cell_w, int cell_h, int gap) {
    if (!s_month_valid) return;
    static const char *const week[] = {"一", "二", "三", "四", "五", "六", "日"};
    for (int i = 0; i < 7; ++i)
        reader_panel_text(fb, x + i * (cell_w + gap) + cell_w / 2, y - 22, 14, week[i],
                          EPD_DRAW_ALIGN_CENTER, false);
    const int first = stats_weekday_monday(s_month_year, s_month_month);
    const int days = stats_days_in_month(s_month_year, s_month_month);
    const int today = stats_today_of_month();
    for (int d = 0; d < days; ++d) {
        const int idx = first + d;
        const int col = idx % 7, row = idx / 7;
        const EpdRect cell = {x + col * (cell_w + gap), y + row * (cell_h + gap), cell_w, cell_h};
        const uint8_t gray = stats_heat_gray(s_month_days[d]);
        ui_fill_rect_fast(cell, gray, fb);
        char num[8];
        snprintf(num, sizeof(num), "%d", d + 1);
        ui_text_fixed_vc(fb, cell.x + cell.width / 2, cell.y + cell.height / 2, 13, num,
                         EPD_DRAW_ALIGN_CENTER, gray <= 0x88);
        if (d + 1 == today) ui_draw_control_frame(fb, cell, 2, 0x20);
    }
}
static void draw_stats_month_summary(uint8_t *fb, int x, int y, int width) {
    if (!s_month_valid) return;
    uint64_t sum = 0;
    int active = 0, streak = 0, best = 0;
    const int days = stats_days_in_month(s_month_year, s_month_month);
    for (int d = 0; d < days; ++d) {
        const uint32_t minutes = s_month_days[d] / 60;
        sum += minutes;
        if (minutes) {
            ++active;
            if (++streak > best) best = streak;
        } else streak = 0;
    }
    char line[96];
    snprintf(line, sizeof(line), "%d年%d月", s_month_year, s_month_month);
    reader_panel_text_vc(fb, x + width / 2, y, 23, line, EPD_DRAW_ALIGN_CENTER, false);
    snprintf(line, sizeof(line), "本月合计 %llu 小时 %llu 分",
             (unsigned long long)(sum / 60), (unsigned long long)(sum % 60));
    reader_panel_text_vc(fb, x + width / 2, y + 38, 19, line, EPD_DRAW_ALIGN_CENTER, false);
    snprintf(line, sizeof(line), "记录 %d 天 · 最长连续 %d 天", active, best);
    reader_panel_text_vc(fb, x + width / 2, y + 68, 19, line, EPD_DRAW_ALIGN_CENTER, false);
    snprintf(line, sizeof(line), "日均 %llu 分钟",
             (unsigned long long)(active ? sum / (uint64_t)active : 0));
    reader_panel_text_vc(fb, x + width / 2, y + 98, 19, line, EPD_DRAW_ALIGN_CENTER, false);
}
static void draw_reader_stats_recent(uint8_t* fb) {
    const bool land = s_reader_landscape;
    if (land) draw_panel_sheet_landscape(fb, "阅读热力图");
    else draw_sheet(fb, 584, "阅读热力图");
    if (!s_recent_days_valid) {
        const int cx = land ? reader_scr_w() / 2 : 342;
        const int top = land ? 0 : 584;
        reader_panel_text_vc(fb, cx, top + 320, 23, "请先完成日期与时间设置", EPD_DRAW_ALIGN_CENTER, false);
        reader_panel_text_vc(fb, cx, top + 368, 18, "完成对时后开始记录每天的阅读时长", EPD_DRAW_ALIGN_CENTER, false);
        return;
    }
    uint64_t sum = 0;
    uint32_t maximum = 0;
    for (int i = 0; i < 30; ++i) {
        sum += s_recent_days[i];
        if (s_recent_days[i] > maximum) maximum = s_recent_days[i];
    }
    char total[64];
    snprintf(total, sizeof(total), "近 30 天累计 %llu 小时 %llu 分钟",
             (unsigned long long)(sum / 3600), (unsigned long long)((sum / 60) % 60));
    if (land) {
        reader_panel_text_vc(fb, reader_scr_w() / 2, 128, 26, total, EPD_DRAW_ALIGN_CENTER, false);
        reader_panel_text(fb, 60, 168, 20, "本月热力图", EPD_DRAW_ALIGN_LEFT, false);
        draw_stats_heatmap(fb, 60, 218, 24, 20, 5);
        draw_stats_month_summary(fb, 500, 200, 620);
        const int base_y = 600, max_h = 100;
        reader_panel_text(fb, 60, base_y - max_h - 34, 20, "近 30 天趋势", EPD_DRAW_ALIGN_LEFT, false);
        ui_hairline(fb, base_y, 80, 1050, 0xb0);
        for (int i = 0; i < 30; ++i) {
            int h = maximum ? (int)((uint64_t)s_recent_days[i] * max_h / maximum) : 0;
            if (s_recent_days[i] && h < 5) h = 5;
            if (h) ui_fill_round_rect(fb, (EpdRect){84 + i * 35, base_y - h, 18, h}, 6, 0x38);
        }
        reader_panel_text(fb, 80, base_y + 22, 17, "30 天前", EPD_DRAW_ALIGN_LEFT, false);
        reader_panel_text(fb, 1130, base_y + 22, 17, "今天", EPD_DRAW_ALIGN_RIGHT, false);
        return;
    }
    const int top = 584;
    reader_panel_text_vc(fb, 342, top + 108, 25, total, EPD_DRAW_ALIGN_CENTER, false);
    reader_panel_text(fb, 54, top + 150, 20, "本月热力图", EPD_DRAW_ALIGN_LEFT, false);
    draw_stats_heatmap(fb, 54, top + 200, 24, 20, 5);
    draw_stats_month_summary(fb, 300, top + 178, 350);
    const int base_y = top + 486, max_h = 96;
    reader_panel_text(fb, 54, base_y - max_h - 30, 20, "近 30 天趋势", EPD_DRAW_ALIGN_LEFT, false);
    ui_hairline(fb, base_y, 42, 600, 0xb0);
    for (int i = 0; i < 30; ++i) {
        int h = maximum ? (int)((uint64_t)s_recent_days[i] * max_h / maximum) : 0;
        if (s_recent_days[i] && h < 5) h = 5;
        if (h) ui_fill_round_rect(fb, (EpdRect){47 + i * 20, base_y - h, 10, h}, 5, 0x38);
    }
    reader_panel_text(fb, 42, base_y + 22, 17, "30 天前", EPD_DRAW_ALIGN_LEFT, false);
    reader_panel_text(fb, 642, base_y + 22, 19, "今天", EPD_DRAW_ALIGN_RIGHT, false);
}

static void draw_reader_panel(uint8_t* fb) {
    if (s_reader_panel==READER_PANEL_NONE) return;
    // 阅读中的活动字体槽是书籍字体；工具栏与二三级设置要跟随用户选的系统字体。
    // 0 号槽常驻系统字体，借用后恢复原槽，不重新打开字体也不改正文排版。
    // The reader's active slot holds the book face; the toolbar and its sub-sheets must follow the
    // configured system font. Slot 0 always holds it, so lend and restore the cursor around the
    // panel paint without reopening a face or touching body layout.
    const bool system_face = app_settings_system_font_path()[0] &&
        ttf_font_slot_ready(TTF_FONT_SLOT_SYSTEM) &&
        !ttf_font_path_is_builtin(app_settings_system_font_path());
    if (system_face) {
        ui_text_set_system_font(true);
        ui_text_set_face_slot(TTF_FONT_SLOT_SYSTEM);
    }
    ui_text_set_system_scale(true);
    if (s_reader_panel == READER_PANEL_TOOLS) {
        const int bar_top = reader_tool_bar_top();
        ui_fill_rect_fast((EpdRect){0, bar_top, reader_scr_w(), 120}, UI_GRAY_WHITE, fb);
        ui_hairline(fb, bar_top, 0, reader_scr_w(), 0x98);
        const char* labels[] = {"目录", "书签", "阅读统计", "阅读设置", "字体设置", "划线"};
        for (int i = 0; i < BOOK_TOOL_COUNT; ++i) {
            EpdRect rect = tool_rect(i);
            int cx = rect.x + rect.width / 2;
            bool bookmarked = i == 1 && bookmark_is_current();
            draw_reader_tool_icon(fb, cx, bar_top + 42, i, bookmarked);
            ui_text_box(fb,(EpdRect){rect.x+6,bar_top+63,rect.width-12,40},20,
                        bookmarked ? "已书签" : labels[i], EPD_DRAW_ALIGN_CENTER, false);
        }
    } else if (s_reader_panel == READER_PANEL_FONT_SETTINGS) draw_font_settings(fb);
    else if (s_reader_panel == READER_PANEL_WEIGHT_SETTINGS) draw_weight_settings(fb);
    else if (s_reader_panel == READER_PANEL_LAYOUT_SETTINGS) draw_layout_settings(fb);
    else if (s_reader_panel == READER_PANEL_RULE_SETTINGS) draw_rule_settings(fb);
    else if (s_reader_panel == READER_PANEL_BACKGROUND) draw_background_directory(fb);
    else if (s_reader_panel == READER_PANEL_BACKGROUND_MENU) draw_background_menu(fb);
    else if (s_reader_panel == READER_PANEL_BACKGROUND_PREVIEW) draw_background_picker(fb);
    else if (s_reader_panel == READER_PANEL_FONT_PICKER) draw_font_picker(fb);
    else if (s_reader_panel == READER_PANEL_STATS) draw_reader_stats(fb);
    else if (s_reader_panel == READER_PANEL_CHAPTER_JUMP) draw_reader_chapter_jump(fb);
    else if (s_reader_panel == READER_PANEL_BOOKMARKS) draw_reader_bookmarks(fb);
    else if (s_reader_panel == READER_PANEL_STATS_RECENT) draw_reader_stats_recent(fb);
    else if (s_reader_panel == READER_PANEL_HIGHLIGHTS) draw_reader_highlights(fb);
    else if (s_reader_panel == READER_PANEL_REFRESH_SETTINGS) draw_reading_settings(fb);
    else if (s_reader_panel == READER_PANEL_TURN_SETTINGS) draw_turn_settings(fb);
    else if (s_reader_panel == READER_PANEL_KEY_SETTINGS) draw_key_settings(fb);
    else if (s_reader_panel == READER_PANEL_KEY_PICKER) draw_key_picker(fb);
    else if (s_reader_panel == READER_PANEL_GESTURE) draw_gesture_settings(fb);
    else if (s_reader_panel == READER_PANEL_GESTURE_PICKER) draw_gesture_picker(fb);
    ui_text_set_system_scale(false);
    if (system_face) {
        ui_text_set_face_slot(-1);
        ui_text_set_system_font(false);
    }
}

/* ---- 绘制与预渲染 / Drawing and preparation ---- */
static uint8_t inline_ink_gray(uint8_t gray) {
    // 解码器已提供灰阶；再次加深并叠加系统对比度会压死抖动前的中间色阶。
    // The decoder already supplies grayscale; extra darkening and UI contrast clip midtones.
    return gray;
}

static void draw_reader_header(uint8_t *fb) {
    ui_nav_back(fb, 36, 79);
    char header[128];
    const char *sample = s_book_title[0] ? s_book_title : s_title;
    copy_text(header, sizeof(header), sample);
    int title_px = ui_text_title_fit(header, 32, 450, sample);
    // 返回键、书名与收藏使用同一视觉中心线；字体切换不改变对齐。
    // Back, title and favorite share one visual centerline across font changes.
    ui_text_title_vc(fb, UI_LOCK_WIDTH / 2, 114, title_px, header, sample, EPD_DRAW_ALIGN_CENTER);
    ui_draw_icon(fb, 620, 114, 48,
                 s_reader_favorite ? UI_ICON_ANIMATE_BOOKMARK_PLUS : UI_ICON_BOOKMARK, 0x38);
    ui_hairline(fb, 151, 36, 612, UI_GRAY_LIGHT);
}
// 竖排章节题头：右列是编号（第三章），左列是章名，读序依旧自右向左；两列整体留出列宽，
// 排版用同一个宽度在首页右边缘预留，绘制与预留因此不会错位。
// A vertical chapter heading: the number column (第三章) on the right and the title on the left,
// still read right to left. Both columns reserve their width, and the layout reserves the same
// width at the right edge of the first page, so drawing and reservation cannot drift apart.
typedef struct {
    int width;       ///< 首页右起需要预留的列宽 / columns to reserve at the first page's right
    int title_px;    ///< 章名字号 / title type size
    int title_x;     ///< 章名列左边缘 / title column's left edge
    int label_px;    ///< 编号字号，无编号时为 0 / number size, 0 without a label
    int label_x;     ///< 编号列左边缘 / label column's left edge
    int text_height; ///< 较长一列的高度，用来垂直居中 / taller column, used to center
} reader_heading_t;

static reader_heading_t reader_heading_metrics(const char *title, const char *label, EpdRect body) {
    reader_heading_t metrics = {0};
    if (title == NULL || title[0] == 0 || body.height <= 0 || body.width <= 0) return metrics;
    // 题头跟横排的题头一样走系统字体：正文换卡上字体不改变章节标题。
    // The heading uses the system face exactly like the horizontal one, so swapping the body face
    // never changes chapter titles.
    ttf_font_select(TTF_FONT_SLOT_SYSTEM);
    const int avail = body.height - 48;
    int px = 48;
    int need = ttf_vertical_text_height_px(px, title, 0);
    // 一列放不下就缩字号；竖排的题头不折列，缩到 24 为止。
    // Shrink the size when one column cannot hold the title; a vertical heading does not break
    // into more columns and stops at 24.
    if (need > avail && avail > 0) {
        px = px * avail / need;
        px &= ~3;
        if (px < 24) px = 24;
    }
    int label_px = label != NULL && label[0] ? 24 : 0;
    const int gap = 12;
    metrics.title_px = px;
    metrics.label_px = label_px;
    metrics.width = px + (label_px ? label_px + gap : 0);
    // 题头最多占正文带的三分之一，留够列给正文。
    // A heading takes at most a third of the body band, leaving the rest for body columns.
    if (metrics.width > body.width / 3) {
        int scale = body.width / 3 * 100 / metrics.width;
        metrics.title_px = metrics.title_px * scale / 100;
        if (metrics.title_px < 24) metrics.title_px = 24;
        metrics.label_px = label_px ? label_px * scale / 100 : 0;
        if (metrics.label_px && metrics.label_px < 18) metrics.label_px = 18;
        metrics.width = metrics.title_px + (metrics.label_px ? metrics.label_px + gap : 0);
    }
    const int right = body.x + body.width;
    metrics.title_x = right - metrics.width;
    metrics.label_x = right - metrics.label_px;
    int title_h = ttf_vertical_text_height_px(metrics.title_px, title, 0);
    int label_h = metrics.label_px ? ttf_vertical_text_height_px(metrics.label_px, label, 0) : 0;
    metrics.text_height = title_h > label_h ? title_h : label_h;
    return metrics;
}

static void draw_vertical_heading(uint8_t *fb, EpdRect body) {
    reader_heading_t metrics = reader_heading_metrics(s_chapter_heading_title, s_chapter_heading_label, body);
    if (!metrics.width) return;
    int y = body.y + (body.height - metrics.text_height) / 2;
    if (y < body.y + 8) y = body.y + 8;
    ttf_font_select(TTF_FONT_SLOT_SYSTEM);
    if (metrics.label_px)
        ttf_draw_text_px_vertical(fb, metrics.label_x, y, metrics.label_px, s_chapter_heading_label, 0, 0, 15);
    ttf_draw_text_px_vertical(fb, metrics.title_x, y, metrics.title_px, s_chapter_heading_title, 0, 0, 15);
}

// 重排前把章节题头的几何重新说给排版：竖排留右侧列宽、横排留顶部行高，
// 绘制侧读的是同一组 s_chapter_lead_*。切模式、切全屏、改字号都必须走这里，
// 否则排版按旧模式预留、题头按新模式绘制，题头就会压到正文上。
// Tell the layout the chapter heading geometry before every re-layout: columns to the right in
// vertical setting, rows at the top in horizontal. Drawing reads the same s_chapter_lead_*
// values. Switching mode or full screen or changing the type size must all come through here;
// otherwise the layout reserves for the old mode while the heading draws in the new one and lands
// on top of the body.
// 题头几何按当前模式重算：竖排留右侧列宽、横排留顶部行高。
// height 由调用方按原有规矩算好（首块是插图、或没有可用标题时为 0），这里不再自己推导——
// 无条件按 214 算会把不该出现的题头带出来，正文里那份标题就与它并排成了两个标题。
// Heading geometry for the current mode: columns to the right vertically, rows at the top
// horizontally. `height` arrives already decided by the caller (zero when the first block is an
// illustration or no title is usable); deriving it here unconditionally brought a heading onto
// sheets that should have none, leaving it side by side with the body's own copy.
static unsigned landscape_heading_height(void) {
    // 横屏同时保留章名与尽量多正文：只给题头一条紧凑横带，正文最多占三分之二。
    // Landscape keeps the chapter name and most of the body: one compact band, at most a third.
    if (!s_chapter_lead_row_height || !s_chapter_heading_title[0]) return 0;
    EpdRect body = body_rect();
    unsigned height = 116;
    if (body.height > 0 && (unsigned)body.height / 3 < height) height = (unsigned)body.height / 3;
    return height >= 64 ? height : 0;
}
static void apply_chapter_lead(const char *title, const char *label, size_t skip, unsigned height) {
    s_chapter_lead_skip = skip;
    if (book_kind() != BOOK_KIND_EPUB || title == NULL || title[0] == 0 || !height) {
        s_chapter_lead_height = s_chapter_lead_width = 0;
        book_layout_set_chapter_lead(0, 0);
        book_layout_set_chapter_lead_width(0);
        return;
    }
    if (app_settings_book_vertical()) {
        // 量竖排题头会光栅化字形，调用方须已持有绘制锁。
        // Measuring the vertical heading rasterizes glyphs; the caller must hold the draw lock.
        s_chapter_lead_height = 0;
        s_chapter_lead_width = (unsigned)reader_heading_metrics(title, label, body_rect()).width;
        book_layout_set_chapter_lead(skip, 0);
        book_layout_set_chapter_lead_width(s_chapter_lead_width);
    } else if (s_reader_landscape) {
        // 横屏题头用紧凑横带，排版只留这一条高度；切回竖屏再按竖屏规则重留。
        // 只有真正从正文里跳过了标题字节才留横带，否则正文自己会显示章名，避免出现两行。
        // Landscape uses a compact band; switching back to portrait reserves by portrait rules.
        // Reserve the band only when the heading bytes are actually skipped from the body,
        // otherwise the body shows the heading itself and a band would duplicate it.
        s_chapter_lead_width = 0;
        s_chapter_lead_height = skip ? landscape_heading_height() : 0;
        book_layout_set_chapter_lead(skip, s_chapter_lead_height);
        book_layout_set_chapter_lead_width(0);
    } else {
        s_chapter_lead_width = 0;
        s_chapter_lead_height = height;
        book_layout_set_chapter_lead(skip, s_chapter_lead_height);
        book_layout_set_chapter_lead_width(0);
    }
}

// 重排前把题头几何交给排版；调用方须持有绘制锁。所有正文重排都要走这一句，
// 否则换了模式或字号之后，排版按上一次的题头尺寸预留，题头就会压住正文。
// Hand the heading geometry to the layout before a re-layout; the caller holds the draw lock.
// Every body re-layout needs this line, otherwise a mode or size change reserves room for the
// previous heading and the heading lands on the body.
static void refresh_chapter_lead(void) {
    apply_chapter_lead(s_chapter_heading_title, s_chapter_heading_label, s_chapter_lead_skip,
                       s_chapter_lead_row_height);
}

/* ---- 插图缩放 / Illustration zoom ---- */
// 整页插图与正文插图的双指缩放实现（自 rc100 移植）。交互帧走 1bit 点阵 + 跟随 DU，
// 松手后用双线性灰阶整屏定稿；横屏本期不启用（留待后续），竖屏完整生效。
// Two-finger zoom for whole-page and inline illustrations (ported from rc100). Interactive frames
// use a 1-bit target plus follow-DU, and release settles with a full-screen bilinear grayscale
// render. Portrait only for this release; landscape support is a later step.

// 定义在本节之后的同文件函数，先声明给缩放的几何判断使用。
// Same-file helpers defined later in the file; forward-declared for the zoom geometry.
static int reader_image_slots(size_t page);
static bool reader_image_screen_rect(int slot, EpdRect *out);

// 整数平方根：双指距离只用来比比例，不必引入浮点。
// Integer square root: pinch distance only feeds a ratio, so no floating point is needed.
static uint32_t reader_sqrt(uint32_t v) {
    uint32_t r = 0, bit = 1u << 30;
    while (bit > v) bit >>= 2;
    while (bit) {
        if (v >= r + bit) { v -= r + bit; r = (r >> 1) + bit; }
        else r >>= 1;
        bit >>= 2;
    }
    return r;
}

// 缓存必须属于当前阅读页和布局；解码失败或换章时不能引用旧槽。
// Require the active page and layout: failed decoding or chapter changes cannot borrow stale slots.
static bool reader_image_cache_ready(void) {
    return s_view == READING && s_text && !app_settings_reader_hide_images() &&
        s_reader_panel == READER_PANEL_NONE && !s_toolbar &&
        s_page_images && s_page_image_count > 0 && s_page_images_for == s_page &&
        s_page_images_generation == book_layout_generation();
}

// 缩放只属于竖屏正文；横屏本期不启用，保持横屏原来的绘制与手势行为。
// Zoom belongs to the portrait reader body only; landscape keeps its original paint and gesture
// behaviour for now, the support there is a later step.
static bool reader_zoom_ready(void) { return !s_reader_landscape && reader_image_cache_ready(); }

// 这一页是不是整屏只有一张插图，且它的灰阶位图已经就绪。
// Whether this page is one illustration and nothing else, with its gray bitmap decoded.
static bool reader_single_image_page(void) {
    return reader_image_cache_ready() &&
           book_layout_page_image(s_page) >= 0 && reader_image_slots(s_page) == 1 &&
           s_page_image_count == 1 && s_page_images[0].gray &&
           s_page_images[0].width > 0 && s_page_images[0].height > 0;
}

// 当前缩放目标：整页插图的唯一一张，或正文里双击进入缩放的那一张。
// Zoom target: the sole illustration of a whole-page sheet, or the inline image a double tap
// opened in zoom mode.
static const reader_image_t *reader_zoom_image(void) {
    if (!reader_zoom_ready()) return NULL;
    if (s_zoom_active)
        return s_zoom_slot >= 0 && s_zoom_slot < s_page_image_count &&
            s_page_images[s_zoom_slot].gray && s_page_images[s_zoom_slot].width > 0 &&
            s_page_images[s_zoom_slot].height > 0 ? &s_page_images[s_zoom_slot] : NULL;
    return reader_single_image_page() ? &s_page_images[0] : NULL;
}
// 有可缩放目标（整页插图，或已进入正文插图缩放模式）。
// Whether a zoom surface is available: a whole-page illustration, or an inline image already
// opened in zoom mode.
static bool reader_zoom_mode(void) { return reader_zoom_image() != NULL; }

// 1:1 时缩放目标在插图区域里的显示尺寸：等比缩小到能放下，不放大。
// The display size of the zoom target at 1:1: aspect-fit into the illustration region, never
// upscaled.
static void reader_image_base_size(int *out_w, int *out_h) {
    const reader_image_t *image = reader_zoom_image();
    EpdRect band = book_layout_image_rect();
    int64_t w = image ? image->width : 1, h = image ? image->height : 1;
    if (w > band.width) { h = h * band.width / w; w = band.width; }
    if (h > band.height) { w = w * band.height / h; h = band.height; }
    if (w < 1) w = 1;
    if (h < 1) h = 1;
    *out_w = (int)w;
    *out_h = (int)h;
}

// 正文里按点选中的插图槽；不在任何插图矩形里返回 false。
// The inline illustration slot under a tap, or false when the tap misses every image rectangle.
static bool reader_inline_image_at(uint16_t x, uint16_t y, int *slot) {
    if (!slot || !reader_zoom_ready()) return false;
    const int slots = reader_image_slots(s_page);
    for (int i = 0; i < slots && i < s_page_image_count; ++i) {
        EpdRect rect = {0};
        // 与 draw_reader_images 共用同一套屏幕定位，命中面和画面不会漂移。
        // Share the screen placement with draw_reader_images so hit and paint never drift apart.
        if (!reader_image_screen_rect(i, &rect)) continue;
        if (x >= rect.x && x < rect.x + rect.width &&
            y >= rect.y && y < rect.y + rect.height) {
            *slot = i;
            return true;
        }
    }
    return false;
}

// 这一页上点到的是不是一张插图（正文插图或整页插图）。
// Whether a tap landed on an illustration of the current page.
static bool reader_page_image_hit(uint16_t x, uint16_t y) {
    int slot = -1;
    return reader_inline_image_at(x, y, &slot);
}

// 图片中心活动范围：图比区域大时图像边缘不能缩进区域里，比区域小时固定在中心。
// Where the image centre may sit: while the image is larger than the region its edges must not
// pull inside it, and while it is smaller the centre stays put.
static void reader_image_clamp_center(int *cx, int *cy, int w, int h, EpdRect band) {
    if (w <= band.width) *cx = band.x + band.width / 2;
    else {
        int low = band.x + band.width - w / 2, high = band.x + w / 2;
        if (*cx < low) *cx = low;
        if (*cx > high) *cx = high;
    }
    if (h <= band.height) *cy = band.y + band.height / 2;
    else {
        int low = band.y + band.height - h / 2, high = band.y + h / 2;
        if (*cy < low) *cy = low;
        if (*cy > high) *cy = high;
    }
}

// 4x4 有序抖动点阵：连续 DU 只认纯黑/纯白，靠点的密度表现灰阶。
// 4x4 ordered-dither matrix: continuous DU only drives pure black and white, so dot density
// carries the gray level.
static const uint8_t s_bayer4[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};

// 把 0=黑…255=白 的一档灰度摊成纯黑/白点阵。/ Turn a 0=black..255=white tone into black/white dots.
static uint8_t reader_bw_tone(uint8_t gray, int x, int y) {
    unsigned threshold = (unsigned)s_bayer4[((y & 3) << 2) | (x & 3)] * 16u + 8u;
    return gray >= threshold ? 0xff : 0x00;
}

// 双线性取样：放大时比最近邻平滑，缩小时也不会出现整片跳变。
// Bilinear sampling: smoother than nearest neighbour when enlarging, without whole-pixel jumps
// when shrinking.
static uint8_t reader_sample_bilinear(const reader_image_t *image, int sx_fp, int sy_fp) {
    int x0 = sx_fp >> 16, y0 = sy_fp >> 16;
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x0 >= image->width) x0 = image->width - 1;
    if (y0 >= image->height) y0 = image->height - 1;
    int x1 = x0 + 1 < image->width ? x0 + 1 : x0;
    int y1 = y0 + 1 < image->height ? y0 + 1 : y0;
    unsigned fx = ((unsigned)sx_fp >> 8) & 0xffu, fy = ((unsigned)sy_fp >> 8) & 0xffu;
    const uint8_t *p = image->gray;
    unsigned top = (unsigned)p[(size_t)y0 * image->width + x0] * (256u - fx) +
                   (unsigned)p[(size_t)y0 * image->width + x1] * fx;
    unsigned bottom = (unsigned)p[(size_t)y1 * image->width + x0] * (256u - fx) +
                      (unsigned)p[(size_t)y1 * image->width + x1] * fx;
    return (uint8_t)((top * (256u - fy) + bottom * fy) >> 16);
}

// 缩放并平移到位的插图，采样用双线性；bw=true 时用点阵出纯黑白，专供跟手快刷。
// The zoom target at the current scale and centre, sampled bilinearly. With bw=true it renders
// pure black/white dots for the interactive fast frames.
static void draw_zoomed_image(uint8_t *fb, EpdRect band, int scale, int cx, int cy, bool bw) {
    const reader_image_t *image = reader_zoom_image();
    if (!image) return;
    int base_w = 0, base_h = 0;
    reader_image_base_size(&base_w, &base_h);
    int w = (int)((int64_t)base_w * scale / READER_IMAGE_ZOOM_MIN);
    int h = (int)((int64_t)base_h * scale / READER_IMAGE_ZOOM_MIN);
    if (w < 1 || h < 1) return;
    int left = cx - w / 2, top = cy - h / 2;
    int64_t step_x = ((int64_t)image->width << 16) / w;
    int64_t step_y = ((int64_t)image->height << 16) / h;
    int64_t max_x = (int64_t)(image->width - 1) << 16;
    int64_t max_y = (int64_t)(image->height - 1) << 16;
    // 只走屏幕与图片的交集，避免每像素再做越界判断。
    // Walk only the intersection of the sheet and the image, so no per-pixel bounds test is needed.
    int x0 = band.x > left ? band.x : left;
    int y0 = band.y > top ? band.y : top;
    int x1 = band.x + band.width < left + w ? band.x + band.width : left + w;
    int y1 = band.y + band.height < top + h ? band.y + band.height : top + h;
    if (x0 < band.x) x0 = band.x;
    if (y0 < band.y) y0 = band.y;
    if (x1 > band.x + band.width) x1 = band.x + band.width;
    if (y1 > band.y + band.height) y1 = band.y + band.height;
    for (int py = y0; py < y1; ++py) {
        int64_t sy_fp = (int64_t)(py - top) * step_y;
        if (sy_fp > max_y) continue;
        for (int px = x0; px < x1; ++px) {
            int64_t sx_fp = (int64_t)(px - left) * step_x;
            if (sx_fp > max_x) continue;
            uint8_t gray = reader_sample_bilinear(image, (int)sx_fp, (int)sy_fp);
            epd_draw_pixel(px, py, bw ? reader_bw_tone(gray, px, py)
                                      : ui_image_dither_gray(inline_ink_gray(gray), px, py), fb);
        }
    }
    // 反色模式下插图保留原灰阶：只把真正画到的图片矩形翻一次，扫描出口再翻回来。
    // Keep artwork original under inversion: flip only the drawn image rectangle here; the scan
    // flips it back at output.
    if (x1 > x0 && y1 > y0)
        display_invert_area(fb, (EpdRect){x0, y0, x1 - x0, y1 - y0});
}

/* ---- 跟手帧：1bit 目标帧 / Gesture frames from a 1-bit target ---- */
// 逻辑坐标正解成物理坐标，与 epdiy 的 _rotate 一致。
// Map a logical pixel to physical coordinates, matching epdiy's _rotate().
static void reader_logical_to_phys(int lx, int ly, int *px, int *py) {
    switch (epd_get_rotation()) {
        case EPD_ROT_PORTRAIT: *px = epd_width() - 1 - ly; *py = lx; break;
        case EPD_ROT_INVERTED_LANDSCAPE: *px = epd_width() - 1 - lx; *py = epd_height() - 1 - ly; break;
        case EPD_ROT_INVERTED_PORTRAIT: *px = ly; *py = epd_height() - 1 - lx; break;
        default: *px = lx; *py = ly; break;
    }
}

// 丢弃整个缩放现场：状态、1bit 目标帧与未完成的连续 DU 相位。翻页、切面板、离开阅读页、
// 进锁屏、换向与换书都必须经过这里；s_image_zoom_bw 为真时先收掉残余相位。
// Drop the whole zoom context: state, the 1-bit target frame and unfinished continuous-DU
// phases. Page turns, panel switches, leaving the reader, locking, rotation and book changes all
// go through here; while s_image_zoom_bw is set the leftover phases are cleared first.
static void reader_zoom_reset(void) {
    if (s_image_zoom_bw) continuous_du_reset();
    s_zoom_active = false;
    s_zoom_slot = -1;
    s_image_zoom = READER_IMAGE_ZOOM_MIN;
    s_image_zoom_page = SIZE_MAX;
    s_image_zoom_start_distance = 0;
    s_image_pan_active = false;
    s_image_zoom_bw = false;
    s_image_zoom_draw_ms = 0;
    s_reader_tap.pending = false;
    free(s_zoom_bits);
    s_zoom_bits = NULL;
    s_zoom_bits_bytes = 0;
}

// 按区域大小准备 1bit 帧缓冲（整块插图区域约 78–104 KiB PSRAM）；尺寸一样就复用。
// Prepare the 1-bit frame buffer sized to the region (78-104 KiB in PSRAM); reuse it while the
// size matches. Allocation failure simply disables the 1-bit fast path, never the zoom itself.
static bool zoom_bits_ready(EpdRect phys) {
    size_t bytes = (size_t)((phys.width + 7) / 8) * (size_t)phys.height;
    if (bytes == 0) return false;
    if (bytes == s_zoom_bits_bytes && s_zoom_bits) return true;
    free(s_zoom_bits);
    s_zoom_bits = NULL;
    s_zoom_bits_bytes = 0;
    uint8_t *a = heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!a) return false;
    memset(a, 0, bytes);
    s_zoom_bits = a;
    s_zoom_bits_bytes = bytes;
    return true;
}

// 生成一帧：按逻辑坐标遍历，源图行顺序读，写出的点落在物理内存里的小块中；
// 逻辑→物理是仿射映射（系数只有 0/±1），所以每次取样只做两次乘法。
// 逐像素取样再按有序抖动摊成黑白：跟手帧用细抖动保持画面连续，灰度定稿另走双线性。
// Build one frame by walking logical coordinates: source rows read sequentially and the dots land
// in a small physical tile. Logical-to-physical is affine with 0/+-1 coefficients, so a sample
// costs two multiplies. Every pixel is sampled and ordered-dithered, so the motion frame keeps a
// continuous look instead of 4x4 blocks; the grayscale settle still uses bilinear.
#define ZOOM_BITS_STEP 1
static void zoom_bits_build(uint8_t *bits, EpdRect phys, EpdRect band, int iw, int ih,
                            int w, int h, int left, int top) {
    const int width_bytes = (phys.width + 7) / 8;
    memset(bits, 0, (size_t)width_bytes * (size_t)phys.height);
    // 只遍历"图片 ∩ 插图区域"：放大后图片比屏幕大得多，多算的部分全在屏幕外。
    // Walk only the image ∩ region: a zoomed image reaches far past the sheet, and anything
    // outside it would be sampled and discarded.
    int lx0 = left > band.x ? left : band.x;
    int ly0 = top > band.y ? top : band.y;
    int lx1 = left + w < band.x + band.width ? left + w : band.x + band.width;
    int ly1 = top + h < band.y + band.height ? top + h : band.y + band.height;
    if (lx1 > left + w) lx1 = left + w;
    if (ly1 > top + h) ly1 = top + h;
    if (lx1 <= lx0 || ly1 <= ly0) return;
    // 仿射系数：px = ax*lx + ay*ly + px0，py = dx*lx + dy*ly + py0。
    // Affine coefficients: px = ax*lx + ay*ly + px0 and py = dx*lx + dy*ly + py0.
    int px0 = 0, py0 = 0, e1x = 0, e1y = 0, e2x = 0, e2y = 0;
    reader_logical_to_phys(0, 0, &px0, &py0);
    reader_logical_to_phys(1, 0, &e1x, &e1y);
    reader_logical_to_phys(0, 1, &e2x, &e2y);
    const int ax = e1x - px0, ay = e2x - px0, ddx = e1y - py0, ddy = e2y - py0;
    // 采样步长用定点：每像素 64 位除法太贵，这里只乘一次再移位。
    // Fixed-point sampling steps: a 64-bit division per pixel is far too costly, so multiply once
    // and shift.
    const int64_t step_x = ((int64_t)iw << 16) / w;
    const int64_t step_y = ((int64_t)ih << 16) / h;
    const int step = ZOOM_BITS_STEP;
    const reader_image_t *zoom_image = reader_zoom_image();
    if (!zoom_image) return;
    for (int ly = ly0; ly < ly1; ly += step) {
        const int sy = (int)(((int64_t)(ly - top) * step_y) >> 16);
        if (sy < 0 || sy >= ih) continue;
        const uint8_t *src = zoom_image->gray + (size_t)sy * iw;
        for (int lx = lx0; lx < lx1; lx += step) {
            const int sx = (int)(((int64_t)(lx - left) * step_x) >> 16);
            if (sx < 0 || sx >= iw) continue;
            const uint8_t gray = src[sx];
            const int lxe = lx + step < lx1 ? lx + step : lx1;
            const int lye = ly + step < ly1 ? ly + step : ly1;
            for (int lv = ly; lv < lye; ++lv) {
                const int py = py0 + ddx * lx + ddy * lv;
                if (py < phys.y || py >= phys.y + phys.height) continue;
                uint8_t *row = bits + (size_t)(py - phys.y) * (size_t)width_bytes;
                for (int lv2 = lx; lv2 < lxe; ++lv2) {
                    const int px = px0 + ax * lv2 + ay * lv;
                    if (px < phys.x || px >= phys.x + phys.width) continue;
                    const int xx = px - phys.x;
                    if (gray < (unsigned)s_bayer4[((py & 3) << 2) | (px & 3)] * 16u + 8u)
                        row[xx >> 3] |= (uint8_t)(0x80u >> (xx & 7));
                }
            }
        }
    }
}

// 交互中的一帧：只生成 1bit 点阵，把它按字节铺进 4bpp 帧缓冲，再用跟随 DU 波形一次刷出。
// 不重采样双线性、不画文字，灰度渲染整个挪到松手之后；跟随波形把整幅黑白一次推完，
// 所以动起来看得到画面，而不是只有停手后才出图。
// One interactive frame: build a 1-bit pattern, blit it byte-wise into the 4bpp framebuffer and
// present it with one follow-DU waveform. No bilinear resample and no text drawing; the grayscale
// render waits for the release. A single waveform push shows the whole frame, so motion is
// visible instead of only the final still.
static void zoom_blit_bits(uint8_t *fb, const uint8_t *bits, EpdRect phys) {
    if (!fb || !bits || phys.width <= 0 || phys.height <= 0) return;
    const int width_bytes = (phys.width + 7) / 8, stride = epd_width() / 2;
    for (int y = 0; y < phys.height; ++y) {
        int py = phys.y + y;
        if (py < 0 || py >= epd_height()) continue;
        for (int x = 0; x < phys.width; ++x) {
            int px = phys.x + x;
            if (px < 0 || px >= epd_width()) continue;
            uint8_t tone = (bits[(size_t)y * width_bytes + x / 8] & (0x80u >> (x & 7))) ? 0 : 15;
            uint8_t *dst = fb + (size_t)py * stride + px / 2;
            *dst = px & 1 ? (*dst & 0x0f) | (tone << 4) : (*dst & 0xf0) | tone;
        }
    }
}

// 一帧交互画面：整块插图区域先铺黑白目标帧，再用跟随 DU 一次推完；反色时图片矩形再翻一次。
// One interactive frame: paint the whole illustration region from the 1-bit target and push it
// with one follow-DU waveform; under inversion the image rectangle is flipped once more so the
// artwork keeps its original tones.
static app_redraw_t zoom_frame(app_ctx_t* ctx) {
    const reader_image_t *image = reader_zoom_image();
    if (!image) { reader_zoom_reset(); return APP_REDRAW_NONE; }
    s_image_zoom_bw = true;
    s_image_zoom_draw_ms = ctx->now_ms;
    EpdRect band = book_layout_image_rect();
    int x0, y0, x1, y1;
    reader_logical_to_phys(band.x, band.y, &x0, &y0);
    reader_logical_to_phys(band.x + band.width - 1, band.y + band.height - 1, &x1, &y1);
    EpdRect phys = {x0 < x1 ? x0 : x1, y0 < y1 ? y0 : y1,
        abs(x1 - x0) + 1, abs(y1 - y0) + 1};
    int base_w = 0, base_h = 0;
    reader_image_base_size(&base_w, &base_h);
    int w = (int)((int64_t)base_w * s_image_zoom / READER_IMAGE_ZOOM_MIN);
    int h = (int)((int64_t)base_h * s_image_zoom / READER_IMAGE_ZOOM_MIN);
    if (w < 1 || h < 1) return APP_REDRAW_NONE;
    int left = s_image_zoom_cx - w / 2, top = s_image_zoom_cy - h / 2;
    // 反色模式：图片与插图区域的逻辑交集就是真正铺进帧缓冲的那块，点阵落屏后整体翻一次
    // （display_invert_area 收逻辑坐标，内部再映射回物理坐标）。
    // Under inversion the logical intersection of image and region is exactly what was painted;
    // flip it once after the dot frame lands (display_invert_area takes logical coordinates and
    // maps them back to physical internally).
    int lx0 = left > band.x ? left : band.x;
    int ly0 = top > band.y ? top : band.y;
    int lx1 = left + w < band.x + band.width ? left + w : band.x + band.width;
    int ly1 = top + h < band.y + band.height ? top + h : band.y + band.height;
    EpdRect art = {lx0, ly0, lx1 > lx0 ? lx1 - lx0 : 0, ly1 > ly0 ? ly1 - ly0 : 0};
    if (!zoom_bits_ready(phys)) {
        // 内存不够时退回 4bpp 重绘的老路，绝不卡住手势。
        // Without memory for the pattern, fall back to the older 4bpp repaint.
        ui_fill_rect_fast(band, 0xFF, ctx->fb);
        draw_zoomed_image(ctx->fb, band, s_image_zoom, s_image_zoom_cx, s_image_zoom_cy, true);
        guard_draw_result(ctx->hl, update_display_area_diff_with(
            ctx->hl, &E0470_FOLLOW_WAVEFORM, MODE_DU, reader_area()));
        return APP_REDRAW_DONE;
    }
    int64_t t_build = esp_timer_get_time();
    zoom_bits_build(s_zoom_bits, phys, band, image->width, image->height,
                    w, h, left, top);
    int64_t t_build_end = esp_timer_get_time();
    zoom_blit_bits(ctx->fb, s_zoom_bits, phys);
    display_invert_area(ctx->fb, art);
    rails_keepalive();
    epd_poweron();
    // 跟随 DU：一次波形把整幅黑白推完（8 帧短波形），画面完整可见。
    // Follow DU: one waveform pushes the whole black/white frame (eight short frames), so the
    // picture is fully visible.
    guard_draw_result(ctx->hl, update_display_area_diff_with(
        ctx->hl, &E0470_FOLLOW_WAVEFORM, MODE_DU, band));
    int64_t t_done = esp_timer_get_time();
    ESP_LOGD(TAG, "zoom %d build=%.1f blit+du=%.1f ms",
             s_image_zoom, (t_build_end - t_build) / 1000.0, (t_done - t_build_end) / 1000.0);
    return APP_REDRAW_DONE;
}

// 松手定稿：把黑白交互帧换成灰阶整页图；缩回原始大小时也走这里，避免半灰残影。
// Settle after the fingers leave: replace the black/white frames with the grayscale page. Zooming
// all the way back lands here too, which is what clears the half-tone ghosting.
static app_redraw_t zoom_settle(app_ctx_t* ctx) {
    s_image_zoom_start_distance = 0;
    s_image_pan_active = false;
    if (!s_image_zoom_bw && s_image_zoom <= READER_IMAGE_ZOOM_MIN) return APP_REDRAW_NONE;
    s_image_zoom_bw = false;
    continuous_du_reset();
    render(ctx, ctx->fb);
    // 松手后整屏全刷：黑白帧留下的光学状态要整个驱动一遍，差分只剩插图区域会留下残影。
    // Full-screen settle after release: the black/white frames leave optical state that a
    // picture-only difference cannot clear, so drive every pixel of the panel.
    guard_draw_result(ctx->hl, update_display_area_full_with(
        ctx->hl, &E0470_FULL_WAVEFORM, MODE_GC16, reader_full_rect()));
    return APP_REDRAW_DONE;
}

// 整页插图的定点缩放：把点到的那一点当作锚，直接跳到目标倍率并整屏刷灰度。
// Point-anchored jump zoom for a whole-page illustration: the tapped point stays under the
// finger, the target scale is applied at once, and the panel is fully refreshed in grayscale.
static app_redraw_t zoom_jump(app_ctx_t* ctx, int scale, int fx, int fy) {
    EpdRect band = book_layout_image_rect();
    int base_w = 0, base_h = 0;
    reader_image_base_size(&base_w, &base_h);
    s_image_zoom_page = s_page;
    s_image_zoom_start_distance = 0;
    s_image_pan_active = false;
    s_image_zoom_bw = false;
    continuous_du_reset();
    if (scale > READER_IMAGE_ZOOM_MIN) {
        const int cx0 = band.x + band.width / 2, cy0 = band.y + band.height / 2;
        int cx = fx - (int)((int64_t)(fx - cx0) * scale / READER_IMAGE_ZOOM_MIN);
        int cy = fy - (int)((int64_t)(fy - cy0) * scale / READER_IMAGE_ZOOM_MIN);
        int w = (int)((int64_t)base_w * scale / READER_IMAGE_ZOOM_MIN);
        int h = (int)((int64_t)base_h * scale / READER_IMAGE_ZOOM_MIN);
        reader_image_clamp_center(&cx, &cy, w, h, band);
        s_image_zoom = scale;
        s_image_zoom_cx = cx;
        s_image_zoom_cy = cy;
    } else {
        s_image_zoom = READER_IMAGE_ZOOM_MIN;
        s_image_zoom_cx = band.x + band.width / 2;
        s_image_zoom_cy = band.y + band.height / 2;
    }
    render(ctx, ctx->fb);
    guard_draw_result(ctx->hl, update_display_area_full_with(
        ctx->hl, &E0470_FULL_WAVEFORM, MODE_GC16, reader_full_rect()));
    return APP_REDRAW_DONE;
}

// 双击正文里的插图：进入缩放模式并以点到的位置为锚放大到 2 倍；再双击退出回到正文。
// Double tap on an inline illustration enters zoom mode at 2x anchored on the tap; another
// double tap leaves zoom mode and returns to the text.
static app_redraw_t inline_zoom_toggle(app_ctx_t* ctx, uint16_t x, uint16_t y) {
    if (s_zoom_active) {
        s_zoom_active = false;
        s_image_zoom = READER_IMAGE_ZOOM_MIN;
        s_image_zoom_bw = false;
        s_image_zoom_start_distance = 0;
        s_image_zoom_page = SIZE_MAX;
        s_image_pan_active = false;
        continuous_du_reset();
        render(ctx, ctx->fb);
        guard_draw_result(ctx->hl, update_display_area_full_with(
            ctx->hl, &E0470_FULL_WAVEFORM, MODE_GC16, reader_full_rect()));
        return APP_REDRAW_DONE;
    }
    int slot = -1;
    if (!reader_inline_image_at(x, y, &slot)) return APP_REDRAW_NONE;
    s_zoom_active = true;
    s_zoom_slot = slot;
    return zoom_jump(ctx, 2000, x, y);
}

// 双指识别入口：本页此刻是否有可缩放目标；有则 app_loop 把双指交给 on_pinch。
// Pinch admission: does this page currently own a zoom surface? When true app_loop hands both
// contacts to on_pinch.
static bool wants_pinch(app_ctx_t* ctx) {
    (void)ctx;
    return reader_zoom_mode();
}

// 双指缩放与平移：两指中点是缩放锚点，中点移动连同单指拖动都直接平移图片。
// Two-finger zoom and pan: the contact midpoint anchors the scale, and moving that midpoint --
// or dragging with one finger -- pans the image.
static app_redraw_t on_pinch(app_ctx_t* ctx, const app_pinch_t* pinch) {
    if (s_reader_panel == READER_PANEL_FONT_RECOVERY) return APP_REDRAW_NONE;
    if (!pinch) return APP_REDRAW_NONE;
    // 收尾事件即使面板刚打开（此时 reader_zoom_mode 已为 false）也要把黑白交互帧定稿：
    // 否则跟随 DU 留下的半黑半白画面会挂在面板底下。没有缩放现场时直接忽略。
    // The end event settles the black/white frames even when a panel just opened and
    // reader_zoom_mode() already reads false; otherwise the follow-DU frame stays half-tone
    // under the sheet. Ignore it when no zoom context exists.
    if (!pinch->active) {
        if (!(s_zoom_active || s_image_zoom_bw || s_image_zoom > READER_IMAGE_ZOOM_MIN))
            return APP_REDRAW_NONE;
        return zoom_settle(ctx);
    }
    if (!reader_zoom_mode()) return APP_REDRAW_NONE;
    // 触摸芯片上报工厂竖屏坐标；180° 竖排时要先映射到当前逻辑坐标再算锚点。
    // Touch reports factory-portrait coordinates; a 180-degree portrait needs the mapping before
    // the anchor math.
    int ax = pinch->ax, ay = pinch->ay, bx = pinch->bx, by = pinch->by;
    if (reader_touch_needs_map()) {
        reader_touch_map(&ax, &ay);
        reader_touch_map(&bx, &by);
    }
    EpdRect band = book_layout_image_rect();
    int dx = bx - ax, dy = by - ay;
    uint32_t distance = reader_sqrt((uint32_t)(dx * dx + dy * dy));
    int mx = (ax + bx) / 2;
    int my = (ay + by) / 2;
    if (s_image_zoom_page != s_page) {
        s_image_zoom_page = s_page;
        s_image_zoom = READER_IMAGE_ZOOM_MIN;
        s_image_zoom_cx = band.x + band.width / 2;
        s_image_zoom_cy = band.y + band.height / 2;
        s_image_zoom_start_distance = 0;
    }
    // 起点太近时比值不可靠，等两指张开一点再记基准；锚点存成 1:1 基准像素下的偏移。
    // A too-near start makes the ratio unreliable, so wait for the fingers to spread; the
    // anchor is stored as an offset in 1:1 base pixels.
    if (!s_image_zoom_start_distance) {
        if (distance < 24) return APP_REDRAW_NONE;
        s_image_zoom_start_distance = distance;
        s_image_zoom_start_scale = s_image_zoom;
        s_image_zoom_start_cx = s_image_zoom_cx;
        s_image_zoom_start_cy = s_image_zoom_cy;
        s_image_zoom_anchor_dx = (mx - s_image_zoom_cx) * READER_IMAGE_ZOOM_MIN / s_image_zoom;
        s_image_zoom_anchor_dy = (my - s_image_zoom_cy) * READER_IMAGE_ZOOM_MIN / s_image_zoom;
        return APP_REDRAW_NONE;
    }
    int scale = (int)((int64_t)s_image_zoom_start_scale * distance / s_image_zoom_start_distance);
    if (scale > READER_IMAGE_ZOOM_MAX) scale = READER_IMAGE_ZOOM_MAX;
    // 缩回原始大小就立刻出一次灰阶：黑白帧留在屏上会变成一片残影。
    // Landing back at 1:1 settles grayscale right away; black/white frames left on the panel
    // would read as ghosting.
    if (scale <= READER_IMAGE_ZOOM_MIN) {
        s_image_zoom = READER_IMAGE_ZOOM_MIN;
        s_image_zoom_cx = band.x + band.width / 2;
        s_image_zoom_cy = band.y + band.height / 2;
        return zoom_settle(ctx);
    }
    int cx = mx - (int)((int64_t)s_image_zoom_anchor_dx * scale / READER_IMAGE_ZOOM_MIN);
    int cy = my - (int)((int64_t)s_image_zoom_anchor_dy * scale / READER_IMAGE_ZOOM_MIN);
    int base_w = 0, base_h = 0;
    reader_image_base_size(&base_w, &base_h);
    int w = (int)((int64_t)base_w * scale / READER_IMAGE_ZOOM_MIN);
    int h = (int)((int64_t)base_h * scale / READER_IMAGE_ZOOM_MIN);
    reader_image_clamp_center(&cx, &cy, w, h, band);
    int moved = cx - s_image_zoom_cx, moved_y = cy - s_image_zoom_cy;
    if (moved < 0) moved = -moved;
    if (moved_y < 0) moved_y = -moved_y;
    int step = scale > s_image_zoom ? scale - s_image_zoom : s_image_zoom - scale;
    // 状态先落地，再决定这一帧要不要推屏：节流只应该省掉刷新，不能吞掉手势。
    // Commit the state first and only then decide whether to present this frame: throttling may
    // skip a refresh, never the gesture itself.
    s_image_zoom = scale;
    s_image_zoom_cx = cx;
    s_image_zoom_cy = cy;
    // 单帧要重采样整块插图，按变化量与时间节流；连续 DU 每扫一个相位约 6 ms，阈值放低也稳。
    // A frame resamples the whole illustration, so throttle by change and time; one continuous-DU
    // phase is about 6 ms, so the thresholds can stay low.
    if (step < 20 && moved + moved_y < 4) return APP_REDRAW_NONE;
    if (ctx->now_ms - s_image_zoom_draw_ms < 40) return APP_REDRAW_NONE;
    return zoom_frame(ctx);
}

// 缩放后单指拖动平移；拖动结束吃掉这次滑动，不翻页也不切工具栏。
// One-finger pan while zoomed; the ending swipe is swallowed so it neither turns the page nor
// toggles the toolbar.
static app_redraw_t image_zoom_gesture(app_ctx_t* ctx, const ui_gesture_event_t* ev, bool* handled) {
    *handled = false;
    if (!reader_zoom_mode() || s_image_zoom_page != s_page ||
        s_image_zoom <= READER_IMAGE_ZOOM_MIN) {
        s_image_pan_active = false;
        return APP_REDRAW_NONE;
    }
    if (ev->type == UI_GESTURE_PRESS) {
        s_image_pan_active = false;
        s_image_pan_x = ev->x;
        s_image_pan_y = ev->y;
        return APP_REDRAW_NONE;
    }
    if (ev->type == UI_GESTURE_MOVE) {
        int dx = (int)ev->x - (int)s_image_pan_x, dy = (int)ev->y - (int)s_image_pan_y;
        int ax = dx < 0 ? -dx : dx, ay = dy < 0 ? -dy : dy;
        if (!s_image_pan_active && ax + ay < 8) return APP_REDRAW_NONE;
        s_image_pan_active = true;
        s_image_pan_x = ev->x;
        s_image_pan_y = ev->y;
        EpdRect band = book_layout_image_rect();
        int base_w = 0, base_h = 0;
        reader_image_base_size(&base_w, &base_h);
        int cx = s_image_zoom_cx + dx, cy = s_image_zoom_cy + dy;
        reader_image_clamp_center(&cx, &cy,
            (int)((int64_t)base_w * s_image_zoom / READER_IMAGE_ZOOM_MIN),
            (int)((int64_t)base_h * s_image_zoom / READER_IMAGE_ZOOM_MIN), band);
        *handled = true;
        s_image_zoom_cx = cx;
        s_image_zoom_cy = cy;
        if (ctx->now_ms - s_image_zoom_draw_ms < 60) return APP_REDRAW_NONE;
        return zoom_frame(ctx);
    }
    if (s_image_pan_active) {
        s_image_pan_active = false;
        *handled = true;
        return zoom_settle(ctx);
    }
    return APP_REDRAW_NONE;
}

// 整页插图用：任意位置的双击都算双击，单击一律延后到双击窗口结束才翻页。
// 自 rc100 的 book_reader_tap_feed_any() 移植（那边是头文件内联，这里不改 book_* 模块）。
// For a whole-page illustration a double tap counts anywhere, and a single tap is deferred until
// the double-tap window expires before it turns the page. Ported from rc100's inline
// book_reader_tap_feed_any(); the book_* module itself stays untouched.
static int reader_tap_feed_any(book_reader_tap_t *tap, EpdRect body,
                               int x, int y, bool vertical, bool rtl, int64_t now_ms) {
    const int direction = book_reader_tap_direction(body, x, y, vertical, rtl);
    if (!direction) { tap->pending = false; return 0; }
    const int dx = x - tap->x, dy = y - tap->y;
    if (tap->pending && now_ms >= tap->at_ms && now_ms - tap->at_ms <= BOOK_READER_DOUBLE_MS &&
        dx * dx + dy * dy <= 120 * 120) {
        tap->pending = false;
        return BOOK_READER_TAP_FULLSCREEN;
    }
    const int expired = tap->pending && now_ms >= tap->at_ms &&
        now_ms - tap->at_ms > BOOK_READER_DOUBLE_MS ? tap->direction : 0;
    *tap = (book_reader_tap_t){true, direction, now_ms, x, y};
    return expired;
}


// PR9 未知尺寸整页图没有混排槽；在调用侧适配原有位图缓存。/ PR9's unknown-size page has no inline slot; adapt the bitmap cache here.
static int reader_image_slots(size_t page) {
    int count = book_layout_page_image_count(page);
    return count ? count : book_layout_page_image(page) >= 0 ? 1 : 0;
}
static bool reader_image_slot(size_t page, int slot, int *index, int *y, int *width, int *height) {
    if (book_layout_page_image_count(page))
        return book_layout_page_image_at(page, slot, index, y, width, height);
    int image = book_layout_page_image(page);
    if (slot != 0 || image < 0) return false;
    // 未知尺寸的整页图同样通栏，不能拿正文栏宽当上限。
    // An unknown-size whole-page image bleeds as well, so the body column is not its ceiling.
    EpdRect band = book_layout_image_rect();
    if (index) *index = image;
    if (y) *y = 0;
    if (width) *width = band.width;
    if (height) *height = band.height;
    return true;
}
static void draw_reader_images(uint8_t *fb, size_t page, EpdRect body) {
    // 位图和布局代次必须匹配；预渲染另一页不能复用当前页插图。
    // Match page and layout generation; a prefetched page must never borrow current-page bitmaps.
    if (!app_settings_reader_hide_images() && page == s_page &&
        s_page_images_for == page && s_page_images_generation == book_layout_generation()) {
        // 插图缩放只属于竖屏正文：横屏本期不启用（留待后续），保持原绘制路径。
        // Illustration zoom is portrait-body only for now; landscape keeps the original paint path.
        if (reader_zoom_ready()) {
            // 缩放只属于缩放时的那一页；换页后回到原始大小与居中位置。
            // The scale belongs to the page it was made on; a page change returns to 1:1 and centre.
            if (s_image_zoom_page != page) {
                // 换页时丢掉还没扫完的相位，别把上一页的点阵带到新页。
                // Drop phases still in flight on a page change so no dots carry over.
                if (s_image_zoom_bw) continuous_du_reset();
                s_image_zoom = READER_IMAGE_ZOOM_MIN;
                s_image_zoom_bw = false;
                s_image_pan_active = false;
                s_zoom_active = false;
                EpdRect reset_band = book_layout_image_rect();
                s_image_zoom_cx = reset_band.x + reset_band.width / 2;
                s_image_zoom_cy = reset_band.y + reset_band.height / 2;
            }
            // 正文插图缩放模式：整块插图区域只画那一张，其他内容不参与。
            // Inline zoom mode: the illustration region shows that one image and nothing else.
            if (s_zoom_active && reader_zoom_mode()) {
                draw_zoomed_image(fb, book_layout_image_rect(), s_image_zoom,
                                  s_image_zoom_cx, s_image_zoom_cy, s_image_zoom_bw);
                return;
            }
            if (s_image_zoom > READER_IMAGE_ZOOM_MIN && reader_single_image_page()) {
                draw_zoomed_image(fb, book_layout_image_rect(), s_image_zoom,
                                  s_image_zoom_cx, s_image_zoom_cy, s_image_zoom_bw);
                return;
            }
        }
        // 横向按插图区域居中：通栏时图片铺满整屏，不再留正文边距。
        // Center horizontally in the illustration region: with full bleed the image spans the
        // panel and no longer carries the body margins.
        EpdRect band = book_layout_image_rect();
        for (int i = 0; i < reader_image_slots(page); ++i) {
            int y, width, height;
            if (!reader_image_slot(page, i, NULL, &y, &width, &height)) continue;
            const reader_image_t *image = s_page_images && i < s_page_image_count ? &s_page_images[i] : NULL;
            if (image && image->gray) {
                int left = band.x + (band.width - image->width) / 2;
                int top = band.y + y + (height - image->height) / 2;
                // 页首插图贴到阅读区顶端：正文上方那点呼吸空间只属于正文，不该把插图压下来。
                // 横屏贴到正文带顶端，避免被顶部状态/题头带裁掉。
                // A page-start illustration sits at the top of the reading area: the inset above
                // body text belongs to text and must not push the illustration down. In landscape
                // it attaches to the body band top so chrome does not clip it.
                if (y == 0) top = s_reader_landscape ? body.y : reader_area().y;

                // 逐像素绘制时每 32 行让出一次主循环：横屏整页插图面积更大，避免长时间
                // 不让出导致看门狗/触摸长时间无响应（真机反馈横屏插图卡死）。
                // Yield once per 32 rows while plotting: a full-page landscape illustration is
                // large enough that a long non-yielding loop looked like a freeze on the device.
                for (int iy = 0; iy < image->height; ++iy) {
                    for (int ix = 0; ix < image->width; ++ix)
                        epd_draw_pixel(left + ix, top + iy,
                            ui_image_dither_gray(inline_ink_gray(image->gray[(size_t)iy * image->width + ix]),
                                                 left + ix, top + iy), fb);
                    if ((iy & 31) == 31) vTaskDelay(1);
                }
                // 反色模式下插图保留原灰阶：单独翻一次，扫描出口再翻回来。
                // Keep illustrations original under inversion: flip this rect once, the scan flips it back.
                display_invert_area(fb, (EpdRect){left, top, image->width, image->height});
            } else if (height >= UI_PX_CAPTION + 4 && width >= 70) {
                char notice[64]; copy_text(notice, sizeof(notice), "此插图暂无法显示");
                fit_text(notice, UI_PX_CAPTION, width - 8);
                ui_text_vc(fb, body.x + body.width / 2, body.y + y + height / 2,
                           UI_PX_CAPTION, notice, EPD_DRAW_ALIGN_CENTER, false);
            }
        }
    }
}
// 横屏章名：居中编号 + 标题 + 细线，全部落在排版预留的紧凑横带里。
// Landscape chapter heading: centred label and title with a hairline, inside the reserved band.
static void draw_landscape_heading(uint8_t *fb, EpdRect body) {
    if (!s_chapter_lead_height || !s_chapter_heading_title[0]) return;
    char heading[128]; copy_text(heading, sizeof(heading), s_chapter_heading_title);
    char label[sizeof(s_chapter_heading_label)]; copy_text(label, sizeof(label), s_chapter_heading_label);
    const int cx = body.x + body.width / 2;
    const int h = (int)s_chapter_lead_height;
    if (label[0])
        ui_text_title_vc(fb, cx, body.y + 20, 20, label, s_chapter_heading_label, EPD_DRAW_ALIGN_CENTER);
    const int px = ui_text_title_fit(heading, 34, body.width - 48, s_chapter_heading_title);
    ui_text_title_vc(fb, cx, body.y + h / 2 + 8, px, heading, s_chapter_heading_title, EPD_DRAW_ALIGN_CENTER);
    ui_hairline(fb, body.y + h - 10, cx - 132, 264, UI_GRAY_LIGHT);
}

// 阅读页顶部状态栏始终用设置里的系统字体；正文和页脚仍走书籍/阅读字体。
// The reading-page status bar always uses the configured system face; body and footer keep
// their book/reading face.
static void reader_status_bar_font(uint8_t *fb) {
    ui_text_set_face_slot(TTF_FONT_SLOT_SYSTEM);
    ui_text_set_system_font(true);
    ui_nav_status(fb);
    ui_text_set_face_slot(-1);
    ui_text_set_system_font(false);
}

// ---- 横屏 chrome 绘制 / Landscape chrome painting ----
static bool reader_status_visible(void);
// 横屏 chrome 带：先白底盖掉正文/插图，再（有阅读背景时）叠背景；随后由调用方画文字/图标。
// 无背景图时等价于清白；有背景图时保持与竖屏「状态栏区域重绘」相同的合成规则。
// Landscape chrome band: white-fill first to cover body/illustrations, then blend the reading
// background if any; the caller paints text/icons afterwards. Without a background this is just a
// clear; with one it matches the portrait status-band recomposition rule.
static void reader_landscape_band_clear(uint8_t *fb, EpdRect band) {
    if (!fb || band.width <= 0 || band.height <= 0) return;
    ui_fill_rect_fast(band, UI_GRAY_WHITE, fb);
    if (s_reader_panel != READER_PANEL_BACKGROUND_PREVIEW &&
        app_settings_book_background_path()[0])
        ui_reader_background_paint(fb, band, true);
}
// 横屏系统状态带（时钟/签名/WiFi/蓝牙/电量%）；ui_nav_status 已按画布宽方向化。
// Landscape system status band; ui_nav_status now derives its anchors from the canvas width.
static void draw_reader_status_landscape(uint8_t *fb) {
    reader_landscape_band_clear(fb, reader_landscape_status_rect());
    reader_status_bar_font(fb);
}
// 横屏阅读题头：返回（左）、书名（左对齐）、收藏（右），非全屏才画。
// Landscape reader header: back on the left, title left-aligned, favorite on the right; not in
// full screen.
static void draw_reader_header_landscape(uint8_t *fb) {
    const int w = reader_scr_w();
    reader_landscape_band_clear(fb, reader_landscape_header_rect());
    ui_nav_back(fb, 24, 38);                       // icon centre (46,73), feedback rect {14,41,64,64}
    char header[128];
    const char *sample = s_book_title[0] ? s_book_title : s_title;
    copy_text(header, sizeof(header), sample);
    // 标题右界 = 收藏命中区左界(1120) - 16；左起 92（返回图标右缘 70 再留 22）。
    // Title right bound = favorite hit left (1120) - 16; starts at x=92.
    int title_px = ui_text_title_fit(header, 30, w - 92 - 16 - 96, sample);
    ui_text_title_vc(fb, 92, READER_LANDSCAPE_STATUS_H + READER_LANDSCAPE_HEADER_H / 2,
                     title_px, header, sample, EPD_DRAW_ALIGN_LEFT);
    ui_draw_icon(fb, w - 64, READER_LANDSCAPE_STATUS_H + READER_LANDSCAPE_HEADER_H / 2, 44,
                 s_reader_favorite ? UI_ICON_ANIMATE_BOOKMARK_PLUS : UI_ICON_BOOKMARK, 0x38);
    ui_hairline(fb, READER_LANDSCAPE_STATUS_H + READER_LANDSCAPE_HEADER_H,
                36, w - 72, UI_GRAY_LIGHT);
}
// 横屏页脚：章节名（左）+ 页码/全书%（右）+ 6px 进度条；非全屏才画。
// Landscape footer: chapter name left, page/book percentage right, 6 px progress bar; not in full
// screen.
static void draw_reader_footer_landscape(uint8_t *fb, size_t page) {
    const EpdRect band = reader_landscape_footer_rect();
    const int bar_x = 36, bar_w = reader_scr_w() - 72;
    reader_landscape_band_clear(fb, band);
    ui_hairline(fb, band.y, 36, bar_w, UI_GRAY_LIGHT);
    // 进度条：6px，位于带底（band.y+38），上方放文字。
    // Progress bar: 6 px at the band bottom, text above it.
    EpdRect track = {bar_x, band.y + 38, bar_w, 6};
    ui_fill_round_rect(fb, track, 3, UI_GRAY_LIGHT);
    track.width = track.width * (int)percent(page) / 100;
    if (track.width) ui_fill_round_rect(fb, track, 3, UI_GRAY_BLACK);
    // 文字与竖屏同一套字符串/截断规则，字号 24→20 以适配 56px 带。
    // Same strings and trimming rules as portrait, 20 px type to fit the 56 px band.
    char chapter_name[72] = {0};
    reader_footer_chapter_name(chapter_name, sizeof(chapter_name));
    const int footer_px = 20;
    char progress[48];
    snprintf(progress, sizeof(progress), "%u/%u · 全书 %u%%",
             (unsigned)page + 1, (unsigned)book_layout_page_count(), percent(page));
    char chapter_line[192];
    snprintf(chapter_line, sizeof(chapter_line), "%s%s",
             s_save_failed ? "未保存 · " : "", chapter_name);
    fit_fixed_text(chapter_line, footer_px,
                   bar_w - ui_text_fixed_width_px(footer_px, progress) - 16);
    ui_text_fixed(fb, bar_x, band.y + 8, footer_px, chapter_line, EPD_DRAW_ALIGN_LEFT, false);
    ui_text_fixed(fb, bar_x + bar_w, band.y + 8, footer_px, progress, EPD_DRAW_ALIGN_RIGHT, false);
}
// 从划线列表跳转后底部出现的“返回前阅读位置”按钮。
// Bottom "back to previous reading position" button shown after a highlight jump.
static EpdRect reader_hl_return_rect(void) {
    const int w = reader_scr_w(), h = reader_scr_h();
    const int y = h - (s_reader_landscape ? 158 : 244);
    return (EpdRect){w / 2 - 132, y, 264, 64};
}
static void draw_hl_return_button(uint8_t *fb) {
    if (!s_hl_return_valid || s_reader_panel != READER_PANEL_NONE || s_toolbar ||
        s_clear_confirm || s_reader_cleanup) return;
    const EpdRect r = reader_hl_return_rect();
    ui_fill_round_rect(fb, r, 22, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, r, 22, 0x48);
    ui_text_fixed_vc(fb, r.x + r.width / 2, r.y + r.height / 2, 21,
                     "返回前阅读位置", EPD_DRAW_ALIGN_CENTER, false);
}

static void draw_reader_outer(uint8_t *fb,size_t page) {
    ui_text_set_system_scale(false);    if (s_reader_landscape) {
        // 横屏：正文/插图之后画三条 chrome 带；面板（除底部工具栏）打开时 chrome 让位。
        // Landscape: paint the three chrome bands after body/illustrations; a full-page sheet
        // (everything except the bottom toolbar) takes over and chrome is skipped.
        EpdRect body = body_rect();
        const bool chrome_visible = s_reader_panel == READER_PANEL_NONE ||
                                    s_reader_panel == READER_PANEL_TOOLS;
        const bool status_visible = chrome_visible && reader_status_visible();
        const bool header_visible = chrome_visible && !s_reader_fullscreen;
        ui_reader_background_paint(fb, (EpdRect){0, 0, reader_scr_w(), reader_scr_h()}, true);
        if (page == 0) {
            // 竖排题头优先于横屏紧凑横带：排版按竖排列宽预留，绘制必须同一口径。
            // The vertical heading wins over the landscape band: the layout reserved a column, so
            // drawing uses the same geometry.
            if (app_settings_book_vertical()) draw_vertical_heading(fb, body);
            else draw_landscape_heading(fb, body);
        }
        draw_reader_images(fb, page, body);
        if (s_reader_fullscreen) {
            // 全屏：保留原来的 3px 全屏进度线（位置/尺寸不变）。
            // Full screen keeps the original 3 px progress line, unchanged in place and size.
            EpdRect track = {36, reader_scr_h() - 9, reader_scr_w() - 72, 3};
            ui_fill_round_rect(fb, track, 1, 0x90);
            track.width = track.width * (int)percent(page) / 100;
            if (track.width) ui_fill_round_rect(fb, track, 1, UI_GRAY_BLACK);
        } else {
            draw_reader_footer_landscape(fb, page);
        }
        if (status_visible) draw_reader_status_landscape(fb);   // 必须在插图之后 / after illustrations
        if (header_visible) draw_reader_header_landscape(fb);   // 必须在插图之后 / after illustrations
        draw_hl_return_button(fb);
        draw_chapter_jump_undo(fb);
        draw_reader_panel(fb);
        return;
    }
    if (!(s_reader_fullscreen && app_settings_reader_immersive())) reader_status_bar_font(fb);
    if (!s_reader_fullscreen) draw_reader_header(fb);
    EpdRect body=body_rect();
    if (page == 0 && s_chapter_heading_title[0] &&
        (s_chapter_lead_height || s_chapter_lead_width)) {
        if (app_settings_book_vertical()) {
            // 竖排题头站在首页预留的那条列里，正文从它左边接着排。
            // The vertical heading stands in the columns the first page reserved; the body
            // continues to its left.
            draw_vertical_heading(fb, body);
        } else {
            char heading[128]; copy_text(heading, sizeof(heading), s_chapter_heading_title);
            int heading_px = ui_text_title_fit(heading, 48, ui_content_width(), s_chapter_heading_title);
            char label[sizeof(s_chapter_heading_label)]; copy_text(label, sizeof(label), s_chapter_heading_label);
            int label_px = ui_text_title_fit(label, 24, ui_content_width(), s_chapter_heading_label);
            ui_text_title_vc(fb, UI_LOCK_WIDTH / 2, body.y + 29, label_px, label,
                              s_chapter_heading_label, EPD_DRAW_ALIGN_CENTER);
            ui_text_title_vc(fb, UI_LOCK_WIDTH / 2, body.y + 112, heading_px, heading,
                              s_chapter_heading_title, EPD_DRAW_ALIGN_CENTER);
            ui_hairline(fb, body.y + 174, 210, 264, UI_GRAY_LIGHT);
        }
    }
    if (s_reader_panel != READER_PANEL_BACKGROUND_PREVIEW)
        ui_reader_background_paint(fb, (EpdRect){0,0,UI_LOCK_WIDTH,UI_LOCK_HEIGHT}, true);
    draw_reader_images(fb, page, body);
    if (s_reader_fullscreen) {
        // Full-book progress uses the last few screen rows and no footer text.
        EpdRect track = {36, READER_FULLSCREEN_PROGRESS_TOP + 3, UI_LOCK_WIDTH - 72, 3};
        ui_fill_round_rect(fb, track, 1, 0x90);
        track.width = track.width * (int)percent(page) / 100;
        if (track.width) ui_fill_round_rect(fb, track, 1, UI_GRAY_BLACK);
    } else {
        EpdRect track = progress_rect();
        EpdRect bar = {track.x, track.y + 16, track.width, 12};
        ui_fill_round_rect(fb, bar, 5, UI_GRAY_LIGHT);
        bar.width = bar.width * (int)percent(page) / 100;
        if (bar.width) ui_fill_round_rect(fb, bar, 5, UI_GRAY_BLACK);
        char chapter_name[72] = {0};
        reader_footer_chapter_name(chapter_name, sizeof(chapter_name));
        const int footer_px = 24;
        char progress[48];
        snprintf(progress, sizeof(progress), "%u/%u · 全书 %u%%",
                 (unsigned)page + 1, (unsigned)book_layout_page_count(), percent(page));
        char chapter_line[192];
        snprintf(chapter_line, sizeof(chapter_line), "%s%s",
                 s_save_failed ? "未保存 · " : "", chapter_name);
        fit_fixed_text(chapter_line, footer_px,
                       track.width - ui_text_fixed_width_px(footer_px, progress) - 16);
        // 页码和全书进度靠右固定，长章节名仅截短左侧；字号不跟随正文设置。
        // Keep page and book progress right-aligned; trim only long chapter titles and ignore body font settings.
        ui_text_fixed(fb, track.x, track.y + 35, footer_px, chapter_line, EPD_DRAW_ALIGN_LEFT, false);
        ui_text_fixed(fb, track.x + track.width, track.y + 35, footer_px,
                      progress, EPD_DRAW_ALIGN_RIGHT, false);
    }
    if (s_reader_notice[0]) {
        EpdRect notice = {218, 160, 248, 48};
        ui_fill_round_rect(fb, notice, 24, 0xd0);
        ui_text_vc(fb, 342, 184, 19, s_reader_notice, EPD_DRAW_ALIGN_CENTER, false);
    }
    draw_hl_return_button(fb);
    draw_chapter_jump_undo(fb);
    draw_reader_panel(fb);
}
// 当前页某张插图在屏幕上的矩形（与 draw_reader_images 的定位规则一致）。
// Screen rect of one illustration on the current page (same placement as draw_reader_images).
static bool reader_image_screen_rect(int slot, EpdRect *out) {
    if (!out || s_page_images_for != s_page ||
        s_page_images_generation != book_layout_generation() ||
        !s_page_images || slot < 0 || slot >= s_page_image_count) return false;
    const reader_image_t *image = &s_page_images[slot];
    if (!image->gray) return false;
    int y = 0, width = 0, height = 0;
    if (!reader_image_slot(s_page, slot, NULL, &y, &width, &height)) return false;
    EpdRect band = book_layout_image_rect();
    int left = band.x + (band.width - image->width) / 2;
    int top = band.y + y + (height - image->height) / 2;
    if (y == 0) top = s_reader_landscape ? body_rect().y : reader_area().y;
    *out = (EpdRect){left, top, image->width, image->height};
    return true;
}
// 推屏阻塞期间由触摸采样器捕获的阅读页轻点：只记方向，下一次 on_tick 再真正翻页。
// 方向必须和正常轻点用同一套分区（上下翻页的 y 三分区、竖排文字的左右反转），
// 否则“上下翻页”模式下刷新期间的点按会按左右半区判方向，出现点下部却翻上一页。
// Reader taps captured while the panel refresh blocked the loop: remember only the direction and
// let the next on_tick perform the turn. The direction must use the same zones as a normal tap
// (vertical mode's y thirds, vertical-text RTL mirroring); otherwise taps captured during a
// refresh are classified by left/right halves and can turn the wrong way.
void app_book_async_touch(int x, int y) {
    if (s_view != READING || !s_text || s_toolbar || s_clear_confirm ||
        s_reader_panel != READER_PANEL_NONE || s_hl_drag_active) return;
    int tx = x, ty = y;
    if (reader_touch_needs_map()) reader_touch_map(&tx, &ty);
    // 命中区必须和正常轻点完全一致（正文栏并上通栏插图带）：否则刷新期间点在页边距上
    // 会被当成翻页，而同样的点按在正常回调里是被忽略的。
    // The hit test must match a normal tap exactly (body column plus a full-bleed image band);
    // otherwise a tap in the margin turns a page here while the normal callback ignores it.
    EpdRect tap_area = body_rect();
    if (reader_image_slots(s_page)) tap_area = ui_rect_union(tap_area, book_layout_image_rect());
    const int direction = book_reader_tap_direction(
        tap_area, tx, ty, app_settings_reader_vertical_turn(), app_settings_book_vertical());
    if (direction) s_async_turn = direction;
}

static void draw_reader(uint8_t *fb,size_t page) {
    ui_text_set_system_scale(false);ui_clear_page(fb);
    book_layout_set_highlight_chapter((uint16_t)s_chapter);
    // 正文插图缩放模式：正文不画，插图区域只画那一张；退出缩放后再照常整页重画。
    // Inline zoom mode skips the body text and paints only that illustration; leaving zoom
    // repaints the whole page as usual.
    if (!(s_zoom_active && page == s_page && reader_zoom_mode()))
        book_layout_draw_page(fb,page,body_rect(),s_px);
    draw_reader_outer(fb,page);
}
// 预绘只在同步推屏期间借用字体；结束前逐行停止并交还，输入回调不等待整页预绘。
// Prefetch borrows fonts only during synchronous output; stop between rows before returning, never joining a whole page for input.
#define BOOK_PREP_RESERVE (1024u * 1024u)
// 第二块预渲染缓冲要求更高的 PSRAM 余量：它是“更流畅”的附加项，不能挤掉插图与书内字体。
// The second prefetch buffer demands more PSRAM headroom: it is an optional smoothness win and
// must never take room away from illustrations or embedded faces.
#define BOOK_PREP_RESERVE2 (1024u * 1024u)
#define BOOK_PREP_IDLE_US 6000
static int reader_prefetch_step(void) {
    if(!s_next_fb||s_prep_page<0)return -1;
    if(!s_prep_cursor.generation)memset(s_next_fb,0xff,fb_bytes());
    book_layout_set_highlight_chapter((uint16_t)s_chapter);
    int result=book_layout_draw_slice(s_next_fb,(size_t)s_prep_page,body_rect(),s_px,&s_prep_cursor);
    if(result<0)invalidate_prep();
    else if(result>0){s_next_page=s_prep_page;s_next_generation=book_layout_generation();}
    return result;
}
// 释放第二块预渲染缓冲：之后所有命中判断都以页号哨兵拒绝它。
// Release the second prefetch buffer; every hit test rejects it through the page sentinel.
static void release_second_fb(void) {
    free(s_next_fb2);
    s_next_fb2 = NULL;
    s_next_page2 = s_prep_page2 = -1;
    s_next_generation2 = 0;
    memset(&s_prep_cursor2, 0, sizeof(s_prep_cursor2));
}
static int reader_prefetch_step2(void) {
    if(!s_next_fb2||s_prep_page2<0)return -1;
    if(!s_prep_cursor2.generation)memset(s_next_fb2,0xff,fb_bytes());
    book_layout_set_highlight_chapter((uint16_t)s_chapter);
    int result=book_layout_draw_slice(s_next_fb2,(size_t)s_prep_page2,body_rect(),s_px,&s_prep_cursor2);
    if(result<0)release_second_fb();
    else if(result>0){s_next_page2=s_prep_page2;s_next_generation2=book_layout_generation();}
    return result;
}
static bool reader_prefetch_buffer(void) {
    size_t need=fb_bytes();
    if(!s_next_fb&&heap_caps_get_free_size(MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)>need+BOOK_PREP_RESERVE)
        s_next_fb=heap_caps_aligned_alloc(16,need,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    return s_next_fb!=NULL;
}
static bool reader_prefetch_buffer2(void) {
    size_t need=fb_bytes();
    if(!s_next_fb2&&heap_caps_get_free_size(MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)>need+BOOK_PREP_RESERVE2)
        s_next_fb2=heap_caps_aligned_alloc(16,need,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    return s_next_fb2!=NULL;
}
static void prep_task(void *arg) {
    (void)arg;
    for(;;){
        ulTaskNotifyTake(pdTRUE,portMAX_DELAY);
        lock_draw();
        while(!atomic_load_explicit(&s_prep_stop,memory_order_acquire)){
            if(reader_prefetch_step()!=0)break;
        }
        unlock_draw();
        xSemaphoreGive(s_prep_done);
    }
}
static bool kick_prep(void) {
    // 长按划线期间布局由主任务独占：预渲染任务读写同一套 s_line/s_idle_draw，不能再启动。
    // Highlight drag owns the layout state on the main task; never start the prefetcher meanwhile.
    if(s_hl_drag_active)return false;
    if(s_view!=READING||!s_text||s_toolbar||s_clear_confirm||s_reader_panel!=READER_PANEL_NONE)return false;
    const int dir = s_turn_dir < 0 ? -1 : 1;
    const int target = (int)s_page + dir;
    if(target<0||target>=(int)book_layout_page_count()||book_layout_page_image_count(s_page)||
       book_layout_page_image_count((size_t)target)||app_settings_book_background_path()[0])return false;
    // 第二块缓冲若已经排好这一页，直接换到主缓冲：连翻两次时第二页不必再整页重排。
    // Promote the secondary buffer when it already holds this target: the second rapid turn then
    // needs no full-page relayout at all.
    if(s_next_fb2&&s_next_page2==target&&s_next_generation2==book_layout_generation()&&!s_prep_running){
        uint8_t *fb_swap=s_next_fb; s_next_fb=s_next_fb2; s_next_fb2=fb_swap;
        s_next_page=s_next_page2; s_next_generation=s_next_generation2;
        s_next_page2=-1; s_next_generation2=0;
        s_prep_page=-1; memset(&s_prep_cursor,0,sizeof(s_prep_cursor));
        s_prep_page2=-1; memset(&s_prep_cursor2,0,sizeof(s_prep_cursor2));
    }
    if(s_next_page==target&&s_next_generation==book_layout_generation())return false;
    if(s_prep_page!=target||s_prep_cursor.generation!=book_layout_generation()){
        s_next_page=-1;s_next_generation=0;s_prep_page=target;memset(&s_prep_cursor,0,sizeof(s_prep_cursor));
    }
    if(!reader_prefetch_buffer())return false;
    if(!s_draw_lock)s_draw_lock=xSemaphoreCreateMutex();
    if(!s_prep_done)s_prep_done=xSemaphoreCreateBinary();
    if(!s_prep_task&&s_draw_lock&&s_prep_done&&
       xTaskCreatePinnedToCore(prep_task,"book_prep",12*1024,NULL,3,&s_prep_task,1)!=pdPASS)s_prep_task=NULL;
    if(!s_prep_task)return false;
    xSemaphoreTake(s_prep_done,0);
    atomic_store_explicit(&s_prep_stop,false,memory_order_release);
    s_prep_running=true;
    xTaskNotifyGive(s_prep_task);
    return true;
}
static void reader_prefetch_end(bool started) {
    if(!started)return;
    atomic_store_explicit(&s_prep_stop,true,memory_order_release);
    // 最多交还当前一行，之后主循环才可改字体、章节或离页，避免竞态。
    // Hand back at the current row boundary before the loop may change fonts, chapters or pages.
    xSemaphoreTake(s_prep_done,portMAX_DELAY);
    s_prep_running=false;
}
// 长按划线前先停预渲染并 join：两者共用布局的行走状态，并发会让取行失败。
// Stop and join the prefetcher before a highlight drag: both use the layout's line cursor, and
// running them concurrently made line lookups fail while the finger was moving.
static void reader_prefetch_stop(void) {
    invalidate_prep();
    if(!s_prep_running||!s_prep_done)return;
    atomic_store_explicit(&s_prep_stop,true,memory_order_release);
    xSemaphoreTake(s_prep_done,portMAX_DELAY);
    s_prep_running=false;
}
static bool reader_prefetch_resume(size_t page) {
    if(!s_next_fb||s_prep_page!=(int)page||!s_prep_cursor.started||
       s_prep_cursor.generation!=book_layout_generation())return false;
    // 连按到尚未完成的目标时接着画，保留已画文字，不清空重画整页。
    // A rapid turn completes the remaining rows of its target, retaining work already drawn.
    while(reader_prefetch_step()==0){}
    return s_next_page==(int)page&&s_next_generation==book_layout_generation();
}
static void reader_prefetch_idle_primary(app_ctx_t *ctx) {
    if(s_hl_drag_active)return;
    if(s_view!=READING||!s_text||s_toolbar||s_clear_confirm||s_reader_panel!=READER_PANEL_NONE||
       ctx->consumed||ctx->request_app||ctx->request_menu||ctx->request_return||
       (ctx->touch&&ctx->touch->touched))return;
    const int dir = s_turn_dir < 0 ? -1 : 1;
    const int target = (int)s_page + dir;
    if(target<0||target>=(int)book_layout_page_count()||s_prep_page!=target)return;
    if(app_settings_book_background_path()[0]||book_layout_page_image_count(s_page)||
       book_layout_page_image_count((size_t)target))return;
    if(s_next_page==s_prep_page&&s_next_generation==book_layout_generation())return;
    if(!reader_prefetch_buffer())return;
    const int64_t deadline=esp_timer_get_time()+BOOK_PREP_IDLE_US;
    for(unsigned row=0;row<8;++row){
        if(reader_prefetch_step()!=0||esp_timer_get_time()>=deadline)break;
    }
}
// 主缓冲就绪后，空闲时把再下一页（同方向）排进第二块缓冲。整页重排一次只给几行预算，
// 主循环始终能先响应输入；内存不够就保持单页预取，功能自然降级。
// After the primary buffer is ready, lay the page after next (same direction) into the second
// buffer while idle. A few rows per turn keep input responsive; without PSRAM headroom the reader
// simply keeps its single-page prefetch.
static void reader_prefetch_idle_second(app_ctx_t *ctx) {
    if(s_hl_drag_active||s_prep_running)return;
    if(s_view!=READING||!s_text||s_toolbar||s_clear_confirm||s_reader_panel!=READER_PANEL_NONE||
       ctx->consumed||ctx->request_app||ctx->request_menu||ctx->request_return||
       (ctx->touch&&ctx->touch->touched))return;
    if(app_settings_book_background_path()[0])return;
    const uint32_t generation = book_layout_generation();
    const int dir = s_turn_dir < 0 ? -1 : 1;
    const int primary = (int)s_page + dir;
    if(primary<0||primary>=(int)book_layout_page_count())return;
    if(s_next_page!=primary||s_next_generation!=generation)return;
    if(book_layout_page_image_count(s_page)||book_layout_page_image_count((size_t)primary))return;
    const int target = (int)s_page + 2 * dir;
    if(target<0||target>=(int)book_layout_page_count())return;
    if(book_layout_page_image_count((size_t)target))return;
    if(s_next_fb2&&s_next_page2==target&&s_next_generation2==generation)return;
    if(s_prep_page2!=target||s_prep_cursor2.generation!=generation){
        s_next_page2=-1;s_next_generation2=0;s_prep_page2=target;memset(&s_prep_cursor2,0,sizeof(s_prep_cursor2));
    }
    if(!reader_prefetch_buffer2())return;
    const int64_t deadline=esp_timer_get_time()+BOOK_PREP_IDLE_US;
    for(unsigned row=0;row<8;++row){
        if(reader_prefetch_step2()!=0||esp_timer_get_time()>=deadline)break;
    }
}
static void reader_prefetch_idle(app_ctx_t *ctx) {
    reader_prefetch_idle_primary(ctx);
    reader_prefetch_idle_second(ctx);
}
static size_t current_toc_position(void) {
    size_t count = book_navigation_count();
    if (s_selected_toc < count && book_navigation_chapter(s_selected_toc) == s_chapter)
        return s_selected_toc;
    size_t selected = SIZE_MAX;
    size_t best_chapter = 0;
    for (size_t i = 0; i < count; ++i) {
        size_t chapter = book_navigation_chapter(i);
        if (chapter > s_chapter) break;
        if (selected == SIZE_MAX || chapter > best_chapter) { selected = i; best_chapter = chapter; }
    }
    return selected;
}
static void render(app_ctx_t* ctx, uint8_t* fb) {
    lock_draw();
    ui_text_set_system_scale(s_view != READING);
    if (s_view == EDIT) { draw_editor(fb); unlock_draw(); return; }
    if (s_view == SEARCH) { draw_search(fb); unlock_draw(); return; }
    if (s_view == IMPORT) { draw_import(fb); unlock_draw(); return; }
    if (s_view == BULK) { draw_bulk(fb, ctx->leaf); unlock_draw(); return; }
    if (s_view == MANAGE) {
        ui_clear_page(fb);
        ui_nav_status(fb);
        ui_nav_back(fb, 36, 79);
        ui_text_vc(fb, 342, 107, 34, "图书详情", EPD_DRAW_ALIGN_CENTER, false);
        ui_hairline(fb, 176, 36, 612, 0x70);
        draw_manage(fb);
        unlock_draw();
        return;
    }
    if (s_view == TOC) {
        book_toc_render(fb, s_book_title[0] ? s_book_title : s_title,
                        book_navigation_count(), current_toc_position(), ctx->leaf, s_message);
        if (s_toc_jump_open)
            book_toc_render_jump(fb, book_navigation_count(), s_toc_jump_percent);
        unlock_draw();
        return;
    }
    if (s_view == READING && s_text) {
        if (s_reader_panel == READER_PANEL_FONT_RECOVERY) {
            ui_clear_page(fb);
            draw_font_recovery(fb);
            unlock_draw();
            return;
        }
        draw_reader(fb, s_page);
        unlock_draw();
        return;
    }
    ui_clear_page(fb);
    // 留白保持纯白，灰阶只由封面和书架材质生成，避免整块背景被当成灰色驱动。
    // Keep whitespace white; only covers and shelf materials create grays, avoiding gray drive over the whole background.
    ui_fill_rect_fast((EpdRect){0,0,UI_LOCK_WIDTH,UI_NAV_TOP},UI_GRAY_WHITE,fb);
    // 题头和分页使用白底，避免整块灰底在进入书架时产生不必要的深色过渡。
    // Keep title and pagination white so entering the shelf does not drive an unnecessary gray-background transition.
    ui_fill_rect_fast((EpdRect){0,0,UI_LOCK_WIDTH,192},UI_GRAY_WHITE,fb);
    ui_fill_rect_fast((EpdRect){0,992,UI_LOCK_WIDTH,UI_NAV_TOP-992},UI_GRAY_WHITE,fb);
    ui_nav_status(fb);
    char category_title[BOOK_STORE_PATH_MAX];
    copy_text(category_title,sizeof(category_title),s_category_selected ? shelf_category_name(s_category_selected) : "书架");
    fit_text(category_title,52,258);
    ui_text(fb, 36, 90, 52, category_title, EPD_DRAW_ALIGN_LEFT, false);
    int title_width=ui_text_fixed_width_px(ui_text_effective_px(52),category_title);
    ui_draw_icon(fb,36+title_width+27,120,26,
                 s_category_menu ? UI_ICON_CHEVRON_UP : UI_ICON_CHEVRON_DOWN,UI_GRAY_BLACK);
    draw_shelf_header_button(fb, shelf_search_rect(), 2);
    draw_shelf_header_button(fb, shelf_manage_rect(), 0);
    draw_shelf_header_button(fb, shelf_import_rect(), 1);
    if (s_message[0] || s_shelf_warning[0])
        ui_text(fb, UI_MARGIN, 991, 17, s_message[0] ? s_message : s_shelf_warning,
                EPD_DRAW_ALIGN_LEFT, false);
    if (app_settings_shelf_style() == 5) {
        ui_fill_round_rect(fb, (EpdRect){36,184,612,788}, 20, UI_GRAY_WHITE);
        ui_draw_control_frame(fb, (EpdRect){36,184,612,788}, 20, 0x50);
    }
    for (int row = 0; row < shelf_rows(); ++row) {
        int i = ctx->leaf * shelf_rows() + row;
        if (i >= s_visible_count) break;
        EpdRect r = row_rect(row);
        char name[128]; copy_text(name, sizeof(name), s_shelf[i].name);
        // 封面抽出只改变书本位置，层板及触摸目标保持原位。
        // Lifting changes the book position only; shelf furniture and touch targets stay put.
        if (s_pressed_control == row)
            r.y -= app_settings_shelf_style() == 5 ? SHELF_LIST_BOUNCE_PX : SHELF_BOOK_LIFT_PX;
        draw_shelf_cover(fb, r, row, name, s_shelf[i].favorite);
        if (app_settings_shelf_style() == 5) draw_list_row(fb, row, &s_shelf[i]);
    }
    draw_shelf_furniture(fb);
    if(app_settings_main_refresh_mode()==APP_MAIN_REFRESH_NORMAL){
        // 32列对齐后的封面/书架区；顶部状态栏、题头和下方分页不做黑色强整理。
        // Aligned cover/furniture area; status, title and lower pagination never enter the dark settling pass.
        const EpdRect artwork={0,192,UI_LOCK_WIDTH,800};
        display_main_transition_gray_bands(&artwork,1);
    }
    draw_shelf_pager(fb, s_visible_count, ctx->leaf, leaves());
    ui_nav_draw(fb, 1);
    if (s_category_menu) draw_category_menu(fb);
    unlock_draw();
}
static EpdRect reader_status_area(void) {
    if (s_reader_landscape) return reader_landscape_status_rect();
    return (EpdRect){0,0,UI_LOCK_WIDTH,80};
}
static bool reader_status_visible(void) {
    if (!(s_view==READING && s_text && !(s_reader_fullscreen && app_settings_reader_immersive())))
        return false;
    // 横屏的全屏阅读面板是整屏白底：此时不能只重绘状态带，否则会盖在面板标题上。
    // 底部工具栏 (TOOLS) 不盖顶部，状态带的分钟/电量局刷仍允许。
    // A landscape full-page sheet is white and would be overdrawn by a status-only update; the
    // bottom toolbar does not cover the top, so the minute/power band refresh stays allowed.
    if (s_reader_landscape)
        return s_reader_panel == READER_PANEL_NONE || s_reader_panel == READER_PANEL_TOOLS;
    return true;
}
static void reader_status_paint(uint8_t *fb) {
    EpdRect area=reader_status_area();
    // 防御：越界矩形在横屏下会静默不刷，但画布外的部分不应参与任何合成。
    // Guard: out-of-canvas rects refresh nothing, and they must not enter compositing either.
    if (area.x < 0 || area.y < 0 || area.width <= 0 || area.height <= 0 ||
        area.x + area.width > reader_scr_w() || area.y + area.height > reader_scr_h()) return;
    if (!s_reader_landscape) {
        // 竖屏原路径逐行保留 / Portrait path kept line for line.
        ui_fill_rect_fast(area,UI_GRAY_WHITE,fb);
        reader_status_bar_font(fb);
        if (s_reader_panel!=READER_PANEL_BACKGROUND_PREVIEW && app_settings_book_background_path()[0])
            ui_reader_background_paint(fb,area,true);
        return;
    }
    // 横屏：先清带/叠背景再画状态栏，与 draw_reader_outer 的 chrome 顺序一致。
    // Landscape: clear the band, blend the background, then paint the status bar, matching the
    // order used by draw_reader_outer.
    reader_landscape_band_clear(fb, area);
    reader_status_bar_font(fb);
}
static app_redraw_t reader_clock_tick(app_ctx_t *ctx) {
    if (!reader_status_visible() || (ctx->touch && ctx->touch->touched)) return APP_REDRAW_NONE;
    if (ui_nav_clock_minute()==s_reader_clock_minute) return APP_REDRAW_NONE;
    s_reader_clock_painted_minute=ui_nav_clock_minute();
    lock_draw(); reader_status_paint(ctx->fb); unlock_draw();
    s_reader_clock_pending=true;
    return APP_REDRAW_AREA;
}
// ---- adaptive reading direction: gravity decision and rotation switch ----
// The reference vector tracks gravity while portrait, which cancels the accelerometer's
// mounting error, so no absolute axis convention has to be hard-coded here.
static void reader_orient_apply(int mode) {
    // 换向会换掉整个画布与插图带；缩放现场直接作废（横屏本来也不启用）。
    // A rotation replaces the whole canvas and illustration band; the zoom context is void
    // (landscape never enabled it in this release anyway).
    reader_zoom_reset();
    epd_set_rotation((enum EpdRotation)mode);
    s_reader_rot = mode;
    s_reader_landscape = reader_landscape_rot(mode);
    invalidate_prep();
    s_reader_tap.pending = false;
    s_reader_text_frame = false;
}
// A rotation change repaints the whole frame: the buffer was drawn for the old orientation.
static bool reader_orient_sync(app_ctx_t *ctx) {
    // 目录页跟随当前方向：横屏与 180° 倒置竖屏都保持，避免进目录的一瞬间屏幕翻转。
    // The directory follows the current direction (landscape or 180-degree portrait) so entering
    // it never flips the screen.
    const bool toc_follow = s_view == TOC && app_settings_reader_adaptive();
    const int want = (reader_orient_body() || toc_follow)
        ? s_orient_desired : EPD_ROT_INVERTED_PORTRAIT;
    if (want == (int)epd_get_rotation()) {
        s_reader_rot = want;
        s_reader_landscape = reader_landscape_rot(want);
        return false;
    }
    // 优先复用旋转锚点：同一页未经翻页时来回旋转，回到原方向必须回到原来那一页。
    // Prefer the rotation anchor: toggling orientation without turning a page must return to the
    // same page, not drift by one page per switch.
    const size_t off = (s_orient_anchor_off != SIZE_MAX && s_orient_anchor_page == s_page)
        ? s_orient_anchor_off
        : ((s_text && s_blocks) ? book_layout_page_start_offset(s_page) : 0);
    lock_draw();
    reader_orient_apply(want);
    // 横竖屏都要重新问题头几何：横屏用紧凑横带并跳过正文里的标题字节，否则正文会
    // 再排一行章名，与横带上的章名重复。竖屏按原竖屏规则重留。
    // Recompute heading geometry for both orientations: landscape reserves the compact band and
    // skips the heading bytes, otherwise the body lays the heading out again (duplicate line).
    refresh_chapter_lead();
    bool ok = s_text && book_layout_build_blocks(s_text, s_text_len, s_blocks,
                                                 s_block_count, body_rect(), s_px);
    if (ok) s_page = book_layout_page_for_offset(off);
    if (ok && s_text && s_blocks) {
        s_orient_anchor_off = off;
        s_orient_anchor_page = s_page;
    } else {
        s_orient_anchor_off = SIZE_MAX;
        s_orient_anchor_page = SIZE_MAX;
    }
    unlock_draw();
    // 旋转换了正文宽：Markdown 表格要按新宽度重新解析，同一旋转只做一次；旋转锚点跟着
    // 重载后的实际页码更新，来回旋转才能回到原来那一页。TXT/EPUB 不进这里。
    // A rotation changes the body width, so Markdown tables must be re-parsed once per rotation;
    // the anchor follows the real page after the reload so toggling returns to the same page.
    if (ok && s_text && book_kind() == BOOK_KIND_MARKDOWN && s_md_tables_rot != s_reader_rot &&
        reader_md_reload_at(ctx, off)) {
        s_orient_anchor_off = off;
        s_orient_anchor_page = s_page;
    }
    return true;
}
static app_redraw_t reader_orient_tick(app_ctx_t* ctx) {
    if (!app_settings_reader_adaptive())
        return reader_orient_sync(ctx) ? APP_REDRAW_FULL : APP_REDRAW_NONE;
    // Calibrate only on an explicit tap: at that moment the visible page is portrait and the
    // user is looking at it, so the gravity reading is a trustworthy portrait reference.
    if (s_orient_calibrate) {
        s_orient_calibrate = false;
        if (!sc7a20h_powered(ctx->acc)) (void)sc7a20h_power_up(ctx->acc);
        sc7a20h_sample_t cal;
        if (read_pico_accel_read(ctx->acc, &cal) == ESP_OK) {
            const int cx = (int)cal.x_mg - READ_PICO_ACCEL_ZERO_X_MG;
            const int cy = (int)cal.y_mg - READ_PICO_ACCEL_ZERO_Y_MG;
            if (cx * cx + cy * cy >= 90000) {
                s_orient_ref_x = cx;
                s_orient_ref_y = cy;
                s_orient_ref_ready = true;
                s_orient_desired = EPD_ROT_INVERTED_PORTRAIT;
                s_orient_seen_n = 0;
            }
        }
    }
    if (!reader_orient_body()) {
        bool changed = reader_orient_sync(ctx);
        return changed ? APP_REDRAW_FULL : APP_REDRAW_NONE;
    }
    if (!ctx->sensor_ready || !ctx->acc) return APP_REDRAW_NONE;
    if (ctx->now_ms < s_orient_next_ms) return APP_REDRAW_NONE;
    s_orient_next_ms = ctx->now_ms + 350;
    if (!sc7a20h_powered(ctx->acc)) (void)sc7a20h_power_up(ctx->acc);
    sc7a20h_sample_t sample;
    if (read_pico_accel_read(ctx->acc, &sample) != ESP_OK) return APP_REDRAW_NONE;
    const int gx = (int)sample.x_mg - READ_PICO_ACCEL_ZERO_X_MG;
    const int gy = (int)sample.y_mg - READ_PICO_ACCEL_ZERO_Y_MG;
    // Laid flat the in-plane gravity is too small to resolve an orientation; keep the current one.
    if (gx * gx + gy * gy < 90000) { s_orient_seen_n = 0; return APP_REDRAW_NONE; }
    if (!s_orient_ref_ready) {
        // Without a reference the page stays portrait until a tap calibrates it.
        return reader_orient_sync(ctx) ? APP_REDRAW_FULL : APP_REDRAW_NONE;
    }
    const int p = gx * s_orient_ref_x + gy * s_orient_ref_y;
    const int q = s_orient_ref_x * gy - s_orient_ref_y * gx;
    const int ap = p < 0 ? -p : p, aq = q < 0 ? -q : q;
    const int idx = ap > aq ? (p > 0 ? 0 : 1) : (q > 0 ? 2 : 3);
    if (idx == 0) {
        s_orient_ref_x += (gx - s_orient_ref_x) / 8;
        s_orient_ref_y += (gy - s_orient_ref_y) / 8;
    }
    // Landscape pair swapped after on-device check: the two landscape rotations were
    // the other way round, which left the text upside down in both hold directions.
    const int want = idx == 0 ? EPD_ROT_INVERTED_PORTRAIT
                   : idx == 1 ? EPD_ROT_PORTRAIT
                   : idx == 2 ? EPD_ROT_INVERTED_LANDSCAPE : EPD_ROT_LANDSCAPE;
    if (want != s_orient_desired) {
        if (idx != s_orient_seen_idx) { s_orient_seen_idx = idx; s_orient_seen_n = 0; }
        if (++s_orient_seen_n < 3) return APP_REDRAW_NONE;
        s_orient_seen_n = 0;
        s_orient_desired = want;
    }
    return reader_orient_sync(ctx) ? APP_REDRAW_FULL : APP_REDRAW_NONE;
}

/* ---- 翻页定向补白掩码 / Per-turn targeted white-settle mask ---- */
static bool present(app_ctx_t* ctx, app_redraw_t redraw) {
    if (reader_orient_sync(ctx)) redraw = APP_REDRAW_FULL;
    // 缩放状态只属于「阅读页 + 无面板 + 竖屏」现场：切面板、离页、清屏确认或换到横屏时
    // 先收尾并释放 1bpp 帧；局部刷新擦不掉放大画面，顺手升为整页重画。
    // Zoom state belongs to the bare portrait reader: settle and release it before presenting any
    // other surface (panel, leave, clear-confirm, landscape); a local refresh cannot erase the
    // zoom view, so upgrade it to a whole-page repaint.
    if ((s_zoom_active || s_image_zoom_bw || s_image_zoom > READER_IMAGE_ZOOM_MIN) &&
        (s_view != READING || !s_text || s_reader_panel != READER_PANEL_NONE ||
         s_clear_confirm || s_reader_landscape)) {
        reader_zoom_reset();
        if (redraw == APP_REDRAW_AREA) redraw = APP_REDRAW_PAGE;
    }
    if(reader_indent_present(ctx,redraw))return true;
    if(s_shelf_key_paint_pending && redraw==APP_REDRAW_AREA && s_view==SHELF && !ctx->request_app){
        s_shelf_key_paint_pending=false;
        guard_draw_result(ctx->hl,update_display_area_diff_with(ctx->hl,&E0470_FOLLOW_WAVEFORM,MODE_DU,s_area));
        return true;
    }
    if (s_reader_clock_pending) {
        s_reader_clock_pending=false;
        if (redraw==APP_REDRAW_AREA && reader_status_visible()) {
            // 时钟单独短刷：竖屏刷 {0,0,684,80}，横屏刷 {0,0,1216,48}；
            // 不再落回下面的整幅 AREA 分支（横屏原来的整屏 GL16 就是从这里漏出去的）。
            // Update the status band alone: portrait {0,0,684,80}, landscape {0,0,1216,48}; it no
            // longer falls through to the full-canvas AREA branch that made landscape flash.
            enum EpdDrawError err=update_display_area_diff_with(ctx->hl,&E0470_WAVEFORM,MODE_GL16,reader_status_area());
            if (err==EPD_DRAW_SUCCESS) s_reader_clock_minute=s_reader_clock_painted_minute;
            guard_draw_result(ctx->hl,err);
            return true;
        }
    }
    // 输入不准备封面或正文；候选停顿只整理词栏，不累计整页清屏次数。
    // Input skips cover/body preparation; idle candidate settling affects only its strip and not whole-page cleanup counting.
    if (redraw == APP_REDRAW_AREA && (s_view == EDIT || s_view == SEARCH)) {
        if (s_input_settle) {
            guard_draw_result(ctx->hl, update_display_area_full_with(ctx->hl, &E0470_WAVEFORM, MODE_GL16, s_area));
            s_input_settle = false;
            s_du_count = 0;
            return true;
        }
        guard_draw_result(ctx->hl, update_display_area_diff_with(ctx->hl,
            s_mode == MODE_DU ? &E0470_FOLLOW_WAVEFORM : &E0470_WAVEFORM, s_mode, s_area));
        s_du_count = 0;
        return true;
    }
    if (redraw == APP_REDRAW_NONE || redraw == APP_REDRAW_DONE || ctx->request_app) return true;
    // 首次扫描尚未完成时不交空书架帧：保留上一屏，扫描完成后由 on_tick 一次画全，
    // 少掉“先闪一屏空书架、再补一次”的整页刷新。
    // Never present an empty shelf before the first scan finishes: keep the previous screen and
    // paint once after the scan, removing the empty-frame flash and the follow-up refresh.
    if (s_view == SHELF && s_scan_pending && s_count == 0 && s_visible_count == 0) return true;
    if (s_presented_view != (int)s_view && redraw == APP_REDRAW_AREA) redraw = APP_REDRAW_PAGE;
    if ((s_view == SHELF || s_view == MANAGE) &&
        !(redraw == APP_REDRAW_AREA && (s_shelf_feedback_pending || s_cover_batch_present_pending))) {
        prepare_covers(ctx);
        gather_cover_entry(ctx);
    }
    if (ctx->request_app) return true;
    if (s_view == READING && s_text) {
        if (s_reader_panel != READER_PANEL_BACKGROUND_PREVIEW)
            (void)ui_reader_background_prepare(app_settings_book_background_path());
        prepare_inline_image();
    }
    int64_t start = esp_timer_get_time();
    const int64_t frame_minute=ui_nav_clock_minute();
    if (redraw == APP_REDRAW_PAGE || redraw == APP_REDRAW_FULL) render(ctx, ctx->fb);
    bool prep = kick_prep();
    int64_t drawn = esp_timer_get_time();
    // 本地细点阵挡板已是黑白目标，不注册灰区，省去暂存和第二轮GL16。
    // Local fine-dot guards are already BW targets; omit gray bands to skip staging and the second GL16 pass.
    if (s_view == SHELF && s_shelf_page_pending) display_main_transition_shelf_page();
    s_shelf_page_pending = false;
    enum EpdDrawError err;
    // 白天纯文字翻页的定向补白掩码是否已在推屏前抓取成功（只有翻页 AREA 分支会置位）。
    // Whether the targeted-settle ink mask was captured before the push (only the turn AREA branch sets it).
    bool image_gray_refresh = s_reader_image_refresh_pending && s_view == READING &&
        s_reader_panel == READER_PANEL_NONE && !s_toolbar && !s_clear_confirm;
    const bool reader_entry=s_view==READING&&s_text&&s_presented_view!=(int)READING;
    // 入书和从目录返回正文时先用目标页一次完整清理，覆盖图片/背景，不追加擦白或补刷。
    // Clean reader entry and TOC returns in one complete target-page output, including images/backgrounds, without white prepasses or replay.
    if(reader_entry)
        err=update_display_area_full_with(ctx->hl,&E0470_FULL_WAVEFORM,MODE_GC16,
                                         reader_full_rect());
    else
    if (image_gray_refresh && redraw == APP_REDRAW_AREA && !s_reader_cleanup && s_presented_view == (int)READING) {
        // 灰阶只驱动正文，避免每张插图都把整屏先清白再闪回。
        // Drive the grayscale body from the current frame instead of clearing the whole screen to white.
        err = app_settings_reader_turn_effect() >= 2
            ? update_display_area_diff_with(ctx->hl, &E0470_WAVEFORM, MODE_GL16, reader_area())
            : update_display_area_with(ctx->hl, &E0470_FULL_WAVEFORM, MODE_GC16, reader_area());
        if (err == EPD_DRAW_SUCCESS && s_reader_footer_pending)
            err = update_display_area_diff_with(ctx->hl, &E0470_WAVEFORM, MODE_GL16, progress_rect());
        if (err == EPD_DRAW_SUCCESS && s_reader_fullscreen)
            err = update_display_area_diff_with(ctx->hl, &E0470_WAVEFORM, MODE_GL16,
                                                reader_fullscreen_progress_area());
    }
    else if (image_gray_refresh) err = app_settings_reader_turn_effect() >= 2 &&
        redraw != APP_REDRAW_FULL && !s_reader_cleanup
        ? update_display_mode_diff(ctx->hl, MODE_GL16)
        : update_display_with(ctx->hl, &E0470_FULL_WAVEFORM, MODE_GC16);
    else if (s_reader_cleanup && redraw != APP_REDRAW_FULL)
        // 周期清理使用完整原厂灰阶定稿，保留饱和驱动；一次输出，不叠加擦白或文字补刷。
        // Periodic cleanup retains the complete vendor settling/saturation phases in one output, without erase or text replay.
        err = update_display_area_full_with(ctx->hl, &E0470_FULL_WAVEFORM, MODE_GC16,
                                            reader_full_rect());
    else if (redraw == APP_REDRAW_FULL) err = update_display_full(ctx->hl);
    else if (redraw == APP_REDRAW_AREA && s_view == SHELF && s_shelf_feedback_pending) {
        // 抽出与复位只驱动发生变化的像素，避免整张封面被反复压黑。
        // Lift and restore only changed pixels, avoiding a dark pulse over the whole cover.
        err = update_display_area_diff_with(ctx->hl,
            s_mode == MODE_DU ? &E0470_FOLLOW_WAVEFORM : &E0470_WAVEFORM, s_mode, s_area);
    }
    else if (redraw == APP_REDRAW_AREA) {
        // 快档每次显式设置并在推屏后恢复，不能把阅读节拍带入主页水波纹。
        // Explicitly select fast pacing per turn and restore afterward, without leaking reader timing into main-page ripple.
        // 水波纹·快刷用 rc100 的快速节拍 + reader 文字灰阶波形；水波纹·高清按用户要求改用
        // 标定脉宽：普通·高清同一张 GL16 表 + FULL 扫描（11090us/帧）、条带加密（8→最多32），
        // 动画约 68 拍/12ms——用更长动画换更准的抗锯齿中灰（字体边缘更细）。
        // Fast water keeps rc100's fast pacing and reader text waveform; HD water trades time for
        // better antialiasing as requested: the ordinary-HD GL16 table on the calibrated FULL scan
        // (11090 us/frame), denser bands (8 -> up to 32) and ~68 ticks at 12 ms, so the antialiased
        // mid-grays are driven at calibrated pulse widths and glyph edges look finer.
        const bool fast_water = s_water_turn_pending && app_settings_reader_turn_effect() == 2;
        const int prior_tick = fast_water ? e0470_page_turn_tick_us() : 0;
        if (fast_water)
            e0470_page_turn_set_tick_us(E0470_TURN_FAST_TICK_US);
        // 翻页动画与页脚刷新独立：全屏没有页脚，仍使用用户选择的水波纹。
        // The turn effect is independent of the footer: full-screen turns still use the selected water effect.
        EpdRect turn_area=s_area;
        // 普通翻页（差分 GL16）把正文与进度并成一次输出；图片、水波纹和清屏保留独立规则。
        // Ordinary turns (differential GL16) present body/progress in one output; images, ripple
        // and cleanup keep their own paths.
        const bool fused_footer=s_reader_turn_pending&&!s_water_turn_pending&&s_mode==MODE_GL16;
        if(fused_footer) {
            EpdRect footer=s_reader_fullscreen?reader_fullscreen_progress_area():progress_rect();
            turn_area=ui_rect_union(turn_area,footer);
        }
        // 普通·快刷 = rc100 的「速读黑白」（见下方独立分支）：纯文字页把目标正文阈值成纯黑白，
        // 用原厂完整 DU（20 相）一次推屏，翻页更快；只在没有任何插图的纯文字页启用。
        // Plain fast is rc100 Fast BW (its own branch below): pure-text pages threshold the target
        // body to pure BW and push once with the vendor 20-phase DU, which turns faster.
        // 白天清残影按 rc100：普通翻页只走校准灰阶的差分 GL16（只驱动变化像素，翻页自身完成擦除），
        // 不再叠加整幅非差分 GL16；水波纹只做 rc100 的单次揭页扫描，不再追加整幅 GL16 定稿。
        // Day ghost handling follows rc100: ordinary turns use only the calibrated differential
        // GL16 (changed pixels only, the turn itself erases), with no full-area non-differential
        // pass; ripple is rc100's single peel scan without a follow-up full-area GL16.
        err = s_water_turn_pending
            ? (app_settings_reader_turn_effect() >= 3
                ? update_display_water_turn_hd(ctx->hl, s_area, s_water_turn_dir)
                : update_display_water_turn(ctx->hl, s_area, s_water_turn_dir))
            // 普通·快刷改用 rc100 的「速读黑白」：纯文字页把目标正文+页脚阈值成纯黑白，
            // 再用原厂完整 DU 一次推屏（rc100 里这是普通翻页的变体，也是最接近的移植目标）。
            // Plain fast now uses rc100 Fast BW: on pure-text pages the target body+footer is
            // thresholded to black/white and pushed once with the vendor DU.
            : s_reader_turn_pending && s_mode == MODE_GL16 && app_settings_reader_turn_effect() == 0 &&
              s_view == READING && s_presented_view == (int)READING &&
              s_reader_panel == READER_PANEL_NONE && !s_toolbar && !s_clear_confirm &&
              book_layout_page_image_count(s_page) == 0 && !app_settings_book_background_path()[0]
                ? update_display_text_turn(ctx->hl, turn_area, E0470_TURN_RTL)
            // 普通翻页与全屏阅读按 rc100 只驱动变化像素（差分 GL16），设置面板等局部绘制保留原路径。
            // Ordinary turns and full-screen reading drive changed pixels only (differential
            // GL16); other local UI keeps its path.
            : (s_reader_fullscreen || s_reader_turn_pending) && s_mode == MODE_GL16
                ? update_display_area_diff_with(ctx->hl,
                    s_reader_turn_pending ? display_main_gray_waveform() : &E0470_WAVEFORM,
                    s_mode, turn_area)
                : update_display_area_with(ctx->hl, &E0470_WAVEFORM, s_mode, s_area);
        if (fast_water) e0470_page_turn_set_tick_us(prior_tick);
        if (s_reader_fullscreen && !fused_footer && err == EPD_DRAW_SUCCESS) {
            // 百分比不变时差分直接跳过；变化时只驱动最底部的少量像素。
            // Skip unchanged percentages; otherwise update only the small bottom strip.
            err = update_display_area_diff_with(ctx->hl, &E0470_WAVEFORM, MODE_GL16,
                                                reader_fullscreen_progress_area());
        }
        if (s_reader_footer_pending && !fused_footer) {
            // 普通翻页页脚只驱动变化像素；全刷由上方整屏分支一次完成。
            // Ordinary turns drive only changed footer pixels; the full-screen branch handles cleanup at once.
            err = (enum EpdDrawError)(err | update_display_area_with(ctx->hl, &E0470_FOLLOW_WAVEFORM,
                                                                     MODE_DU, progress_rect()));
            ESP_LOGD(TAG, "reader regions body_h=%d footer=diff pct=%u", s_area.height, percent(s_page));
        }
    }
    else err = s_view == READING
        // 面板切换按 rc100：只推最终灰阶的差分 GL16，不把首次选择水波纹算作周期全刷。
        // Panel transitions follow rc100: differential GL16 to the final grays only, without
        // counting the first ripple selection as periodic cleanup.
        ? update_display_area_diff_with(ctx->hl,display_main_normal_waveform(),MODE_GL16,
              reader_full_rect())
        : update_display_fast_page(ctx->hl);
    int64_t displayed = esp_timer_get_time();
    reader_prefetch_end(prep);
    if (redraw == APP_REDRAW_AREA && s_mode == MODE_DU &&
        !s_reader_cleanup && !image_gray_refresh && !s_shelf_feedback_pending) {
        s_du_area = s_du_count ? ui_rect_union(s_du_area, s_area) : s_area;
        ++s_du_count;
        s_du_ms = esp_timer_get_time() / 1000;
    } else s_du_count = 0;
    ESP_LOGD(TAG, "present draw=%lld display=%lld join=%lld ms", (drawn - start) / 1000,
             (displayed - drawn) / 1000, (esp_timer_get_time() - displayed) / 1000);
    guard_draw_result(ctx->hl, err);
    // 白天清残影：rc100 差分 GL16 翻页之后，只对「上一页有墨、这一页已纯白」的像素做一次定向
    // 补白，不再把整片纯白底全幅推白（每页 80–90% 像素被重复过驱动，是本轮残影加重的来源）。
    // 白天补白已停用：整片推白会过驱动累积残影，定向补白又会让上一页字迹比背景更白（真机反馈）。
    // 白天清残影交回 rc100 翻页差分与周期整屏清理；反色补黑保持原样。
    // Day white settle is disabled: the whole-ground push over-drove residue, and the targeted
    // push made old glyphs whiter than the background (device feedback). Day-mode ghost handling is
    // rc100's differential turn plus the periodic full cleanup; inverted black settle is unchanged.
    if (err == EPD_DRAW_SUCCESS && epd_get_inverted() && s_view == READING &&
        (s_reader_turn_pending || s_water_turn_pending) && !s_reader_cleanup &&
        s_reader_panel == READER_PANEL_NONE && book_layout_page_image_count(s_page) == 0 &&
        !app_settings_book_background_path()[0])
        display_black_settle(ctx->hl, reader_area());
    if ((s_view==SHELF || s_view==MANAGE) && err==EPD_DRAW_SUCCESS) {
        // 整页渲染已经画出所有“本行已解码”的封面；其余行解码后由 on_tick 逐行补推。
        // A full-page repaint already includes every decoded row; later rows reveal from on_tick.
        if (redraw==APP_REDRAW_PAGE || redraw==APP_REDRAW_FULL) s_cover_dirty_mask=0;
        else if (s_cover_batch_present_pending) s_cover_dirty_mask &= ~s_cover_present_mask;
    }
    s_cover_present_mask=0;
    if (err==EPD_DRAW_SUCCESS && reader_status_visible() &&
        (redraw==APP_REDRAW_PAGE || redraw==APP_REDRAW_FULL || s_reader_cleanup))
        s_reader_clock_minute=frame_minute;
    s_reader_text_frame = err == EPD_DRAW_SUCCESS && s_view == READING && s_text &&
        s_reader_panel == READER_PANEL_NONE && !s_toolbar && !s_clear_confirm &&
        book_layout_page_image_count(s_page) == 0 && !app_settings_book_background_path()[0];
    s_reader_cleanup = false;
    s_reader_image_refresh_pending = false;
    if(err==EPD_DRAW_SUCCESS) {
        s_presented_view = (int)s_view;
        if(reader_entry)s_turns=0;
    }
    s_reader_footer_pending = false;
    s_water_turn_pending = false;
    s_shelf_feedback_pending = false;
    s_cover_batch_present_pending = false;
    s_reader_turn_pending = false;
    s_mode = MODE_GL16;
    return true;
}
static app_redraw_t paint_reading(app_ctx_t* ctx, enum EpdDrawMode mode) {
    s_water_turn_pending = false;
    s_reader_turn_pending = false;
    int64_t started = esp_timer_get_time();
    (void)ui_reader_background_prepare(app_settings_book_background_path());
    prepare_inline_image();
    s_reader_image_refresh_pending = !app_settings_reader_hide_images() &&
        book_layout_page_image_count(s_page) > 0 && s_page_images;
    lock_draw();
    bool cached = false;
    if (!s_toolbar && !s_clear_confirm) {
        const uint32_t generation = book_layout_generation();
        const uint8_t *source = NULL;
        if (s_next_fb && s_next_page == (int)s_page && s_next_generation == generation) source = s_next_fb;
        else if (s_next_fb2 && s_next_page2 == (int)s_page && s_next_generation2 == generation)
            // 第二块缓冲命中同样直接接管：连翻两次的第二页不再当场重排。
            // A second-buffer hit is adopted as well, so the page after next never relayouts on the spot.
            source = s_next_fb2;
        else if (reader_prefetch_resume(s_page)) source = s_next_fb;
        if (source) {
            memcpy(ctx->fb, source, fb_bytes());
            cached = true;
        }
    }
    if (cached) draw_reader_outer(ctx->fb,s_page);
    else draw_reader(ctx->fb, s_page);
    // 下一页可能预渲染于数分钟前，复制后以当前时间重绘状态栏。
    // A prefetched page can be minutes old; replace its status with the current time.
    if (cached && reader_status_visible()) reader_status_paint(ctx->fb);
    unlock_draw();
    ESP_LOGD(TAG, "paint cached=%d ms=%lld", cached, (esp_timer_get_time() - started) / 1000);
    s_area = reader_area();
    s_reader_footer_pending = !s_reader_fullscreen && !s_reader_landscape;
    s_mode = mode;
    return APP_REDRAW_AREA;
}

/* ---- 文件与进度 / Files and progress ---- */
typedef struct {
    size_t chapter;
    char** images;
    size_t count;
} reader_dims_ctx_t;
static reader_dims_ctx_t s_reader_dims_ctx;

// 按 PR9 通过完整资源解包测量，兼容 SVG 包装及较晚的 JPEG 尺寸头。/ Use PR9's full resource measurement for SVG wrappers and late JPEG headers.
static bool reader_image_dims(void* ctx, int image, int* width, int* height) {
    const reader_dims_ctx_t* c = (const reader_dims_ctx_t*)ctx;
    if (!c || image < 0 || (size_t)image >= c->count) return false;
    uint8_t* encoded = NULL;
    size_t size = 0;
    bool png = false;
    if (book_chapter_image(c->chapter, c->images[image], &encoded, &size, &png) != ESP_OK) return false;
    unsigned w = 0, h = 0;
    const bool ok = book_image_dimensions(encoded, size, png, &w, &h) && w && h;
    free(encoded);
    if (!ok) return false;
    if (width) *width = (int)w;
    if (height) *height = (int)h;
    return true;
}
static void flush_ticket_stats(void) {
    uint32_t seconds = s_stats_pending_ms / 1000;
    if (!seconds && !s_stats_pending_turns) return;
    if (book_ticket_record(seconds, s_stats_pending_turns) == ESP_OK) {
        s_stats_pending_ms -= seconds * 1000;
        s_stats_pending_turns = 0;
    }
}
static void track_ticket_stats(app_ctx_t* ctx) {
    if (s_view != READING || !s_text) { s_stats_last_ms = ctx->now_ms; return; }
    if (s_stats_last_ms > 0 && ctx->now_ms >= s_stats_last_ms &&
        ctx->now_ms - s_stats_last_ms <= 5000 &&
        ctx->now_ms - s_stats_activity_ms <= 300000 && !s_toolbar) {
        uint32_t elapsed = (uint32_t)(ctx->now_ms - s_stats_last_ms);
        s_stats_pending_ms += elapsed;
        s_session_read_ms += elapsed;
    }
    s_stats_last_ms = ctx->now_ms;
    if (s_stats_pending_ms >= 30000) flush_ticket_stats();
}
static void free_book(void) {
    // 先落盘再释放：换书/退出时最后一段划线不能丢。
    // Flush before releasing so the newest range cannot be lost when switching or leaving.
    (void)book_highlight_save();
    book_highlight_unload();
    // 换书/退出时清掉未完成的划线拖动与待开始的长按，别把它们带到下一本书。
    // Drop an unfinished highlight drag or armed long press so they cannot leak into the next book.
    s_hl_drag_active = false;
    s_hl_hold_pending = false;
    // 重排留下的 Markdown 重解析请求不能带到下一本书。
    // A pending Markdown re-parse from a re-layout must not leak into the next book.
    s_md_reload_pending = false;
    s_md_reload_offset = s_md_reload_chapter = SIZE_MAX;
    // 字体回退计数与重启提示只属于当前这本书，换书即清。
    // Font-fallback counters and the restart prompt belong to the current book only.
    reader_font_recovery_reset();
    reader_anchor_invalidate();
    // 字体预览遮罩约百 KB，离书即还；下次打开再按需重建。
    // Preview masks are ~100 KB; hand them back when the book closes and rebuild on demand.
    font_preview_clear();
    flush_ticket_stats();
    e0470_page_turn_release();
    s_water_turn_pending = false;
    s_reader_turn_pending = s_reader_text_frame = false;
    pending_progress_t* pending = pending_find(s_path);
    if (pending && !pending->dirty) pending_discard(s_path);
    invalidate_prep();
    // 第二页缓冲只在当前阅读中有意义；换书立即还给堆。/ The second buffer only helps the current book; return it when switching.
    release_second_fb();
    book_layout_set_image_dims(NULL, NULL);
    s_reader_dims_ctx = (reader_dims_ctx_t){0};
    book_layout_free();
    book_layout_set_chapter_lead(0, 0);
    book_layout_set_chapter_lead_width(0);
    s_chapter_lead_skip = s_chapter_lead_height = 0;
    s_chapter_lead_width = 0;
    s_chapter_heading_title[0] = s_chapter_heading_label[0] = 0;
    free(s_text);
    free(s_blocks);
    free(s_runs);
    for (size_t i = 0; i < s_image_count; ++i) free(s_images[i]);
    free(s_images);
    s_images = NULL; s_image_count = 0;
    release_page_images();
    release_prefetch_images();
    s_reader_image_refresh_pending = false;
    s_blocks = NULL;
    s_block_count = 0;
    s_runs = NULL;
    s_run_count = 0;
    book_layout_set_runs(NULL, 0);
    s_text = NULL;
    s_text_len = 0;
    s_selected_toc = SIZE_MAX;
    s_jump_offset = SIZE_MAX;
    book_close();
    s_path[0] = 0;
    s_reader_favorite = false;
    s_book_title[0] = 0;
    app_font_activate_system();
}
// 通栏之后一页位图更大：装不下就按最大空闲块等比缩一档——图小一圈也胜过整页消失。
// A full-bleed page bitmap is larger: when it does not fit, step the aspect-preserving size down
// into the largest free block. A slightly smaller illustration still beats a missing one.
static uint8_t *alloc_page_bitmap(int *width, int *height, size_t *pixels) {
    uint8_t *gray = heap_caps_malloc(*pixels, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (gray) return gray;
    // 内存吃紧时先退掉可重建的第二页预渲染缓冲再试一次，随后才按最大空闲块缩小图片。
    // Under memory pressure drop the rebuildable second-page prefetch buffer and retry once,
    // before shrinking the illustration to the largest free block.
    if (s_next_fb2) {
        lock_draw();
        release_second_fb();
        invalidate_prep();
        unlock_draw();
        gray = heap_caps_malloc(*pixels, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (gray) return gray;
    }
    size_t room = heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (room == 0) return NULL;
    for (int guard = 0; guard < 24 && *pixels > room; ++guard) {
        *width = *width > 1 ? *width * 7 / 8 : 1;
        *height = *height > 1 ? *height * 7 / 8 : 1;
        *pixels = (size_t)*width * (size_t)*height;
    }
    if (*pixels > room) return NULL;
    gray = heap_caps_malloc(*pixels, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (gray)
        ESP_LOGW(TAG, "inline illustration shrunk to %dx%d, free block %u KB",
                 *width, *height, (unsigned)(room / 1024));
    return gray;
}
static void release_page_images(void) {
    // 位图即将释放，缩放目标不再有效；顺手丢掉 1bit 帧与连续 DU 相位。
    // The bitmaps are about to be freed, so the zoom target dies with them; drop the 1-bit frame
    // and continuous-DU phases too.
    reader_zoom_reset();
    for (int i = 0; i < s_page_image_count; ++i) free(s_page_images[i].gray);
    free(s_page_images); s_page_images = NULL; s_page_image_count = 0;
    s_page_images_for = SIZE_MAX;
}
static void release_prefetch_images(void) {
    for (int i = 0; i < s_prefetch_image_count; ++i) free(s_prefetch_images[i].gray);
    free(s_prefetch_images);
    s_prefetch_images = NULL;
    s_prefetch_image_count = s_prefetch_image_index = 0;
    s_prefetch_for = SIZE_MAX;
    s_prefetch_generation = 0;
    s_prefetch_pixels_left = 0;
}
// 解一页里的第 slot 张插图；返回 1 成功（out 已填），0 该槽无效/失败（跳过）。
// Decode one illustration slot for a page: 1 on success (out filled), 0 when the slot is unusable.
static int decode_prefetch_image(size_t page, int slot, size_t *pixels_left, reader_image_t *out) {
    int index = -1, width = 0, height = 0;
    if (!reader_image_slot(page, slot, &index, NULL, &width, &height) || index < 0 ||
        (size_t)index >= s_image_count || width <= 0 || height <= 0) return 0;
    uint8_t *encoded = NULL; size_t size = 0; bool png = false;
    esp_err_t err = book_chapter_image(s_chapter, s_images[index], &encoded, &size, &png);
    if (err != ESP_OK) { free(encoded); return 0; }
    unsigned source_w = 0, source_h = 0;
    if (!book_image_dimensions(encoded, size, png, &source_w, &source_h) || !source_w || !source_h) {
        free(encoded);
        return 0;
    }
    uint64_t w = source_w, h = source_h;
    // 横屏正文栏比面板宽，插图若按整栏放大，解码位图和逐像素绘制都会接近翻倍；
    // 这里把横屏插图宽度限制在面板短边（竖屏宽度），和竖屏保持同一档开销。
    // The landscape body column is wider than the panel; sizing illustrations to the whole column
    // nearly doubles both the decoded bitmap and the per-pixel draw. Cap the landscape image width
    // to the panel's short side (the portrait width) so costs stay at the portrait level.
    int limit_w = width;
    if (s_reader_landscape && limit_w > UI_LOCK_WIDTH) limit_w = UI_LOCK_WIDTH;
    if (w > (unsigned)limit_w) { h = h * limit_w / w; w = limit_w; }
    if (h > (unsigned)height) { w = w * height / h; h = height; }
    width = w ? (int)w : 1;
    height = h ? (int)h : 1;
    size_t pixels = (size_t)width * height;
    if (pixels > *pixels_left) { free(encoded); return 0; }
    uint8_t *gray = alloc_page_bitmap(&width, &height, &pixels);
    if (gray == NULL) { free(encoded); return 0; }
    if (!book_image_grayscale(encoded, size, png, width, height, gray)) {
        free(gray);
        free(encoded);
        return 0;
    }
    free(encoded);
    *pixels_left -= pixels;
    *out = (reader_image_t){gray, width, height};
    return 1;
}
// 每次 tick 最多解一张图，避免占住主循环；相邻页 + 同章 + 无背景图才预取。
// At most one illustration per tick so the main loop keeps responding; neighbouring page only,
// same chapter, no reader background.
static void prefetch_inline_images_tick(void) {
    if (app_settings_reader_hide_images() || !s_text || s_view != READING ||
        s_toolbar || s_clear_confirm || s_reader_panel != READER_PANEL_NONE ||
        app_settings_book_background_path()[0]) {
        release_prefetch_images();
        return;
    }
    const int target = (int)s_page + 1;
    const uint32_t generation = book_layout_generation();
    if (target >= (int)book_layout_page_count()) {
        release_prefetch_images();
        return;
    }
    if (s_prefetch_for != (size_t)target || s_prefetch_generation != generation) {
        release_prefetch_images();
        s_prefetch_for = (size_t)target;
        s_prefetch_generation = generation;
        const int slots = reader_image_slots((size_t)target);
        if (slots > 0 && slots <= (int)HTML_TEXT_MAX_BLOCKS &&
            heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT) >= (size_t)2 * 1024 * 1024) {
            s_prefetch_images = heap_caps_calloc((size_t)slots, sizeof(*s_prefetch_images),
                                                 MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
            if (s_prefetch_images) {
                s_prefetch_image_count = slots;
                const EpdRect band = book_layout_image_rect();
                s_prefetch_pixels_left = (size_t)band.width * band.height;
            }
        }
        s_prefetch_image_index = 0;
    }
    if (!s_prefetch_images || s_prefetch_image_index >= s_prefetch_image_count) return;
    reader_image_t image = {0};
    if (decode_prefetch_image((size_t)target, s_prefetch_image_index, &s_prefetch_pixels_left, &image) > 0)
        s_prefetch_images[s_prefetch_image_index] = image;
    ++s_prefetch_image_index;
    s_prefetch_next_ms = esp_timer_get_time() / 1000 + 120;
}
static void prepare_inline_image(void) {
    if (app_settings_reader_hide_images()) { release_page_images(); release_prefetch_images(); return; }
    uint32_t generation = book_layout_generation();
    // 预加载已完成整页时直接接管，不再读卡解码；半途翻页则丢弃重解，避免缺图。
    // Adopt a fully preloaded page without touching media; a partial preload is discarded.
    if (s_prefetch_images && s_prefetch_for == s_page && s_prefetch_generation == generation &&
        s_prefetch_image_count > 0 && s_prefetch_image_index >= s_prefetch_image_count) {
        release_page_images();
        s_page_images = s_prefetch_images;
        s_page_image_count = s_prefetch_image_count;
        s_page_images_for = s_page;
        s_page_images_generation = generation;
        s_prefetch_images = NULL;
        s_prefetch_image_count = s_prefetch_image_index = 0;
        s_prefetch_for = SIZE_MAX;
        s_prefetch_pixels_left = 0;
        invalidate_prep();
        return;
    }
    if (s_page_images_for == s_page && s_page_images_generation == generation) return;
    // Preserve the prefetched next text page; invalidate only across layout generations or image-bearing pages.
    const bool changed_layout_or_image = s_page_images_generation != generation || s_page_image_count > 0;
    release_page_images();
    s_page_images_for = s_page; s_page_images_generation = generation;
    // 插图不显示没有别的症状，每条失败路径以前都是静默 continue；这里把结局记下来，
    // 免得继续靠猜。
    // A missing illustration has no other symptom and every failure path used to be a silent
    // continue; record the outcome instead of guessing.
    int count = reader_image_slots(s_page);
    if (changed_layout_or_image || count > 0) invalidate_prep();
    size_t psram_before = heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!count || count > (int)HTML_TEXT_MAX_BLOCKS) {
        ESP_LOGD(TAG, "inline page %u: %d image slots", (unsigned)s_page, count);
        return;
    }
    s_page_images = heap_caps_calloc((size_t)count, sizeof(*s_page_images), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!s_page_images) {
        // 分配失败时计数必须跟着归零：release_page_images 会按计数遍历这张表。
        // The count has to follow the table to zero: release_page_images walks it by count.
        s_page_image_count = 0;
        ESP_LOGW(TAG, "inline page %u: no PSRAM for %d slots", (unsigned)s_page, count);
        return;
    }
    s_page_image_count = count;
    // 逐张解码并立即释放压缩数据；全页灰阶位图的总面积不超过插图区域。
    // Decode serially and release each encoded buffer; the page's bitmap area stays within its
    // illustration region.
    EpdRect band = book_layout_image_rect();
    size_t pixels_left = (size_t)band.width * band.height;
    int decoded = 0;
    for (int i = 0; i < count; ++i) {
        int index = -1, width = 0, height = 0;
        if (!reader_image_slot(s_page, i, &index, NULL, &width, &height) ||
            index < 0 || (size_t)index >= s_image_count || width <= 0 || height <= 0) {
            ESP_LOGW(TAG, "inline %d: slot i=%d width=%d height=%d", i, index, width, height);
            continue;
        }
        uint8_t *encoded = NULL; size_t size = 0; bool png = false;
        esp_err_t err = book_chapter_image(s_chapter, s_images[index], &encoded, &size, &png);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "inline %d %s: read %s", i, s_images[index], esp_err_to_name(err));
            free(encoded);
            continue;
        }
        unsigned source_w = 0, source_h = 0;
        if (book_image_dimensions(encoded, size, png, &source_w, &source_h) && source_w && source_h) {
            // 回退槽也使用真实宽高等比缩小，避免尺寸探测失败时拉伸图片。
            // Aspect-fit even fallback slots from decoded dimensions, avoiding stretched unknown-size images.
            uint64_t w = source_w, h = source_h;
            // 与预取路径一致：横屏插图宽度不超过面板短边，避免解码与绘制的面积翻倍。
            // Match the prefetch path: landscape widths stay within the panel's short side so the
            // decoded area and per-pixel draw never double.
            int limit_w = width;
            if (s_reader_landscape && limit_w > UI_LOCK_WIDTH) limit_w = UI_LOCK_WIDTH;
            if (w > (unsigned)limit_w) { h = h * limit_w / w; w = limit_w; }
            if (h > (unsigned)height) { w = w * height / h; h = height; }
            width = w ? (int)w : 1; height = h ? (int)h : 1;
            size_t pixels = (size_t)width * height;
            if (pixels > pixels_left) {
                ESP_LOGW(TAG, "inline %d: %ux%u over %u px budget",
                         i, (unsigned)width, (unsigned)height, (unsigned)pixels_left);
                free(encoded);
                continue;
            }
            uint8_t *gray = alloc_page_bitmap(&width, &height, &pixels);
            if (gray == NULL) {
                ESP_LOGW(TAG, "inline %d: no PSRAM for %u px (free %u)",
                         i, (unsigned)pixels,
                         (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
                free(encoded);
                continue;
            }
            if (book_image_grayscale(encoded, size, png, width, height, gray)) {
                s_page_images[i] = (reader_image_t){gray, width, height};
                pixels_left -= pixels;
                ++decoded;
            } else {
                ESP_LOGW(TAG, "inline %d: grayscale decode failed", i);
                free(gray);
            }
        } else {
            ESP_LOGW(TAG, "inline %d: unknown dimensions (%u bytes, png=%d)", i, (unsigned)size, (int)png);
        }
        free(encoded);
        vTaskDelay(1);
    }
    // 只在有图没画出来时汇总：插图缺失没有别的症状，而每次都打会把日志淹掉。
    // Summary only when something did not make it: a missing illustration has no other symptom,
    // and logging every page would drown the console.
    if (decoded < count) {
        ESP_LOGW(TAG, "inline page %u: %d/%d decoded, psram %u->%u KB", (unsigned)s_page, decoded, count,
                 (unsigned)(psram_before / 1024),
                 (unsigned)(heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT) / 1024));
    }
}
// 标题匹配要宽松：书内导航与正文的写法常常不同（"第一章 出发" 对 "出发"、"1. Prologue" 对
// "序章"，竖排书尤其如此）。逐字比较失败时正文标题块不会被跳过，题头与正文就各显示一次。
// Heading matching has to be forgiving: an authored navigation title rarely matches the body text
// verbatim ("Chapter 1 Departure" against "Departure", a numbered English title against its
// Japanese one), and a strict compare leaves the body heading on the page, so it shows up twice.
static bool heading_text_matches(const char *text, const char *toc, const char *heading,
                                 const char *label) {
    if (text == NULL || text[0] == 0) return false;
    const char *candidates[3] = {toc, heading, label};
    for (int i = 0; i < 3; ++i) {
        const char *cand = candidates[i];
        if (cand == NULL || cand[0] == 0) continue;
        // 互相包含即视为同一标题；短于三个字节的候选不作为依据，免得误吞正文。
        // Either containing the other counts as the same heading; candidates shorter than three
        // bytes are ignored so ordinary body text cannot be swallowed.
        if (strlen(cand) < 3) continue;
        if (strstr(text, cand) != NULL || strstr(cand, text) != NULL) return true;
    }
    return false;
}

static bool load_chapter_at(app_ctx_t* ctx, size_t chapter, size_t offset,
                            bool last_page, const char *anchor, size_t source_offset) {
    // 换章/跳转后旧锚点不再代表当前页：所有换章入口（含目录跳转与字体开关重排）都经过这里。
    // A chapter change/jump invalidates the old rotation anchor. Every chapter load, including TOC
    // jumps and the embedded-face re-typeset, comes through here.
    reader_anchor_invalidate();
    // Markdown 表格在解析阶段就按正文宽、字号与字间距排成预对齐文本行，所以必须早于章节解析；
    // 每次打开/重排章节都在这里刷新。字间距必须与 book_layout_set_typography() 传同一个像素值，
    // 否则字距非 0 时表格行会被二次折行、列也对不齐。TXT/EPUB 书源忽略这次调用。
    // Markdown tables become pre-aligned text rows during parsing, so the metrics must be current
    // before the chapter load. Tracking must equal what book_layout_set_typography() receives, or a
    // non-zero tracking wraps and misaligns the table rows. TXT/EPUB sources ignore the call.
    book_md_set_metrics(body_rect().width, s_px,
                        (int)app_settings_book_tracking() + APP_BOOK_TRACK_MIN);
    bool clear_toc = chapter != s_chapter || (!anchor && source_offset == SIZE_MAX);
    html_text_t loaded = {0};
    size_t anchor_offset = 0;
    esp_err_t err = book_chapter_load_blocks_target(chapter, anchor, source_offset,
                                                    &anchor_offset, &loaded);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "chapter load failed: %s", esp_err_to_name(err));
        copy_text(s_message, sizeof(s_message), "加载失败，请检查存储卡后重试");
        return false;
    }
    char heading[128] = {0}, label[32] = {0}, toc_title[128] = {0};
    size_t lead_skip = 0;
    unsigned lead_height = 0;
    if (book_kind() == BOOK_KIND_EPUB && loaded.len) {
        // 已识别的正文编号题头优先；没有时沿用书内导航或备用标题。
        // Prefer a recognized numbered body heading, then authored navigation or a fallback title.
        if (book_chapter_title(chapter, toc_title, sizeof(toc_title)) != ESP_OK)
            snprintf(toc_title, sizeof(toc_title), "第 %u 节", (unsigned)chapter + 1);
        copy_text(heading, sizeof(heading), toc_title);
        char *chapter_mark = strstr(heading, "章");
        if (chapter_mark && chapter_mark - heading < 24) {
            char *after = chapter_mark + strlen("章");
            while (*after == ' ' || *after == '\t' || *after == ':' || *after == '-' ||
                   !strncmp(after, "：", strlen("：")) || !strncmp(after, "、", strlen("、"))) {
                if (*after == ' ' || *after == '\t' || *after == ':' || *after == '-') ++after;
                else after += strlen("：");
            }
            if (*after && (size_t)(chapter_mark + strlen("章") - heading) < sizeof(label)) {
                size_t label_len = (size_t)(chapter_mark + strlen("章") - heading);
                memcpy(label, heading, label_len); label[label_len] = 0;
                memmove(heading, after, strlen(after) + 1);
            }
        }
        size_t skip_blocks = 0;
        // 最多看四个块：标题可能被拆成"第一章"、"出发"、"——副标题"这样几块。
        // Up to four blocks: a heading can arrive split across several.
        while (skip_blocks < loaded.count && skip_blocks < 4 &&
               loaded.blocks[skip_blocks].heading && loaded.blocks[skip_blocks].image < 0) {
            char body_heading[128] = {0};
            size_t len = loaded.blocks[skip_blocks].len;
            if (len >= sizeof(body_heading)) break;
            memcpy(body_heading, loaded.utf8 + loaded.blocks[skip_blocks].offset, len);
            while (len && (body_heading[len - 1] == ' ' || body_heading[len - 1] == '\t')) body_heading[--len] = 0;
            const char *trimmed = body_heading;
            while (*trimmed == ' ' || *trimmed == '\t') ++trimmed;
            if (!heading_text_matches(trimmed, toc_title, heading, label)) break;
            ++skip_blocks;
        }
        if (skip_blocks) lead_skip = skip_blocks < loaded.count ? loaded.blocks[skip_blocks].offset : loaded.len;
        // 首块是插图时不预留题头：那页整页留给插图，标题在它后面才排。
        // 这个条件一直是题头该不该出现的判据，横排竖排都一样。
        // An illustration at the head of the chapter reserves nothing: it owns that page and the
        // heading follows. This condition has always decided whether a sheet gets a heading at all,
        // in either setting.
        if (skip_blocks < loaded.count && loaded.blocks[skip_blocks].image >= 0) {
            lead_skip = 0;
            lead_height = 0;
        } else {
            lead_height = body_rect().height > 214 ? 214 : 0;
        }
    }
    size_t old_lead_skip = s_chapter_lead_skip;
    unsigned old_lead_height = s_chapter_lead_height;
    unsigned old_lead_width = s_chapter_lead_width;
    reader_dims_ctx_t old_dims_ctx = s_reader_dims_ctx;
    lock_draw();
    invalidate_prep();
    // 题头几何按当前模式重算，横排留顶部行高、竖排留右侧列宽，绘制与预留不会错开。
    // Recompute the heading geometry for the current mode -- rows at the top horizontally,
    // columns at the right vertically -- so drawing and reservation cannot drift apart.
    apply_chapter_lead(heading, label, lead_skip, lead_height);
    s_reader_dims_ctx = (reader_dims_ctx_t){chapter, loaded.images, loaded.image_count};
    book_layout_set_image_dims(reader_image_dims, &s_reader_dims_ctx);
    book_layout_set_runs(loaded.runs, loaded.run_count);
    bool ok = book_layout_build_blocks(loaded.utf8, loaded.len, loaded.blocks, loaded.count, body_rect(), s_px);
    if (!ok) {
        // 回滚前恢复旧章上下文，避免尺寸回调引用已释放的新章图片。/ Restore the previous context before rollback to avoid a freed image list.
        s_reader_dims_ctx = old_dims_ctx;
        html_text_free(&loaded);
        // run 表随 loaded 一起没了，先把排版还回旧章的那份，否则重排会读到已释放的内存。
        // The run table dies with `loaded`, so put the previous chapter's back before the
        // rollback layout reads freed memory.
        book_layout_set_runs(s_runs, s_run_count);
        // 题头几何也跟着回滚，否则这一章的题头参数会留在失败的那次上。
        // Roll the heading geometry back too, or the failed chapter's parameters would stick.
        s_chapter_lead_skip = old_lead_skip;
        s_chapter_lead_height = old_lead_height;
        s_chapter_lead_width = old_lead_width;
        book_layout_set_chapter_lead(old_lead_skip, old_lead_height);
        book_layout_set_chapter_lead_width(old_lead_width);
        bool restored = s_text && book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
        unlock_draw();
        if (!restored) {
            free_book();
            s_view = SHELF;
            ctx->leaf = 0;
        }
        copy_text(s_message, sizeof(s_message), "排版失败：内存不足或章节过长");
        return false;
    }
    book_excerpt_offer(s_path, chapter, &loaded);
    free(s_text);
    free(s_blocks);
    free(s_runs);
    s_text = loaded.utf8;
    s_text_len = loaded.len;
    s_blocks = loaded.blocks;
    s_block_count = loaded.count;
    s_runs = loaded.runs;
    s_run_count = loaded.run_count;
    for (size_t i = 0; i < s_image_count; ++i) free(s_images[i]);
    free(s_images);
    s_images = loaded.images; s_image_count = loaded.image_count;
    release_page_images();
    s_chapter = chapter;
    if (clear_toc) s_selected_toc = SIZE_MAX;
    s_chapter_lead_skip = lead_skip;
    s_chapter_lead_row_height = lead_height;
    copy_text(s_chapter_heading_title, sizeof(s_chapter_heading_title), heading);
    copy_text(s_chapter_heading_label, sizeof(s_chapter_heading_label), label);
    s_page = last_page ? book_layout_page_count() - 1 :
             book_layout_page_for_offset(anchor || source_offset != SIZE_MAX ? anchor_offset : offset);
    s_jump_offset = anchor || source_offset != SIZE_MAX ? anchor_offset : SIZE_MAX;
    s_jump_page = s_page;
    if (book_chapter_title(chapter, s_title, sizeof(s_title)) != ESP_OK)
        snprintf(s_title, sizeof(s_title), "第 %u 节", (unsigned)chapter + 1);
    copy_text(s_font_path, sizeof(s_font_path), ttf_font_path());
    s_message[0] = 0;
    unlock_draw();
    prepare_inline_image();
    // 开书这条链上有解析、解压和字体装载，栈曾经在这里溢出过；留一个可观测的水位。
    // 顺带量一下章节排完后的 PSRAM 余量：书内字体的装载预算要靠这个数来定，不能靠估。
    // Parsing, inflate and face loading all ride this chain, and it overflowed once before;
    // keep the headroom observable. The PSRAM left after a chapter is laid out is also the
    // number the face budget should be derived from rather than guessed.
    ESP_LOGD(TAG, "chapter %u stack free %u psram free %u largest %u", (unsigned)chapter,
             (unsigned)uxTaskGetStackHighWaterMark(NULL),
             (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT),
             (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    // 当前正文已按这次解析时的旋转方向与 metrics 成形；旋转路径据此判断是否还欠一次重解析。
    // The body is parsed for this rotation and metrics; the rotation path uses the flag to decide
    // whether a Markdown re-parse is still owed.
    s_md_tables_rot = s_reader_rot;
    return true;
}
static bool load_chapter(app_ctx_t* ctx, size_t chapter, size_t offset, bool last_page) {
    // 换章/跳转的锚点失效已统一在 load_chapter_at 里处理，避免直接调用它的路径漏掉。
    // Anchor invalidation for chapter changes lives in load_chapter_at so direct callers cannot miss it.
    return load_chapter_at(ctx, chapter, offset, last_page, NULL, SIZE_MAX);
}
// Markdown 的表格列宽在解析期按正文宽/字号/字距固化成空格填充，重排类操作（字号、边距、行距、
// 段距、字距、缩进、横竖屏旋转、系统字体切换）之后必须按“重排前的页首输出偏移”重载当前章，
// 让表格按新指标重新成形。TXT/EPUB 直接返回 false，不碰任何状态（零回归）。
// Markdown bakes table column widths into space padding at parse time from the body width, font
// size and tracking. After any re-layout (size, margins, line/paragraph spacing, tracking, indent,
// rotation, system face) the chapter must be reloaded at the pre-layout page-start output offset so
// tables re-form with the new metrics. TXT/EPUB return false without touching any state.
static bool reader_md_reload_at(app_ctx_t *ctx, size_t offset) {
    if (book_kind() != BOOK_KIND_MARKDOWN) return false;
    return load_chapter(ctx, s_chapter, offset, false);
}
// 触摸回调内的重排只登记一次重解析请求，真正的 load_chapter 交给 on_tick（见状态注释）。
// A re-layout inside a touch callback only records the re-parse request here; the real
// load_chapter runs from on_tick (see the state comment above).
static void reader_md_reload_request(size_t offset) {
    if (book_kind() != BOOK_KIND_MARKDOWN) return;
    s_md_reload_pending = true;
    s_md_reload_offset = offset;
    s_md_reload_chapter = s_chapter;
}
// 关闭图片时跳过纯插图页，避免出现空白翻页。/ Skip illustration-only pages when images are disabled.
static void skip_hidden_image_pages(app_ctx_t *ctx, int direction) {
    if (!app_settings_reader_hide_images()) return;
    for (int guard = 0; guard < 128 && book_layout_page_image(s_page) >= 0; ++guard) {
        if (direction > 0 && s_page + 1 < book_layout_page_count()) ++s_page;
        else if (direction < 0 && s_page > 0) --s_page;
        else if (direction > 0 && s_chapter + 1 < book_chapter_count()) {
            if (!load_chapter(ctx, s_chapter + 1, 0, false)) break;
        } else if (direction < 0 && s_chapter > 0) {
            if (!load_chapter(ctx, s_chapter - 1, 0, true)) break;
        } else break;
    }
}
static bool open_book_impl(app_ctx_t* ctx, const char* path) {
    // 首页预热可能正在扫卡/解封面；开书前先收手，别和解析、字体装载抢 SD 与任务。
    // Home prewarm may be walking the card or decoding covers; stand it down before parsing and
    // face loading compete for the card and worker tasks.
    shelf_prewarm_abort();
    if (!book_file_path_supported(path)) {
        copy_text(s_message, sizeof(s_message), "此版本仅支持 TXT、EPUB 和 Markdown 书籍");
        return false;
    }
    s_reader_return_home = false;
    if (!strncmp(path, "/sdcard/", 8)) {
        read_pico_sd_info_t sd = {0};
        read_pico_sd_get_info(&sd);
        if (!sd.present || !sd.mounted) {
            copy_text(s_message, sizeof(s_message), "TF 卡不可用，请重新挂载后打开");
            return false;
        }
    }
    // 自动续读也不能绕过同路径旧文件的清理重试。
    // Automatic resume must also finish cleanup of the old file at this path.
    if (delete_retry_find(path)) {
        copy_text(s_message, sizeof(s_message), "文件已删除，进度清理失败，请重试");
        return false;
    }
    struct stat st;
    if (stat(path, &st) != 0 || !S_ISREG(st.st_mode) || st.st_size < 0 || (uint64_t)st.st_size > UINT32_MAX) {
        copy_text(s_message, sizeof(s_message), "文件不可读，请检查 TF 卡和书籍文件");
        return false;
    }
    if (strncmp(path, "/flash/", 7) == 0 && st.st_size > BOOK_STORE_FLASH_FILE_MAX) {
        copy_text(s_message, sizeof(s_message), "内置存储单本限 1 MB");
        return false;
    }
    read_pico_transfer_status_t network = {0};
    read_pico_transfer_get_status(&network);
    s_shelf_key_mode=s_shelf_key_paint_pending=false;s_shelf_key_delta=s_shelf_key_pressed=0;
    // 书架封面和上一本书的预渲染缓冲可以重建；先释放，再解析 EPUB。
    // Cover and previous-page caches are rebuildable; release them before EPUB parsing.
    invalidate_covers();
    app_home_release_clock_cache();
    lock_draw();
    invalidate_prep();
    free(s_next_fb);
    s_next_fb = NULL;
    release_second_fb();
    unlock_draw();
    if (network.network_ready) ttf_font_cache_clear();
    // 开书前把字形缓存全还回去并量一下能腾多少：书内字体要的正是这块 PSRAM，而系统字体
    // 的缓存是里面最容易回收的。字体本身保持装载，翻页时按需重新缓存。
    // Hand every glyph cache back before opening and measure what that was worth: embedded
    // faces need exactly this PSRAM, and the system face's cache is the easiest part to
    // reclaim. The faces stay loaded and re-cache on demand.
    size_t psram_before = heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    size_t reclaimed = ttf_font_cache_clear_all();
    size_t psram_after = heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    ESP_LOGD(TAG, "open start wifi=%d internal=%u/%u psram=%u/%u cache=%uK freed=%uK",
             network.network_ready,
             (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
             (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
             (unsigned)psram_after,
             (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT),
             (unsigned)(reclaimed / 1024),
             (unsigned)((psram_after - psram_before) / 1024));
    if (!pending_reserve(path)) {
        copy_text(s_message, sizeof(s_message), "内存不足，无法保留待保存进度");
        return false;
    }
    save_progress();
    free_book();
    s_reader_fullscreen = s_requested_fullscreen;
    app_font_activate_reading();
    if (!pending_reserve(path)) {
        copy_text(s_message, sizeof(s_message), "内存不足，无法打开图书");
        app_font_activate_system();
        return false;
    }
    esp_err_t err = book_open(path);
    // 书源打开后再把书内字体开关接上：EPUB 才有效，TXT 是空操作。
    // Wire the embedded-face switch only after the source is open: it only applies to EPUB,
    // and is a no-op for TXT.
    if (err == ESP_OK) {
        s_book_fonts_applied = app_settings_book_fonts();
        book_set_embedded_fonts(s_book_fonts_applied);
    }
    if (err != ESP_OK) {
        pending_progress_t* pending = pending_find(path);
        if (pending && !pending->dirty) pending_discard(path);
        copy_text(s_message, sizeof(s_message),
                  err == ESP_ERR_NOT_SUPPORTED ? "文件格式或压缩方式暂不支持" :
                  err == ESP_ERR_NO_MEM ? "内存不足，请重启后重试" :
                  err == ESP_ERR_INVALID_SIZE ? "图书资源过大或章节过多" :
                  "无法打开图书，请检查文件");
        ESP_LOGW(TAG, "open failed: %s internal=%u/%u psram=%u/%u", esp_err_to_name(err),
                 (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                 (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                 (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT),
                 (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        app_font_activate_system();
        return false;
    }
    copy_text(s_path, sizeof(s_path), path);
    s_reader_favorite = favorite_load(path);
    const char* filename = strrchr(path, '/');
    filename = filename ? filename + 1 : path;
    if (!book_title_from_path(path, s_book_title, sizeof(s_book_title)))
        clean_filename(s_book_title, sizeof(s_book_title), filename);
    s_file_size = (uint32_t)st.st_size;
    // 划线记录按书载入；没有文件就是空集合，不影响开书。
    // Load this book's ranges; a missing file is just an empty set and never blocks opening.
    (void)book_highlight_load(s_path);
    book_progress_t p = {0};
    bool resume = pending_restore(path, s_file_size, &p) || book_progress_load(path, s_file_size, &p);
    // 排版字号以全局阅读设置为准；旧书进度只决定阅读位置。
    // Use the shared reading size for every book; per-book progress restores position only.
    s_px = app_settings_book_px();
    if (s_px < BOOK_PX_MIN || s_px > BOOK_PX_MAX) s_px = 48;
    size_t chapter = resume && p.chapter < book_chapter_count() ? p.chapter : 0;
    if (!load_chapter(ctx, chapter, resume && p.chapter == chapter ? p.byte_off : 0, false)) {
        free_book();
        return false;
    }
    skip_hidden_image_pages(ctx, 1);
    if (!s_text) { free_book(); return false; }
    s_view = READING;
    s_reader_image_refresh_pending = !app_settings_reader_hide_images() &&
        book_layout_page_image_count(s_page) > 0 && s_page_images;
    s_stats_last_ms = s_stats_activity_ms = ctx->now_ms;
    s_reader_panel = READER_PANEL_NONE;
    s_clear_confirm = s_batch_confirm = false;
    s_session_read_ms = s_session_turns = 0;
    s_reader_notice[0] = 0;
    s_turns = s_unsaved = 0;
    pending_mark_latest(s_path);
    save_progress();
    // 打开即重新上书架：移出书架只隐藏条目，重新读这本书就是它该在架上的信号。
    // Opening puts the book back on the shelf: removal only hides the entry, and reading it
    // again is the signal that it belongs there.
    if (shelf_hidden_load(s_path)) (void)shelf_hidden_save(s_path, false);
    ESP_LOGD(TAG, "opened kind=%d chapters=%u pages=%u px=%d", book_kind(), (unsigned)book_chapter_count(), (unsigned)book_layout_page_count(), s_px);
    return true;
}
static bool open_book(app_ctx_t *ctx, const char *path) {
    if (!book_cover_jobs_quiesce(2000)) {
        copy_text(s_message,sizeof(s_message),"封面任务正在收尾，请稍后再试");return false;
    }
    esp_err_t checkpoint_error=pico_boot_book_begin(path);
    if (checkpoint_error != ESP_OK) {
        ESP_LOGW("book", "open checkpoint failed: %s", esp_err_to_name(checkpoint_error));
        copy_text(s_message, sizeof(s_message), "启动记录保存失败，请重试");
        return false;
    }
    bool ok = open_book_impl(ctx, path);
    pico_boot_book_end(ok);
    return ok;
}
static bool open_requested_book(app_ctx_t* ctx) {
    if (!s_requested_open[0]) return false;
    char path[BOOK_STORE_PATH_MAX];
    copy_text(path, sizeof(path), s_requested_open);
    bool from_home = s_requested_open_home;
    s_requested_open[0] = 0;
    s_requested_open_home = false;
    bool opened = open_book(ctx, path);
    s_requested_fullscreen = true;
    if (!opened) return false;
    s_reader_return_home = from_home;
    return true;
}
/* ---- 书架数据 / Shelf data ---- */
static int shelf_category_add(const char *path) {
    for (int i=2;i<s_category_count;++i) {
        if (!strcmp(s_categories[i].path,path)) { s_categories[i].available=true; return i; }
    }
    if (s_category_count==SHELF_CATEGORY_LIMIT) return -1;
    if (s_category_count==s_category_capacity) {
        int capacity=s_category_capacity ? s_category_capacity*2 : 16;
        if (capacity>SHELF_CATEGORY_LIMIT) capacity=SHELF_CATEGORY_LIMIT;
        shelf_category_t *next=heap_caps_realloc(s_categories,(size_t)capacity*sizeof(*next),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
        if (!next) return -1;
        s_categories=next; s_category_capacity=capacity;
    }
    int index=s_category_count++;
    memset(&s_categories[index],0,sizeof(s_categories[index]));
    copy_text(s_categories[index].path,sizeof(s_categories[index].path),path);
    s_categories[index].available=true;
    return index;
}
static void shelf_category_init(void) {
    const char *root=app_settings_books_dir();
    if (strcmp(s_category_root,root)) {
        free(s_categories); s_categories=NULL;
        s_category_count=s_category_capacity=s_category_selected=s_category_menu_page=0;
        copy_text(s_category_root,sizeof(s_category_root),root);
        s_shelf_cache_valid=false;
    }
    if (s_categories) return;
    s_categories=heap_caps_calloc(16,sizeof(*s_categories),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if (!s_categories) return;
    s_category_capacity=16; s_category_count=2;
    s_categories[0].available=s_categories[1].available=true;
}
static const char *shelf_category_name(int index) {
    if (index==1) return "未分类";
    if (!s_categories || index<2 || index>=s_category_count) return "全部书籍";
    const char *slash=strrchr(s_categories[index].path,'/');
    return slash ? slash+1 : s_categories[index].path;
}
static bool shelf_category_matches(const char *path) {
    if (!s_category_selected || !s_categories) return true;
    if (s_category_selected==1) {
        char child[BOOK_STORE_PATH_MAX];
        return !book_shelf_child(s_category_root,path,child,sizeof(child));
    }
    size_t size=strlen(s_categories[s_category_selected].path);
    return !strncmp(path,s_categories[s_category_selected].path,size) && path[size]=='/';
}
static void shelf_category_remember(app_ctx_t *ctx) {
    if (s_categories && s_view==SHELF && !s_scan_pending)
        s_categories[s_category_selected].pages[app_settings_shelf_style()==5]=ctx->leaf;
}
static void shelf_category_restore(app_ctx_t *ctx) {
    int layout=app_settings_shelf_style()==5;
    int saved=s_categories ? s_categories[s_category_selected].pages[layout] : 0;
    ctx->leaf=book_shelf_saved_page(saved,s_visible_count,shelf_rows());
    if (s_categories) s_categories[s_category_selected].pages[layout]=ctx->leaf;
}
static void shelf_categories_recount(void) {
    if (!s_categories) return;
    for (int i=0;i<s_category_count;++i) s_categories[i].count=0;
    for (int i=0;i<s_count;++i) {
        if (s_shelf[i].removed) continue;
        ++s_categories[0].count;
        char child[BOOK_STORE_PATH_MAX],path[BOOK_STORE_PATH_MAX];
        if (!book_shelf_child(s_category_root,s_shelf[i].path,child,sizeof(child))) {
            ++s_categories[1].count; continue;
        }
        int written=snprintf(path,sizeof(path),"%s/%s",s_category_root,child);
        if (written<0 || (size_t)written>=sizeof(path)) continue;
        int index=shelf_category_add(path);
        if (index>=2) ++s_categories[index].count;
    }
    if (s_category_selected>=s_category_count || !s_categories[s_category_selected].available)
        s_category_selected=0;
}
static int shelf_category_at(int ordinal) {
    for (int i=0;i<s_category_count;++i) {
        if (s_categories[i].available && ordinal--==0) return i;
    }
    return -1;
}
static int shelf_category_available(void) {
    int count=0;
    for (int i=0;i<s_category_count;++i) if (s_categories[i].available) ++count;
    return count;
}
static EpdRect shelf_category_box(void) {
    int count=shelf_category_available()-s_category_menu_page*SHELF_CATEGORY_ROWS;
    if (count>SHELF_CATEGORY_ROWS) count=SHELF_CATEGORY_ROWS;
    if (count<1) count=1;
    return (EpdRect){36,158,400,16+count*83+(shelf_category_available()>SHELF_CATEGORY_ROWS ? 56 : 0)};
}
static void draw_category_menu(uint8_t *fb) {
    EpdRect box=shelf_category_box();
    ui_fill_round_rect(fb,box,23,UI_GRAY_WHITE);
    ui_draw_control_frame(fb,box,23,0x50);
    for (int row=0;row<SHELF_CATEGORY_ROWS;++row) {
        int index=shelf_category_at(s_category_menu_page*SHELF_CATEGORY_ROWS+row);
        if (index<0) break;
        int y=box.y+8+row*83;
        bool selected=index==s_category_selected;
        if (selected) ui_fill_round_rect(fb,(EpdRect){box.x+8,y,box.width-16,79},16,0xd0);
        ui_draw_icon(fb,box.x+35,y+40,27,index<2 ? UI_ICON_LIBRARY_BIG : UI_ICON_FOLDER_OPEN,UI_GRAY_BLACK);
        char name[BOOK_STORE_PATH_MAX],count[24];
        snprintf(count,sizeof(count),"%d",s_categories[index].count);
        int name_width=290-ui_text_fixed_width_px(ui_text_effective_px(22),count);
        if (name_width>228) name_width=228;
        if (name_width<60) name_width=60;
        copy_text(name,sizeof(name),shelf_category_name(index)); fit_text(name,28,name_width);
        ui_text_vc(fb,box.x+62,y+40,28,name,EPD_DRAW_ALIGN_LEFT,false);
        ui_text_vc(fb,box.x+box.width-38,y+40,22,count,EPD_DRAW_ALIGN_RIGHT,false);
        if (selected) epd_fill_circle(box.x+box.width-20,y+40,4,UI_GRAY_BLACK,fb);
    }
    if (shelf_category_available()>SHELF_CATEGORY_ROWS) {
        int y=box.y+box.height-28;
        ui_draw_icon(fb,box.x+48,y,28,UI_ICON_CHEVRON_LEFT,s_category_menu_page ? 0 : 0x90);
        char pages[24]; snprintf(pages,sizeof(pages),"%d / %d",s_category_menu_page+1,
            (shelf_category_available()+SHELF_CATEGORY_ROWS-1)/SHELF_CATEGORY_ROWS);
        ui_text_vc(fb,box.x+box.width/2,y,22,pages,EPD_DRAW_ALIGN_CENTER,false);
        ui_draw_icon(fb,box.x+box.width-48,y,28,UI_ICON_CHEVRON_RIGHT,0);
    }
}
static bool shelf_matches(const shelf_entry_t* item) {
    return shelf_category_matches(item->path) && item->search_match && (s_filter == 0 || (s_filter == 1 && !item->is_flash) || (s_filter == 2 && item->is_flash));
}
static int compare_books(const void* a, const void* b) {
    const shelf_entry_t* x = a;
    const shelf_entry_t* y = b;
    if (shelf_matches(x) != shelf_matches(y)) return shelf_matches(x) ? -1 : 1;
    // 搜索跟随书架：从最近阅读到从未读过；收藏不再提前，保证结果顺序一眼可预期。
    // Search follows the shelf's reading order (most recent first, unread last); favourites are
    // not hoisted so the result order is predictable.
    if (s_query[0]) {
        if (x->recent != y->recent) return x->recent > y->recent ? -1 : 1;
        int by_name = strcasecmp(x->name, y->name);
        return by_name ? by_name : strcmp(x->path, y->path);
    }
    if (x->favorite != y->favorite)
        return x->favorite ? -1 : 1;
    if (s_recent_sort && x->recent != y->recent) return x->recent > y->recent ? -1 : 1;
    int name = strcasecmp(x->name, y->name);
    return name ? name : strcmp(x->path, y->path);
}
static void sort_shelf(app_ctx_t* ctx) {
    invalidate_covers();
    if (s_count > 1) qsort(s_shelf, s_count, sizeof(*s_shelf), compare_books);
    s_visible_count = 0;
    while (s_visible_count < s_count && shelf_matches(&s_shelf[s_visible_count])) ++s_visible_count;
    ctx->leaf = 0;
}
static app_redraw_t shelf_category_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type!=UI_GESTURE_TAP && ev->type!=UI_GESTURE_SWIPE_U && ev->type!=UI_GESTURE_SWIPE_D)
        return APP_REDRAW_NONE;
    EpdRect previous=shelf_category_box();
    if (ev->type==UI_GESTURE_TAP && ui_nav_hit(ev->x0,ev->y0)>=0) {
        s_category_menu=false; ui_nav_request(ctx,ui_nav_hit(ev->x0,ev->y0)); return APP_REDRAW_NONE;
    }
    if (!s_category_menu) {
        if (ev->type!=UI_GESTURE_TAP || !s_categories) return APP_REDRAW_NONE;
        s_category_menu=true; s_category_menu_page=0;
        int ordinal=0;
        for (int i=0;i<s_category_selected;++i) if (s_categories[i].available) ++ordinal;
        s_category_menu_page=ordinal/SHELF_CATEGORY_ROWS;
    } else {
        int pages=(shelf_category_available()+SHELF_CATEGORY_ROWS-1)/SHELF_CATEGORY_ROWS;
        int direction=ev->type==UI_GESTURE_SWIPE_U ? 1 : ev->type==UI_GESTURE_SWIPE_D ? -1 : 0;
        if (!direction && ui_rect_hit(previous,ev->x0,ev->y0)) {
            int row=((int)ev->y0-previous.y-8)/83;
            bool footer=pages>1 && ev->y0>=previous.y+previous.height-56;
            if (footer) direction=ev->x0<previous.x+previous.width/2 ? -1 : 1;
            else {
                int index=ev->y0>=previous.y+8 && row<SHELF_CATEGORY_ROWS
                    ? shelf_category_at(s_category_menu_page*SHELF_CATEGORY_ROWS+row) : -1;
                if (index>=0) {
                    shelf_category_remember(ctx); s_category_selected=index;
                    s_category_menu=false; clear_selection(); sort_shelf(ctx); shelf_category_restore(ctx);
                    return APP_REDRAW_PAGE;
                }
            }
        } else if (!direction) s_category_menu=false;
        if (direction) {
            int next=s_category_menu_page+direction;
            if (next<0 || next>=pages) return APP_REDRAW_NONE;
            s_category_menu_page=next;
        }
    }
    EpdRect next=shelf_category_box();
    int bottom=previous.y+previous.height>next.y+next.height ? previous.y+previous.height : next.y+next.height;
    s_area=(EpdRect){24,79,424,bottom-79+4}; s_mode=MODE_GL16;
    render(ctx,ctx->fb);
    return APP_REDRAW_AREA;
}
static bool shelf_reserve(void) {
    if ((size_t)s_count < s_shelf_capacity) return true;
    if (s_count == INT_MAX) return false;
    size_t cap = s_shelf_capacity ? s_shelf_capacity * 2 : 32;
    if (cap > INT_MAX || cap > SIZE_MAX / sizeof(*s_shelf)) return false;
    shelf_entry_t* entries = heap_caps_realloc(s_shelf, cap * sizeof(*entries), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!entries) return false;
    s_shelf = entries;
    s_shelf_capacity = cap;
    return true;
}

// 在删除文件前预留记录，避免删除成功后才遇到内存不足。
// Reserve before unlink so allocation failure never loses a completed deletion's retry.
static delete_retry_t* delete_retry_reserve(const shelf_entry_t* entry) {
    delete_retry_t* existing = delete_retry_find(entry->path);
    if (existing) return existing;
    delete_retry_t* p = heap_caps_malloc(sizeof(*p), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!p) p = malloc(sizeof(*p));
    if (!p) return NULL;
    p->entry = *entry;
    p->next = s_delete_retries;
    s_delete_retries = p;
    return p;
}
static void delete_retry_discard(const char* path) {
    delete_retry_t** p = &s_delete_retries;
    while (*p) {
        if (!strcmp((*p)->entry.path, path)) {
            delete_retry_t* old = *p;
            *p = old->next;
            free(old);
            return;
        }
        p = &(*p)->next;
    }
}
// 显式目录栈放在 PSRAM；主任务只有 8 KB 栈，递归进多级 books 会在封面出现前溢出。
// Keep directory frames in PSRAM: recursive books scanning can overflow the 8 KB main-task stack before covers appear.
#define BOOK_SCAN_DEPTH_LIMIT 12
typedef struct {
    DIR *dir;
    char path[BOOK_STORE_PATH_MAX];
} shelf_scan_frame_t;
// 可暂停的目录遍历：状态整块放 PSRAM。正式进入书架时一次跑到底（首帧不能缺书），
// 首页空闲预热时按预算分多次推进，触摸/切页立即让路。
// A resumable directory walk with its state in PSRAM. The real shelf entry runs it to completion
// (the first frame must not miss books); home-idle prewarm advances it under a budget and yields
// at once to touch or page changes.
typedef struct {
    shelf_scan_frame_t *frames;   ///< BOOK_SCAN_DEPTH_LIMIT + 1 帧 / frames
    int depth;                    ///< -1 表示已经走完 / -1 means the walk is finished
    bool is_flash;
    bool truncated, unreadable, skipped;
} shelf_walk_t;
#define SHELF_WALK_DONE 1
#define SHELF_WALK_BUDGET 2
static void shelf_walk_begin(shelf_walk_t *walk, const char *root, bool is_flash) {
    memset(walk, 0, sizeof(*walk));
    walk->depth = -1;
    walk->is_flash = is_flash;
    walk->frames = heap_caps_calloc(BOOK_SCAN_DEPTH_LIMIT + 1, sizeof(*walk->frames),
                                    MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!walk->frames) { walk->truncated = true; return; }
    size_t root_len = strnlen(root, sizeof(walk->frames[0].path));
    if (root_len >= sizeof(walk->frames[0].path)) { walk->skipped = true; return; }
    walk->frames[0].dir = opendir(root);
    if (!walk->frames[0].dir) { walk->unreadable = true; return; }
    memcpy(walk->frames[0].path, root, root_len + 1);
    walk->depth = 0;
}
static void shelf_walk_end(shelf_walk_t *walk) {
    if (!walk->frames) return;
    for (int i = 0; i <= walk->depth && i <= BOOK_SCAN_DEPTH_LIMIT; ++i)
        if (walk->frames[i].dir) closedir(walk->frames[i].dir);
    free(walk->frames);
    walk->frames = NULL;
    walk->depth = -1;
}
// 推进遍历最多 budget 个目录项：SHELF_WALK_DONE 结束，SHELF_WALK_BUDGET 预算用完（可续跑）。
// Advance at most `budget` directory entries: SHELF_WALK_DONE finished, SHELF_WALK_BUDGET resumed later.
static int shelf_walk_step(app_ctx_t *ctx, shelf_walk_t *walk, nvs_handle_t favorites,
                           nvs_handle_t hidden, int budget, bool responsive) {
    while (walk->depth >= 0 && !walk->truncated) {
        if (budget <= 0) return SHELF_WALK_BUDGET;
        if (responsive && s_view == SHELF && app_poll_main_navigation(ctx)) {
            shelf_walk_end(walk);
            return SHELF_WALK_DONE;
        }
        const int depth = walk->depth;
        errno = 0;
        struct dirent *ent = readdir(walk->frames[depth].dir);
        if (!ent) {
            if (errno) walk->unreadable = true;
            closedir(walk->frames[depth].dir);
            walk->frames[depth].dir = NULL;
            --walk->depth;
            continue;
        }
        --budget;
        if (ent->d_name[0] == '.') continue;
        char path[BOOK_STORE_PATH_MAX];
        int len = snprintf(path, sizeof(path), "%s/%s", walk->frames[depth].path, ent->d_name);
        if (len < 0 || (size_t)len >= sizeof(path)) { walk->skipped = true; continue; }
        struct stat st;
        if (stat(path, &st) != 0) { walk->unreadable = true; continue; }
        if (S_ISDIR(st.st_mode)) {
            if (!walk->is_flash && depth == 0 && !strcmp(walk->frames[0].path, app_settings_books_dir()))
                shelf_category_add(path);
            if (depth == BOOK_SCAN_DEPTH_LIMIT) { walk->skipped = true; continue; }
            DIR *child = opendir(path);
            if (!child) { walk->unreadable = true; continue; }
            ++walk->depth;
            walk->frames[walk->depth].dir = child;
            memcpy(walk->frames[walk->depth].path, path, (size_t)len + 1);
            continue;
        }
        if (!S_ISREG(st.st_mode)) continue;
        const char *ext = strrchr(ent->d_name, '.');
        if (!book_file_path_supported(path)) continue;
        // 显式移出书架的书不再列入；文件仍在存储卡上，随时可以重新读回书架。
        // Books the user removed stay off the shelf; the file stays on the card and reading it
        // again puts it back.
        if (hidden && shelf_hidden_read_handle(hidden, path)) continue;
        if (strlen(ent->d_name) >= sizeof(((shelf_entry_t *)0)->name) ||
            st.st_size < 0 || (uint64_t)st.st_size > UINT32_MAX) { walk->skipped = true; continue; }
        if (!shelf_reserve()) { walk->truncated = true; break; }
        shelf_entry_t candidate = {0};
        shelf_entry_t *item = &candidate;
        copy_text(item->path, sizeof(item->path), path);
        if (!book_title_from_path(item->path, item->name, sizeof(item->name)))
            clean_filename(item->name, sizeof(item->name), ent->d_name);
        if (!strcasecmp(ext, ".epub")) {
            char title[sizeof(item->name)] = {0};
            char author[sizeof(item->author)] = {0};
            // Listing must stay cheap and bounded: never parse every EPUB before
            // the shelf is first painted. Opening a book populates this cache.
            // 首屏列书只读已有元数据缓存，不在封面出现前逐本解析 EPUB。
            if (book_epub_metadata_cached(item->path, title, sizeof(title), author, sizeof(author)) == ESP_OK)
                copy_text(item->author, sizeof(item->author), author);
        }
        item->search_match = shelf_search_match(item);
        item->size = st.st_size;
        item->is_flash = walk->is_flash;
        book_progress_t p;
        item->has_progress = book_progress_load(item->path, item->size, &p);
        item->pct = item->has_progress ? p.pct : 0;
        item->chapter = item->has_progress ? p.chapter : 0;
        item->recent = item->has_progress ? p.last_open_s : 0;
        item->favorite = favorites && favorite_read_handle(favorites, item->path);
        s_shelf[s_count++] = candidate;
    }
    shelf_walk_end(walk);
    return SHELF_WALK_DONE;
}
// 正式进入书架：一次跑完整根目录（输入在扫描期间仍可能触发导航，此时提前收手）。
// Real shelf entry: run a whole root to completion; navigation during the scan still stops it early.
static void scan_shelf_dir(app_ctx_t *ctx, const char *root, bool is_flash, nvs_handle_t favorites,
                           nvs_handle_t hidden, bool *truncated, bool *unreadable,
                           bool *skipped) {
    if (*truncated) return;
    shelf_walk_t walk;
    shelf_walk_begin(&walk, root, is_flash);
    while (walk.depth >= 0 && !walk.truncated)
        if (shelf_walk_step(ctx, &walk, favorites, hidden, INT_MAX, true) == SHELF_WALK_DONE) break;
    shelf_walk_end(&walk);
    *truncated |= walk.truncated;
    *unreadable |= walk.unreadable;
    *skipped |= walk.skipped;
}

// 阅读过的书即使不在书根目录内也要上书架：文件管理可以直接打开存储卡任意位置的 TXT/EPUB，
// 这些书以前读完就消失了。文件已删除或内容已被替换的记录不上架，与进度不可恢复的口径一致。
// A book that was read belongs on the shelf even outside the book roots, because the file
// manager can open a TXT or EPUB anywhere on the card. Records whose file is gone, or whose
// contents were replaced, stay off the shelf, matching the rule that changed sizes never resume.
typedef struct {
    nvs_handle_t favorites;
    nvs_handle_t hidden;
    bool truncated;
} shelf_backfill_t;

static bool shelf_backfill_visit(const char* path, const book_progress_t* progress, void* ctx) {
    shelf_backfill_t* scan = ctx;
    if (scan->truncated) return false;
    // 历史可能来自其他固件；只补入当前阅读器支持的真实文件格式。
    // History may come from another firmware; admit only file formats this reader supports.
    if (!book_file_path_supported(path)) return true;
    for (int i = 0; i < s_count; ++i)
        if (!strcmp(s_shelf[i].path, path)) return true;   // 书根目录已经收录
    struct stat st;
    if (stat(path, &st) != 0 || !S_ISREG(st.st_mode) || st.st_size < 0 ||
        (uint64_t)st.st_size > UINT32_MAX || (uint32_t)st.st_size != progress->file_size)
        return true;
    if (scan->hidden && shelf_hidden_read_handle(scan->hidden, path)) return true;
    const char* base = strrchr(path, '/');
    base = base ? base + 1 : path;
    if (strlen(base) >= sizeof(((shelf_entry_t*)0)->name)) return true;
    if (!shelf_reserve()) { scan->truncated = true; return false; }
    shelf_entry_t candidate = {0};
    shelf_entry_t* item = &candidate;
    copy_text(item->path, sizeof(item->path), path);
    if (!book_title_from_path(item->path, item->name, sizeof(item->name)))
        clean_filename(item->name, sizeof(item->name), base);
    if (!item->name[0]) return true;
    const char* ext = strrchr(base, '.');
    if (ext && !strcasecmp(ext, ".epub") && pico_boot_asset_allowed(item->path)) {
        char title[sizeof(item->name)] = {0};
        char author[sizeof(item->author)] = {0};
        if (book_epub_metadata_cached(item->path, title, sizeof(title), author, sizeof(author)) == ESP_OK)
            copy_text(item->author, sizeof(item->author), author);
    }
    item->size = (uint32_t)st.st_size;
    // 内置书根固定在 /flash 下，与 book_store.c 和 open_book 的前缀判断一致。
    // The internal root lives under /flash, matching the prefix test in book_store.c and open_book.
    item->is_flash = !strncmp(path, "/flash/", 7);
    item->has_progress = true;
    item->pct = progress->pct;
    item->chapter = progress->chapter;
    item->recent = progress->last_open_s;
    item->search_match = read_pico_search_match(item->name, s_query);
    item->favorite = scan->favorites && favorite_read_handle(scan->favorites, item->path);
    s_shelf[s_count++] = candidate;
    return true;
}

// 把书根目录之外读过的书补进书架，返回是否新增了条目。
// 阅读只写进度、不动存储版本，所以缓存复用的路径也必须调用它，否则刚读完的书要等手动重扫。
// Backfill books read outside the roots and report whether anything was added. Reading only
// writes progress and never bumps the store revision, so the cached path has to call this too
// or a freshly read book stays invisible until a manual rescan.
static bool shelf_backfill_read_books(bool* truncated) {
    nvs_handle_t favorites = 0;
    nvs_handle_t hidden = 0;
    (void)nvs_open("rp_favs", NVS_READONLY, &favorites);
    (void)nvs_open(SHELF_HIDDEN_NS, NVS_READONLY, &hidden);
    const int before = s_count;
    shelf_backfill_t backfill = {.favorites = favorites, .hidden = hidden};
    (void)book_progress_list_cached(shelf_backfill_visit, &backfill);
    if (favorites) nvs_close(favorites);
    if (hidden) nvs_close(hidden);
    if (truncated && backfill.truncated) *truncated = true;
    return s_count != before;
}

// 扫描会话：开始（准备根目录与进度缓存）→ 逐根目录遍历 → 收尾（排序、补历史、写缓存标记）。
// 正式进入书架时一次跑完三步；首页空闲预热只把中间的遍历拆成多次推进，收尾语义完全相同，
// 因此预热完成后的缓存与正常扫描得到的缓存等价，进入书架可直接复用。
// A scan session: begin (roots + progress cache), walk each root, then finish (sort, backfill,
// cache markers). Real shelf entry runs all three in one call; home-idle prewarm only splits the
// walk into budgeted steps, and its finish is the same code, so a prewarmed cache is equivalent
// to a normal scan's and can be reused as-is.
typedef struct {
    uint32_t progress_revision;
    book_store_root_t roots[BOOK_STORE_ROOT_MAX];
    int root_count;
    nvs_handle_t favorites, hidden;
    bool truncated, unreadable, skipped;
} shelf_scan_ctx_t;

static void scan_shelf_begin(shelf_scan_ctx_t *scan) {
    memset(scan, 0, sizeof(*scan));
    scan->progress_revision = book_progress_revision();
    // 一次遍历读入进度，后面逐本查表；书多时省掉成百次 nvs_open。
    // Load progress once for the whole scan instead of one nvs_open per book.
    book_progress_cache_prepare();
    shelf_category_init();
    for (int i = 2; i < s_category_count; ++i) s_categories[i].available = false;
    s_count = 0;
    s_visible_count = 0;
    s_message[0] = 0;
    s_shelf_warning[0] = 0;
    // 内置分区每次启动都必须重新挂载；已有文件不会因此格式化。
    // Flash mounts on each boot; existing files are not formatted by that mount.
    esp_err_t root_err = book_store_roots(scan->roots, &scan->root_count);
    scan->unreadable = root_err != ESP_OK || book_store_roots_degraded();
    (void)nvs_open("rp_favs", NVS_READONLY, &scan->favorites);
    (void)nvs_open(SHELF_HIDDEN_NS, NVS_READONLY, &scan->hidden);
    s_storage[0] = 0;
}
static void scan_shelf_close_handles(shelf_scan_ctx_t *scan) {
    if (scan->favorites) nvs_close(scan->favorites);
    if (scan->hidden) nvs_close(scan->hidden);
    scan->favorites = 0;
    scan->hidden = 0;
}
// 容量摘要只在第一个根、内置根以及紧跟内置根之后的那个根上追加。
// The capacity summary is appended only for the first root, the flash root and the one right after it.
static void scan_shelf_note_storage(const shelf_scan_ctx_t *scan, int index) {
    if (index < 0 || index >= scan->root_count) return;
    if (index != 0 && !scan->roots[index].is_flash && !scan->roots[index - 1].is_flash) return;
    char capacity[64];
    snprintf(capacity, sizeof(capacity), "%s%s %.1f MB", s_storage[0] ? " · " : "",
             scan->roots[index].is_flash ? "内置余" : "TF余",
             book_store_free_bytes(&scan->roots[index]) / 1048576.0);
    strncat(s_storage, capacity, sizeof(s_storage) - strlen(s_storage) - 1);
}
static void scan_shelf_finish(app_ctx_t* ctx, shelf_scan_ctx_t *scan) {
    const bool truncated = scan->truncated, unreadable = scan->unreadable, skipped = scan->skipped;
    if (ctx->request_app) {
        scan_shelf_close_handles(scan);
        book_progress_cache_release();
        s_shelf_cache_valid = false; s_scan_pending = true;
        return;
    }
    // 同路径重新出现也先完成旧清理，避免新阅读进度被后续重试擦掉。
    // Finish old cleanup even if the path reappears, before new reading can create progress.
    for (delete_retry_t* p = s_delete_retries; p; p = p->next) {
        int i = 0;
        while (i < s_count && strcmp(s_shelf[i].path, p->entry.path)) ++i;
        if (i == s_count) {
            if (!shelf_reserve()) { scan->truncated = true; continue; }
            ++s_count;
        }
        s_shelf[i] = p->entry;
        s_shelf[i].selected = false;
        s_shelf[i].search_match = shelf_search_match(&s_shelf[i]);
    }
    scan_shelf_close_handles(scan);
    // 补齐书根目录之外读过的书；显式移出书架的除外。
    // Backfill books read outside the roots, minus the ones removed from the shelf.
    (void)shelf_backfill_read_books(&scan->truncated);
    shelf_categories_recount();
    sort_shelf(ctx);
    if (s_view==SHELF) shelf_category_restore(ctx);
    s_latest_path[0] = 0;
    char last_path[BOOK_STORE_PATH_MAX];
    if (book_progress_last_path(last_path, sizeof(last_path))) {
        for (int i = 0; i < s_count; ++i) {
            if (!strcmp(s_shelf[i].path, last_path) && !s_shelf[i].removed) {
                copy_text(s_latest_path, sizeof(s_latest_path), last_path);
                break;
            }
        }
    }
    if (!scan->root_count) copy_text(s_storage, sizeof(s_storage), "存储不可用，请检查 TF 卡");
    if (truncated || scan->truncated)
        snprintf(s_shelf_warning, sizeof(s_shelf_warning), "内存不足，仅列 %d 本；释放后重扫", s_count);
    else if (unreadable) copy_text(s_shelf_warning, sizeof(s_shelf_warning), "部分目录或文件不可读，请检查后重扫");
    else if (skipped) copy_text(s_shelf_warning, sizeof(s_shelf_warning), "部分文件过大或名称过长，未列入");
    else if (s_pending_invalidated) copy_text(s_shelf_warning, sizeof(s_shelf_warning), "图书已更新，旧待保存进度已作废");
    if (!s_count && !unreadable && !truncated) copy_text(s_message, sizeof(s_message), "暂无图书，请传入 TXT、EPUB 或 Markdown");
    read_pico_sd_info_t cache_sd = {0};
    read_pico_sd_get_info(&cache_sd);
    s_cache_sd_present = cache_sd.present;
    s_cache_sd_mounted = cache_sd.mounted;
    s_cache_shelf_style = app_settings_shelf_style();
    s_store_revision = book_store_revision();
    s_progress_revision = scan->progress_revision;
    // SD 根目录的书需要卡仍挂载；只有内置书时不受卡影响。/ SD-rooted books need a mounted card; flash-only shelves do not.
    const bool sd_roots = scan->root_count > 0 && !scan->roots[0].is_flash;
    s_shelf_cache_valid = !unreadable && !truncated && !scan->truncated &&
                          (!sd_roots || (cache_sd.present && cache_sd.mounted));
    book_progress_cache_release();
    ESP_LOGD(TAG, "shelf books=%d roots=%d", s_count, scan->root_count);
}

static void scan_shelf(app_ctx_t* ctx) {
    shelf_scan_ctx_t scan;
    scan_shelf_begin(&scan);
    for (int i = 0; i < scan.root_count; ++i) {
        scan_shelf_note_storage(&scan, i);
        if (s_view == SHELF && app_poll_main_navigation(ctx)) break;
        scan_shelf_dir(ctx, scan.roots[i].path, scan.roots[i].is_flash, scan.favorites, scan.hidden,
                       &scan.truncated, &scan.unreadable, &scan.skipped);
    }
    scan_shelf_finish(ctx, &scan);
}

/* ---- 首页空闲的书架预热 / Home-idle shelf prewarm ---- */
// 首页空闲时用零碎时间把书目扫完、把首屏封面解码进 SD 缓存。所有步骤都按预算推进，
// 触摸、翻页或切页立刻让路；真正进入书架时若缓存完整就直接复用，不完整的部分安全回退到
// 正常扫描。看书（含阅读上下文尚未释放）时绝不运行，避免和正文抢 SD 与 PSRAM。
// Home-idle prewarm spends spare cycles finishing the shelf listing and decoding the first
// screen's covers into the SD cache. Every step is budgeted and yields immediately to touch, page
// changes or navigation; a complete cache is reused by the real shelf entry, anything else falls
// back to the normal scan. It never runs while a book is open (even with the reader context still
// retained), so it cannot compete with the body for SD or PSRAM.
#define SHELF_PREWARM_ENTRIES 8
#define SHELF_PREWARM_GAP_MS 40
typedef enum {
    SHELF_PREWARM_IDLE,
    SHELF_PREWARM_SCAN,
    SHELF_PREWARM_COVERS,
} shelf_prewarm_phase_t;
static struct {
    shelf_prewarm_phase_t phase;
    int64_t next_ms;
    shelf_scan_ctx_t scan;
    shelf_walk_t walk;
    int root_index;
    bool walk_active;
    unsigned cover_generation;
    unsigned cover_pending;
    int cover_row, cover_rows;
} s_shelf_prewarm;
// 上一轮预热完成时的状态签名：状态没变就不再重复扫描/解封面，避免首页空闲时周期性重做。
// State signature of the last completed prewarm round: unchanged state means no repeat scan or
// cover decode, so an idle home page never redoes finished work every tick.
static uint32_t s_shelf_prewarm_done_sig;
// 完成但缓存仍不可用（例如卡不可读）时的重试时间：失败不该每个空闲 tick 重来一遍。
// Retry time for a completed round whose cache is still unusable (e.g. an unreadable card): a
// failure must not be repeated on every idle tick.
static int64_t s_shelf_prewarm_retry_ms;
static uint32_t shelf_prewarm_state_sig(void) {
    uint32_t sig = 2166136261u;
#define SHELF_PREWARM_MIX(v) (sig = (sig ^ (uint32_t)(v)) * 16777619u)
    SHELF_PREWARM_MIX(book_store_revision());
    SHELF_PREWARM_MIX((uint32_t)app_settings_shelf_style());
    SHELF_PREWARM_MIX((uint32_t)(app_settings_main_fast_refresh() ? 1 : 0));
    SHELF_PREWARM_MIX((uint32_t)app_settings_system_contrast());
#undef SHELF_PREWARM_MIX
    return sig ? sig : 1u;
}

// 首屏行数：当前书架样式一页的封面数（网格 9，列表 4）。
// First-screen rows: covers per page in the current shelf style (nine in the grid, four in the list).
static int shelf_prewarm_first_rows(void) {
    int rows = app_settings_shelf_style() == 5 ? 4 : BOOK_GRID_ROWS;
    if (s_visible_count < rows) rows = s_visible_count;
    if (rows < 0) rows = 0;
    return rows;
}
// 与 row_rect / shelf_cover_image 的首屏几何一致（不依赖当前 s_view，允许从首页调用）。
// Same first-screen geometry as row_rect / shelf_cover_image, without relying on the current s_view,
// so it can be called from the home page.
static EpdRect shelf_prewarm_cover_image(int row) {
    if (app_settings_shelf_style() == 5)
        return (EpdRect){71, 184 + row * 197 + (197 - 156) / 2, 120, 156};
    const int cell = (ui_content_width() - 2 * UI_GAP) / 3;
    const int col = row % 3;
    return (EpdRect){UI_MARGIN + col * (cell + UI_GAP) + (cell - 164) / 2,
                     192 + (row / 3) * 282, 164, 214};
}
// 提交一本首屏书的封面解码；结果像素在本轮收取后立即释放，只保留后台写出的 SD 缓存。
// Submit one first-screen cover decode; the pixels are freed when taken and only the SD cache the
// worker writes is retained.
static bool shelf_prewarm_submit_cover(int row) {
    if (!s_shelf || row < 0 || row >= s_visible_count || row >= s_count) return false;
    const shelf_entry_t *item = &s_shelf[row];
    if (item->removed) return false;
    const bool list = app_settings_shelf_style() == 5;
    const bool fast = app_settings_main_fast_refresh();
    const EpdRect image = shelf_prewarm_cover_image(row);
    book_cover_job_t request = {.list = list, .fast = fast,
        .width = fast ? (unsigned)image.width : BOOK_COVER_W,
        .height = fast ? (unsigned)image.height : BOOK_COVER_H,
        .stride = SHELF_FAST_COVER_STRIDE, .contrast = app_settings_system_contrast(),
        .phase = (image.x & 3) | ((image.y & 3) << 2), .x = image.x, .y = image.y};
    copy_text(request.path, sizeof(request.path), item->path);
    copy_text(request.title, sizeof(request.title), item->name);
    copy_text(request.author, sizeof(request.author), item->author);
    return book_cover_jobs_submit(s_shelf_prewarm.cover_generation, (unsigned)row, &request);
}
// 释放预热状态：取消封面任务、关闭目录句柄、释放进度缓存；扫描未完成时让缓存失效，
// 真正进入书架会走正常扫描（安全回退）。
// Release prewarm state: cancel covers, close directory handles and the progress cache. An
// unfinished scan invalidates the cache so the real shelf entry falls back to a normal scan.
static void shelf_prewarm_release(void) {
    if (s_shelf_prewarm.cover_generation) {
        book_cover_jobs_cancel(s_shelf_prewarm.cover_generation);
        s_shelf_prewarm.cover_generation = 0;
    }
    if (s_shelf_prewarm.walk_active) {
        shelf_walk_end(&s_shelf_prewarm.walk);
        s_shelf_prewarm.walk_active = false;
    }
    if (s_shelf_prewarm.phase == SHELF_PREWARM_SCAN) {
        scan_shelf_close_handles(&s_shelf_prewarm.scan);
        book_progress_cache_release();
        s_shelf_cache_valid = false;
    }
    memset(&s_shelf_prewarm, 0, sizeof(s_shelf_prewarm));
    s_shelf_prewarm.phase = SHELF_PREWARM_IDLE;
}
static void shelf_prewarm_abort(void) {
    if (s_shelf_prewarm.phase != SHELF_PREWARM_IDLE) shelf_prewarm_release();
}
static bool shelf_prewarm_start(app_ctx_t *ctx) {
    read_pico_sd_info_t sd = {0};
    // SD 探测/挂载尚未完成时先不启动，下一轮空闲再试。
    // Wait for the SD probe/mount instead of starting against a half-initialised card.
    if (read_pico_sd_get_info(&sd) == ESP_ERR_NOT_FINISHED) return false;
    const bool cache_usable = s_shelf_cache_valid && s_shelf && s_count > 0 &&
        sd.present == s_cache_sd_present && sd.mounted == s_cache_sd_mounted &&
        s_cache_shelf_style == app_settings_shelf_style() &&
        s_store_revision == book_store_revision();
    if (cache_usable) {
        // 书目已有可用缓存：只补首屏封面，进书架时不再扫卡。
        // A usable listing exists: only warm the first-screen covers; the shelf entry then skips the scan.
        s_shelf_prewarm.phase = SHELF_PREWARM_COVERS;
        s_shelf_prewarm.cover_row = 0;
        s_shelf_prewarm.cover_rows = shelf_prewarm_first_rows();
    } else {
        scan_shelf_begin(&s_shelf_prewarm.scan);
        s_shelf_prewarm.root_index = 0;
        s_shelf_prewarm.walk_active = false;
        s_shelf_prewarm.phase = SHELF_PREWARM_SCAN;
    }
    s_shelf_prewarm.next_ms = ctx->now_ms;
    return true;
}
// 推进扫描：每次调用只给一个预算窗口，回来主循环处理输入。
// Advance the scan one budget window per call, returning to the main loop for input.
static bool shelf_prewarm_scan_step(app_ctx_t *ctx) {
    shelf_scan_ctx_t *scan = &s_shelf_prewarm.scan;
    if (s_shelf_prewarm.root_index < scan->root_count) {
        const int index = s_shelf_prewarm.root_index;
        if (!s_shelf_prewarm.walk_active) {
            scan_shelf_note_storage(scan, index);
            shelf_walk_begin(&s_shelf_prewarm.walk, scan->roots[index].path,
                             scan->roots[index].is_flash);
            s_shelf_prewarm.walk_active = true;
        }
        const int state = shelf_walk_step(ctx, &s_shelf_prewarm.walk, scan->favorites, scan->hidden,
                                          SHELF_PREWARM_ENTRIES, false);
        if (state == SHELF_WALK_BUDGET) {
            s_shelf_prewarm.next_ms = ctx->now_ms + SHELF_PREWARM_GAP_MS;
            return true;
        }
        scan->truncated |= s_shelf_prewarm.walk.truncated;
        scan->unreadable |= s_shelf_prewarm.walk.unreadable;
        scan->skipped |= s_shelf_prewarm.walk.skipped;
        shelf_walk_end(&s_shelf_prewarm.walk);
        s_shelf_prewarm.walk_active = false;
        ++s_shelf_prewarm.root_index;
        s_shelf_prewarm.next_ms = ctx->now_ms + 4;
        return true;
    }
    // 全部根目录走完：用与正常扫描相同的收尾，完成后书架缓存可直接复用。
    // All roots walked: finish exactly like the normal scan, so the shelf can reuse the cache.
    scan_shelf_finish(ctx, scan);
    s_shelf_prewarm.walk_active = false;
    if (!s_shelf_cache_valid || ctx->request_app) {
        shelf_prewarm_abort();
        return false;
    }
    s_shelf_prewarm.phase = SHELF_PREWARM_COVERS;
    s_shelf_prewarm.cover_row = 0;
    s_shelf_prewarm.cover_rows = shelf_prewarm_first_rows();
    s_shelf_prewarm.next_ms = ctx->now_ms + SHELF_PREWARM_GAP_MS;
    return true;
}
// 推进封面预热：同一时刻最多一张在解码，open_book 前的 quiesce 因此很短。
// Advance cover prewarm with at most one decode in flight, so the quiesce before open_book stays short.
static bool shelf_prewarm_cover_step(app_ctx_t *ctx) {
    if (!s_shelf_prewarm.cover_generation) {
        if (s_shelf_prewarm.cover_row >= s_shelf_prewarm.cover_rows) return false;
        s_shelf_prewarm.cover_generation = book_cover_jobs_begin();
        s_shelf_prewarm.cover_pending = 0;
    }
    for (int row = 0; row < s_shelf_prewarm.cover_rows; ++row) {
        const unsigned bit = 1u << row;
        if (!(s_shelf_prewarm.cover_pending & bit)) continue;
        book_cover_result_t result = {0};
        const int state = book_cover_jobs_take(s_shelf_prewarm.cover_generation, (unsigned)row, &result);
        if (!state) continue;
        free(result.pixels);
        s_shelf_prewarm.cover_pending &= ~bit;
    }
    if (s_shelf_prewarm.cover_pending) {
        s_shelf_prewarm.next_ms = ctx->now_ms + SHELF_PREWARM_GAP_MS;
        return true;
    }
    if (s_shelf_prewarm.cover_row < s_shelf_prewarm.cover_rows) {
        const int row = s_shelf_prewarm.cover_row++;
        const bool submitted = shelf_prewarm_submit_cover(row);
        if (submitted) s_shelf_prewarm.cover_pending |= 1u << row;
        s_shelf_prewarm.next_ms = ctx->now_ms + (submitted ? SHELF_PREWARM_GAP_MS : 4);
        return true;
    }
    // 收齐：封面的成品已由后台写进 SD 缓存，正常进入书架直接命中。
    // All taken: the worker already wrote the decoded covers into the SD cache for the shelf to hit.
    book_cover_jobs_cancel(s_shelf_prewarm.cover_generation);
    s_shelf_prewarm.cover_generation = 0;
    return false;
}
// 首页空闲调用：非阻塞、可被触摸/切页打断，看书时不运行，失败自动回退到正常扫描。
// Called from the home page while idle: non-blocking, preempted by touch or page changes, never
// runs while a book is open, and any failure falls back to the normal shelf scan.
void app_book_shelf_prewarm(app_ctx_t *ctx) {
    if (!ctx) return;
    // 只要还有打开的图书上下文（含从阅读页退回首页但未释放的情况）就不碰 SD/PSRAM；
    // 已经从阅读页退出应用时 s_text 为空，可以正常预热（此时 s_view 可能仍是 READING 的旧值）。
    // Never touch SD/PSRAM while a book context is open (including home shown with the reader
    // retained). After leaving the app from the reader s_text is NULL and prewarm may run even
    // though s_view still carries a stale READING value.
    if (s_text) { shelf_prewarm_abort(); return; }
    // 触摸/翻页只是让路，下一轮空闲继续；导航离页才放弃。
    // Touch or a page change only yields this round; leaving the page through navigation abandons it.
    if (ctx->consumed || (ctx->touch && ctx->touch->touched)) return;
    if (s_requested_open[0] || s_open_pending || ctx->request_app || ctx->request_menu ||
        ctx->request_return) {
        shelf_prewarm_abort();
        return;
    }
    if (ctx->now_ms < s_shelf_prewarm.next_ms) return;
    if (s_shelf_prewarm.phase == SHELF_PREWARM_IDLE) {
        // 上一轮完成且状态未变：无需重复劳动；缓存仍不可用时按退避时间再试。
        // The last round completed and nothing changed: no repeat work; when the cache is still
        // unusable, retry only after the backoff expires.
        if (shelf_prewarm_state_sig() == s_shelf_prewarm_done_sig &&
            (s_shelf_cache_valid || ctx->now_ms < s_shelf_prewarm_retry_ms)) return;
        (void)shelf_prewarm_start(ctx);
        return;
    }
    if (s_shelf_prewarm.phase == SHELF_PREWARM_SCAN) {
        (void)shelf_prewarm_scan_step(ctx);
        return;
    }
    if (s_shelf_prewarm.phase == SHELF_PREWARM_COVERS && !shelf_prewarm_cover_step(ctx)) {
        s_shelf_prewarm_done_sig = shelf_prewarm_state_sig();
        s_shelf_prewarm_retry_ms = s_shelf_cache_valid ? 0 : ctx->now_ms + 30000;
        shelf_prewarm_release();
    }
}

static void refresh_cached_progress(app_ctx_t* ctx) {
    const uint32_t revision=book_progress_revision();
    if(s_progress_revision==revision){if(s_view==SHELF)shelf_category_restore(ctx);return;}
    s_progress_revision=revision;
    // 目录没变也要补一次：阅读只写进度，不改存储版本，否则刚读完的书不会出现。
    // Backfill even when the listing is unchanged: reading writes progress and never bumps the
    // store revision, so a freshly read book would otherwise stay invisible until a manual rescan.
    const bool added = shelf_backfill_read_books(NULL);
    bool recent_changed = false;
    char latest[BOOK_STORE_PATH_MAX];
    if (book_progress_last_path(latest, sizeof(latest))) {
        for (int i = 0; i < s_count; ++i) {
            shelf_entry_t *item = &s_shelf[i];
            if (strcmp(item->path, latest) || item->removed) continue;
            book_progress_t progress;
            item->has_progress = book_progress_load(item->path, item->size, &progress);
            uint32_t next_recent=item->has_progress?progress.last_open_s:0;
            recent_changed=item->recent!=next_recent;
            item->pct = item->has_progress ? progress.pct : 0;
            item->chapter = item->has_progress ? progress.chapter : 0;
            item->recent = next_recent;
            copy_text(s_latest_path, sizeof(s_latest_path), latest);
            break;
        }
    }
    // 新增条目必须重排才能重算可见列表；只刷新进度时沿用原有顺序。
    // Added entries need a re-sort to recompute the visible list; a progress refresh alone
    // keeps the current order.
    if (added || (s_recent_sort && recent_changed)) { shelf_categories_recount(); sort_shelf(ctx); }
    if (s_view==SHELF) shelf_category_restore(ctx);
}
static void return_to_cached_shelf(app_ctx_t* ctx) {
    if (s_shelf_cache_valid && s_store_revision == book_store_revision()) refresh_cached_progress(ctx);
    else scan_shelf(ctx);
}

static void refresh_capacity(void) {
    book_store_root_t roots[BOOK_STORE_ROOT_MAX];
    int count = 0;
    s_storage[0] = 0;
    book_store_roots(roots, &count);
    for (int i = 0; i < count; ++i) {
        if (i && !roots[i].is_flash && !roots[i - 1].is_flash) continue;
        char line[64];
        snprintf(line, sizeof(line), "%s%s %.1f MB", s_storage[0] ? " · " : "", roots[i].is_flash ? "内置余" : "TF余", book_store_free_bytes(&roots[i]) / 1048576.0);
        strncat(s_storage, line, sizeof(s_storage) - strlen(s_storage) - 1);
    }
}
static void manage_apply(app_ctx_t* ctx) {
    if (!strcmp(s_path, s_managed.path)) free_book();
    esp_err_t err;
    if (s_delete_confirm && !s_file_removed) {
        delete_retry_t* retry = delete_retry_reserve(&s_managed);
        if (!retry) {
            copy_text(s_manage_message, sizeof(s_manage_message), "内存不足，无法保留删除重试记录");
            s_clear_confirm = false;
            return;
        }
        bool removed = false;
        err = book_store_delete(s_managed.path, &removed);
        if (removed) {
            retry->entry.removed = true;
            s_file_removed = true;
            pending_discard(s_managed.path);
            book_store_notify_changed();
            s_store_revision = book_store_revision();
            for (int i = 0; i < s_count; ++i) if (!strcmp(s_shelf[i].path, s_managed.path)) s_shelf[i].removed = true;
            refresh_capacity();
        } else delete_retry_discard(s_managed.path);
    } else {
        pending_discard(s_managed.path);
        err = book_progress_forget(s_managed.path);
    }
    s_clear_confirm = false;
    if (err != ESP_OK) {
        copy_text(s_manage_message, sizeof(s_manage_message), s_file_removed ?
                  "文件已删除，进度清理失败，请重试" : s_delete_confirm ?
                  "文件删除失败，请检查存储后重试" : "进度清理失败，请重新尝试");
        return;
    }
    delete_retry_discard(s_managed.path);
    s_view = SHELF;
    int write = 0, leaf = ctx->leaf;
    for (int i = 0; i < s_count; ++i) {
        if (!strcmp(s_shelf[i].path, s_managed.path)) {
            if (s_file_removed) continue;
            s_shelf[i].has_progress = false; s_shelf[i].pct = 0; s_shelf[i].chapter = 0; s_shelf[i].recent = 0;
        }
        s_shelf[write++] = s_shelf[i];
    }
    s_count = write;
    sort_shelf(ctx);
    ctx->leaf = leaf < leaves() ? leaf : leaves() - 1;
}

/* ---- 输入与生命周期 / Input and lifecycle ---- */

static bool reader_turn_chrome(app_ctx_t *ctx) {
    bool changed = !s_reader_fullscreen || s_toolbar;
    if (!s_reader_fullscreen) (void)toggle_reader_fullscreen(ctx);
    s_reader_panel = READER_PANEL_NONE;
    s_reader_slider = -1;
    if (changed) { invalidate_prep(); s_reader_text_frame = false; }
    return changed;
}
static app_redraw_t turn_page(app_ctx_t* ctx, int dir) {
    if (!s_text || s_clear_confirm) return APP_REDRAW_NONE;
    // 翻页/换章后旧的缩放现场不再代表当前画面，先整体收尾再动页码。
    // A turn or chapter change invalidates the zoom context; tear it down before moving pages.
    reader_zoom_reset();
    // 页面图片表可能随跨章加载替换，旧页资格以实际成功显示的画面为准。
    // Chapter loads may replace the image table; the old-page eligibility comes from the displayed frame.
    bool from_text_frame = s_reader_text_frame;
    bool changed = true;
    if (dir > 0 && s_page + 1 < book_layout_page_count()) ++s_page;
    else if (dir < 0 && s_page) --s_page;
    else if (dir > 0 && s_chapter + 1 < book_chapter_count()) { save_progress(); changed = load_chapter(ctx, s_chapter + 1, 0, false); }
    else if (dir < 0 && s_chapter) { save_progress(); changed = load_chapter(ctx, s_chapter - 1, 0, true); }
    else return reader_turn_chrome(ctx) ? APP_REDRAW_PAGE : APP_REDRAW_NONE;
    if (!changed) { set_reader_view(s_text ? TOC : SHELF); ctx->leaf = s_text ? s_chapter / BOOK_TOC_ROWS : 0; return APP_REDRAW_PAGE; }
    s_turn_dir = dir > 0 ? 1 : -1;
    // 真正翻页后旋转锚点失效：下一次旋转应以新页首为基准。
    // A real page turn invalidates the rotation anchor; the next rotation anchors on the new page.
    reader_anchor_invalidate();
    skip_hidden_image_pages(ctx, dir);
    if (!s_text) { s_view = SHELF; return APP_REDRAW_PAGE; }
    // 先选择旧布局的目标页，再切全屏，保留目标位置而不是跨过未读段落。
    // Choose the destination in the old layout first, then reflow to retain its reading position.
    bool chrome_changed = reader_turn_chrome(ctx);
    if (!s_text) return APP_REDRAW_PAGE;
    s_jump_offset = SIZE_MAX;
    s_last_turn_ms = s_stats_activity_ms = ctx->now_ms;
    ++s_stats_pending_turns;
    ++s_session_turns;
    uint8_t full_pages = app_settings_reader_full_pages();
    if (full_pages) ++s_turns;
    else s_turns = 0;
    s_reader_cleanup = full_pages > 0 && s_turns >= full_pages;
    if (s_reader_cleanup) s_turns = 0;
    if (s_unsaved < 8) ++s_unsaved;
    if (s_unsaved >= 8 && !s_save_failed) save_progress();
    ESP_LOGD(TAG, "turn chapter=%u page=%u/%u pct=%u", (unsigned)s_chapter, (unsigned)s_page + 1, (unsigned)book_layout_page_count(), percent(s_page));
    // 预渲染未命中时也使用 GL16；到达设定页数后在本次翻页整屏全刷。
    // A cache miss still uses GL16; the selected turn count triggers a full-screen refresh on this turn.
    app_redraw_t redraw = paint_reading(ctx, MODE_GL16);
    // 横屏下这两条自动翻页路径的条带是按竖屏扫描几何标定的（条带沿物理 y），
    // 换到横屏会落在物理 x 上，实测只刷新部分画面；横屏改走整幅 GL16 差分。
    // Both turn paths are calibrated for the portrait scan geometry (bands along physical y);
    // in landscape they land on physical x and only part of the canvas refreshed, so landscape
    // takes the plain full-canvas GL16 differential instead.
    const bool turn_paths = !s_reader_landscape;
    s_reader_turn_pending = turn_paths && !chrome_changed && redraw == APP_REDRAW_AREA &&
        from_text_frame && book_layout_page_image_count(s_page) == 0 &&
        !app_settings_book_background_path()[0];
    // The ripple is back in landscape: its bands follow the physical axis through
    // uses_line_phase()/phys_to_logical() and now cover the whole canvas.
    s_water_turn_pending = !chrome_changed && redraw == APP_REDRAW_AREA &&
        !s_reader_cleanup && app_settings_reader_turn_effect() >= 2 && from_text_frame &&
        book_layout_page_image_count(s_page) == 0 && !app_settings_book_background_path()[0];
    s_water_turn_dir = dir > 0 ? E0470_TURN_RTL : E0470_TURN_LTR;
    return chrome_changed ? APP_REDRAW_PAGE : redraw;
}
static app_redraw_t resize_text(app_ctx_t* ctx, int dir) {
    int next = s_px + dir * BOOK_PX_STEP;
    if (next < BOOK_PX_MIN || next > BOOK_PX_MAX) return APP_REDRAW_NONE;
    size_t off = book_layout_page_start_offset(s_page);
    lock_draw();
    invalidate_prep();
    reader_anchor_invalidate();
    int old = s_px;
    if (!book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), next)) {
        bool restored = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), old);
        unlock_draw();
        if (!restored) {
            free_book();
            s_view = SHELF;
            copy_text(s_message, sizeof(s_message), "排版失败，请重新扫描并打开图书");
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    s_px = next;
    s_page = book_layout_page_for_offset(off);
    unlock_draw();
    app_settings_set_book_px(s_px);
    save_progress();
    return paint_reading(ctx, MODE_DU);
}

static app_redraw_t apply_reader_layout(app_ctx_t* ctx, int next_px, int next_margin,
                                        int next_margin_v, uint8_t next_line, uint8_t next_para) {
    (void)ctx;
    if (next_px < BOOK_PX_MIN || next_px > BOOK_PX_MAX ||
        next_margin < BOOK_MARGIN_MIN || next_margin > BOOK_MARGIN_MAX ||
        next_margin_v < 0 || next_margin_v > 48 ||
        next_line < 100 || next_line > 150 ||
        app_settings_book_paragraph_value(app_settings_book_paragraph_level(next_para)) != next_para) return APP_REDRAW_NONE;
    if (next_px == s_px && next_margin == s_margin && next_margin_v == s_margin_v &&
        next_line == app_settings_book_line_spacing() &&
        next_para == app_settings_book_paragraph_spacing()) return APP_REDRAW_NONE;
    size_t off = book_layout_page_start_offset(s_page);
    int old_px = s_px, old_margin = s_margin, old_margin_v = s_margin_v;
    uint8_t old_line = app_settings_book_line_spacing();
    uint8_t old_para = app_settings_book_paragraph_spacing();
    lock_draw();
    invalidate_prep();
    reader_anchor_invalidate();
    s_px = next_px;
    s_margin = next_margin;
    // 先落地上下边距再重排，body_rect() 才会带上新值。
    // Publish the vertical margin before reflow so body_rect() sees the new value.
    s_margin_v = next_margin_v;
    s_line_spacing = next_line;
    book_layout_set_spacing(next_line, next_para);
    // 正文带随字号与边距变了，题头的预留跟着重算。
    // The body band moved with the size and margin, so the heading's reservation follows.
    refresh_chapter_lead();
    bool ok = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    if (ok) s_page = book_layout_page_for_offset(off);
    else {
        s_px = old_px;
        s_margin = old_margin;
        s_margin_v = old_margin_v;
        s_line_spacing = old_line;
        book_layout_set_spacing(old_line, old_para);
        refresh_chapter_lead();
        (void)book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    }
    unlock_draw();
    if (!ok) return APP_REDRAW_NONE;
    app_settings_set_book_px((uint8_t)s_px);
    app_settings_set_book_margin((uint8_t)s_margin);
    app_settings_set_book_margin_v((uint8_t)s_margin_v);
    app_settings_set_book_line_spacing(next_line);
    app_settings_set_book_paragraph_spacing(next_para);
    // 字号/边距变了：Markdown 表格要按新指标重解析，但触摸回调栈太深，这里只登记重排前的
    // 页首偏移，由下一轮 on_tick 的浅栈执行并统一推屏；TXT/EPUB 立即返回整页刷新（行为不变）。
    // Size/margins changed: Markdown tables must be re-parsed, but the touch callback stack is too
    // deep, so only record the pre-layout offset for on_tick to run on its shallow stack and present
    // once; TXT/EPUB return a page refresh immediately, exactly as before.
    save_progress();
    if (book_kind() == BOOK_KIND_MARKDOWN) {
        reader_md_reload_request(off);
        return APP_REDRAW_NONE;
    }
    return APP_REDRAW_PAGE;
}

static app_redraw_t apply_reader_typography(app_ctx_t* ctx, int tracking_index) {
    (void)ctx;
    if (!s_text || tracking_index < 0 || tracking_index >= APP_BOOK_TRACK_COUNT)
        return APP_REDRAW_NONE;
    int old_index = app_settings_book_tracking();
    if (tracking_index == old_index) return APP_REDRAW_NONE;
    size_t off = book_layout_page_start_offset(s_page);
    lock_draw();
    invalidate_prep();
    reader_anchor_invalidate();
    book_layout_set_typography((tracking_index + APP_BOOK_TRACK_MIN));
    bool ok = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count,
                                       body_rect_for_tracking(tracking_index), s_px);
    if (ok) s_page = book_layout_page_for_offset(off);
    else {
        book_layout_set_typography(old_index + APP_BOOK_TRACK_MIN);
        (void)book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    }
    unlock_draw();
    if (!ok) return APP_REDRAW_NONE;
    // 先持久化字距：load_chapter_at 里的 book_md_set_metrics 读 app_settings_book_tracking()，
    // 顺序反了表格会仍按旧字距成形。Markdown 的重解析登记给 on_tick（触摸回调栈太深）。
    // Persist tracking first: book_md_set_metrics inside load_chapter_at reads
    // app_settings_book_tracking(), so the reverse order would bake the old tracking. The Markdown
    // re-parse is registered for on_tick because the touch callback stack is too deep.
    app_settings_set_book_tracking((uint8_t)tracking_index);
    save_progress();
    if (book_kind() == BOOK_KIND_MARKDOWN) {
        reader_md_reload_request(off);
        return APP_REDRAW_NONE;
    }
    return APP_REDRAW_PAGE;
}

static app_redraw_t apply_reader_indent(app_ctx_t* ctx, int em, int adjustment) {
    (void)ctx;
    if (!s_text || em < 0 || em > 3 || adjustment < -100 || adjustment > 100 ||
        (em == app_settings_book_indent() && adjustment == app_settings_book_indent_adjust()))
        return APP_REDRAW_NONE;
    size_t off = book_layout_page_start_offset(s_page);
    uint8_t old_em = app_settings_book_indent();
    int old_adjustment = app_settings_book_indent_adjust();
    lock_draw();
    invalidate_prep();
    reader_anchor_invalidate();
    book_layout_set_first_line_indent((unsigned)em);
    book_layout_set_first_line_indent_adjust(adjustment);
    bool ok = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    if (ok) s_page = book_layout_page_for_offset(off);
    else {
        book_layout_set_first_line_indent(old_em);
        book_layout_set_first_line_indent_adjust(old_adjustment);
        (void)book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    }
    unlock_draw();
    if (!ok) return APP_REDRAW_NONE;
    app_settings_set_book_indent((uint8_t)em);
    app_settings_set_book_indent_adjust((int8_t)adjustment);
    // 缩进不改表格列宽，但表格块与正文共用同一套坐标口径；Markdown 的重解析登记给 on_tick
    // （触摸回调栈太深），避免表格行缩进与新正文坐标错位。
    // Indent does not change table column widths, but table blocks share the body coordinate model;
    // the Markdown re-parse is registered for on_tick (deep touch stack) so table rows stay aligned.
    save_progress();
    if (book_kind() == BOOK_KIND_MARKDOWN) {
        reader_md_reload_request(off);
        return APP_REDRAW_NONE;
    }
    return APP_REDRAW_PAGE;
}

static app_redraw_t reader_indent_finish(app_ctx_t *ctx,bool commit) {
    int value=s_indent_hold.value;
    bool valid=commit&&!s_indent_hold.cancelled;
    reader_indent_hold_cancel();
    if(valid){
        app_redraw_t redraw=apply_reader_indent(ctx,app_settings_book_indent(),value);
        if(redraw!=APP_REDRAW_NONE)return redraw;
    }
    return reader_indent_feedback(ctx);
}
static app_redraw_t reader_indent_gesture(app_ctx_t *ctx,const ui_gesture_event_t *ev,bool *handled) {
    *handled=false;
    if(s_view!=READING||s_reader_panel!=READER_PANEL_LAYOUT_SETTINGS||s_clear_confirm){reader_indent_hold_cancel();return APP_REDRAW_NONE;}
    if(ev->type==UI_GESTURE_PRESS){
        reader_indent_hold_cancel();int control=indent_adjust_hit(ev->x0,ev->y0);
        if(control<0||ctx->consumed||ctx->now_ms<0)return APP_REDRAW_NONE;
        s_indent_hold.active=true;s_indent_hold.control=control;s_indent_hold.value=app_settings_book_indent_adjust();
        s_indent_hold.last_ms=ctx->now_ms;s_indent_hold.next_ms=ctx->now_ms+UI_LONG_PRESS_MS;
        s_reader_tap.pending=false;s_pressed_control=-1;*handled=true;
        return reader_indent_feedback(ctx);
    }
    if(!s_indent_hold.active)return APP_REDRAW_NONE;
    *handled=true;
    bool inside=indent_adjust_hit(ev->x,ev->y)==s_indent_hold.control;
    if(ctx->consumed||!inside||ctx->now_ms<s_indent_hold.last_ms){
        s_indent_hold.cancelled=true;
        if(ev->type==UI_GESTURE_TAP||ev->type==UI_GESTURE_CANCEL||ctx->released)return reader_indent_finish(ctx,false);
        return reader_indent_feedback(ctx);
    }
    if(ev->type==UI_GESTURE_TAP){
        if(!s_indent_hold.repeated){
            int next=s_indent_hold.control==1?0:s_indent_hold.value+(s_indent_hold.control==0?-1:1);
            s_indent_hold.value=next<-100?-100:next>100?100:next;
        }
        return reader_indent_finish(ctx,true);
    }
    if(ev->type==UI_GESTURE_CANCEL){
        bool released=ctx->released&&ctx->touch&&!ctx->touch->touched;
        return reader_indent_finish(ctx,released);
    }
    if(ev->type==UI_GESTURE_SWIPE_L||ev->type==UI_GESTURE_SWIPE_R||ev->type==UI_GESTURE_SWIPE_U||ev->type==UI_GESTURE_SWIPE_D)return reader_indent_finish(ctx,false);
    return APP_REDRAW_NONE;
}
static app_redraw_t reader_indent_hold_tick(app_ctx_t *ctx) {
    if(!s_indent_hold.active)return APP_REDRAW_NONE;
    if(s_view!=READING||s_reader_panel!=READER_PANEL_LAYOUT_SETTINGS||s_clear_confirm||ctx->request_app||ctx->request_menu||ctx->request_return){reader_indent_hold_cancel();return APP_REDRAW_NONE;}
    if(s_indent_hold.cancelled)return APP_REDRAW_NONE;
    bool held=!ctx->released&&ctx->touch&&ctx->touch->touched&&ctx->touch->count==1;
    // 触摸在横屏仍报竖屏逻辑坐标；这里直接读原始触摸，必须先映射再判定还在不在控件内。
    // Touch still reports portrait logical coordinates in landscape; map the raw sample before the
    // hold test so the finger does not "leave" its control.
    int hold_x = ctx->touch ? (int)ctx->touch->x : 0, hold_y = ctx->touch ? (int)ctx->touch->y : 0;
    if (reader_touch_needs_map()) reader_touch_map(&hold_x, &hold_y);
    if(!held||ctx->now_ms<s_indent_hold.last_ms||indent_adjust_hit(hold_x,hold_y)!=s_indent_hold.control){
        s_indent_hold.cancelled=true;return reader_indent_feedback(ctx);
    }
    if(ctx->consumed)return APP_REDRAW_NONE;
    s_indent_hold.last_ms=ctx->now_ms;
    if(s_indent_hold.control==1||ctx->now_ms<s_indent_hold.next_ms)return APP_REDRAW_NONE;
    // 推屏慢时不补发跳变，每次仍只改1px；重排和NVS写入留到松手。
    // Never catch up after slow output: retain 1px steps and defer reflow/NVS writes until release.
    s_indent_hold.next_ms=ctx->now_ms+120;s_indent_hold.repeated=true;
    int next=s_indent_hold.value+(s_indent_hold.control==0?-1:1);
    if(next<-100||next>100)return APP_REDRAW_NONE;
    s_indent_hold.value=next;ctx->user_activity=true;
    return reader_indent_feedback(ctx);
}

static app_redraw_t reader_manual_refresh(app_ctx_t* ctx) {
    (void)ctx;
    if (!s_text) return APP_REDRAW_NONE;
    s_reader_panel = READER_PANEL_NONE;
    s_reader_slider = -1;
    s_reader_footer_pending = s_reader_image_refresh_pending = false;
    s_water_turn_pending = s_reader_cleanup = false;
    s_du_count = s_turns = 0;
    invalidate_prep();
    return APP_REDRAW_FULL;
}

static app_redraw_t apply_reader_option(app_ctx_t* ctx, int kind) {
    (void)ctx;
    if (kind == 0) {
        app_settings_set_reader_power_turn(!app_settings_reader_power_turn());
        return APP_REDRAW_PAGE;
    }
    if (!s_text || kind < 1 || kind > 4) return APP_REDRAW_NONE;
    bool previous = kind == 1 ? app_settings_reader_immersive() :
                    kind == 2 ? app_settings_reader_hide_images() :
                    kind == 3 ? app_settings_reader_adaptive() : app_settings_book_vertical();
    // 重新开启插图时，先补齐尺寸；文件读取必须在绘制锁外。
    // Probe missing dimensions before re-enabling images, outside the drawing lock.
    if (kind == 2 && previous) for (size_t i = 0; i < s_block_count; ++i) {
        blk_t *block = &s_blocks[i];
        if (block->image < 0 || (size_t)block->image >= s_image_count ||
            (block->image_width && block->image_height)) continue;
        unsigned width = 0, height = 0;
        if (book_chapter_image_dimensions(s_chapter, s_images[block->image], &width, &height) == ESP_OK) {
            block->image_width = width; block->image_height = height;
        }
        vTaskDelay(1);
    }
    lock_draw();
    size_t off = book_layout_page_start_offset(s_page);
    invalidate_prep();
    reader_anchor_invalidate();
    if (kind == 1) app_settings_set_reader_immersive(!previous);
    else if (kind == 2) {
        app_settings_set_reader_hide_images(!previous);
        book_layout_set_images_visible(previous);
    } else if (kind == 4) {
        // 竖排要重排整章：列序自右向左，页界与插图分页都跟着变。用户本轮要求竖排也要能在
        // 横屏下工作，因此不再和自适应方向互斥：转屏时按新的正文框重新排一次竖排列即可。
        // Vertical text re-typesets the chapter (right-to-left columns, new page and illustration
        // breaks). The user asked for vertical text in landscape too, so it no longer excludes
        // adaptive rotation: a rotation simply re-typesets the columns in the new body rect.
        app_settings_set_book_vertical(!previous);
        book_layout_set_vertical(!previous);
    } else {
        // The adaptive switch only flips the setting; gravity owns the body orientation.
        // Turning it on invalidates the reference: the next tap is a portrait moment and
        // re-learns the device's up direction.
        if (!previous) { s_orient_ref_ready = false; s_orient_calibrate = true; }
        app_settings_set_reader_adaptive(!previous);
    }
    // 模式变了，题头预留也跟着换轴：竖排留右侧列宽、横排留顶部行高。
    // The mode changed, so the heading's reservation changes axis too: columns to the right
    // vertically, rows at the top horizontally.
    apply_chapter_lead(s_chapter_heading_title, s_chapter_heading_label, s_chapter_lead_skip,
                       s_chapter_lead_row_height);
    bool ok = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    if (ok) s_page = book_layout_page_for_offset(off);
    else {
        if (kind == 1) app_settings_set_reader_immersive(previous);
        else if (kind == 2) {
            app_settings_set_reader_hide_images(previous);
            book_layout_set_images_visible(!previous);
        } else if (kind == 4) {
            app_settings_set_book_vertical(previous);
            book_layout_set_vertical(previous);
        } else {
            app_settings_set_reader_adaptive(previous);
        }
        apply_chapter_lead(s_chapter_heading_title, s_chapter_heading_label, s_chapter_lead_skip,
                       s_chapter_lead_row_height);
        (void)book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
        copy_text(s_reader_notice, sizeof(s_reader_notice), "排版失败，请重试");
        s_reader_notice_until = esp_timer_get_time() / 1000 + 1800;
    }
    unlock_draw();
    if (ok) {
        release_page_images();
        prepare_inline_image();
        s_jump_offset = SIZE_MAX;
        save_progress();
    }
    s_reader_footer_pending = s_reader_image_refresh_pending = false;
    s_water_turn_pending = false;
    return APP_REDRAW_PAGE;
}

// 返回主页以本次开书来源为准；分类页码已在书架开书前记忆，不被目录/工具栏覆盖。
// Return to this opening's origin; shelf category/page were saved before opening, independently of TOC/tools.
static app_redraw_t reader_return(app_ctx_t *ctx) {
    save_progress();
    if (s_reader_return_home) {
        ui_nav_request(ctx, 0);
        return APP_REDRAW_NONE;
    }
    free_book();
    s_view = SHELF;
    s_reader_panel = READER_PANEL_NONE;
    return_to_cached_shelf(ctx);
    return APP_REDRAW_PAGE;
}

static app_redraw_t toggle_reader_fullscreen(app_ctx_t* ctx) {
    (void)ctx;
    if (!s_text) return APP_REDRAW_NONE;
    size_t off = book_layout_page_start_offset(s_page);
    lock_draw();
    invalidate_prep();
    reader_anchor_invalidate();
    s_reader_fullscreen = !s_reader_fullscreen;
    // 全屏切换会换掉整个正文带，题头的预留必须跟着换。
    // Toggling full screen swaps the whole body band, so the heading's reservation must follow.
    refresh_chapter_lead();
    bool ok = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    bool restored = true;
    if (ok) s_page = book_layout_page_for_offset(off);
    else {
        s_reader_fullscreen = !s_reader_fullscreen;
        refresh_chapter_lead();
        restored = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    }
    unlock_draw();
    if (!ok) {
        if (!restored) {
            free_book();
            s_view = SHELF;
            copy_text(s_message, sizeof(s_message), "排版失败，请重新扫描并打开图书");
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    release_page_images();
    prepare_inline_image();
    s_jump_offset = SIZE_MAX;
    s_reader_panel = READER_PANEL_NONE;
    save_progress();
    return APP_REDRAW_PAGE;
}

static app_redraw_t select_reading_font_item(app_ctx_t* ctx, const ttf_font_item_t* item) {
    (void)ctx;
    // 记录本次选择，换字体后由 reader_font_choice_finish() 判断是否回退到内建字体。
    // Record this choice so reader_font_choice_finish() can detect a fallback to the builtin face.
    if (item && ttf_font_path_is_builtin(item->path)) reader_font_choice_begin(item->path);
    if (!item || !strcmp(ttf_font_path(), item->path)) return APP_REDRAW_NONE;
    reader_font_choice_begin(item->path);
    char previous[TTF_FONT_PATH_MAX];
    copy_text(previous, sizeof(previous), ttf_font_path());
    if (ttf_font_open(item->path) != ESP_OK) {
        reader_font_choice_finish();
        return APP_REDRAW_PAGE;
    }
    size_t off = book_layout_page_start_offset(s_page);
    lock_draw();
    invalidate_prep();
    reader_anchor_invalidate();
    bool ok = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    if (ok) s_page = book_layout_page_for_offset(off);
    else if (previous[0]) {
        (void)ttf_font_open(previous);
        (void)book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    }
    unlock_draw();
    if (!ok) {
        reader_font_choice_finish();
        return APP_REDRAW_NONE;
    }
    app_settings_set_font_path(item->path);
    copy_text(s_font_path, sizeof(s_font_path), item->path);
    // 选好字体后确认是否真的用上了：仍回退到内建字体就累计一次，满 3 次弹重启提示。
    // Confirm the face actually loaded: still on the builtin face counts a fallback, and three
    // fallbacks bring up the restart dialog.
    reader_font_choice_finish();
    // 换字体后表格里的空格宽度要按新字面重新测量；字体页的触摸回调栈太深（曾实测溢出），
    // Markdown 的重解析登记给 on_tick，TXT/EPUB 行为不变。
    // A new face changes the table's space advances; the font-page touch callback stack is too deep
    // (measured overflow once), so the Markdown re-parse is registered for on_tick. TXT/EPUB keep
    // their old behaviour.
    save_progress();
    if (book_kind() == BOOK_KIND_MARKDOWN) {
        reader_md_reload_request(off);
        return APP_REDRAW_NONE;
    }
    return APP_REDRAW_PAGE;
}

static int slider_index(EpdRect rect, int x, int count) {
    int span = rect.width - 128;
    int pos = x - rect.x - 64;
    int index = span > 0 && count > 1 ? (pos * (count - 1) + span / 2) / span : 0;
    if (index < 0) index = 0;
    if (index >= count) index = count - 1;
    return index;
}
static int reader_margin_input(EpdRect rect, int x, int current, int px, int tracking_px) {
    int widths[BOOK_MARGIN_CHOICES], values[BOOK_MARGIN_CHOICES];
    int count = reader_margin_levels(px, tracking_px, widths, values);
    int level = reader_margin_level_for(current, px, tracking_px);
    if (x < rect.x + 64) --level;
    else if (x >= rect.x + rect.width - 64) ++level;
    else level = slider_index(rect, x, count);
    return reader_margin_for_level(level, current, px, tracking_px);
}

static EpdRect reader_slider_rect(int slider) {
    // 字号滑杆在双列字体卡片上方，绘制与拖动共用位置。/ The size rail sits above the paired cards; paint and drag share its position.
    if (slider == 0) return s_reader_landscape ? (EpdRect){20, 82, 1176, 78}
                                               : (EpdRect){36,700-reader_ui_extra(112),612,76};
    if (s_reader_landscape) {
        // 横屏排版页：边距与行距并排，段距、字间距与上下边距通栏；标签画在滑杆左侧的同一行。
        // Landscape layout sheet: margin+line pair up; paragraph, tracking and vertical margin span
        // the canvas with their labels in the free space to the left of each rail.
        if (slider == 1) return (EpdRect){20, 100, 578, 76};
        if (slider == 2) return (EpdRect){618, 100, 578, 76};
        if (slider == 3) return (EpdRect){170, 192, 1026, 76};
        if (slider == 4) return (EpdRect){170, 284, 1026, 76};
        return (EpdRect){170, 376, 1026, 76};
    }
    // 竖屏：抽屉上移到 380 后五条滑杆自上而下排开，每行之间留 54 像素给标题文字。
    // Portrait: with the drawer raised to 380 the five rails stack down the sheet, leaving 54 px
    // between rows for the adjacent captions.
    if (slider == 1) return (EpdRect){36, 500, 294, 66};
    if (slider == 2) return (EpdRect){354, 500, 294, 66};
    if (slider == 3) return (EpdRect){36, 620, 612, 66};
    if (slider == 4) return (EpdRect){36, 740, 612, 66};
    return (EpdRect){36, 860, 612, 66};
}

static int reader_slider_at(uint16_t x, uint16_t y) {
    int first = s_reader_panel == READER_PANEL_FONT_SETTINGS ? 0 : 1;
    int end = s_reader_panel == READER_PANEL_FONT_SETTINGS ? 1 : 6;
    for (int i = first; i < end; ++i) if (ui_rect_hit(reader_slider_rect(i), x, y)) return i;
    return -1;
}

static void reader_slider_map(int slider, int x) {
    if (slider == 0) s_reader_preview_px = BOOK_PX_MIN + slider_index(reader_slider_rect(0), x, BOOK_PX_MAX - BOOK_PX_MIN + 1);
    else if (slider == 1) {
        int widths[BOOK_MARGIN_CHOICES], values[BOOK_MARGIN_CHOICES];
        int count = reader_margin_levels(s_px, (app_settings_book_tracking() + APP_BOOK_TRACK_MIN), widths, values);
        s_reader_preview_margin = reader_margin_for_level(
            slider_index(reader_slider_rect(1), x, count), s_reader_preview_margin,
            s_px, (app_settings_book_tracking() + APP_BOOK_TRACK_MIN));
    }
    else if (slider == 2) s_reader_preview_line = 100 + slider_index(reader_slider_rect(2), x, 51);
    else if (slider == 3) s_reader_preview_para = app_settings_book_paragraph_value((uint8_t)slider_index(reader_slider_rect(3), x, APP_BOOK_PARAGRAPH_COUNT));
    else if (slider == 4) s_reader_preview_tracking = slider_index(reader_slider_rect(4), x, APP_BOOK_TRACK_COUNT);
    // 上下边距 9 档，每档 6 像素，0..48。
    // The vertical margin has nine 6-px stops spanning 0..48.
    else if (slider == 5) s_reader_preview_margin_v = 6 * slider_index(reader_slider_rect(5), x, 9);
}

static void reader_slider_begin(int slider, int x) {
    s_reader_slider = slider;
    s_reader_preview_px = s_px;
    s_reader_preview_margin = s_margin;
    s_reader_preview_margin_v = s_margin_v;
    s_reader_preview_line = app_settings_book_line_spacing();
    s_reader_preview_para = app_settings_book_paragraph_spacing();
    s_reader_preview_tracking = app_settings_book_tracking();
    EpdRect rect = reader_slider_rect(slider);
    int *value = slider == 0 ? &s_reader_preview_px : slider == 1 ? &s_reader_preview_margin :
                 slider == 2 ? &s_reader_preview_line : slider == 3 ? &s_reader_preview_para :
                 slider == 4 ? &s_reader_preview_tracking : &s_reader_preview_margin_v;
    s_reader_slider_endpoint = x < rect.x + 64 || x >= rect.x + rect.width - 64;
    if (slider == 1) {
        *value = reader_margin_input(rect, x, *value, s_px, (app_settings_book_tracking() + APP_BOOK_TRACK_MIN));
        return;
    }
    if (slider == 3) {
        int level = app_settings_book_paragraph_level((uint8_t)*value);
        if (x < rect.x + 64) --level;
        else if (x >= rect.x + rect.width - 64) ++level;
        else level = slider_index(rect, x, APP_BOOK_PARAGRAPH_COUNT);
        if (level < 0) level = 0;
        if (level >= APP_BOOK_PARAGRAPH_COUNT) level = APP_BOOK_PARAGRAPH_COUNT - 1;
        *value = app_settings_book_paragraph_value((uint8_t)level);
        return;
    }
    if (slider == 5) {
        // 仿真器滑杆 2 的写法：端点区各走一档 6 像素，拖动按 9 档吸附，再夹到 0..48。
        // Follows the line-spacing rail: each edge zone steps one 6-px stop, dragging snaps to the
        // nine stops, and the result is clamped to 0..48.
        if (x < rect.x + 64) *value -= 6;
        else if (x >= rect.x + rect.width - 64) *value += 6;
        else *value = 6 * slider_index(rect, x, 9);
        if (*value < 0) *value = 0;
        if (*value > 48) *value = 48;
        return;
    }
    int min = slider == 0 ? BOOK_PX_MIN : slider == 2 ? 100 : 0;
    int max = slider == 0 ? BOOK_PX_MAX : slider == 2 ? 150 : APP_BOOK_TRACK_COUNT - 1;
    if (x < rect.x + 64) --*value;
    else if (x >= rect.x + rect.width - 64) ++*value;
    else reader_slider_map(slider, x);
    if (*value < min) *value = min;
    if (*value > max) *value = max;
}

static void reader_slider_move(int x) {
    int slider = s_reader_slider;
    if (slider < 0) return;
    s_reader_slider_endpoint = false;
    reader_slider_map(slider, x);
}

static app_redraw_t reader_slider_commit(app_ctx_t* ctx) {
    if (s_reader_slider < 0) return APP_REDRAW_NONE;
    int slider = s_reader_slider;
    int px = s_reader_preview_px, margin = s_reader_preview_margin, line = s_reader_preview_line;
    int margin_v = s_reader_preview_margin_v;
    int para = s_reader_preview_para;
    int tracking = s_reader_preview_tracking;
    s_reader_slider = -1;
    if (slider == 4) return apply_reader_typography(ctx, tracking);
    return apply_reader_layout(ctx, px, margin, margin_v, line, (uint8_t)para);
}

static app_redraw_t reading_settings_action(app_ctx_t *ctx, uint16_t x, uint16_t y) {
    if (y < reading_settings_top() || ui_rect_hit(reading_done_rect(), x, y)) {
        s_reader_panel = READER_PANEL_NONE;
    } else if (ui_rect_hit(reading_setting_rect(0), x, y)) {
        static const uint8_t options[] = {5, 10, 15, 30, 0};
        unsigned next = 0;
        for (unsigned i = 0; i < 5; ++i)
            if (app_settings_reader_full_pages() == options[i]) { next = (i + 1) % 5; break; }
        app_settings_set_reader_full_pages(options[next]);
        s_turns = 0;
    } else if (ui_rect_hit(reading_setting_rect(1), x, y)) {
        app_settings_set_reader_turn_effect((uint8_t)((app_settings_reader_turn_effect() + 1) % 4));
        // 新模式从新一轮计数开始，首次翻页不继承旧模式的自动全刷欠账。
        // Start a fresh cleanup cycle so the first turn does not inherit the previous effect's cleanup debt.
        s_turns=0;
    } else if (ui_rect_hit(reading_setting_rect(2), x, y)) {
        s_reader_panel = READER_PANEL_TURN_SETTINGS;
    } else if (ui_rect_hit(reading_setting_rect(4), x, y)) {
        s_reader_panel = READER_PANEL_KEY_SETTINGS;
    } else if (ui_rect_hit(reading_setting_rect(9), x, y)) {
        // 三级菜单第一层：阅读背景（当前背景 / 选择图片 / 无背景 / 返回）。
        // Level one of the three-level background menu.
        s_background_prepare_pending = false;
        s_background_depth = 0;
        s_reader_panel = READER_PANEL_BACKGROUND_MENU;
    } else {
        for (int i = 0; i < 5; ++i)
            if (ui_rect_hit(reading_toggle_rect(i), x, y)) return apply_reader_option(ctx, i);
        return APP_REDRAW_NONE;
    }
    invalidate_prep();
    return APP_REDRAW_PAGE;
}

/* ---- 本章跳转：草稿页 + 数字键盘 + 7 秒撤销 / Chapter jump: draft page, keypad, 7-second undo ---- */
static void reader_chapter_jump_sync_digits(void) {
    snprintf(s_chapter_jump_digits, sizeof(s_chapter_jump_digits), "%u",
             (unsigned)(s_chapter_jump_page + 1));
    s_chapter_jump_replace = true;
}
static void reader_chapter_jump_begin(void) {
    size_t count = book_layout_page_count();
    s_chapter_jump_page = count ? (s_page < count ? s_page : count - 1) : 0;
    reader_chapter_jump_sync_digits();
    s_chapter_jump_error = false;
}
static bool reader_chapter_jump_parse(size_t *page) {
    if (!s_chapter_jump_digits[0]) return false;
    size_t value = 0;
    for (const char *p = s_chapter_jump_digits; *p; ++p) {
        if (*p < '0' || *p > '9') return false;
        unsigned digit = (unsigned)(*p - '0');
        if (value > (SIZE_MAX - digit) / 10) return false;
        value = value * 10 + digit;
    }
    if (!value || value > book_layout_page_count()) return false;
    *page = value - 1;
    return true;
}
// 跳转/撤销：草稿页只在这里变成真实位置；撤销按文字锚点恢复，重排后也能回到原文。
// Jump/undo only here turns the draft into a real position; undo restores the text anchor so a reflow
// still lands on the original text.
static app_redraw_t reader_chapter_jump_commit(app_ctx_t *ctx, size_t page, bool restore) {
    if (!s_text || s_view != READING || !book_layout_page_count()) return APP_REDRAW_NONE;
    size_t offset = SIZE_MAX;
    if (restore) {
        if (!s_chapter_jump_undo.valid || s_chapter_jump_undo.chapter != s_chapter ||
            ctx->now_ms >= s_chapter_jump_undo.until_ms) return APP_REDRAW_NONE;
        offset = s_chapter_jump_undo.offset;
        page = book_layout_page_for_offset(offset);
        s_chapter_jump_undo.valid = false;
    }
    if (page >= book_layout_page_count()) return APP_REDRAW_NONE;
    lock_draw();
    invalidate_prep();
    reader_anchor_invalidate();
    const size_t before = reader_page_offset(s_page);
    const size_t destination = offset == SIZE_MAX ? book_layout_page_start_offset(page) : offset;
    const bool changed = page != s_page || destination != before;
    s_chapter_jump_undo.valid = !restore && changed;
    s_chapter_jump_undo.chapter = s_chapter;
    s_chapter_jump_undo.offset = before;
    s_chapter_jump_undo.until_ms = ctx->now_ms + 7000;
    s_page = page;
    s_jump_page = page;
    s_jump_offset = offset;
    s_reader_panel = READER_PANEL_NONE;
    s_reader_slider = -1;
    s_reader_tap.pending = false;
    s_water_turn_pending = s_reader_turn_pending = s_reader_text_frame = false;
    s_reader_footer_pending = s_reader_image_refresh_pending = s_reader_cleanup = false;
    unlock_draw();
    release_page_images();
    prepare_inline_image();
    if (changed) save_progress();
    s_stats_activity_ms = ctx->now_ms;
    ctx->user_activity = true;
    return APP_REDRAW_PAGE;
}
static app_redraw_t reader_chapter_jump_action(app_ctx_t *ctx, uint16_t x, uint16_t y) {
    const bool land = s_reader_landscape;
    const size_t total = book_layout_page_count();
    // 横屏靠画布顶部标题带返回，竖屏是抽屉题头；取消与返回等价。
    // Landscape returns through the canvas header; portrait uses the sheet header; Cancel equals Back.
    const bool back = land ? (y < 96) : (y < 500);
    if (back || ui_rect_hit(chapter_jump_cancel_rect(), x, y)) {
        s_reader_panel = READER_PANEL_STATS;
        s_chapter_jump_error = false;
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(chapter_jump_commit_rect(), x, y)) {
        size_t page = s_chapter_jump_page;
        if (!s_chapter_jump_digits[0]) {
            if (!total) return APP_REDRAW_NONE;
            return reader_chapter_jump_commit(ctx, page, false);
        }
        if (reader_chapter_jump_parse(&page)) return reader_chapter_jump_commit(ctx, page, false);
        s_chapter_jump_error = true;
        return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(chapter_jump_minus_rect(), x, y)) {
        if (!s_chapter_jump_page) return APP_REDRAW_NONE;
        --s_chapter_jump_page;
        reader_chapter_jump_sync_digits();
        s_chapter_jump_error = false;
        return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(chapter_jump_plus_rect(), x, y)) {
        if (!total || s_chapter_jump_page + 1 >= total) return APP_REDRAW_NONE;
        ++s_chapter_jump_page;
        reader_chapter_jump_sync_digits();
        s_chapter_jump_error = false;
        return APP_REDRAW_PAGE;
    }
    for (int key = 0; key < 12; ++key) {
        if (!ui_rect_hit(chapter_jump_key_rect(key), x, y)) continue;
        size_t len = strlen(s_chapter_jump_digits);
        if (key == 9) s_chapter_jump_digits[0] = 0;
        else if (key == 11) { if (len) s_chapter_jump_digits[len - 1] = 0; }
        else {
            if (s_chapter_jump_replace) len = 0;
            if (len + 1 >= sizeof(s_chapter_jump_digits)) return APP_REDRAW_NONE;
            s_chapter_jump_digits[len] = (char)('0' + (key == 10 ? 0 : key + 1));
            s_chapter_jump_digits[len + 1] = 0;
        }
        s_chapter_jump_replace = false;
        s_chapter_jump_error = false;
        return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}

static app_redraw_t reader_panel_action(app_ctx_t* ctx, uint16_t x, uint16_t y) {
    if (s_reader_panel == READER_PANEL_BACKGROUND || s_reader_panel == READER_PANEL_BACKGROUND_PREVIEW)
        return reader_background_action(x, y);
    if (s_reader_panel == READER_PANEL_BACKGROUND_MENU)
        return reader_background_menu_action(x, y);
    if (s_reader_panel == READER_PANEL_TOOLS) {
        for (int i = 0; i < BOOK_TOOL_COUNT; ++i) if (ui_rect_hit(tool_rect(i), x, y)) {
            invalidate_prep();
            if (i == 0) {
                save_progress();
                set_reader_view(TOC);
                s_message[0] = 0;
                s_toc_jump_open = s_toc_jump_drag = false;
                s_reader_panel = READER_PANEL_NONE;
                size_t toc = current_toc_position();
                ctx->leaf = toc == SIZE_MAX ? 0 : (int)(toc / BOOK_TOC_ROWS);
            } else if (i == 1) {
                (void)bookmark_toggle();
            } else if (i == 2) {
                s_reader_panel = READER_PANEL_STATS;
            } else if (i == 3) {
                s_reader_panel = READER_PANEL_REFRESH_SETTINGS;
            } else if (i == 4) {
                s_line_spacing = app_settings_book_line_spacing();
                s_reader_slider = -1;
                s_reader_panel = READER_PANEL_FONT_SETTINGS;
            } else {
                // 划线按钮打开本书的划线列表；新增划线只靠正文长按拖动。
                // The highlight tool opens this book's range list; new ranges come from long-press drag.
                s_highlight_page = 0;
                s_reader_panel = READER_PANEL_HIGHLIGHTS;
                s_reader_tap.pending = false;
            }
            return APP_REDRAW_PAGE;
        }
        s_reader_panel = READER_PANEL_NONE;
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (s_reader_panel == READER_PANEL_HIGHLIGHTS) {
        const int count = book_highlight_count();
        const int pages = highlight_pages(count);
        const int top = s_reader_landscape ? 96 : 560;
        // 先判开关：横屏开关画在面板标题栏下方、top 边界之上，必须抢在“点上面板外关闭”之前。
        // Check the switch first: in landscape it sits above the sheet boundary and would otherwise
        // be swallowed by the "tap above the sheet closes the panel" rule.
        if (ui_rect_hit(highlight_hold_toggle_rect(), x, y)) {
            app_settings_set_reader_long_press_highlight(!app_settings_reader_long_press_highlight());
            invalidate_prep();
            return APP_REDRAW_PAGE;
        }
        if (y < top) {
            s_reader_panel = READER_PANEL_NONE;
            invalidate_prep();
            return APP_REDRAW_PAGE;
        }
        if (count && y >= highlight_page_label_y() - 22) {
            const int half = (s_reader_landscape ? reader_scr_w() : UI_LOCK_WIDTH) / 2;
            if (x < half && s_highlight_page > 0) --s_highlight_page;
            else if (x >= half && s_highlight_page + 1 < pages) ++s_highlight_page;
            return APP_REDRAW_PAGE;
        }
        for (int row = 0; row < highlight_rows(); ++row) {
            const int index = count - 1 - (s_highlight_page * highlight_rows() + row);
            if (index < 0) break;
            if (!ui_rect_hit(highlight_row_rect(row), x, y)) continue;
            if (ui_rect_hit(highlight_tag_rect(row), x, y)) {
                // 循环切换标签：无→重要→待读→疑问，立即保存并只重绘列表。
                // Cycle the preset tag and save immediately; the list repaints.
                const uint8_t tag = book_highlight_tag(index);
                (void)book_highlight_set_tag(index, tag > 3 ? 1 : (uint8_t)((tag + 1) & 3));
                invalidate_prep();
                return APP_REDRAW_PAGE;
            }
            if (ui_rect_hit(highlight_delete_rect(row), x, y)) {
                (void)book_highlight_remove(index);
                const int last = highlight_pages(book_highlight_count()) - 1;
                if (s_highlight_page > last) s_highlight_page = last;
                if (s_highlight_page < 0) s_highlight_page = 0;
                invalidate_prep();
                return APP_REDRAW_PAGE;
            }
            uint16_t chapter = 0;
            uint32_t start = 0, end = 0;
            if (book_highlight_at(index, &chapter, &start, &end, NULL) < 0) continue;
            // 记录跳转前位置，阅读页底部会出现“返回前阅读位置”。
            s_hl_return_chapter = (uint16_t)s_chapter;
            s_hl_return_offset = book_layout_page_start_offset(s_page);
            s_hl_return_valid = true;
            s_reader_panel = READER_PANEL_NONE;
            s_reader_tap.pending = false;
            if (chapter < book_chapter_count()) {
                if (chapter != s_chapter) {
                    if (load_chapter(ctx, chapter, start, false)) save_progress();
                } else {
                    s_page = book_layout_page_for_offset(start);
                    save_progress();
                }
            }
            invalidate_prep();
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_reader_panel == READER_PANEL_STATS) {
        const int top = s_reader_landscape ? 96 : 768;
        EpdRect details = stats_details_rect(), recent = stats_recent_rect(), jump = stats_jump_rect();
        if (ui_rect_hit(details, x, y)) {
            s_bookmark_page = 0;
            s_bookmark_edit = s_bookmark_delete_confirm = s_bookmark_delete_error = false;
            s_bookmark_selected = 0;
            s_reader_panel = READER_PANEL_BOOKMARKS;
        }
        else if (ui_rect_hit(jump, x, y)) {
            reader_chapter_jump_begin();
            s_reader_panel = READER_PANEL_CHAPTER_JUMP;
        }
        else if (ui_rect_hit(recent, x, y)) {
            flush_ticket_stats();
            s_recent_days_valid = book_ticket_recent_days(s_recent_days);
            s_month_valid = false;
            const time_t now = time(NULL);
            if (now >= 1704067200) {
                struct tm t;
                const time_t china = now + 8 * 3600;
                if (gmtime_r(&china, &t)) {
                    s_month_year = t.tm_year + 1900;
                    s_month_month = t.tm_mon + 1;
                    s_month_valid = book_ticket_month_days(s_month_year, s_month_month, s_month_days);
                }
            }
            s_reader_panel = READER_PANEL_STATS_RECENT;
        } else s_reader_panel = y < top ? READER_PANEL_NONE : READER_PANEL_TOOLS;
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (s_reader_panel == READER_PANEL_CHAPTER_JUMP)
        return reader_chapter_jump_action(ctx, x, y);
    if (s_reader_panel == READER_PANEL_BOOKMARKS) {
        const int top = s_reader_landscape ? 96 : 560;
        const EpdRect manage_rect = bookmark_manage_rect();
        if (s_bookmark_delete_confirm) {
            const EpdRect panel = bookmark_confirm_rect();
            if (y >= panel.y + 152 && y < panel.y + 216) {
                if (x < panel.x + 288) s_bookmark_delete_confirm = s_bookmark_delete_error = false;
                else if (bookmark_delete_selected()) s_bookmark_delete_confirm = s_bookmark_delete_error = false;
                else s_bookmark_delete_error = true;
            }
        } else if (y < top) s_reader_panel = READER_PANEL_NONE;
        else if (y < top + 86) {
            if (x >= manage_rect.x && bookmark_count()) {
                s_bookmark_edit = !s_bookmark_edit;
                s_bookmark_selected = 0;
                s_bookmark_page = 0;
            } else s_reader_panel = READER_PANEL_STATS;
        } else {
            reader_bookmarks_t marks = {0};
            bool valid = bookmark_load(&marks);
            int pages = bookmark_pages(valid ? marks.count : 0);
            const EpdRect all_rect = bookmark_select_all_rect();
            const EpdRect remove_rect = bookmark_remove_rect();
            if (s_bookmark_edit && y >= all_rect.y && y < all_rect.y + all_rect.height) {
                if (x < all_rect.x + all_rect.width + 8) {
                    int first = s_bookmark_page * bookmark_rows();
                    for (int row = 0; row < bookmark_rows() && first + row < marks.count; ++row)
                        s_bookmark_selected |= UINT32_C(1) << (marks.count - 1 - (first + row));
                } else if (s_bookmark_selected) s_bookmark_delete_confirm = true;
            } else if (y >= bookmark_page_label_y() - 18) {
                const int half = (s_reader_landscape ? reader_scr_w() : UI_LOCK_WIDTH) / 2;
                if (x < half && s_bookmark_page > 0) --s_bookmark_page;
                else if (x >= half && s_bookmark_page + 1 < pages) ++s_bookmark_page;
            } else if (valid && y >= (s_reader_landscape ? 128 : top + 96)) {
                int row = ((int)y - (s_reader_landscape ? 128 : top + 96)) / bookmark_row_step();
                int position = s_bookmark_page * bookmark_rows() + row;
                if (row >= 0 && row < bookmark_rows() && position < marks.count &&
                    ui_rect_hit(bookmark_row_rect(row),x,y)) {
                    int newest = (int)marks.count - 1 - position;
                    reader_bookmark_entry_t mark = marks.entries[newest];
                    if (!s_bookmark_edit && ui_rect_hit(bookmark_tag_rect(row), x, y)) {
                        const uint8_t tag = mark.tag <= 3 ? mark.tag : 0;
                        (void)bookmark_set_tag(newest, (uint8_t)((tag + 1) & 3));
                        return APP_REDRAW_PAGE;
                    }
                    if (s_bookmark_edit) s_bookmark_selected ^= UINT32_C(1) << newest;
                    else if (mark.chapter < book_chapter_count() && load_chapter(ctx, mark.chapter, mark.byte_off, false)) {
                        s_reader_panel = READER_PANEL_NONE;
                        save_progress();
                    }
                }
            }
        }
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (s_reader_panel == READER_PANEL_STATS_RECENT) {
        int top = s_reader_landscape ? 96 : 584;
        if (y < top) s_reader_panel = READER_PANEL_NONE;
        else if (y < top + 112) s_reader_panel = READER_PANEL_STATS;
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (s_reader_panel == READER_PANEL_REFRESH_SETTINGS)
        return reading_settings_action(ctx, x, y);
    if (s_reader_panel == READER_PANEL_KEY_SETTINGS || s_reader_panel == READER_PANEL_KEY_PICKER) {
        bool picker = s_reader_panel == READER_PANEL_KEY_PICKER;
        // 手势设置入口在按键控制页两个方向都可用；动作选择页不显示入口。
        // The gesture entry works in both key-sheet orientations; the picker never shows it.
        if (!picker && ui_rect_hit(reader_gesture_entry_rect(), x, y)) {
            s_gesture_error[0] = 0;
            s_reader_panel = READER_PANEL_GESTURE;
            invalidate_prep();
            return APP_REDRAW_PAGE;
        }
        if (s_reader_landscape && !picker) {
            if (y < 96 || ui_rect_hit(reading_done_rect(), x, y)) {
                s_reader_panel = READER_PANEL_REFRESH_SETTINGS;
                invalidate_prep();
                return APP_REDRAW_PAGE;
            }
            for (unsigned i = 0; i < 3; ++i)
                if (ui_rect_hit(reader_key_card(i), x, y)) {
                    s_reader_key_pick = (int)i;
                    s_reader_key_error[0] = 0;
                    s_reader_panel = READER_PANEL_KEY_PICKER;
                    return APP_REDRAW_PAGE;
                }
            if (ui_rect_hit(reader_key_hold_rect(), x, y)) {
                s_reader_key_pick = 3;
                s_reader_key_error[0] = 0;
                s_reader_panel = READER_PANEL_KEY_PICKER;
                return APP_REDRAW_PAGE;
            }
            for (unsigned preset = 1; preset <= 2; ++preset)
                if (ui_rect_hit(reader_key_preset_card(preset), x, y)) {
                    app_settings_set_reader_key_preset((int)preset);
                    invalidate_prep();
                    return APP_REDRAW_PAGE;
                }
            return APP_REDRAW_NONE;
        }
        if (s_reader_landscape && picker) {
            // 横屏选择页：标题区与底部返回键都回按键设置；选项行与绘制共用同一矩形。
            // Landscape picker: the header and the Done bar return to the key sheet; rows share the paint geometry.
            if (y < 96 || ui_rect_hit(reading_done_rect(), x, y)) {
                s_reader_panel = READER_PANEL_KEY_SETTINGS;
                invalidate_prep();
                return APP_REDRAW_PAGE;
            }
            for (int i = 0; i < APP_READER_KEY_COUNT; ++i)
                if (ui_rect_hit(reader_key_pick_row(i), x, y)) return reader_key_pick_apply(i);
            return APP_REDRAW_NONE;
        }
        if (y < 270) s_reader_panel = READER_PANEL_NONE;
        else if (ui_rect_hit((EpdRect){36, 299, 56, 56}, x, y) || ui_rect_hit((EpdRect){36, 1141, 612, 58}, x, y))
            s_reader_panel = picker ? READER_PANEL_KEY_SETTINGS : READER_PANEL_REFRESH_SETTINGS;
        else if (picker) {
            for (int i = 0; i < APP_READER_KEY_COUNT; ++i)
                if (ui_rect_hit(reader_key_pick_row(i), x, y)) return reader_key_pick_apply(i);
            return APP_REDRAW_NONE;
        } else {
            for (unsigned i = 0; i < 3; ++i) if (ui_rect_hit(reader_key_card(i), x, y)) {
                s_reader_key_pick = i;
                s_reader_key_error[0] = 0;
                s_reader_panel = READER_PANEL_KEY_PICKER;
                return APP_REDRAW_PAGE;
            }
            if (ui_rect_hit((EpdRect){36, 646, 612, 96}, x, y)) {
                s_reader_key_pick = 3;
                s_reader_key_error[0] = 0;
                s_reader_panel = READER_PANEL_KEY_PICKER;
                return APP_REDRAW_PAGE;
            }
            for (unsigned i = 1; i <= 2; ++i) if (ui_rect_hit(reader_key_preset_card(i), x, y)) {
                app_settings_set_reader_key_preset(i);
                return APP_REDRAW_PAGE;
            }
            return APP_REDRAW_NONE;
        }
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (s_reader_panel == READER_PANEL_GESTURE || s_reader_panel == READER_PANEL_GESTURE_PICKER) {
        const bool picker = s_reader_panel == READER_PANEL_GESTURE_PICKER;
        // 横屏标题区/完成键、竖屏抽屉题头/返回/完成都回上一级：选择页回手势页，手势页回按键页。
        // Landscape header and Done, portrait sheet header, back and Done all step back one level:
        // the picker returns to the gesture sheet, the gesture sheet returns to the key sheet.
        if (s_reader_landscape) {
            if (y < 96 || ui_rect_hit(reading_done_rect(), x, y)) {
                s_reader_panel = picker ? READER_PANEL_GESTURE : READER_PANEL_KEY_SETTINGS;
                invalidate_prep();
                return APP_REDRAW_PAGE;
            }
        } else if (y < 270) {
            s_reader_panel = READER_PANEL_NONE;
            invalidate_prep();
            return APP_REDRAW_PAGE;
        } else if (ui_rect_hit((EpdRect){36, 299, 56, 56}, x, y) ||
                   ui_rect_hit(reading_done_rect(), x, y)) {
            s_reader_panel = picker ? READER_PANEL_GESTURE : READER_PANEL_KEY_SETTINGS;
            invalidate_prep();
            return APP_REDRAW_PAGE;
        }
        if (picker) {
            for (int i = 0; i < APP_GESTURE_ACTION_COUNT; ++i)
                if (ui_rect_hit(reader_gesture_pick_row(i), x, y))
                    return reader_gesture_pick_apply(i);
            return APP_REDRAW_NONE;
        }
        for (int i = 0; i < APP_GESTURE_COUNT; ++i)
            if (ui_rect_hit(reader_gesture_slot_row(i), x, y)) {
                s_gesture_slot = (app_gesture_slot_t)i;
                s_gesture_error[0] = 0;
                s_reader_panel = READER_PANEL_GESTURE_PICKER;
                return APP_REDRAW_PAGE;
            }
        for (unsigned preset = 1; preset <= 4; ++preset)
            if (ui_rect_hit(reader_gesture_preset_card(preset), x, y))
                return reader_gesture_preset_apply(preset);
        return APP_REDRAW_NONE;
    }
    if (s_reader_panel == READER_PANEL_TURN_SETTINGS) {
        if (s_reader_landscape) {
            if (y < 96 || ui_rect_hit(reading_done_rect(), x, y)) {
                s_reader_panel = READER_PANEL_REFRESH_SETTINGS;
                invalidate_prep();
                return APP_REDRAW_PAGE;
            }
            for (int i = 0; i < 2; ++i) {
                if (!ui_rect_hit((EpdRect){36 + i * 592, 110, 560, 420}, x, y)) continue;
                app_settings_set_reader_vertical_turn(i != 0);
                invalidate_prep();
                return APP_REDRAW_PAGE;
            }
            return APP_REDRAW_NONE;
        }
        if (y < 270) s_reader_panel = READER_PANEL_NONE;
        else if (ui_rect_hit((EpdRect){36, 299, 56, 56}, x, y)) s_reader_panel = READER_PANEL_REFRESH_SETTINGS;
        else if (ui_rect_hit((EpdRect){36, 1141, 612, 58}, x, y)) s_reader_panel = READER_PANEL_REFRESH_SETTINGS;
        else {
            for (int i = 0; i < 2; ++i) {
                if (!ui_rect_hit((EpdRect){36, 370 + i * 322, 612, 292}, x, y)) continue;
                app_settings_set_reader_vertical_turn(i != 0);
                invalidate_prep();
                return APP_REDRAW_PAGE;
            }
            return APP_REDRAW_NONE;
        }
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (s_reader_panel == READER_PANEL_WEIGHT_SETTINGS) {
        if (s_reader_landscape) {
            // 横屏：标题区与底部完成键回字体设置，圆钮之外不改数值。
            // Landscape: header and Done return to the font sheet; taps outside the round buttons do nothing.
            if (y < 96 || ui_rect_hit(reading_done_rect(), x, y)) {
                s_reader_panel = READER_PANEL_FONT_SETTINGS;
                return APP_REDRAW_PAGE;
            }
        } else if (y < 690 || y >= 1141) {
            s_reader_panel = y < 580 ? READER_PANEL_NONE : READER_PANEL_FONT_SETTINGS;
            return APP_REDRAW_PAGE;
        }
        int step=reader_weight_step(x,y),weight=app_settings_book_weight_fine();
        if(step) {
            int next=weight+step;if(next < -APP_BOOK_WEIGHT_FINE_MAX || next > APP_BOOK_WEIGHT_FINE_MAX)return APP_REDRAW_NONE;
            lock_draw();
            invalidate_prep();
            bool ok = app_settings_set_book_weight_fine(next);
            if (ok) ttf_set_stroke_adjust_fine(next);
            unlock_draw();
            if (!ok) {
                copy_text(s_reader_notice, sizeof(s_reader_notice), "保存失败，请重试");
                s_reader_notice_until = esp_timer_get_time() / 1000 + 1800;
            }
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_reader_panel == READER_PANEL_FONT_SETTINGS) {
        const int top = reader_font_top();
        EpdRect size = reader_slider_rect(0);
        EpdRect font = s_font_card;
        EpdRect layout = s_layout_card;
        EpdRect rule = s_rule_card;
        EpdRect bookfont = s_bookfont_card;
        if (ui_rect_hit(reader_font_done_rect(), x, y)) {
            s_reader_panel = READER_PANEL_NONE;
            invalidate_prep(); return APP_REDRAW_PAGE;
        }
        if (ui_rect_hit(size, x, y)) {
            int px = BOOK_PX_MIN + slider_index(size, x, BOOK_PX_MAX - BOOK_PX_MIN + 1);
            return apply_reader_layout(ctx, px, s_margin, s_margin_v, app_settings_book_line_spacing(),
                                       app_settings_book_paragraph_spacing());
        }
        if (ui_rect_hit(font, x, y)) {
            reader_scan_fonts();
            s_font_page = 0;
            int count = ttf_font_count();
            const char* active = ttf_font_path();
            for (int i = 0; i < count; ++i) {
                const ttf_font_item_t* item = ttf_font_item(i);
                if (item && !strcmp(active, item->path)) { s_font_page = i / BOOK_FONT_PAGE; break; }
            }
            s_reader_panel = READER_PANEL_FONT_PICKER;
            return APP_REDRAW_PAGE;
        }
        if (ui_rect_hit(s_weight_card, x, y)) {
            s_reader_panel = READER_PANEL_WEIGHT_SETTINGS;
            return APP_REDRAW_PAGE;
        }
        if (ui_rect_hit(s_antialias_card, x, y)) {
            lock_draw();
            invalidate_prep();
            bool on = !app_settings_book_antialias();
            bool ok = app_settings_set_book_antialias(on);
            if (ok) ttf_set_antialias(on);
            unlock_draw();
            if (!ok) {
                copy_text(s_reader_notice, sizeof(s_reader_notice), "保存失败，请重试");
                s_reader_notice_until = esp_timer_get_time() / 1000 + 1800;
            }
            return APP_REDRAW_PAGE;
        }
        if (ui_rect_hit(layout, x, y)) {
            s_reader_slider = -1;
            s_reader_panel = READER_PANEL_LAYOUT_SETTINGS;
            return APP_REDRAW_PAGE;
        }
        if (ui_rect_hit(rule, x, y)) {
            s_reader_panel = READER_PANEL_RULE_SETTINGS;
            return APP_REDRAW_PAGE;
        }
        if (ui_rect_hit(bookfont, x, y)) {
            // 触摸回调的栈比 on_tick 深得多：在这里直接重排一章会把主任务栈顶穿（实测溢出过一次）。
            // 只记下意愿，交给下一轮 on_tick 在浅栈上做。
            // The touch callback runs far deeper than on_tick, and laying a chapter out from here
            // overran the main task stack (measured once). Record the intent and let the next
            // on_tick do it on a shallow stack.
            bool on = !app_settings_book_fonts();
            app_settings_set_book_fonts(on);
            s_book_fonts_applied = on;
            book_set_embedded_fonts(on);
            s_fonts_reload_pending = true;
            invalidate_prep();
            return APP_REDRAW_PAGE;
        }
        s_reader_panel = y < top ? READER_PANEL_NONE : READER_PANEL_TOOLS;
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (s_reader_panel == READER_PANEL_LAYOUT_SETTINGS) {
        // 竖屏抽屉从 500 上移到 380，给第 5 条滑杆腾出整行；横屏不用该值。
        // The portrait drawer moves from 500 up to 380 to fit the fifth rail; landscape ignores it.
        const int top = 380;
        // 横屏没有抽屉式面板题头，返回靠画布顶部的标题/返回提示；竖屏保留原图钉与底栏。
        // Landscape has no sheet header, so the top band returns; portrait keeps its icon and footer.
        bool layout_back = s_reader_landscape ? y < 96
                                             : ui_rect_hit((EpdRect){36, top + 29, 56, 56}, x, y);
        EpdRect back_button = reader_layout_back_rect();
        if (layout_back || ui_rect_hit(back_button, x, y)) {
            s_reader_slider = -1;
            s_reader_panel = READER_PANEL_FONT_SETTINGS;
            return APP_REDRAW_PAGE;
        }
        EpdRect margin = reader_slider_rect(1);
        EpdRect line = reader_slider_rect(2);
        EpdRect paragraph = reader_slider_rect(3);
        EpdRect tracking = reader_slider_rect(4);
        EpdRect margin_v = reader_slider_rect(5);
        if (ui_rect_hit(margin, x, y)) {
            return apply_reader_layout(ctx, s_px,
                                       reader_margin_input(margin, x, s_margin, s_px,
                                                           (app_settings_book_tracking() + APP_BOOK_TRACK_MIN)),
                                       s_margin_v, app_settings_book_line_spacing(), app_settings_book_paragraph_spacing());
        }
        if (ui_rect_hit(line, x, y)) {
            uint8_t value = (uint8_t)(100 + slider_index(line, x, 51));
            return apply_reader_layout(ctx, s_px, s_margin, s_margin_v, value,
                                       app_settings_book_paragraph_spacing());
        }
        if (ui_rect_hit(paragraph, x, y))
            return apply_reader_layout(ctx, s_px, s_margin, s_margin_v, app_settings_book_line_spacing(),
                                       app_settings_book_paragraph_value((uint8_t)slider_index(paragraph, x, APP_BOOK_PARAGRAPH_COUNT)));
        // 上下边距只有 9 档：点哪档就落哪档，单位为 6 像素。
        // The vertical margin has 9 stops of 6 px; tapping a rail section applies that stop.
        if (ui_rect_hit(margin_v, x, y))
            return apply_reader_layout(ctx, s_px, s_margin, 6 * slider_index(margin_v, x, 9),
                                       app_settings_book_line_spacing(), app_settings_book_paragraph_spacing());
        if (ui_rect_hit(tracking, x, y))
            return apply_reader_typography(ctx, slider_index(tracking, x, APP_BOOK_TRACK_COUNT));
        for (int i = 0; i < 4; ++i) {
            EpdRect choice = reader_indent_choice_rect(i);
            if (ui_rect_hit(choice, x, y)) return apply_reader_indent(ctx, i, app_settings_book_indent_adjust());
        }
        for (int i = 0; i < 3; ++i) {
            if (indent_adjust_hit(x,y)!=i) continue;
            int adjustment = i == 1 ? 0 : app_settings_book_indent_adjust() + (i == 0 ? -1 : 1);
            if (adjustment < -100) adjustment = -100;
            if (adjustment > 100) adjustment = 100;
            return apply_reader_indent(ctx, app_settings_book_indent(), adjustment);
        }
        // 横屏的标题带已在上面处理；正文区空白不再当作“退回阅读页”。
        // The landscape top band was handled above; empty body space no longer dismisses the sheet.
        if(!s_reader_landscape && y<top){s_reader_panel=READER_PANEL_NONE;invalidate_prep();return APP_REDRAW_PAGE;}
        return APP_REDRAW_NONE;
    }
    if (s_reader_panel == READER_PANEL_RULE_SETTINGS) {
        // 横屏用画布顶部标题带返回；竖屏沿用手写面板的 729 像素分界与底部按键。
        // Landscape returns via the canvas header; portrait keeps its 729-pixel sheet edge and footer key.
        const int close_y = s_reader_landscape ? 96 : 729;
        if (y < close_y || ui_rect_hit(reader_rule_done_rect(), x, y)) {
            s_reader_panel = READER_PANEL_FONT_SETTINGS;
            return APP_REDRAW_PAGE;
        }
        for (int i = 0; i < 3; ++i) {
            if (!ui_rect_hit(rule_style_rect(i), x, y)) continue;
            app_settings_set_book_reading_line((uint8_t)i);
            book_layout_set_reading_line((unsigned)i);
            invalidate_prep();
            return APP_REDRAW_PAGE;
        }
        if (app_settings_book_reading_line()) {
            int offset = app_settings_book_reading_line_offset();
            if (ui_rect_hit(rule_offset_rect(0), x, y)) offset -= 2;
            else if (ui_rect_hit(rule_offset_rect(1), x, y)) offset = 0;
            else if (ui_rect_hit(rule_offset_rect(2), x, y)) offset += 2;
            else return APP_REDRAW_NONE;
            if (offset < -8) offset = -8;
            if (offset > 8) offset = 8;
            app_settings_set_book_reading_line_offset((int8_t)offset);
            book_layout_set_reading_line_offset(offset);
            invalidate_prep();
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_reader_panel == READER_PANEL_FONT_PICKER) {
        const int top = reader_font_picker_top();
        // 横屏的返回是画布顶部标题带，竖屏仍是面板题头的 112 像素区。
        // Landscape returns through the canvas header; portrait keeps its 112-pixel sheet header band.
        if (s_reader_landscape ? (y < top + 32) : (y < top + 112)) {
            s_reader_panel = READER_PANEL_FONT_SETTINGS;
            return APP_REDRAW_PAGE;
        }
        int count = ttf_font_count(), start = s_font_page * BOOK_FONT_PAGE;
        for (int slot = 0; slot < BOOK_FONT_PAGE && start + slot < count; ++slot) {
            EpdRect card = reader_font_pick_rect(slot);
            if (ui_rect_hit(card, x, y)) return select_reading_font_item(ctx, ttf_font_item(start + slot));
        }
        return APP_REDRAW_NONE;
    }
    return APP_REDRAW_NONE;
}
static app_redraw_t adjust_spacing(app_ctx_t* ctx, int control) {
    uint8_t old_line = app_settings_book_line_spacing();
    uint8_t old_para = app_settings_book_paragraph_spacing();
    uint8_t line = old_line, para = old_para;
    if (control == 3 && line > 120) line -= 30;
    if (control == 4 && line < 180) line += 30;
    uint8_t para_level=app_settings_book_paragraph_level(para);
    if (control == 5 && para_level > 0) para=app_settings_book_paragraph_value(para_level-1);
    if (control == 6 && para_level+1 < APP_BOOK_PARAGRAPH_COUNT) para=app_settings_book_paragraph_value(para_level+1);
    if (control == 17) { line = 150; para = 50; }
    if (line == old_line && para == old_para) return APP_REDRAW_NONE;
    size_t off = book_layout_page_start_offset(s_page);
    lock_draw();
    invalidate_prep();
    reader_anchor_invalidate();
    book_layout_set_spacing(line, para);
    bool ok = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    if (ok) s_page = book_layout_page_for_offset(off);
    else {
        book_layout_set_spacing(old_line, old_para);
        (void)book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    }
    unlock_draw();
    if (!ok) return APP_REDRAW_NONE;
    app_settings_set_book_line_spacing(line);
    app_settings_set_book_paragraph_spacing(para);
    save_progress();
    return paint_reading(ctx, MODE_DU);
}
static app_redraw_t select_reading_font(app_ctx_t* ctx, int style) {
    static const char* filenames[] = {
        "Song.ttf", "Hei.ttf", "Kai.ttf", "WenKai.ttf", "FangSong.ttf", "KingHwa.ttf",
        "CangErYunHei05.ttf", "ChillKai.ttf"
    };
    static const char* names[] = {"宋体", "黑体", "楷体", "文楷", "仿宋", "京华老宋", "仓耳云黑05", "寒蝉正楷"};
    char path[160];
    if (snprintf(path, sizeof(path), "%s/%s", app_settings_fonts_dir(), filenames[style]) >= sizeof(path)) return APP_REDRAW_NONE;
    if (!strcmp(ttf_font_path(), path)) return APP_REDRAW_NONE;
    struct stat font_stat;
    if (stat(path, &font_stat) != 0) {
        snprintf(s_message, sizeof(s_message), "请将 %s 字体放入所选字体目录", names[style]);
        return APP_REDRAW_PAGE;
    }
    if (ttf_font_open(path) != ESP_OK) {
        snprintf(s_message, sizeof(s_message), "请将 %s 字体放入所选字体目录", names[style]);
        return APP_REDRAW_PAGE;
    }
    app_settings_set_font_path(path);
    s_message[0] = 0;
    size_t off = book_layout_page_start_offset(s_page);
    save_progress();
    lock_draw();
    invalidate_prep();
    reader_anchor_invalidate();
    bool ok = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
    if (ok) s_page = book_layout_page_for_offset(off);
    copy_text(s_font_path, sizeof(s_font_path), ttf_font_path());
    unlock_draw();
    if (!ok) {
        free_book(); s_view = SHELF;
        copy_text(s_message, sizeof(s_message), "字体重排失败，请重新打开图书");
        return APP_REDRAW_PAGE;
    }
    save_progress();
    return paint_reading(ctx, MODE_GL16);
}
static app_redraw_t manage_action(app_ctx_t* ctx, uint16_t x, uint16_t y) {
    if (ui_rect_hit(manage_back_rect(), x, y)) {
        if (s_clear_confirm) s_clear_confirm = false;
        else s_view = SHELF;
        return APP_REDRAW_PAGE;
    }
    if (!s_clear_confirm && !s_file_removed && ui_rect_hit((EpdRect){UI_MARGIN, manage_panel().y + manage_panel().height - 190, ui_content_width(), 68}, x, y)) {
        extern void app_files_request_folder(int folder);
        app_files_request_folder(0);
        ui_nav_request(ctx, 2);
        return APP_REDRAW_NONE;
    }
    int count = s_clear_confirm || s_file_removed ? 2 : 3;
    for (int i = 0; i < count; ++i) if (ui_rect_hit(manage_rect(i, count), x, y)) {
        if (s_clear_confirm) { if (!i) s_clear_confirm = false; else manage_apply(ctx); }
        else if (!i) s_view = SHELF;
        else if (s_file_removed) manage_apply(ctx);
        else { s_clear_confirm = true; s_delete_confirm = i == 2; s_manage_message[0] = 0; }
        break;
    }
    return APP_REDRAW_PAGE;
}
static app_redraw_t editor_save(app_ctx_t* ctx) {
    if (ui_keyboard_pending()) {
        copy_text(s_editor_notice, sizeof(s_editor_notice), "请先选择候选字");
        return APP_REDRAW_PAGE;
    }
    char *start = s_editor_title;
    while (*start == ' ') ++start;
    if (start != s_editor_title) memmove(s_editor_title, start, strlen(start) + 1);
    size_t len = strlen(s_editor_title);
    while (len && s_editor_title[len - 1] == ' ') s_editor_title[--len] = 0;
    if (s_edit_note_mode) {
        // 笔记允许为空（等于清除）；保存到当前划线的 sidecar 后回到划线列表。
        // Notes may be empty (clears it); save into the highlight sidecar and return to the list.
        if (!book_highlight_set_note(s_edit_note_index, s_editor_title)) {
            copy_text(s_editor_notice, sizeof(s_editor_notice), "笔记保存失败，请重试");
            return APP_REDRAW_PAGE;
        }
        ui_keyboard_end();
        s_edit_note_mode = false;
        s_edit_note_index = -1;
        s_view = READING;
        s_reader_panel = READER_PANEL_HIGHLIGHTS;
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (!s_editor_title[0]) {
        copy_text(s_editor_notice, sizeof(s_editor_notice), "书名不能为空");
        return APP_REDRAW_PAGE;
    }
    esp_err_t err = book_title_set(s_managed.path, s_editor_title);
    if (err != ESP_OK) {
        copy_text(s_editor_notice, sizeof(s_editor_notice), "保存失败，请检查书名或存储");
        return APP_REDRAW_PAGE;
    }
    for (int i = 0; i < s_count; ++i)
        if (!strcmp(s_shelf[i].path, s_managed.path)) copy_text(s_shelf[i].name, sizeof(s_shelf[i].name), s_editor_title);
    free(s_editor_cover); s_editor_cover = NULL;
    ui_keyboard_end();
    s_view = SHELF;
    sort_shelf(ctx);
    return APP_REDRAW_PAGE;
}
static app_redraw_t editor_paint(app_ctx_t* ctx, bool field) {
    bool search = s_view == SEARCH;
    ui_keyboard_update_t update = ui_keyboard_update(ctx->fb, 560,
        search ? (EpdRect){UI_MARGIN, 200, ui_content_width(), 88} : (EpdRect){36, 424, 612, 83},
        search ? UI_PX_BODY : 31, false, NULL, field);
    s_area = update.area; s_mode = update.layout ? MODE_GL16 : MODE_DU; s_input_settle = update.settle;
    return update.area.width ? APP_REDRAW_AREA : APP_REDRAW_NONE;
}
static app_redraw_t editor_action(app_ctx_t* ctx, uint16_t x, uint16_t y) {
    if (s_edit_note_mode) {
        if (y < 134) {
            if (x < 160) {
                ui_keyboard_end();
                s_edit_note_mode = false;
                s_edit_note_index = -1;
                s_view = READING;
                s_reader_panel = READER_PANEL_HIGHLIGHTS;
                return APP_REDRAW_PAGE;
            }
            if (x > 510) return editor_save(ctx);
            return APP_REDRAW_NONE;
        }
        if (ui_text_input_tap(&s_editor_input, (EpdRect){36, 424, 612, 83}, 30, false, NULL, x, y))
            return editor_paint(ctx, true);
        ui_keyboard_result_t note_result = ui_keyboard_tap(x, y, 560, ctx->now_ms);
        if (note_result == UI_KEYBOARD_DONE) return editor_save(ctx);
        return note_result == UI_KEYBOARD_CHANGED ? editor_paint(ctx, false) : APP_REDRAW_NONE;
    }
    if (y < 134) {
        if (x < 160) { ui_keyboard_end(); free(s_editor_cover); s_editor_cover = NULL; s_view = SHELF; return APP_REDRAW_PAGE; }
        if (x > 510) return editor_save(ctx);
        return APP_REDRAW_NONE;
    }
    if (ui_text_input_tap(&s_editor_input, (EpdRect){36, 424, 612, 83}, 31,
                          false, NULL, x, y)) return editor_paint(ctx, true);
    ui_keyboard_result_t result = ui_keyboard_tap(x, y, 560, ctx->now_ms);
    if (result == UI_KEYBOARD_DONE) return editor_save(ctx);
    return result == UI_KEYBOARD_CHANGED ? editor_paint(ctx, false) : APP_REDRAW_NONE;
}
// 成功项退出选择，已删文件的失败项仅重试元数据。/ Deselect successes; removed-file failures retry metadata only.
static void batch_apply(app_ctx_t* ctx) {
    unsigned done = 0, failed = 0;
    int write = 0;
    const bool unshelf = s_batch_kind == BATCH_UNSHELF;
    for (int i = 0; i < s_count; ++i) {
        shelf_entry_t item = s_shelf[i];
        bool discard = false;
        if (item.selected) {
            esp_err_t err = ESP_OK;
            if (unshelf) {
                // 只隐藏条目：文件与阅读进度都留在原处，再次打开这本书会重新上书架。
                // Hide the entry only: file and progress stay, and reopening the book puts it back.
                if (shelf_hidden_save(item.path, true)) discard = true;
                else err = ESP_FAIL;
            } else {
                if (!strcmp(s_path, item.path)) free_book();
                if (s_batch_kind == BATCH_DELETE && !item.removed) {
                    delete_retry_t* retry = delete_retry_reserve(&item);
                    if (!retry) { ++failed; s_shelf[write++] = item; continue; }
                    bool removed = false;
                    err = book_store_delete(item.path, &removed);
                    if (removed) {
                        retry->entry.removed = true;
                        item.removed = true; pending_discard(item.path);
                        book_store_notify_changed(); s_store_revision = book_store_revision();
                    } else delete_retry_discard(item.path);
                } else { pending_discard(item.path); err = book_progress_forget(item.path); }
            }
            if (err == ESP_OK) {
                delete_retry_discard(item.path);
                ++done; item.selected = false;
                if (!unshelf) {
                    item.has_progress = false; item.pct = 0;
                    item.chapter = 0; item.recent = 0;
                }
                discard = discard || item.removed;
            } else ++failed;
        }
        if (!discard) s_shelf[write++] = item;
    }
    s_count = write;
    refresh_capacity();
    int leaf = ctx->leaf;
    sort_shelf(ctx);
    ctx->leaf = leaf < leaves() ? leaf : leaves() - 1;
    s_batch_confirm = false;
    if (unshelf)
        snprintf(s_batch_message, sizeof(s_batch_message), "已移出书架 %u 本，失败 %u 本%s",
                 done, failed, failed ? "；所选可重试" : "");
    else
        snprintf(s_batch_message, sizeof(s_batch_message), "成功 %u 本，失败 %u 本%s",
                 done, failed, failed ? "；所选可重试" : "");
}
static app_redraw_t batch_action(app_ctx_t* ctx, uint16_t x, uint16_t y) {
    if (s_batch_confirm) {
        if (ui_rect_hit(ui_row_rect(0, 2, 620, UI_BTN_H), x, y)) {
            s_batch_confirm = false;
            return APP_REDRAW_PAGE;
        }
        if (ui_rect_hit(ui_row_rect(1, 2, 620, UI_BTN_H), x, y)) {
            batch_apply(ctx);
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    for (int i = 0; i < 6; ++i) if (ui_rect_hit(batch_rect(i), x, y)) {
        s_batch_message[0] = 0;
        if (!i) select_page(ctx->leaf);
        else if (i == 1) clear_selection();
        else if (i == 2) { clear_selection(); s_batch_message[0] = 0; scan_shelf(ctx); }
        else if (selected_count()) {
            s_batch_kind = i == 3 ? BATCH_DELETE : i == 4 ? BATCH_CLEAR : BATCH_UNSHELF;
            s_batch_confirm = true;
        }
        else copy_text(s_batch_message, sizeof(s_batch_message), "请先选择图书");
        return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}
static app_redraw_t bulk_turn_page(app_ctx_t* ctx, int direction) {
    int next = ctx->leaf + direction;
    if (s_scan_pending || s_batch_confirm || next < 0 || next >= leaves()) return APP_REDRAW_NONE;
    ctx->leaf = next;
    return APP_REDRAW_PAGE;
}
static app_redraw_t bulk_finish(app_ctx_t* ctx) {
    int first = ctx->leaf * BOOK_BULK_ROWS;
    clear_selection();
    s_batch_message[0] = 0;
    s_batch_confirm = false;
    s_view = SHELF;
    ctx->leaf = first / shelf_rows();
    if (ctx->leaf >= leaves()) ctx->leaf = leaves() - 1;
    return APP_REDRAW_PAGE;
}
// 批量管理单独路由，不复用带示例菜单的旧底栏。
// Route batch management independently of the legacy bar and demo menu.
static app_redraw_t bulk_action(app_ctx_t* ctx, uint16_t x, uint16_t y) {
    if (ui_rect_hit(manage_back_rect(), x, y)) {
        if (s_batch_confirm) { s_batch_confirm = false; return APP_REDRAW_PAGE; }
        return bulk_finish(ctx);
    }
    app_redraw_t result = batch_action(ctx, x, y);
    if (result != APP_REDRAW_NONE || s_batch_confirm || s_scan_pending) return result;
    for (int i = 0; i < 3; ++i) if (ui_rect_hit(bulk_filter_rect(i), x, y)) {
        if (i == 2) { search_begin(); return APP_REDRAW_PAGE; }
        if (i == 0) s_filter = (s_filter + 1) % 3;
        else { s_recent_sort = !s_recent_sort; app_settings_set_shelf_recent_sort(s_recent_sort); }
        clear_selection(); s_batch_message[0] = 0;
        sort_shelf(ctx);
        return APP_REDRAW_PAGE;
    }
    int nav = bulk_nav_hit(x, y);
    if (nav == 1) return bulk_finish(ctx);
    if (nav == 0 || nav == 2) return bulk_turn_page(ctx, nav == 0 ? -1 : 1);
    for (int row = 0; row < BOOK_BULK_ROWS; ++row) {
        int index = ctx->leaf * BOOK_BULK_ROWS + row;
        if (index < s_visible_count && ui_rect_hit(row_rect(row), x, y)) {
            toggle_selection(index); s_batch_message[0] = 0;
            return APP_REDRAW_PAGE;
        }
    }
    return APP_REDRAW_NONE;
}
static int bulk_control_at(app_ctx_t* ctx, uint16_t x, uint16_t y, EpdRect* rect) {
    *rect = manage_back_rect();
    if (ui_rect_hit(*rect, x, y)) return 711;
    if (s_batch_confirm) {
        for (int i = 0; i < 2; ++i) {
            *rect = ui_row_rect(i, 2, 620, UI_BTN_H);
            if (ui_rect_hit(*rect, x, y)) return 600 + i;
        }
        return -1;
    }
    for (int i = 0; i < 3; ++i) {
        *rect = bulk_filter_rect(i);
        if (ui_rect_hit(*rect, x, y)) return 110 + i;
        *rect = bulk_nav_rect(i);
        if (ui_rect_hit(*rect, x, y)) return 100 + i;
    }
    for (int i = 0; i < 6; ++i) {
        *rect = batch_rect(i);
        if (ui_rect_hit(*rect, x, y)) return 610 + i;
        if (ctx->leaf * BOOK_BULK_ROWS + i < s_visible_count) {
            *rect = row_rect(i);
            if (ui_rect_hit(*rect, x, y)) return i;
        }
    }
    return -1;
}
static app_redraw_t action_at(app_ctx_t* ctx, uint16_t x, uint16_t y) {
    if (s_view == BULK) return bulk_action(ctx, x, y);
    if (s_view == IMPORT) {
        if (y < 160 && x < 120) { s_view = SHELF; return APP_REDRAW_PAGE; }
        int tab = ui_nav_hit(x, y);
        if (tab == 1) { s_view = SHELF; return APP_REDRAW_PAGE; }
        if (tab >= 0) { ui_nav_request(ctx, tab); return APP_REDRAW_NONE; }
        for (int i = 0; i < 4; ++i) if (ui_rect_hit(import_rect(i), x, y)) {
            if (i == 0) {
                extern const app_desc_t app_files;
                ctx->request_app = &app_files;
            } else {
                extern const app_desc_t app_transfer;
                if (i == 1) app_transfer_request_wifi_upload();
                else if (i == 2) app_transfer_request_hotspot_start();
                else app_transfer_request_usb_start();
                ctx->request_app = &app_transfer;
            }
            return APP_REDRAW_NONE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_view == TOC) {
        if (s_toc_jump_open) {
            int choice = book_toc_jump_hit(x, y);
            if (choice == BOOK_TOC_JUMP_TRACK) {
                s_toc_jump_percent = book_toc_jump_percent(x);
                return APP_REDRAW_PAGE;
            }
            if (choice == BOOK_TOC_JUMP_CONFIRM)
                ctx->leaf = book_toc_page_from_percent(s_toc_jump_percent, leaves());
            s_toc_jump_open = s_toc_jump_drag = false;
            return APP_REDRAW_PAGE;
        }
        int target = book_toc_hit(x, y, ctx->leaf, book_navigation_count());
        if (target == BOOK_TOC_BACK) {
            s_message[0] = 0;
            set_reader_view(READING);
            s_reader_panel = READER_PANEL_NONE;
            return APP_REDRAW_PAGE;
        }
        if (target == BOOK_TOC_PREV || target == BOOK_TOC_NEXT ||
            target == BOOK_TOC_SKIP_PREV || target == BOOK_TOC_SKIP_NEXT) {
            int step = target == BOOK_TOC_SKIP_PREV || target == BOOK_TOC_SKIP_NEXT ? 10 : 1;
            int next = ctx->leaf + (target == BOOK_TOC_PREV || target == BOOK_TOC_SKIP_PREV ? -step : step);
            if (next < 0) next = 0;
            if (next >= leaves()) next = leaves() - 1;
            if (next != ctx->leaf) { ctx->leaf = next; return APP_REDRAW_PAGE; }
            return APP_REDRAW_NONE;
        }
        if (target == BOOK_TOC_JUMP && book_navigation_count()) {
            s_toc_jump_open = true;
            s_toc_jump_percent = (ctx->leaf + 1) * 100 / leaves();
            return APP_REDRAW_PAGE;
        }
        if (target >= 0 && !s_message[0]) {
            size_t chapter = book_navigation_chapter((size_t)target);
            if (chapter >= book_chapter_count()) return APP_REDRAW_NONE;
            save_progress();
            set_reader_view(READING);
            if (load_chapter_at(ctx, chapter, 0, false, book_navigation_anchor((size_t)target),
                                book_navigation_source_offset((size_t)target))) {
                s_selected_toc = (size_t)target;
                char entry_title[sizeof(s_title)];
                if (book_navigation_title((size_t)target, entry_title, sizeof(entry_title)) == ESP_OK)
                    copy_text(s_title, sizeof(s_title), entry_title);
                s_view = READING;
                s_reader_panel = READER_PANEL_NONE;
                save_progress();
            } else set_reader_view(s_text ? TOC : SHELF);
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_view == MANAGE) return manage_action(ctx, x, y);
    if (s_view == SEARCH) {
        if (y < 160 && x < 160) { search_finish(ctx, false); return APP_REDRAW_PAGE; }
        if (ui_text_input_tap(&s_search_input, (EpdRect){UI_MARGIN, 200, ui_content_width(), 88},
                              UI_PX_BODY, false, NULL, x, y)) return editor_paint(ctx, true);
        if (ui_rect_hit((EpdRect){36, 392, 180, 66}, x, y)) { s_search_draft[0] = 0; ui_text_edit_init(&s_search_input, s_search_draft, sizeof(s_search_draft)); ui_keyboard_begin(&s_search_input, false); return APP_REDRAW_PAGE; }
        ui_keyboard_result_t result = ui_keyboard_tap(x, y, 560, ctx->now_ms);
        if (result == UI_KEYBOARD_DONE || (y < 160 && x > 510 && !ui_keyboard_pending())) { search_finish(ctx, true); return APP_REDRAW_PAGE; }
        if (result == UI_KEYBOARD_CHANGED) return editor_paint(ctx, false);
        return APP_REDRAW_NONE;
    }
    if (s_view == READING) {
        if (s_toolbar && !(s_reader_panel == READER_PANEL_TOOLS &&
                          y < reader_tool_bar_top() && ui_rect_hit(body_rect(), x, y)))
            return reader_panel_action(ctx, x, y);
        if (!s_reader_fullscreen &&
            ui_rect_hit(s_reader_landscape ? reader_landscape_back_hit()
                                           : (EpdRect){32, 75, 64, 64}, x, y))
            return reader_return(ctx);
        const bool favorite_hit = s_reader_landscape
            ? ui_rect_hit(reader_landscape_favorite_hit(), x, y)
            : (x >= 584 && y >= 76 && y < 145);
        if (!s_reader_fullscreen && favorite_hit) {
            bool next = !s_reader_favorite;
            if (!favorite_save(s_path, next)) {
                copy_text(s_reader_notice, sizeof(s_reader_notice), "收藏保存失败");
                s_reader_notice_until = esp_timer_get_time() / 1000 + 1800;
                return APP_REDRAW_PAGE;
            }
            s_reader_favorite = next;
            for (int i = 0; i < s_count; ++i)
                if (!strcmp(s_shelf[i].path, s_path)) s_shelf[i].favorite = next;
            sort_shelf(ctx);
            render(ctx, ctx->fb);
            // 横屏收藏图标在题头带右端；只推图标 ±8px，避免整页重刷。
            // The landscape favorite sits at the header band's right edge; push only the icon
            // neighbourhood instead of a full page.
            s_area = s_reader_landscape ? (EpdRect){reader_scr_w() - 100, 40, 72, 64}
                                        : (EpdRect){584, 76, 64, 70};
            s_mode = MODE_GL16;
            return APP_REDRAW_AREA;
        }
        // 通栏插图铺满整屏，点在图两侧的边条上同样要翻页；文字页仍按正文栏判定。
        // A full-bleed illustration spans the panel, so taps on its side strips must turn pages
        // too; text pages keep the body column.
        EpdRect tap_area = body_rect();
        if (reader_image_slots(s_page)) tap_area = ui_rect_union(tap_area, book_layout_image_rect());
        if (!ui_rect_hit(tap_area, x, y)) return APP_REDRAW_NONE;
        // 整页插图任意位置双击都算双击（用于定点缩放），单击延后到双击窗口后再翻页；
        // 其它页面仍按原来的中间双击、两侧单击识别。横屏本期不启用缩放，保持原识别方式。
        // On a whole-page illustration a double tap counts anywhere (point-anchored zoom) and a
        // single tap is deferred; other pages keep the centre double tap and side taps. Landscape
        // keeps the original recognition because zoom lands there in a later step.
        const bool zoom_tap = !s_reader_landscape &&
            (reader_zoom_mode() || reader_page_image_hit(x, y));
        int target = zoom_tap
            ? reader_tap_feed_any(&s_reader_tap, tap_area, x, y,
                                  app_settings_reader_vertical_turn(),
                                  app_settings_book_vertical(), ctx->now_ms)
            : book_reader_tap_feed(&s_reader_tap, tap_area, x, y,
                                   app_settings_reader_vertical_turn(),
                                   app_settings_book_vertical(), ctx->now_ms);
        // 中间双击不再写死全屏：正文（无面板）里按"双击中间"槽位派发，经典预设仍是切换全屏；
        // 工具栏展开时上方正文仍可双击，但保持旧的全屏行为，不算手势映射的生效场景。
        // The centre double tap is no longer hard-wired: with no panel open it dispatches the
        // DOUBLE_TAP slot (the classic preset still toggles full screen). With the toolbar open the
        // body above the bar keeps the old full-screen toggle, since the map only owns bare body.
        if (target == BOOK_READER_TAP_FULLSCREEN) {
            // 竖屏插图优先接管双击：已在缩放视图时再双击退出；整页插图双击定点放大/还原，
            // 正文插图双击进入 2 倍缩放；两处都没命中才走配置的手势动作（经典预设仍是切换全屏）。
            // 横屏本期不启用缩放（代码直接跳过），完全保持原来的双击派发。
            // Portrait illustrations take the double tap first: a second double tap leaves the
            // zoom view, a whole-page illustration jumps to 2x at the tapped point (or back), and
            // an inline one opens 2x zoom. Only a miss falls through to the configured gesture
            // action (the classic preset still toggles full screen). Landscape skips zoom for now
            // and keeps the original dispatch byte for byte.
            if (!s_reader_landscape) {
                if (s_zoom_active) return inline_zoom_toggle(ctx, x, y);
                if (reader_single_image_page()) {
                    const bool zoomed = s_image_zoom_page == s_page &&
                                        s_image_zoom > READER_IMAGE_ZOOM_MIN;
                    return zoom_jump(ctx, zoomed ? READER_IMAGE_ZOOM_MIN : 2000, x, y);
                }
                app_redraw_t opened = inline_zoom_toggle(ctx, x, y);
                if (opened != APP_REDRAW_NONE) return opened;
            }
            return s_reader_panel == READER_PANEL_NONE
                       ? reader_gesture_action(
                             ctx, app_settings_gesture_action(APP_GESTURE_DOUBLE_TAP))
                       : toggle_reader_fullscreen(ctx);
        }
        if (target) return turn_page(ctx, target);
        return APP_REDRAW_NONE;
    }
    if (s_view == SHELF) {
        if (s_view == SHELF) {
            int tab = ui_nav_hit(x, y);
            if (tab >= 0) { ui_nav_request(ctx, tab); return APP_REDRAW_NONE; }
            int pager=ui_pager_hit(x,y);
            if(pager>=0)return shelf_turn_page(ctx,ui_pager_target(pager,ctx->leaf,leaves())-ctx->leaf);
        }
        if (s_view == SHELF && ui_rect_hit(shelf_search_rect(), x, y)) {
            // 搜索跟随当前二级书架与书架顺序；只过滤内存列表，不扫卡。
            // Search follows the current category and shelf order; filters memory, never rescans.
            search_begin();
            return APP_REDRAW_PAGE;
        }
        if (s_view == SHELF && ui_rect_hit(shelf_import_rect(), x, y)) {
            s_view = IMPORT;
            return APP_REDRAW_PAGE;
        }
        if (s_view == SHELF && ui_rect_hit(shelf_manage_rect(), x, y)) {
            clear_selection();
            s_batch_confirm = false;
            s_batch_message[0] = 0;
            s_view = BULK;
            ctx->leaf = 0;
            return APP_REDRAW_PAGE;
        }
        if (s_view == SHELF && s_save_failed && y >= UI_CONTENT_BOTTOM - UI_PX_CAPTION && y < UI_CONTENT_BOTTOM) {
            retry_progress();
            return APP_REDRAW_PAGE;
        }
    }
    if (s_message[0] && !((s_view == SHELF || s_view == BULK) && s_visible_count)) return APP_REDRAW_NONE;
    int rows = s_view == BULK ? BOOK_BULK_ROWS : shelf_rows();
    for (int row = 0; row < rows; ++row) if (ui_rect_hit(row_rect(row), x, y)) {
        int i = ctx->leaf * rows + row;
        if (s_view == SHELF && i < s_visible_count) {
            shelf_category_remember(ctx);
            if (s_shelf[i].removed) {
                s_managed = s_shelf[i]; s_view = MANAGE; s_file_removed = s_delete_confirm = true; s_clear_confirm = false;
                copy_text(s_manage_message, sizeof(s_manage_message), "文件已删除，进度清理失败，请重试");
            } else {
                // 先给即时反馈，再把打开图书的重活放到 on_tick，触摸回调立刻返回。
                // Acknowledge at once, then run the heavy open from on_tick so the touch callback returns fast.
                copy_text(s_open_pending_path, sizeof(s_open_pending_path), s_shelf[i].path);
                s_open_pending = true;
                ui_fill_round_rect(ctx->fb, (EpdRect){212, 556, 260, 64}, 30, 0x30);
                ui_text_vc(ctx->fb, 342, 588, 22, "正在打开…", EPD_DRAW_ALIGN_CENTER, true);
                s_area = (EpdRect){196, 540, 292, 96};
                s_mode = MODE_DU;
                return APP_REDRAW_AREA;
            }
        }
        return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}
static void on_enter(app_ctx_t* ctx) {
    // 进页从干净的缩放状态开始（上一次离开若异常没走到 on_exit 也不会带状态进来）。
    // Start with a clean zoom context (a missed on_exit can never leak one into this entry).
    reader_zoom_reset();
    // 进入图书应用（含从首页直接开书）：首页预热立即收手，扫描交给这里的正常路径。
    // Entering the book app (including a direct open from home): home prewarm stands down and the
    // normal scan path here takes over.
    shelf_prewarm_abort();
    // First entry after boot has no gravity reference yet: say so, because the page will stay
    // portrait until one tap calibrates it.
    if (app_settings_reader_adaptive() && !s_orient_ref_ready) {
        copy_text(s_reader_notice, sizeof(s_reader_notice), "轻点屏幕校准阅读方向");
        s_reader_notice_until = ctx->now_ms + 2600;
    }
    reader_indent_hold_cancel();
    s_shelf_key_mode=s_shelf_key_paint_pending=false;s_shelf_key_delta=s_shelf_key_pressed=0;
    shelf_category_init();
    s_category_menu=false;
    s_reader_tap.pending = false;
    s_open_pending = false;
    s_highlight_page = 0;
    s_shelf_page_pending = false;
    // 设置页试按的旧事件不得在开书后翻页。/ Discard remote tests from earlier pages before opening a book.
    ble_pt_event_t old_key;
    ble_pt_raw_t old_raw;
    while (ble_pt_pop_key(&old_key)) {}
    while (ble_pt_pop_raw(&old_raw)) {}
    book_layout_set_spacing(app_settings_book_line_spacing(), app_settings_book_paragraph_spacing());
    book_layout_set_images_visible(!app_settings_reader_hide_images());
    // 插图通栏：整屏宽是面板常量，进入阅读页说一次，之后每次重排都沿用同一条带。
    // Full-bleed illustrations: the panel width is a constant, so publish it once per entry and
    // every later re-layout reuses the same band.
    book_layout_set_image_bleed_width(UI_LOCK_WIDTH);
    // 竖排是阅读设置里的手动开关，进页时同步给排版；关着就是原来的横排。
    // Vertical setting is a manual reader switch, published to the layout on entry; off is the
    // original horizontal setting.
    book_layout_set_vertical(app_settings_book_vertical());
    book_layout_set_typography(((int)app_settings_book_tracking() + APP_BOOK_TRACK_MIN));
    book_layout_set_first_line_indent(app_settings_book_indent());
    book_layout_set_first_line_indent_adjust(app_settings_book_indent_adjust());
    book_layout_set_reading_line(app_settings_book_reading_line());
    book_layout_set_reading_line_offset(app_settings_book_reading_line_offset());
    // 字体页可能刚改过书内字体开关；回正文时重排当前章，别让用户对着旧排版猜。
    // The font page may have just changed the embedded-face switch; re-typeset this chapter
    // so the reader is not left guessing at stale type.
    bool book_fonts = app_settings_book_fonts();
    if (book_fonts != s_book_fonts_applied) {
        s_book_fonts_applied = book_fonts;
        book_set_embedded_fonts(book_fonts);
        if (s_text && book_kind() == BOOK_KIND_EPUB)
            (void)load_chapter(ctx, s_chapter, book_layout_page_start_offset(s_page), false);
    }
    s_reader_fullscreen = false;
    s_bookmark_edit = s_bookmark_delete_confirm = s_bookmark_delete_error = false;
    s_bookmark_selected = 0;
    clear_selection();
    s_view = s_requested_manage ? BULK : SHELF;
    s_reader_return_home = false;
    s_requested_manage = false;
    s_presented_view = -1;
    ctx->leaf = s_view==SHELF && s_categories ? s_categories[s_category_selected].pages[app_settings_shelf_style()==5] : 0;
    s_px = app_settings_book_px();
    s_recent_sort = app_settings_shelf_recent_sort();
    s_margin = app_settings_book_margin();
    s_margin_v = app_settings_book_margin_v();
    s_line_spacing = app_settings_book_line_spacing();
    // 传书页已停止并 join HTTP，安全注销且只丢弃对应路径的旧进度。
    // Transfer has stopped and joined HTTP; safely unregister only invalidated paths.
    pending_drop_invalidated();
    s_reader_panel = READER_PANEL_NONE;
    s_reader_slider = -1;
    s_clear_confirm = s_batch_confirm = false;
    s_pressed_control = -1;
    s_du_count = 0;
    s_shelf_feedback_pending = false;
    s_cover_batch_present_pending = false;
    s_reader_cleanup = false;
    s_poll_ms = 0;
    read_pico_sd_info_t sd = {0};
    esp_err_t media_err = read_pico_sd_get_info(&sd);
    bool reuse = s_shelf_cache_valid && media_err != ESP_ERR_NOT_FINISHED &&
                 sd.present == s_cache_sd_present && sd.mounted == s_cache_sd_mounted &&
                 s_cache_shelf_style == app_settings_shelf_style() &&
                 s_store_revision == book_store_revision();
    s_scan_pending = !reuse;
    if (reuse) {
        refresh_cached_progress(ctx);
        (void)open_requested_book(ctx);
    } else {
        s_count = s_visible_count = 0;
        s_message[0] = 0;
        s_storage[0] = 0;
        invalidate_covers();
        // 已指定文件可直接打开；书架目录留到真正进入书架时再扫描。
        // Open a requested file directly; scan the shelf only when it is actually shown.
        if (open_requested_book(ctx)) {
            s_scan_pending = false;
            return;
        }
        read_pico_sd_start_probe();
    }

}
static void book_on_exit(app_ctx_t* ctx) {
    // 离开图书应用：缩放状态、1bit 帧与连续 DU 相位一并释放。
    // Leaving the book app: release the zoom state, the 1-bit frame and continuous-DU phases.
    reader_zoom_reset();
    (void)book_highlight_save();
    book_highlight_unload();
    // 离开图书应用：首页预热状态（目录句柄、封面代次）一并释放。
    // Leaving the app: release any home-prewarm state (directory handles, cover generation).
    shelf_prewarm_abort();
    // 退出应用时把长按/拖动划线状态一并清掉；否则下次进入阅读页会带着上一轮的锚点。
    // Clear long-press/drag highlight state on exit; otherwise the next reader entry inherits it.
    s_hl_hold_pending = false;
    s_hl_drag_active = false;
    book_layout_set_highlight_preview((uint16_t)s_chapter, false, 0, 0);
    s_open_pending = false;
    s_highlight_page = 0;
    s_hl_return_valid = false;
    s_async_turn = 0;
    reader_indent_hold_cancel();
    s_shelf_key_mode=s_shelf_key_paint_pending=false;s_shelf_key_delta=s_shelf_key_pressed=0;
    book_cover_jobs_cancel(s_cover_generation);s_cover_generation=0;
    shelf_category_remember(ctx);
    s_category_menu=false;
    s_reader_tap.pending = false;
    s_shelf_page_pending = false;
    ui_keyboard_end();
    s_presented_view = -1;
    free(s_editor_cover); s_editor_cover = NULL;
    // 定向补白掩码约 79–102 KiB：应用退出时归还 PSRAM，下次进阅读页按需重建。
    // The targeted-settle ink mask costs about 79-102 KiB; return it when the app exits and rebuild
    // it lazily on the next reader session.
    s_edit_note_mode = false;
    s_edit_note_index = -1;
    s_pressed_control = -1;
    s_reader_slider = -1;
    save_progress();
    if ((int)epd_get_rotation() != EPD_ROT_INVERTED_PORTRAIT) {
        epd_set_rotation(EPD_ROT_INVERTED_PORTRAIT);
        s_reader_rot = EPD_ROT_INVERTED_PORTRAIT;
        s_reader_landscape = false;
    }
    s_orient_desired = EPD_ROT_INVERTED_PORTRAIT;
    s_orient_seen_n = 0;
    if (ctx->acc && sc7a20h_powered(ctx->acc)) (void)sc7a20h_power_down(ctx->acc);
    s_reader_return_home = false;
    ui_reader_background_release();
    free(s_backgrounds); s_backgrounds = NULL; s_background_count = 0;
    free_book();
    free(s_next_fb);
    s_next_fb = NULL;
    release_second_fb();
    if(s_prep_task){vTaskDelete(s_prep_task);s_prep_task=NULL;}
    if(s_prep_done){vSemaphoreDelete(s_prep_done);s_prep_done=NULL;}
    if (s_draw_lock) { vSemaphoreDelete(s_draw_lock); s_draw_lock = NULL; }
}
// 先停止使用旧卡句柄与字体预渲染，主循环随后切换内置字体。
// Stop old-card handles and font preparation before the loop switches to the builtin font.
static void book_on_media_lost(app_ctx_t* ctx) {
    reader_indent_hold_cancel();
    // 卡被移除：首页预热持有的目录句柄与封面任务全部作废。
    // The card is gone: any home-prewarm directory handles and cover jobs are void.
    shelf_prewarm_abort();
    s_shelf_prewarm_done_sig = 0;
    s_shelf_prewarm_retry_ms = 0;
    // 卡被移除后字体目录可能变了，下次重新扫描而不是沿用旧目录表。
    // The card is gone, so the font directory may change; rescan instead of trusting the old table.
    s_font_scan_done = false;
    s_shelf_key_mode=s_shelf_key_paint_pending=false;s_shelf_key_delta=s_shelf_key_pressed=0;
    shelf_category_remember(ctx);
    s_category_menu=false;
    s_reader_tap.pending = false;
    lock_draw();
    save_progress();
    free_book();
    unlock_draw();
    free(s_editor_cover); s_editor_cover = NULL;
    s_view = SHELF;
    s_count = s_visible_count = 0;
    s_shelf_cache_valid = false;
    free(s_shelf); s_shelf = NULL; s_shelf_capacity = 0;
    invalidate_covers();
    ctx->leaf = 0;
    s_reader_panel = READER_PANEL_NONE;
    s_reader_slider = -1;
    s_clear_confirm = s_batch_confirm = false;
    s_pressed_control = -1;
    s_scan_pending = true;
    s_du_count = 0;
    copy_text(s_storage, sizeof(s_storage), "TF 卡已移除");
    copy_text(s_message, sizeof(s_message), "TF 卡已移除");
}
static void book_on_media_ready(app_ctx_t* ctx) {
    (void)ctx;
    shelf_prewarm_abort();
    s_shelf_prewarm_done_sig = 0;
    s_shelf_prewarm_retry_ms = 0;
    s_shelf_cache_valid = false;
    // 重新挂载后可能有新字体导入，目录表与预览遮罩都按新目录重建。
    // A fresh mount may carry new faces; rebuild both the catalogue and the preview masks.
    s_font_scan_done = false;
    font_preview_clear();
    if (s_view == SHELF) s_scan_pending = true;
}
// 控件编号仅用于保持按下与抬起命中同一个目标。/ IDs pair a press with release on the same control.
static int control_at(app_ctx_t* ctx, uint16_t x, uint16_t y, EpdRect* rect) {
    if (s_view==SHELF && (s_category_menu || ui_rect_hit((EpdRect){24,79,306,74},x,y))) return -1;
    if (s_view == BULK) return bulk_control_at(ctx, x, y, rect);
    if (s_view == MANAGE) {
        *rect = manage_back_rect();
        if (ui_rect_hit(*rect, x, y)) return 711;
    }
    if (s_view == IMPORT) {
        *rect = (EpdRect){36, 79, 58, 58};
        if (ui_rect_hit(*rect, x, y)) return 700;
        for (int i = 0; i < 4; ++i) {
            *rect = import_rect(i);
            if (ui_rect_hit(*rect, x, y)) return 701 + i;
        }
        int tab = ui_nav_hit(x, y);
        if (tab >= 0) { *rect = (EpdRect){tab * 171, UI_NAV_TOP, 171, 120}; return 705 + tab; }
        return -1;
    }
    if (s_view == SEARCH) {
        for (int i = 0; i < 45; ++i) { *rect = search_rect(i); if (ui_rect_hit(*rect, x, y)) return 500 + i; }
        return -1;
    }
    if (s_view == MANAGE) {
        if (!s_clear_confirm && !s_file_removed) {
            *rect = (EpdRect){UI_MARGIN, manage_panel().y + manage_panel().height - 274, ui_content_width(), 68};
            if (ui_rect_hit(*rect, x, y)) return 405;
            *rect = (EpdRect){UI_MARGIN, manage_panel().y + manage_panel().height - 190, ui_content_width(), 68};
            if (ui_rect_hit(*rect, x, y)) return 404;
        }
        int count = s_clear_confirm || s_file_removed ? 2 : 3;
        for (int i = 0; i < count; ++i) {
            *rect = manage_rect(i, count);
            if (ui_rect_hit(*rect, x, y)) return s_clear_confirm ? 300 + i : s_file_removed && i == 1 ? 403 : 400 + i;
        }
        return -1;
    }
    if (s_clear_confirm) {
        for (int i = 0; i < 2; ++i) {
            *rect = ui_row_rect(i, 2, 610, UI_BTN_H);
            if (ui_rect_hit(*rect, x, y)) return 300 + i;
        }
        return -1;
    }
    if (s_view == READING) {
        if (s_reader_panel == READER_PANEL_TOOLS) for (int i = 0; i < BOOK_TOOL_COUNT; ++i) {
            *rect = tool_rect(i);
            if (ui_rect_hit(*rect, x, y)) return 200 + i;
        }
        return -1;
    }
    if (s_view != SHELF) for (int i = 0; i < 3; ++i) {
        *rect = ui_bar_rect(i, 3);
        if (ui_rect_hit(*rect, x, y)) return 100 + i;
    }
    if (s_view == SHELF && ui_rect_hit(shelf_search_rect(), x, y)) { *rect = shelf_search_rect(); return 113; }
    if (s_view == SHELF && ui_rect_hit(shelf_manage_rect(), x, y)) { *rect = shelf_manage_rect(); return 114; }
    if (s_view == SHELF && ui_rect_hit(shelf_import_rect(), x, y)) { *rect = shelf_import_rect(); return 115; }
    if (s_view == SHELF) {
        for (int i = UI_PAGER_FIRST; i <= UI_PAGER_LAST; ++i) {
            *rect = i==UI_PAGER_PREVIOUS?shelf_page_arrow_rect(-1):i==UI_PAGER_NEXT?shelf_page_arrow_rect(1):ui_pager_rect(i);
            if (ui_rect_hit(*rect, x, y)) return 116 + i;
        }
    }
    if (s_message[0] && !((s_view == SHELF || s_view == BULK) && s_visible_count)) return -1;
    int rows = s_view == BULK ? BOOK_BULK_ROWS : shelf_rows();
    int count = s_visible_count;
    for (int row = 0; row < rows && ctx->leaf * rows + row < count; ++row) {
        *rect = row_rect(row);
        if (ui_rect_hit(*rect, x, y)) return row;
    }
    return -1;
}
static app_redraw_t paint_control(app_ctx_t* ctx, EpdRect rect) {
    if(s_view==SHELF)for(int i=UI_PAGER_FIRST;i<=UI_PAGER_LAST;++i){
        EpdRect r=ui_pager_rect(i);
        if(!memcmp(&rect,&r,sizeof(r)))return shelf_key_paint(ctx);
    }
    if (s_view == SHELF && app_settings_shelf_style() == 5) {
        for (int row = 0; row < shelf_rows(); ++row) {
            EpdRect target = row_rect(row);
            if (memcmp(&rect, &target, sizeof(rect))) continue;
            s_area = paint_list_cover_feedback(ctx, row);
            s_mode = app_settings_main_fast_refresh() ? MODE_DU : MODE_GL16;
            s_shelf_feedback_pending = true;
            return APP_REDRAW_AREA;
        }
    }
    // 网格书架的按压反馈只重画这一格（封面+层板），不再整页 render：手指按下到
    // 视觉反馈之间少掉一次全屏绘制，书架点按更跟手。
    // Grid-shelf press feedback repaints just this cell (cover + shelf board) instead of a full
    // render, removing one whole-page draw between touch-down and the visual response.
    if (s_view == SHELF) {
        for (int row = 0; row < shelf_rows(); ++row) {
            EpdRect target = row_rect(row);
            if (memcmp(&rect, &target, sizeof(rect))) continue;
            const int index = ctx->leaf * shelf_rows() + row;
            if (index < 0 || index >= s_visible_count) break;
            EpdRect image = shelf_cover_image(row);
            EpdRect lifted = image;
            lifted.y -= SHELF_BOOK_LIFT_PX;
            EpdRect area = ui_rect_union(target, lifted);
            ui_fill_rect_fast(area, UI_GRAY_WHITE, ctx->fb);
            EpdRect card = target;
            if (s_pressed_control == row) card.y -= SHELF_BOOK_LIFT_PX;
            draw_shelf_cover(ctx->fb, card, row, s_shelf[index].name, s_shelf[index].favorite);
            // 层板/亚克力挡板在完整绘制里排在封面之后，这里只补本行，别扫到相邻行。
            // Shelf boards/acrylic guards come after covers in the full paint; redraw only this
            // row's furniture so neighbouring rows are never touched.
            const uint8_t style = app_settings_shelf_style();
            const int top = (s_view == SHELF ? 192 : 224) + row * 282;
            if (style == 1) {
                ui_fill_rect_fast((EpdRect){36, top + 214, 612, 12}, 0x30, ctx->fb);
                ui_hairline(ctx->fb, top + 214, 36, 612, 0x58);
                ui_hairline(ctx->fb, top + 225, 36, 612, 0x10);
            } else if (style == 2) {
                draw_shelf_guard(ctx->fb, (EpdRect){20, top + 136, 644, 90}, row);
            }
            s_area = area;
            s_mode = MODE_DU;
            s_shelf_feedback_pending = true;
            return APP_REDRAW_AREA;
        }
    }
    // 小按钮反馈只重画按钮，不重新绘制全部封面；其余装饰沿用原绘制路径。
    // Repaint small header buttons alone rather than every cover; other decorations retain their path.
    if (s_view == SHELF && !memcmp(&rect, &(EpdRect){333,94,97,54}, sizeof(rect)))
        draw_shelf_header_button(ctx->fb, rect, 2);
    else if (s_view == SHELF && !memcmp(&rect, &(EpdRect){442,94,97,54}, sizeof(rect)))
        draw_shelf_header_button(ctx->fb, rect, 0);
    else if (s_view == SHELF && !memcmp(&rect, &(EpdRect){551,94,97,54}, sizeof(rect)))
        draw_shelf_header_button(ctx->fb, rect, 1);
    else render(ctx, ctx->fb);
    s_mode = MODE_DU;
    s_shelf_feedback_pending = false;
    if (s_view == SHELF) {
        for (int row = 0; row < shelf_rows(); ++row) {
            EpdRect target = row_rect(row);
            if (rect.x != target.x || rect.y != target.y ||
                rect.width != target.width || rect.height != target.height) continue;
            // 覆盖抽出前后的并集，释放或取消时也擦净上方的旧封面。
            // Refresh both book positions so release or cancellation clears the lifted edge.
            rect.y -= SHELF_BOOK_LIFT_PX;
            rect.height += SHELF_BOOK_LIFT_PX;
            s_mode = MODE_GL16;
            s_shelf_feedback_pending = true;
            break;
        }
    }
    s_area = rect;
    return APP_REDRAW_AREA;
}
// 底部上滑呼出工具栏固定生效；正文四向滑动按其手势槽位派发（经典预设仍是左右翻页）。
// The bottom-edge tools swipe always works; body swipes follow their gesture slots (the classic
// preset keeps left/right page turns).
// 从屏幕底部120px上滑呼出工具栏；其他面板保留自己的滑动，正文中部按手势映射解释。
// Open tools from the bottom 120px; other panels keep their own swipes and mid-body swipes
// follow the gesture map.
static bool reader_tools_swipe(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (s_view != READING || !s_text || s_reader_panel != READER_PANEL_NONE ||
        s_clear_confirm || s_scan_pending || ctx->consumed || ev->type != UI_GESTURE_SWIPE_U ||
        ev->x0 >= reader_scr_w() || ev->y0 < reader_scr_h() - 120 || ev->y0 >= reader_scr_h()) return false;
    s_reader_tap.pending = false;
    s_pressed_control = s_reader_slider = -1;
    s_reader_panel = READER_PANEL_TOOLS;
    s_stats_activity_ms = ctx->now_ms;
    ctx->user_activity = true;
    invalidate_prep();
    return true;
}
// 旧滑动方向规则；只留给兼容路径：工具栏展开时的正文滑动、以及 NONE 槽位在上下翻页模式下的回退。
// Legacy swipe direction rules, kept only for the compatibility paths: body swipes above the open
// toolbar, and the vertical-turn fallback of a NONE slot.
static int reader_swipe_direction(ui_gesture_type_t type, bool vertical) {
    int direction = 0;
    if (type == UI_GESTURE_SWIPE_L || (vertical && type == UI_GESTURE_SWIPE_U)) direction = 1;
    else if (type == UI_GESTURE_SWIPE_R || (vertical && type == UI_GESTURE_SWIPE_D)) direction = -1;
    if (direction && !vertical && app_settings_book_vertical()) direction = -direction;
    return direction;
}

// 开始划线：长按延时到点且手指仍按住时由 on_tick 调用。
// Begin a highlight from the delayed long-press while the finger is still down.
static app_redraw_t reader_highlight_begin(app_ctx_t *ctx, uint16_t x, uint16_t y) {
    // 先停掉后台预渲染：它和划线共用布局的行走状态，并发放着会让取字失败。
    // Stop the background prefetcher first: it shares the layout's glyph cursor.
    reader_prefetch_stop();
    uint32_t char_start, char_len;
    if (!book_layout_char_at(s_page, body_rect(), s_px, x, y, &char_start, &char_len))
        return APP_REDRAW_NONE;
    // 长按落在已划线的句子上：删除整段划线，不再进入拖动。
    // Long-press on an already highlighted sentence deletes that whole range and never starts a drag.
    int hit = -1;
    const int total = book_highlight_count();
    for (int i = 0; i < total; ++i) {
        uint16_t hc = 0;
        uint32_t hs = 0, he = 0;
        if (book_highlight_at(i, &hc, &hs, &he, NULL) < 0) continue;
        if (hc == (uint16_t)s_chapter && char_start >= hs && char_start < he) {
            hit = i;
            break;
        }
    }
    if (hit >= 0) {
        (void)book_highlight_remove(hit);
        copy_text(s_reader_notice, sizeof(s_reader_notice), "已删除划线");
        s_reader_notice_until = esp_timer_get_time() / 1000 + 1400;
        s_reader_tap.pending = false;
        invalidate_prep();
        render(ctx, ctx->fb);
        s_area = body_rect();
        s_mode = MODE_GL16;
        return APP_REDRAW_AREA;
    }
    s_hl_drag_active = true;
    s_hl_drag_anchor_start = char_start;
    s_hl_drag_anchor_len = char_len;
    s_hl_drag_start = char_start;
    s_hl_drag_end = char_start + char_len;
    s_hl_drag_next_ms = ctx->now_ms;
    s_reader_tap.pending = false;
    s_pressed_control = -1;
    book_layout_set_highlight_preview((uint16_t)s_chapter, true, s_hl_drag_start, s_hl_drag_end);
    render(ctx, ctx->fb);
    s_area = body_rect();
    s_mode = MODE_GL16;
    return APP_REDRAW_AREA;
}
static app_redraw_t gesture_event(app_ctx_t* ctx, const ui_gesture_event_t* ev) {
    // 字体异常提示是模态框：只认两个按钮，其他手势一律忽略（与 rc100 行为一致）。
    // The font-recovery dialog is modal: only its two buttons respond, every other gesture is ignored.
    if (s_view == READING && s_reader_panel == READER_PANEL_FONT_RECOVERY)
        return reader_font_recovery_gesture(ctx, ev);
    // 长按划线拖动期间手势事件全部交给 on_tick 的原始坐标轮询，这里不再分类/翻页。
    // During a highlight drag all gesture events are ignored; on_tick polls raw touch instead.
    if (s_hl_drag_active) return APP_REDRAW_NONE;
    // Released or tapped before the highlight hold deadline: cancel the pending start.
    if (s_hl_hold_pending &&
        (ev->type == UI_GESTURE_PRESS || ev->type == UI_GESTURE_TAP ||
         ev->type == UI_GESTURE_CANCEL || ev->type == UI_GESTURE_SWIPE_L ||
         ev->type == UI_GESTURE_SWIPE_R || ev->type == UI_GESTURE_SWIPE_U ||
         ev->type == UI_GESTURE_SWIPE_D))
        s_hl_hold_pending = false;
    // Touch keeps reporting portrait logical coordinates in landscape; map before any hit test.
    if (app_settings_reader_adaptive() && !s_orient_ref_ready && ev->type == UI_GESTURE_TAP)
        s_orient_calibrate = true;
    ui_gesture_event_t mapped;
    if (reader_touch_needs_map()) {
        int x0 = ev->x0, y0 = ev->y0, x = ev->x, y = ev->y;
        mapped = *ev;
        reader_touch_map(&x0, &y0);
        reader_touch_map(&x, &y);
        mapped.x0 = (uint16_t)x0; mapped.y0 = (uint16_t)y0;
        mapped.x = (uint16_t)x; mapped.y = (uint16_t)y;
        // The gesture type was classified from raw portrait deltas; re-classify it in the
        // rotated frame so page turns, the tools swipe and back swipes all follow the screen.
        switch (ev->type) {
            case UI_GESTURE_SWIPE_L: case UI_GESTURE_SWIPE_R:
            case UI_GESTURE_SWIPE_U: case UI_GESTURE_SWIPE_D: {
                const int ldx = x - x0, ldy = y - y0;
                const int ax = ldx < 0 ? -ldx : ldx, ay = ldy < 0 ? -ldy : ldy;
                mapped.type = ax >= ay
                    ? (ldx < 0 ? UI_GESTURE_SWIPE_L : UI_GESTURE_SWIPE_R)
                    : (ldy < 0 ? UI_GESTURE_SWIPE_U : UI_GESTURE_SWIPE_D);
                break;
            }
            default: break;
        }
        ev = &mapped;
    }
    // 插图缩放的平移手势优先于通用阅读手势：缩放视图里的拖动只平移图片，
    // 结束的滑动被吃掉，不翻页也不切工具栏。
    // Illustration-zoom pan takes precedence over shared reader gestures: a drag in the zoom
    // view pans the image, and the ending swipe is swallowed so it neither turns a page nor
    // toggles the toolbar.
    bool zoom_handled = false;
    app_redraw_t zoom_redraw = image_zoom_gesture(ctx, ev, &zoom_handled);
    if (zoom_handled) return zoom_redraw;
    bool indent_handled=false;
    app_redraw_t indent_redraw=reader_indent_gesture(ctx,ev,&indent_handled);
    if(indent_handled)return indent_redraw;
    // 插图缩放视图：缩放与平移由上面的 image_zoom_gesture / on_pinch 处理；单击仍走普通
    // 翻页路径（翻页即退出缩放），长按在缩放视图里暂时忽略，避免对隐藏正文起划线。
    // Inline zoom view: zoom and pan come from image_zoom_gesture / on_pinch above; a single tap
    // keeps the ordinary turn path (a turn leaves the zoom view), and long presses are ignored
    // here so a highlight cannot start on hidden body text.
    // 阅读页底部“返回前阅读位置”：先于其它阅读手势判断。
    if (s_view == READING && ev->type == UI_GESTURE_TAP &&
        s_reader_panel == READER_PANEL_NONE && !s_toolbar && s_hl_return_valid &&
        ui_rect_hit(reader_hl_return_rect(), ev->x0, ev->y0)) {
        if (s_hl_return_chapter < book_chapter_count() &&
            load_chapter(ctx, s_hl_return_chapter, s_hl_return_offset, false))
            save_progress();
        s_hl_return_valid = false;
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    // 本章跳转后 7 秒内的「返回跳转前」浮标：只认落在同一矩形内的点按，先于普通翻页手势。
    // The post-jump "back" badge listens only for taps inside its rect, before ordinary turn gestures.
    if (s_view == READING && ev->type == UI_GESTURE_TAP && s_reader_panel == READER_PANEL_NONE &&
        !s_toolbar && chapter_jump_undo_visible() &&
        ui_rect_hit(chapter_jump_undo_rect(), ev->x0, ev->y0) &&
        ui_rect_hit(chapter_jump_undo_rect(), ev->x, ev->y)) {
        s_reader_tap.pending = false;
        return reader_chapter_jump_commit(ctx, 0, true);
    }
    // 划线列表里长按一条记录：打开笔记编辑器（点按仍是跳转，标签/删除按钮各自独立）。
    // Long-press a highlight row opens the note editor; taps still jump, tag/delete stay separate.
    if (s_view == READING && s_reader_panel == READER_PANEL_HIGHLIGHTS &&
        ev->type == UI_GESTURE_LONG_PRESS) {
        const int count = book_highlight_count();
        for (int row = 0; row < highlight_rows(); ++row) {
            const int index = count - 1 - (s_highlight_page * highlight_rows() + row);
            if (index < 0) break;
            if (ui_rect_hit(highlight_row_rect(row), ev->x0, ev->y0)) {
                editor_start_note(index);
                return APP_REDRAW_PAGE;
            }
        }
    }
    // 只有书架题头（标题+下拉箭头）算二级分类入口；右侧搜索/管理/导入按钮不能落进这里。
    // Only the shelf title + caret open the category menu; the search/manage/import buttons to
    // the right must not be swallowed by this hit area.
    if (s_view==SHELF && (s_category_menu || ui_rect_hit((EpdRect){24,79,306,74},ev->x0,ev->y0)))
        return shelf_category_gesture(ctx,ev);
    if (s_view == READING && (s_reader_panel == READER_PANEL_BACKGROUND ||
        s_reader_panel == READER_PANEL_BACKGROUND_MENU ||
        s_reader_panel == READER_PANEL_BACKGROUND_PREVIEW) &&
        (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D)) {
        return reader_background_step(ev->type == UI_GESTURE_SWIPE_U ? 1 : -1);
    }
    if (ev->type == UI_GESTURE_CANCEL || ev->type == UI_GESTURE_LONG_PRESS ||
        ev->type == UI_GESTURE_SWIPE_L || ev->type == UI_GESTURE_SWIPE_R ||
        ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D ||
        (ev->type == UI_GESTURE_PRESS && !reader_zoom_mode() &&
         !reader_page_image_hit(ev->x0, ev->y0) &&
         !book_reader_center(body_rect(), ev->x0, ev->y0)))
        s_reader_tap.pending = false;
    if (reader_tools_swipe(ctx, ev)) return APP_REDRAW_PAGE;
    bool input_feedback = false;
    if (s_view == SEARCH || s_view == EDIT) {
        if (ev->type == UI_GESTURE_PRESS)
            return ui_keyboard_press(ev->x0, ev->y0, 560, ctx->now_ms) ? editor_paint(ctx, false) : APP_REDRAW_NONE;
        input_feedback = ev->type != UI_GESTURE_LONG_PRESS && ui_keyboard_release();
    }
    if (s_view == SEARCH) {
        if (ev->type == UI_GESTURE_TAP) return action_at(ctx, ev->x0, ev->y0);
        if (ev->type == UI_GESTURE_SWIPE_L || ev->type == UI_GESTURE_SWIPE_R) {
            if (!ui_keyboard_page(ev->type == UI_GESTURE_SWIPE_L ? 1 : -1) && !input_feedback) return APP_REDRAW_NONE;
            return editor_paint(ctx, false);
        }
        return input_feedback ? editor_paint(ctx, false) : APP_REDRAW_NONE;
    }
    if (s_view == TOC) {
        if (s_toc_jump_open) {
            if (ev->type == UI_GESTURE_PRESS &&
                book_toc_jump_hit(ev->x0, ev->y0) == BOOK_TOC_JUMP_TRACK) {
                s_toc_jump_drag = true;
                s_toc_jump_percent = book_toc_jump_percent(ev->x0);
                return APP_REDRAW_PAGE;
            }
            if (s_toc_jump_drag && ev->type == UI_GESTURE_MOVE) {
                int next = book_toc_jump_percent(ev->x);
                if (next == s_toc_jump_percent) return APP_REDRAW_NONE;
                s_toc_jump_percent = next;
                render(ctx, ctx->fb);
                s_area = book_toc_jump_rect();
                s_mode = MODE_GL16;
                return APP_REDRAW_AREA;
            }
            if (s_toc_jump_drag && ev->type != UI_GESTURE_PRESS) {
                s_toc_jump_drag = false;
                if (ev->type == UI_GESTURE_CANCEL) return APP_REDRAW_NONE;
                s_toc_jump_percent = book_toc_jump_percent(ev->x);
                return APP_REDRAW_PAGE;
            }
            if (ev->type == UI_GESTURE_TAP) return action_at(ctx, ev->x0, ev->y0);
            return APP_REDRAW_NONE;
        }
        if (ev->type == UI_GESTURE_TAP) {
            int start = book_toc_hit(ev->x0, ev->y0, ctx->leaf, book_navigation_count());
            int end = book_toc_hit(ev->x, ev->y, ctx->leaf, book_navigation_count());
            if (start != -1 && start == end) return action_at(ctx, ev->x0, ev->y0);
        }
        if (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D) {
            int next = ctx->leaf + (ev->type == UI_GESTURE_SWIPE_U ? 1 : -1);
            if (next >= 0 && next < leaves()) { ctx->leaf = next; return APP_REDRAW_PAGE; }
        }
        return APP_REDRAW_NONE;
    }
    if (s_view == EDIT) {
        if (ev->type == UI_GESTURE_TAP) return editor_action(ctx, ev->x0, ev->y0);
        if (ev->type == UI_GESTURE_SWIPE_L || ev->type == UI_GESTURE_SWIPE_R)
            return (ui_keyboard_page(ev->type == UI_GESTURE_SWIPE_L ? 1 : -1) || input_feedback) ? editor_paint(ctx, false) : APP_REDRAW_NONE;
        return input_feedback ? editor_paint(ctx, false) : APP_REDRAW_NONE;
    }
    if (s_view == SHELF && ev->type == UI_GESTURE_TAP && ui_nav_hit(ev->x0, ev->y0) >= 0) {
        ui_nav_request(ctx, ui_nav_hit(ev->x0, ev->y0));
        return APP_REDRAW_NONE;
    }
    if (s_view == READING && ev->type != UI_GESTURE_PRESS) s_stats_activity_ms = ctx->now_ms;
    if (s_view == READING &&
        (s_reader_panel == READER_PANEL_FONT_SETTINGS || s_reader_panel == READER_PANEL_LAYOUT_SETTINGS)) {
        if (ev->type == UI_GESTURE_PRESS) {
            int slider = reader_slider_at(ev->x0, ev->y0);
            if (slider >= 0) {
                reader_slider_begin(slider, ev->x0);
                render(ctx, ctx->fb);
                s_area = reader_slider_refresh_rect(slider);
                s_mode = MODE_GL16;
                return APP_REDRAW_AREA;
            }
        } else if (s_reader_slider >= 0) {
            if (ev->type == UI_GESTURE_MOVE) {
                int slider = s_reader_slider;
                reader_slider_move(ev->x);
                render(ctx, ctx->fb);
                s_area = reader_slider_refresh_rect(slider);
                s_mode = MODE_GL16;
                return APP_REDRAW_AREA;
            }
            if (ev->type == UI_GESTURE_TAP || ev->type == UI_GESTURE_SWIPE_L ||
                ev->type == UI_GESTURE_SWIPE_R || ev->type == UI_GESTURE_SWIPE_U ||
                ev->type == UI_GESTURE_SWIPE_D || ev->type == UI_GESTURE_LONG_PRESS) {
                if (!s_reader_slider_endpoint) reader_slider_move(ev->x);
                return reader_slider_commit(ctx);
            }
            if (ev->type == UI_GESTURE_CANCEL) {
                s_reader_slider = -1;
                return APP_REDRAW_PAGE;
            }
        }
    }
    if (s_view == READING && s_reader_panel == READER_PANEL_FONT_PICKER &&
        (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D)) {
        int count = ttf_font_count();
        int pages = count > 0 ? (count + BOOK_FONT_PAGE - 1) / BOOK_FONT_PAGE : 1;
        if (ev->type == UI_GESTURE_SWIPE_U && s_font_page + 1 < pages) ++s_font_page;
        else if (ev->type == UI_GESTURE_SWIPE_D && s_font_page > 0) --s_font_page;
        else return APP_REDRAW_NONE;
        return APP_REDRAW_PAGE;
    }
    EpdRect start_rect = {0}, end_rect = {0};
    int start = control_at(ctx, ev->x0, ev->y0, &start_rect);
    int end = control_at(ctx, ev->x, ev->y, &end_rect);
    if (ev->type == UI_GESTURE_PRESS) {
        s_pressed_control = start;
        return start >= 0 ? paint_control(ctx, start_rect) : APP_REDRAW_NONE;
    }
    bool decorated = s_pressed_control >= 0;
    s_pressed_control = -1;
    if (ev->type == UI_GESTURE_LONG_PRESS && start == end) {
        if (s_view == SHELF && start >= 0 && start < shelf_rows() && !s_clear_confirm) {
            s_managed = s_shelf[ctx->leaf * shelf_rows() + start];
            s_view = MANAGE;
            s_clear_confirm = false;
            s_delete_confirm = s_file_removed = s_managed.removed;
            copy_text(s_manage_message, sizeof(s_manage_message), s_file_removed ? "文件已删除，进度清理失败，请重试" : "");
            return APP_REDRAW_PAGE;
        }
        if (s_view == READING && !s_toolbar && !s_clear_confirm && !s_scan_pending &&
            !s_zoom_active && ui_rect_hit(body_rect(), ev->x0, ev->y0)) {
            // 长按按"长按正文"槽位派发；经典预设映射到划线，所以旧的"划线/目录"开关仍然有效：
            // 关闭长按划线时依旧直接打开目录，与手势配置接入前完全一致。
            // Long-press dispatches the LONG_PRESS slot. The classic preset maps it to highlight,
            // so the legacy highlight/directory switch still decides: with highlighting switched
            // off the hold opens the directory exactly as it did before gesture settings.
            const app_gesture_action_t action =
                app_settings_gesture_action(APP_GESTURE_LONG_PRESS);
            if (action != APP_GESTURE_ACTION_HIGHLIGHT)
                return reader_gesture_action(ctx, action);
            // 关闭“长按划线”后恢复原来的长按行为：直接打开目录。
            // With highlighting switched off, long-press restores the original behaviour and
            // opens the directory.
            if (!app_settings_reader_long_press_highlight())
                return reader_gesture_action(ctx, APP_GESTURE_ACTION_TOC);
            // 划线长按比通用长按多等一会儿：手势层 500 ms 就发 LONG_PRESS，这里记一个
            // 更晚的截止时间，由 on_tick 在手指仍按住时正式开始划线。
            // The highlight hold waits a little longer than the generic long press: the gesture
            // layer reports LONG_PRESS at 500 ms, so arm a later deadline and start from on_tick
            // while the finger is still down.
            s_hl_hold_pending = true;
            s_hl_hold_due_ms = ctx->now_ms + READER_HIGHLIGHT_HOLD_EXTRA_MS;
            s_hl_hold_x = ev->x0;
            s_hl_hold_y = ev->y0;
            s_reader_tap.pending = false;
            return APP_REDRAW_NONE;
        }
    }
    if (ev->type == UI_GESTURE_TAP && !s_scan_pending) {
        if (start >= 0 && start == end) {
            // 列表先完成回弹，才释放封面缓存并开书；没有人为等待或整页预刷新。
            // Settle a list bounce before opening frees artwork, without a delay or whole-page pre-refresh.
            if (decorated && s_view == SHELF && app_settings_shelf_style() == 5 && start < shelf_rows())
                (void)present(ctx, paint_control(ctx, start_rect));
            app_redraw_t result = action_at(ctx, ev->x0, ev->y0);
            if (ctx->request_app || ctx->request_menu || ctx->request_return) return result;
            return result != APP_REDRAW_NONE ? result : paint_control(ctx, start_rect);
        }
        if (start < 0 && end < 0 && s_view == READING && !s_clear_confirm)
            return action_at(ctx, ev->x0, ev->y0);
    }
    if (!s_clear_confirm && !s_scan_pending) {
        if (s_view == READING && (!s_toolbar || (s_reader_panel == READER_PANEL_TOOLS &&
            ev->y0 < reader_tool_bar_top())) &&
            ui_rect_hit(body_rect(), ev->x0, ev->y0)) {
            if (s_reader_panel == READER_PANEL_NONE) {
                // 底部 120px 上滑呼出工具栏已由 reader_tools_swipe() 先行处理；这里只派发四向
                // 滑动的槽位映射，映射为不动作时保持原来的"不翻页"结果。
                // The bottom-edge tools swipe was handled by reader_tools_swipe already; this
                // block only dispatches the four swipe slots and leaves NONE as a no-turn result.
                app_redraw_t gesture = reader_gesture_swipe(ctx, ev);
                if (gesture != APP_REDRAW_NONE) return gesture;
            } else {
                // 工具栏展开时正文上方的滑动沿用旧语义，只翻页，不派发其它手势动作。
                // Swipes above the open toolbar keep the legacy page-turn-only semantics.
                const int direction = reader_swipe_direction(ev->type,
                                                             app_settings_reader_vertical_turn());
                if (direction) { ctx->user_activity = true; return turn_page(ctx, direction); }
            }
        } else if (s_view == SHELF && (ev->type == UI_GESTURE_SWIPE_L || ev->type == UI_GESTURE_SWIPE_R)) {
            app_redraw_t result = shelf_turn_page(ctx, ev->type == UI_GESTURE_SWIPE_L ? 1 : -1);
            if (result != APP_REDRAW_NONE) return result;
        } else if ((s_view == BULK && !s_batch_confirm) &&
                   (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D)) {
            return bulk_turn_page(ctx, ev->type == UI_GESTURE_SWIPE_U ? 1 : -1);
        }
    }
    return decorated ? paint_control(ctx, start_rect) : APP_REDRAW_NONE;
}
static app_redraw_t reader_key_action(app_ctx_t *ctx, app_reader_key_action_t action) {
    s_reader_tap.pending = false;
    switch (action) {
        case APP_READER_KEY_PREV: case APP_READER_KEY_NEXT:
            s_stats_activity_ms = ctx->now_ms;
            return turn_page(ctx, action == APP_READER_KEY_PREV ? -1 : 1);
        case APP_READER_KEY_HOME: return reader_return(ctx);
        case APP_READER_KEY_FULLSCREEN: return toggle_reader_fullscreen(ctx);
        case APP_READER_KEY_REFRESH: return reader_manual_refresh(ctx);
        case APP_READER_KEY_TOOLS:
            s_reader_slider = -1;
            s_reader_panel = s_reader_panel == READER_PANEL_TOOLS ? READER_PANEL_NONE : READER_PANEL_TOOLS;
            invalidate_prep();
            return APP_REDRAW_PAGE;
        default: return APP_REDRAW_NONE;
    }
}
// 手势动作派发：与三键动作等价，但用独立的手势动作枚举；目录与划线沿用现有阅读路径。
// 调用方已经检查过"正文、无面板、无划线拖动"这些前提。
// Gesture action dispatch, equivalent to the key actions but on the gesture enum; TOC and
// highlight reuse the existing reader paths. The caller already checked body / no-panel state.
static app_redraw_t reader_gesture_action(app_ctx_t *ctx, app_gesture_action_t action) {
    s_reader_tap.pending = false;
    switch (action) {
        case APP_GESTURE_ACTION_PREV: case APP_GESTURE_ACTION_NEXT:
            s_stats_activity_ms = ctx->now_ms;
            return turn_page(ctx, action == APP_GESTURE_ACTION_PREV ? -1 : 1);
        case APP_GESTURE_ACTION_HOME: return reader_return(ctx);
        case APP_GESTURE_ACTION_FULLSCREEN: return toggle_reader_fullscreen(ctx);
        case APP_GESTURE_ACTION_REFRESH: return reader_manual_refresh(ctx);
        case APP_GESTURE_ACTION_TOOLS:
            s_reader_slider = -1;
            s_reader_panel = s_reader_panel == READER_PANEL_TOOLS ? READER_PANEL_NONE
                                                                 : READER_PANEL_TOOLS;
            invalidate_prep();
            return APP_REDRAW_PAGE;
        case APP_GESTURE_ACTION_TOC: {
            // 与长按开目录逐字一致：先存进度，再切目录视图并定位到当前章。
            // Same as the long-press TOC path: save progress, switch view, locate the chapter.
            save_progress();
            set_reader_view(TOC);
            s_message[0] = 0;
            s_toc_jump_open = s_toc_jump_drag = false;
            s_reader_panel = READER_PANEL_NONE;
            size_t toc = current_toc_position();
            ctx->leaf = toc == SIZE_MAX ? 0 : (int)(toc / BOOK_TOC_ROWS);
            return APP_REDRAW_PAGE;
        }
        default: return APP_REDRAW_NONE;  // 划线与不操作在此没有副作用 / No side effect here
    }
}
// 正文四向滑动按槽位映射；左右滑动保留竖排正文的方向反转。槽位为 NONE 时不动作，但
// 上下翻页模式下的上下滑动仍按旧的 reader_swipe_direction 翻页（经典预设的回归保险）。
// Body swipes follow the slot map and horizontal moves keep the vertical-text mirror. A NONE
// slot does nothing, except up/down swipes in vertical-turn mode still page like the legacy path.
static app_redraw_t reader_gesture_swipe(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    // 经典预设 = 旧行为：四向滑动整段交给旧的 reader_swipe_direction()，包括上下翻页模式下
    // 上下滑动翻页、竖排正文的左右反转，以及左右滑动不叠加手势表。预设 1 的槽位行只用于界面
    // 显示；只有自定义与预设 2/3/4 才走下面的槽位绝对映射。
    // Classic preset means the old behaviour verbatim: all four swipes go through the legacy
    // helper (up/down turn in vertical-turn mode, vertical-text mirror, no slot table). The classic
    // slot row is display-only; only custom and presets 2..4 use the absolute slot map below.
    if (app_settings_gesture_preset() == 1) {
        const int direction = reader_swipe_direction(ev->type, app_settings_reader_vertical_turn());
        if (!direction) return APP_REDRAW_NONE;
        ctx->user_activity = true;
        s_stats_activity_ms = ctx->now_ms;
        return turn_page(ctx, direction);
    }
    app_gesture_slot_t slot;
    switch (ev->type) {
        case UI_GESTURE_SWIPE_U: slot = APP_GESTURE_SWIPE_UP; break;
        case UI_GESTURE_SWIPE_D: slot = APP_GESTURE_SWIPE_DOWN; break;
        case UI_GESTURE_SWIPE_L: slot = APP_GESTURE_SWIPE_LEFT; break;
        case UI_GESTURE_SWIPE_R: slot = APP_GESTURE_SWIPE_RIGHT; break;
        default: return APP_REDRAW_NONE;
    }
    const app_gesture_action_t action = app_settings_gesture_action(slot);
    if (action == APP_GESTURE_ACTION_NONE) {
        // 预设 2/3/4 与自定义的 NONE 槽位：上下翻页模式下上下滑动继续翻页，其余真的不动作。
        // A NONE slot under custom or presets 2..4: vertical-turn mode keeps up/down paging,
        // everything else really does nothing.
        if (slot == APP_GESTURE_SWIPE_UP || slot == APP_GESTURE_SWIPE_DOWN) {
            const int fallback = reader_swipe_direction(ev->type,
                                                        app_settings_reader_vertical_turn());
            if (fallback) {
                ctx->user_activity = true;
                s_stats_activity_ms = ctx->now_ms;
                return turn_page(ctx, fallback);
            }
        }
        return APP_REDRAW_NONE;
    }
    if (action == APP_GESTURE_ACTION_PREV || action == APP_GESTURE_ACTION_NEXT) {
        int direction = action == APP_GESTURE_ACTION_NEXT ? 1 : -1;
        // 竖排正文的左右滑动方向与视觉相反；旧 reader_swipe_direction 只在左右翻页模式下反向，
        // 上下翻页模式本来就按上下滑动翻页，横向不再叠加反向，这里保持同一条件。
        // Vertical body text mirrors visual left/right; the legacy helper negated only in the
        // horizontal-turn mode (vertical-turn mode already pages by up/down), so match that.
        if ((slot == APP_GESTURE_SWIPE_LEFT || slot == APP_GESTURE_SWIPE_RIGHT) &&
            !app_settings_reader_vertical_turn() && app_settings_book_vertical())
            direction = -direction;
        ctx->user_activity = true;
        s_stats_activity_ms = ctx->now_ms;
        return turn_page(ctx, direction);
    }
    ctx->user_activity = true;
    return reader_gesture_action(ctx, action);
}
// 双指轻点：ui_gesture 对多点直接取消，因此这里读原始触摸快照自行识别。
// 两指同时按下、600 ms 内两指都抬起、位移小于 24 px 才触发一次；任何一条不满足就丢弃。
// Two-finger tap: ui_gesture cancels on multitouch, so the raw snapshot is read here. It fires
// once when both fingers are down together, both lift within 600 ms and neither moves 24 px.
static app_redraw_t reader_two_finger_tap_tick(app_ctx_t *ctx) {
    // 双指触摸在可缩放现场归缩放（app_loop 交给 on_pinch），不再识别成"双指轻点"，
    // 否则同一物理手势会被缩放和手势动作各消费一次。
    // Wherever a zoom surface exists, multi-touch belongs to pinch (app_loop hands it to
    // on_pinch) and is not recognised as a two-finger tap, so one physical gesture cannot be
    // consumed twice.
    const bool active = s_view == READING && s_text && s_reader_panel == READER_PANEL_NONE &&
                        !s_clear_confirm && !s_scan_pending && !s_hl_drag_active &&
                        !reader_zoom_mode();
    const cst836u_touch_t *touch = ctx->touch;
    // 离开正文或面板打开时立即丢弃半程识别，避免旧的两指样本在别的页面触发动作。
    // Leaving the bare body or opening a panel drops a half-recognised tap so stale samples can
    // never fire an action on another screen.
    if (!active || !touch) { s_two_finger_tap.armed = false; return APP_REDRAW_NONE; }
    const bool two = touch->touched && touch->count >= 2 &&
                     touch->points[0].active && touch->points[1].active;
    if (!two) {
        if (!s_two_finger_tap.armed) return APP_REDRAW_NONE;
        // 结束判定：只有"两指都抬起"且没超时、没越过容差才算一次轻点。
        // Finish only when both fingers are up, inside the deadline and without movement.
        const bool fired = !s_two_finger_tap.moved && !touch->touched &&
                           ctx->now_ms - s_two_finger_tap.down_ms <= READER_TWO_FINGER_MS;
        s_two_finger_tap.armed = false;
        if (!fired) return APP_REDRAW_NONE;
        return reader_gesture_action(ctx,
                                     app_settings_gesture_action(APP_GESTURE_TWO_FINGER_TAP));
    }
    int points[2][2] = {
        {touch->points[0].x, touch->points[0].y},
        {touch->points[1].x, touch->points[1].y},
    };
    for (int i = 0; i < 2; ++i)
        if (reader_touch_needs_map()) reader_touch_map(&points[i][0], &points[i][1]);
    if (!s_two_finger_tap.armed) {
        s_two_finger_tap.armed = true;
        s_two_finger_tap.moved = false;
        s_two_finger_tap.down_ms = ctx->now_ms;
        for (int i = 0; i < 2; ++i) {
            s_two_finger_tap.x0[i] = points[i][0];
            s_two_finger_tap.y0[i] = points[i][1];
        }
        // 双指落下时丢弃待触发的单击翻页与待开始的划线长按，避免同一个手势被消费两次。
        // Drop a pending single-tap turn and a pending highlight hold when the two fingers land,
        // so one physical gesture can never be consumed twice.
        s_reader_tap.pending = false;
        s_hl_hold_pending = false;
        return APP_REDRAW_NONE;
    }
    for (int i = 0; i < 2; ++i) {
        const int dx = points[i][0] - s_two_finger_tap.x0[i];
        const int dy = points[i][1] - s_two_finger_tap.y0[i];
        if (dx > READER_TWO_FINGER_SLOP || dx < -READER_TWO_FINGER_SLOP ||
            dy > READER_TWO_FINGER_SLOP || dy < -READER_TWO_FINGER_SLOP) {
            s_two_finger_tap.moved = true;
            break;
        }
    }
    // 超时后重新计时：双指按住不放不是轻点，抬起时不能误触发。
    // Re-arm on timeout: a held two-finger press is not a tap and must not fire on release.
    if (ctx->now_ms - s_two_finger_tap.down_ms > READER_TWO_FINGER_MS)
        s_two_finger_tap.armed = false;
    return APP_REDRAW_NONE;
}
static app_redraw_t on_key(app_ctx_t* ctx, int key) {
    // 字体异常提示下任意键回到字体选择页（不重启）；与 rc100 的按键行为一致。
    // Any key returns from the font-recovery dialog to the font picker instead of restarting.
    if (s_reader_panel == READER_PANEL_FONT_RECOVERY) {
        reader_font_recovery_reset();
        s_reader_panel = READER_PANEL_FONT_PICKER;
        return APP_REDRAW_PAGE;
    }
    reader_indent_hold_cancel();
    s_reader_tap.pending = false;
    s_pressed_control = -1;
    if (s_view == TOC && s_toc_jump_open) {
        if (key == UI_KEY_2) s_toc_jump_open = s_toc_jump_drag = false;
        else if (key == UI_KEY_1 || key == UI_KEY_3) {
            s_toc_jump_percent += key == UI_KEY_1 ? -5 : 5;
            if (s_toc_jump_percent < 0) s_toc_jump_percent = 0;
            if (s_toc_jump_percent > 100) s_toc_jump_percent = 100;
        }
        return APP_REDRAW_PAGE;
    }
    if (s_view != READING && s_view != TOC) {
        if (key == UI_KEY_2) { ui_nav_request(ctx, 0); return APP_REDRAW_NONE; }
        if (s_view == EDIT) { ui_keyboard_end(); free(s_editor_cover); s_editor_cover = NULL; s_view = MANAGE; return APP_REDRAW_PAGE; }
        if (s_view == SEARCH) { search_finish(ctx, false); return APP_REDRAW_PAGE; }
        if (s_batch_confirm) { s_batch_confirm = false; return APP_REDRAW_PAGE; }
        if (s_view == MANAGE || s_view == BULK || s_view == IMPORT) {
            if (s_view == BULK) return bulk_finish(ctx);
            s_view = SHELF; return APP_REDRAW_PAGE;
        }
        if (s_view == SHELF) { ui_nav_request(ctx, 0); return APP_REDRAW_NONE; }
    }
    if (s_scan_pending || s_clear_confirm) return APP_REDRAW_NONE;
    if (s_view == READING && (key == UI_KEY_1 || key == UI_KEY_2 || key == UI_KEY_3))
        return reader_key_action(ctx, app_settings_reader_key_action(key == UI_KEY_1 ? 0 : key == UI_KEY_2 ? 1 : 2));
    if (key == UI_KEY_2) {
        if (s_view == BULK) s_view = SHELF;
        else if (s_view == SHELF) { ui_nav_request(ctx, 3); return APP_REDRAW_NONE; }
        else if (s_view == READING) {
            s_reader_slider = -1;
            s_reader_panel = s_reader_panel == READER_PANEL_TOOLS ? READER_PANEL_NONE : READER_PANEL_TOOLS;
            invalidate_prep();
        } else if (s_view == TOC) {
            set_reader_view(s_text ? READING : SHELF);
            s_reader_panel = READER_PANEL_NONE;
        } else {
            ui_nav_request(ctx, 0);
            return APP_REDRAW_NONE;
        }
        return APP_REDRAW_PAGE;
    }
    if (key != UI_KEY_1 && key != UI_KEY_3) return APP_REDRAW_NONE;
    int dir = key == UI_KEY_1 ? -1 : 1;
    if (s_view == READING) { s_stats_activity_ms = ctx->now_ms; return turn_page(ctx, dir); }
    int next = ctx->leaf + dir;
    if (next < 0 || next >= leaves()) return APP_REDRAW_NONE;
    ctx->leaf = next;
    return APP_REDRAW_PAGE;
}
static app_redraw_t on_power_short(app_ctx_t* ctx) {
    s_reader_tap.pending = false;
    if (s_view != READING || !s_text || s_clear_confirm ||
        !app_settings_reader_power_turn()) return APP_REDRAW_NONE;
    s_stats_activity_ms = ctx->now_ms;
    app_redraw_t result = turn_page(ctx, 1);
    return result == APP_REDRAW_NONE ? APP_REDRAW_DONE : result;
}
static app_redraw_t on_key_long(app_ctx_t* ctx, int key) {
    s_hl_hold_pending = false;
    reader_indent_hold_cancel();
    s_reader_tap.pending = false;
    if (key != UI_KEY_2) return APP_REDRAW_NONE;
    if (s_view == TOC && s_toc_jump_open) {
        s_toc_jump_open = s_toc_jump_drag = false;
        return APP_REDRAW_PAGE;
    }
    if (s_view != READING && s_view != TOC) { ui_nav_request(ctx, 0); return APP_REDRAW_NONE; }
    if (s_view == READING) {
        return reader_key_action(ctx, app_settings_reader_hold_action());
    }
    s_message[0] = 0;
    set_reader_view(s_text ? READING : SHELF);
    s_reader_panel = READER_PANEL_NONE;
    return APP_REDRAW_PAGE;
}
static bool menu_handle_enabled(app_ctx_t* ctx) {
    (void)ctx;
    // 图书所有视图只使用产品导航，旧菜单不能抢占右侧分页按钮。
    // All book views use product navigation; the legacy menu must never steal the right pager.
    return false;
}
static app_redraw_t shelf_turn_page(app_ctx_t *ctx, int direction) {
    int next = ctx->leaf + direction;
    if (s_view != SHELF || s_scan_pending || s_clear_confirm || next == ctx->leaf || next < 0 || next >= leaves())
        return APP_REDRAW_NONE;
    ctx->leaf = next;
    shelf_category_remember(ctx);
    s_category_menu=false;
    s_shelf_page_pending = true;
    s_pressed_control = -1;
    prepare_covers(ctx);
    render(ctx, ctx->fb);
    s_area = (EpdRect){0, 176, UI_LOCK_WIDTH, 912};
    s_mode = MODE_GL16;
    return APP_REDRAW_AREA;
}

static app_redraw_t shelf_key_tick(app_ctx_t *ctx) {
    if(s_view!=SHELF || ctx->request_app){
        s_shelf_key_mode=s_shelf_key_paint_pending=false;s_shelf_key_delta=s_shelf_key_pressed=0;
        return APP_REDRAW_NONE;
    }
    if(!s_shelf_key_mode || !s_shelf_key_pressed || ctx->now_ms<s_shelf_key_until || ctx->consumed)
        return APP_REDRAW_NONE;
    int dir=(s_shelf_key_delta>0)-(s_shelf_key_delta<0);
    if(dir)s_shelf_key_delta-=dir;
    s_shelf_key_pressed=0;
    app_redraw_t redraw=dir?shelf_turn_page(ctx,dir):APP_REDRAW_NONE;
    if(s_shelf_key_delta){s_shelf_key_pressed=s_shelf_key_delta<0?-1:1;s_shelf_key_until=ctx->now_ms+35;}
    return redraw==APP_REDRAW_NONE?shelf_key_paint(ctx):redraw;
}

// 键事件与原始边沿可能属于同一份报告，每轮最多执行一次；其他子页只清理旧输入。
// Keys and raw edges may come from the same report: apply one turn per tick, discard on other subpages.
static int book_remote_direction(void) {
    int direction = 0;
    ble_pt_event_t event;
    while (ble_pt_pop_key(&event)) {
        ble_pt_action_t action = ble_pt_action_for_usage(event.usage, event.mods);
        if (action == BLE_PT_ACTION_PREV) direction = -1;
        else if (action == BLE_PT_ACTION_NEXT) direction = 1;
    }
    ble_pt_raw_t raw;
    while (ble_pt_pop_raw(&raw)) {
        if (!raw.pressed) continue;
        ble_pt_action_t action = ble_pt_action_for_frame(&raw.frame);
        if (action == BLE_PT_ACTION_PREV) direction = -1;
        else if (action == BLE_PT_ACTION_NEXT) direction = 1;
    }
    return direction;
}
// 整行划线的取行/提交：长按开始、拖动整行扩展、松手落盘；与预渲染共用布局状态，
// 所以长按先 join 预渲染任务，拖动期间 on_tick 只做布局查询和一次区域刷新。
// Whole-line highlight drag: start on long press, extend line by line, commit on release. The
// prefetcher shares layout state, so a long press joins it first and on_tick only queries lines.
static void highlight_make_excerpt(uint32_t start, uint32_t end, char *out, size_t cap) {
    if (!out || !cap) return;
    out[0] = 0;
    if (!s_text || start >= s_text_len) return;
    size_t write = 0, i = start;
    while (i < s_text_len && write + 1 < cap) {
        if (end > start && i >= end) break;
        const unsigned char c = (unsigned char)s_text[i];
        const size_t n = c < 0x80 ? 1 : (c & 0xE0) == 0xC0 ? 2 : (c & 0xF0) == 0xE0 ? 3 :
                         (c & 0xF8) == 0xF0 ? 4 : 1;
        if (i + n > s_text_len) break;
        if (n == 1 && (s_text[i] == '\n' || s_text[i] == '\r')) {
            out[write++] = ' ';
            ++i;
            continue;
        }
        if (write + n >= cap) break;
        memcpy(out + write, s_text + i, n);
        write += n;
        i += n;
    }
    out[write] = 0;
    while (write && out[write - 1] == ' ') out[--write] = 0;
}
static void reader_highlight_drag_cancel(void) {
    s_hl_drag_active = false;
    book_layout_set_highlight_preview((uint16_t)s_chapter, false, 0, 0);
}
// 段落间距/页边距里取不到字时，向上下最近的行走一圈，避免手指经过空档时色带停住。
// In paragraph gaps or margins, scan toward the nearest line so the band never stalls mid-drag.
static bool highlight_char_at_point(int x, int y, uint32_t *start, uint32_t *len) {
    EpdRect body = body_rect();
    if (y < body.y) y = body.y;
    if (y >= body.y + body.height) y = body.y + body.height - 1;
    if (book_layout_char_at(s_page, body, s_px, x, y, start, len)) return true;
    for (int d = 2; d <= 64; d += 2) {
        int ty = y + d;
        if (ty < body.y + body.height &&
            book_layout_char_at(s_page, body, s_px, x, ty, start, len)) return true;
        ty = y - d;
        if (ty >= body.y &&
            book_layout_char_at(s_page, body, s_px, x, ty, start, len)) return true;
    }
    return false;
}
static app_redraw_t reader_highlight_drag_tick(app_ctx_t* ctx) {
    if (!s_hl_drag_active) return APP_REDRAW_NONE;
    if (s_view != READING || !s_text) {
        reader_highlight_drag_cancel();
        return APP_REDRAW_PAGE;
    }
    // 注意：不能用 ctx->consumed 取消拖动。长按本身返回 AREA，主循环会给这一轮置
    // consumed=true；若据此取消，拖动会在第一帧就结束（正是“只能画一个字”的原因）。
    // Never cancel on ctx->consumed here: the long press itself returns AREA this turn and the
    // main loop marks that turn consumed; cancelling on it ends the drag after exactly one glyph.
    if (ctx->touch && ctx->touch->touched) {
        if (ctx->now_ms < s_hl_drag_next_ms) return APP_REDRAW_NONE;
        int tx = ctx->touch->x, ty = ctx->touch->y;
        if (reader_touch_needs_map()) reader_touch_map(&tx, &ty);
        uint32_t char_start, char_len;
        if (!highlight_char_at_point(tx, ty, &char_start, &char_len)) return APP_REDRAW_NONE;
        // 从锚点字到手指字的有序范围：往前滑逐字增长，往回滑逐字收回。
        // Ordered range from the anchor glyph to the finger glyph: sliding forward grows glyph by
        // glyph, sliding back shrinks it the same way.
        uint32_t start, end;
        if (char_start < s_hl_drag_anchor_start) {
            start = char_start;
            end = s_hl_drag_anchor_start + s_hl_drag_anchor_len;
        } else {
            start = s_hl_drag_anchor_start;
            end = char_start + char_len;
        }
        if (start == s_hl_drag_start && end == s_hl_drag_end) return APP_REDRAW_NONE;
        s_hl_drag_start = start;
        s_hl_drag_end = end;
        book_layout_set_highlight_preview((uint16_t)s_chapter, true, start, end);
        render(ctx, ctx->fb);
        s_area = body_rect();
        s_mode = MODE_GL16;
        s_hl_drag_next_ms = ctx->now_ms + 120;
        return APP_REDRAW_AREA;
    }
    // 抬手：把临时选段转成正式划线并重绘最终画面。
    // Release: commit the temporary range as a real highlight and repaint the final frame.
    const uint32_t start = s_hl_drag_start, end = s_hl_drag_end;
    reader_highlight_drag_cancel();
    if (end > start) {
        char excerpt[BOOK_HIGHLIGHT_EXCERPT];
        highlight_make_excerpt(start, end, excerpt, sizeof(excerpt));
        const bool added = book_highlight_add((uint16_t)s_chapter, start, end, excerpt);
        copy_text(s_reader_notice, sizeof(s_reader_notice), added ? "已划线" : "划线保存失败");
        s_reader_notice_until = esp_timer_get_time() / 1000 + 1400;
    }
    invalidate_prep();
    render(ctx, ctx->fb);
    s_area = body_rect();
    s_mode = MODE_GL16;
    return APP_REDRAW_AREA;
}

/* ---- 阅读字体加载异常提示 / Reader font load recovery ---- */

static EpdRect reader_font_recovery_button(int index) {
    return (EpdRect){66 + index * 286, 764, 266, 82};
}
static void draw_font_recovery(uint8_t *fb) {
    ui_text_set_system_scale(true);
    EpdRect card = {42, 410, 600, 464};
    ui_fill_round_rect(fb, card, 26, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, card, 26, UI_GRAY_BLACK);
    ui_text_box(fb, (EpdRect){66,438,552,80}, 30, "阅读字体加载异常", EPD_DRAW_ALIGN_CENTER, false);
    ui_text_box(fb, (EpdRect){66,538,552,66}, 24, "已多次回退到内建字体", EPD_DRAW_ALIGN_CENTER, false);
    ui_text_box(fb, (EpdRect){66,610,552,66}, 24, "可尝试重启后重新选择", EPD_DRAW_ALIGN_CENTER, false);
    ui_text_box(fb, (EpdRect){66,688,552,58}, 21,
        s_font_recovery_save_failed ? "进度保存失败，请重试" : "重启前将保存阅读进度", EPD_DRAW_ALIGN_CENTER, false);
    for (int i = 0; i < 2; ++i) {
        EpdRect button = reader_font_recovery_button(i);
        ui_fill_round_rect(fb, button, 22, i ? UI_GRAY_BLACK : UI_GRAY_WHITE);
        ui_draw_control_frame(fb, button, 22, UI_GRAY_BLACK);
        ui_text_box(fb, ui_inset_rect(button, 12), 25,
            i ? "立即重启" : "暂不重启", EPD_DRAW_ALIGN_CENTER, i != 0);
    }
    ui_text_set_system_scale(false);
}
static app_redraw_t reader_font_recovery_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    (void)ctx;
    if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
    for (int i = 0; i < 2; ++i) {
        EpdRect button = reader_font_recovery_button(i);
        if (!ui_rect_hit(button, ev->x0, ev->y0) || !ui_rect_hit(button, ev->x, ev->y)) continue;
        if (i) s_font_restart_pending = true;
        else {
            reader_font_recovery_reset();
            s_reader_panel = READER_PANEL_FONT_PICKER;
        }
        return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}
static app_redraw_t reader_font_recovery_tick(app_ctx_t *ctx) {
    if (s_view != READING || !s_text) return APP_REDRAW_NONE;
    if (s_font_recovery_pending) {
        s_font_recovery_pending = false;
        s_font_recovery_save_failed = false;
        s_reader_panel = READER_PANEL_FONT_RECOVERY;
        s_reader_tap.pending = false;
        s_reader_slider = s_pressed_control = -1;
        invalidate_prep();
        return APP_REDRAW_PAGE;
    }
    if (s_reader_panel != READER_PANEL_FONT_RECOVERY || !s_font_restart_pending || ctx->consumed)
        return APP_REDRAW_NONE;
    s_font_restart_pending = false;
    // 使用已有保存/预绘制退出入口；存储失败时留在提示框，不能静默丢失进度。
    // Reuse the checkpoint/prefetch teardown; keep the dialog on storage failure rather than lose
    // progress silently.
    before_lock(ctx);
    retry_progress();
    if (s_save_failed) {
        s_font_recovery_save_failed = true;
        return APP_REDRAW_PAGE;
    }
    app_restart_host();
    return APP_REDRAW_DONE;
}

static app_redraw_t on_tick(app_ctx_t* ctx) {
    app_redraw_t recovery = reader_font_recovery_tick(ctx);
    if (recovery != APP_REDRAW_NONE) return recovery;
    if (s_reader_panel == READER_PANEL_FONT_RECOVERY) return APP_REDRAW_NONE;
    // 跳转撤销浮标只有 7 秒：到点自动清掉并重画正文，把按钮抹掉。
    // The jump-undo badge lives seven seconds: expire it and repaint the page once to erase it.
    if (s_chapter_jump_undo.valid && s_view == READING && s_reader_panel == READER_PANEL_NONE &&
        ctx->now_ms >= s_chapter_jump_undo.until_ms) {
        s_chapter_jump_undo.valid = false;
        return APP_REDRAW_PAGE;
    }
    if (s_async_turn) {
        const int dir = s_async_turn;
        s_async_turn = 0;
        return turn_page(ctx, dir);
    }
    if (s_open_pending) {
        // 书架点书的延后打开：反馈已由触摸回调单独推过，这里只做重活。
        // Deferred shelf open: the touch callback already pushed its feedback, so only heavy work runs here.
        char path[BOOK_STORE_PATH_MAX];
        copy_text(path, sizeof(path), s_open_pending_path);
        s_open_pending_path[0] = 0;
        s_open_pending = false;
        (void)open_book(ctx, path);
        return APP_REDRAW_PAGE;
    }
    // Markdown 重排后的重解析：触摸回调只登记重排前的页首偏移，这里用主循环的浅栈执行一次
    // 并统一推屏，避免在触摸回调里排整章撑爆主任务栈。
    // Markdown re-parse after a re-layout: the touch callback only recorded the pre-layout page
    // offset; run it here on the main loop's shallow stack and present once.
    if (s_md_reload_pending) {
        s_md_reload_pending = false;
        const size_t reload_off = s_md_reload_offset;
        const size_t reload_chapter = s_md_reload_chapter;
        s_md_reload_offset = s_md_reload_chapter = SIZE_MAX;
        if (s_view == READING && s_text && book_kind() == BOOK_KIND_MARKDOWN &&
            reload_chapter == s_chapter) {
            (void)reader_md_reload_at(ctx, reload_off);
            save_progress();
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_hl_hold_pending) {
        const bool held = ctx->touch && ctx->touch->touched;
        if (!held) {
            s_hl_hold_pending = false;
        } else if (ctx->now_ms >= s_hl_hold_due_ms) {
            s_hl_hold_pending = false;
            if (s_view == READING && !s_toolbar && !s_clear_confirm &&
                ui_rect_hit(body_rect(), s_hl_hold_x, s_hl_hold_y)) {
                app_redraw_t begun = reader_highlight_begin(ctx, s_hl_hold_x, s_hl_hold_y);
                if (begun != APP_REDRAW_NONE) return begun;
            }
        }
    }
    // 双指轻点只用原始触摸快照识别，命中一次就把映射动作交给同一个派发器。
    // The two-finger tap reads the raw touch snapshot and hands a fired tap to the same dispatcher.
    app_redraw_t two_finger = reader_two_finger_tap_tick(ctx);
    if (two_finger != APP_REDRAW_NONE) return two_finger;
    app_redraw_t highlight = reader_highlight_drag_tick(ctx);
    if (highlight != APP_REDRAW_NONE) return highlight;
    // Preload the next page's illustrations while idle; the turn then shows them at once.
    if (!s_hl_drag_active && s_view == READING && s_reader_panel == READER_PANEL_NONE &&
        !s_toolbar && !s_clear_confirm && !(ctx->touch && ctx->touch->touched) &&
        ctx->now_ms >= s_prefetch_next_ms)
        prefetch_inline_images_tick();
    // 书架空闲时预取相邻页封面，翻到下一页时直接命中缓存。
    // Preload the neighbouring shelf page's covers while idle so the next page hits the cache.
    if (s_view == SHELF) shelf_cover_prefetch_tick(ctx);
    app_redraw_t indent=reader_indent_hold_tick(ctx);
    if(indent!=APP_REDRAW_NONE)return indent;
    app_redraw_t keys=shelf_key_tick(ctx);
    if(keys!=APP_REDRAW_NONE || ctx->request_app)return keys;
    app_redraw_t orient = reader_orient_tick(ctx);
    if (orient != APP_REDRAW_NONE) return orient;
    // 字体开关留下的重排在这里做：触摸回调的栈太深，一章排下来会把主任务栈顶穿（实测溢出过）。
    // The font switch's re-typeset happens here: the touch callback runs too deep, and laying out a
    // chapter from there overran the main task stack (measured).
    if (s_fonts_reload_pending) {
        s_fonts_reload_pending = false;
        if (s_text && book_kind() == BOOK_KIND_EPUB)
            (void)load_chapter(ctx, s_chapter, book_layout_page_start_offset(s_page), false);
        return APP_REDRAW_PAGE;
    }
    // 字体选择页/字体设置页的空闲预载：每轮最多装载一个候选字库，补好一张卡再局部刷新；
    // 打开列表后名字会一张张换成各自的字体，而不再是一次十次字体装载的等待。
    // Idle font-preview preload: at most one candidate face per turn, then one local card refresh;
    // names fill in one by one instead of one blocking pass of ten face loads.
    app_redraw_t font_preview = font_preview_tick(ctx);
    if (font_preview != APP_REDRAW_NONE) return font_preview;
    if (s_view != READING || (s_toolbar && s_reader_panel != READER_PANEL_TOOLS) || s_clear_confirm || ctx->consumed) s_reader_tap.pending = false;
    else {
        int tap = book_reader_tap_tick(&s_reader_tap, ctx->now_ms, ctx->touch && ctx->touch->touched);
        if (tap) return turn_page(ctx, tap);
    }
    track_ticket_stats(ctx);
    book_highlight_tick(ctx->now_ms);
    if (s_view == SEARCH || s_view == EDIT) {
        if (ctx->consumed) return APP_REDRAW_NONE;
        bool held = !ctx->released && ctx->touch && ctx->touch->touched && ctx->touch->count == 1;
        if (ui_keyboard_hold_tick(held, ctx->touch ? ctx->touch->x : 0,
            ctx->touch ? ctx->touch->y : 0, ctx->now_ms) == UI_KEYBOARD_CHANGED) return editor_paint(ctx, false);
        return ui_keyboard_idle_tick(ctx->touch && ctx->touch->touched, ctx->now_ms) == UI_KEYBOARD_CHANGED
            ? editor_paint(ctx, false) : APP_REDRAW_NONE;
    }
    if (ctx->consumed) return APP_REDRAW_NONE;
    // 蓝牙翻页键沿用同一套方向语义：PREV 往回翻、NEXT 往前翻；书架复用滑动式的局部刷新，
    // 不闪动题头和底栏。
    // The BLE keys keep the same direction semantics: PREV turns back, NEXT turns forward; the
    // shelf reuses the swipe-style partial refresh without flashing chrome.
    if (app_settings_ble_turner()) {
        int ble_dir = book_remote_direction();
        if (ble_dir && s_view == SHELF) {
            app_redraw_t redraw = shelf_turn_page(ctx, ble_dir);
            if (redraw != APP_REDRAW_NONE) return redraw;
        } else if (ble_dir && s_view == READING) {
            s_stats_activity_ms = ctx->now_ms;
            return turn_page(ctx, ble_dir);
        }
    }
    if (s_reader_notice[0] && ctx->now_ms >= s_reader_notice_until) {
        s_reader_notice[0] = 0;
        if (s_view == READING && !s_reader_landscape) {
            // 区域刷新不会自动重绘帧缓冲；先移除提示，再只更新提示所在区域。
            // Area refreshes do not rerender the framebuffer; erase the toast before updating its region.
            render(ctx, ctx->fb);
            s_area = (EpdRect){208, 150, 268, 68};
            s_mode = MODE_GL16;
            return APP_REDRAW_AREA;
        }
    }
    if (s_save_failed && ctx->now_ms - s_save_retry_ms >= 15000) {
        s_save_retry_ms = ctx->now_ms;
        bool failed = s_save_failed;
        retry_progress();
        if (failed != s_save_failed) { invalidate_prep(); return APP_REDRAW_PAGE; }
    }
    app_redraw_t background = reader_background_tick();
    if (background != APP_REDRAW_NONE) return background;
    if (s_scan_pending && ctx->now_ms - s_poll_ms >= 500) {
        s_poll_ms = ctx->now_ms;
        read_pico_sd_info_t info = {0};
        if (read_pico_sd_get_info(&info) == ESP_ERR_NOT_FINISHED) return APP_REDRAW_NONE;
        s_scan_pending = false;
        scan_shelf(ctx);
        if (ctx->request_app) return APP_REDRAW_NONE;
        (void)open_requested_book(ctx);
        return APP_REDRAW_PAGE;
    }
    if ((s_view == SHELF || s_view == MANAGE) && !(ctx->touch && ctx->touch->touched)) {
        (void)prepare_cover_batch(ctx, false);
        // 已解码的行逐行补推；占位页或失败输出不能消费已加载封面的待刷标记。
        // Push decoded rows one by one; placeholders and failed output cannot consume pending artwork.
        unsigned changed=shelf_cover_reveal_mask();
        if (ctx->request_app) return APP_REDRAW_NONE;
        EpdRect area = {0};
        for (int row = 0; row < shelf_rows(); ++row) {
            if (!(changed & (1u << row))) continue;
            EpdRect r = row_rect(row);
            if (!area.width) area = r;
            else {
                int right = area.x+area.width > r.x+r.width ? area.x+area.width : r.x+r.width;
                int bottom = area.y+area.height > r.y+r.height ? area.y+area.height : r.y+r.height;
                if (r.x < area.x) area.x = r.x;
                if (r.y < area.y) area.y = r.y;
                area.width = right-area.x; area.height = bottom-area.y;
            }
        }
        if (area.width) {
            render(ctx, ctx->fb);
            s_area = area;
            s_mode = s_view == SHELF && app_settings_main_fast_refresh() ? MODE_DU : MODE_GL16;
            s_shelf_feedback_pending = s_view == SHELF;
            s_cover_batch_present_pending = true;
            s_cover_present_mask=changed;
            return APP_REDRAW_AREA;
        }
    }
    warm_shelf_lock_cover(ctx);
    if (ctx->request_app) return APP_REDRAW_NONE;
    // 目录暂借系统字体，不应把正文按系统字体重新分页。/ The directory borrows the system face without repaginating the reader.
    if (s_view == READING && s_text && strcmp(s_font_path, ttf_font_path())) {
        size_t off = book_layout_page_start_offset(s_page);
        save_progress();
        lock_draw();
        invalidate_prep();
        reader_anchor_invalidate();
        bool ok = book_layout_build_blocks(s_text, s_text_len, s_blocks, s_block_count, body_rect(), s_px);
        if (ok) s_page = book_layout_page_for_offset(off);
        copy_text(s_font_path, sizeof(s_font_path), ttf_font_path());
        unlock_draw();
        if (!ok) { free_book(); s_view = SHELF; copy_text(s_message, sizeof(s_message), "字体重排失败，请重新打开图书"); }
        // 系统字体换了，表格里的空格宽度也要按新字面重新测量：Markdown 重载本章，TXT/EPUB 不动。
        // 重解析后输出文本偏移可能微移，进度按重载后的页重新保存。
        // The system face changed, so table space advances must be measured with the new face:
        // reload Markdown only. The re-parse can shift output offsets, so save progress anew.
        if (ok && book_kind() == BOOK_KIND_MARKDOWN && reader_md_reload_at(ctx, off))
            save_progress();
        return APP_REDRAW_PAGE;
    }
    app_redraw_t clock=reader_clock_tick(ctx);
    if(clock==APP_REDRAW_NONE)reader_prefetch_idle(ctx);
    return clock;
}
static void before_lock(app_ctx_t* ctx) {
    // 进锁屏前收起缩放现场，锁屏画面不继承放大视图和黑白残影。
    // Settle the zoom context before locking; the lock face must not inherit a zoom view or
    // black/white residue.
    reader_zoom_reset();
    s_hl_hold_pending = false;
    reader_indent_hold_cancel();
    s_shelf_key_mode=s_shelf_key_paint_pending=false;s_shelf_key_delta=s_shelf_key_pressed=0;
    shelf_category_remember(ctx);
    s_category_menu=false;
    s_reader_tap.pending = false;
    track_ticket_stats(ctx);
    save_progress();
    // 锁屏前丢弃分行预绘，后续只按当前字体重建。/ Discard idle prefetch before lock; rebuild only with the current face.
    lock_draw();
    invalidate_prep();
    unlock_draw();
    // 锁屏票根始终以当前正在阅读的书为准；不要依赖书架最近项是否已经同步。
    if (s_text && s_path[0]) book_progress_set_last_path(s_path);
    flush_ticket_stats();
    s_stats_last_ms = 0;
}
static EpdRect area_hint(app_ctx_t* ctx) { (void)ctx; return s_area; }
static bool main_page_visible(app_ctx_t* ctx) {
    (void)ctx;
    return s_view == SHELF && !s_clear_confirm && !s_batch_confirm;
}

const app_desc_t app_book = {
    .title = "图书 Books", .detail = "TF 卡 txt / epub / md 阅读", .enter_full = false, .owns_keys = true,
    .defer_middle_short = true,
    .menu_handle_enabled = menu_handle_enabled,
    .main_page_visible = main_page_visible,
    .render = render, .present = present, .on_enter = on_enter, .on_exit = book_on_exit,
    .on_media_lost = book_on_media_lost, .on_media_ready = book_on_media_ready,
    .on_before_lock = before_lock, .on_main_key = shelf_main_key,
    .on_gesture = gesture_event, .on_key = on_key, .on_key_long = on_key_long,
    // 插图缩放：本页要求原始双指时由主循环把双指交过来（竖屏整页/正文插图）。
    // Illustration zoom: the loop hands both contacts over while the page asks for raw pinch
    // input (portrait whole-page / inline illustrations).
    .wants_pinch = wants_pinch, .on_pinch = on_pinch,
    .on_power_short = on_power_short,
    .on_tick = on_tick, .area_hint = area_hint,
};