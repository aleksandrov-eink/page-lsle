/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 墨水屏刷新、HV 轨空闲超时、pclk 回退。
 *
 * EPD present, HV-rail idle timeout, and pclk fallback.
 */

#pragma once

#include <stdint.h>
#include <stdbool.h>

#include "epd_highlevel.h"
#include "epdiy.h"
#include "e0470_page_turn.h"
#include "read_pico_epd_timing.h"

#ifdef __cplusplus
extern "C" {
#endif

// LCD 像素时钟：只决定有效像素段占一行的多少，剩下的由行结束段补足——行周期被锁在
// 波形标定的帧周期上，所以调 pclk 不会让刷新变快，只影响 DMA 的供数余量。12MHz 是
// epdiy 的保守默认值，18MHz 实测稳定（前提是 PSRAM 跑在 120MHz，80MHz 下 16MHz
// 就喂不满 DMA），开机锁 18MHz 留足余量。
// LCD pixel clock: it only sets how much of the line the active pixels occupy;
// the line-end pad fills the rest. The line period is locked to the waveform
// frame time, so pclk does not make refresh faster — it only changes DMA slack.
// 12 MHz is epdiy's conservative default; 18 MHz is stable here when PSRAM runs
// at 120 MHz (at 80 MHz even 16 MHz starves DMA). Boot locks 18 MHz for margin.
#define DISPLAY_PCLK_DEFAULT_MHZ 18
// 出现供数不足（EPD_DRAW_EMPTY_LINE_QUEUE）时退回这个确定安全的频率。
// Fall back to this known-safe clock on underrun (EPD_DRAW_EMPTY_LINE_QUEUE).
#define DISPLAY_PCLK_SAFE_MHZ READ_PICO_EPD_PCLK_MIN_MHZ
// 工程页上还能继续往上试。行消隐与 CKV 宽度会跟着频率重解。
// The lab page can still step higher. Line blanking and CKV width re-solve with the clock.
#define DISPLAY_PCLK_MIN_MHZ READ_PICO_EPD_PCLK_MIN_MHZ
#define DISPLAY_PCLK_MAX_MHZ READ_PICO_EPD_PCLK_MAX_MHZ
#define DISPLAY_PCLK_STEP_MHZ 1

/// 保留高压轨并释放像素驱动，包括无变化刷新；不增加扫描。/ Retain HV rails and release pixel drive, including no-change updates, without another scan.
void rails_keepalive(void);
void rails_idle_check(int64_t now_ms, bool input_idle);
/// 睡眠/关机前等低优先级断电任务收尾，避免两路同时写 SY7636A。
/// Wait for the low-priority power-off task before sleep/shutdown so no two paths touch SY7636A.
void display_quiet_rails_off(void);

/// 大量文件I/O期间增加扫描预填，调用方离开时恢复。/ Increase scan prefill during bulk file I/O; caller restores on exit.
void display_set_bulk_io(bool active);

/// 请求下一张完成绘制的画面整屏清理一次，用于解锁。/ Clean the next completed frame once after unlock.
void display_request_full_refresh(void);
enum EpdDrawError update_display_mode(EpdiyHighlevelState* hl, enum EpdDrawMode mode);
/// 普通页面切换使用真实差分 GL16；未变化像素不进入 dirty map。
/// True differential GL16 for ordinary page transitions; unchanged pixels stay clean.
enum EpdDrawError update_display_mode_diff(EpdiyHighlevelState* hl, enum EpdDrawMode mode);
/// 系统子页只推最终差分，不因操作计数全刷；显式全刷和故障恢复独立。
/// System children present final differences without count-triggered full output; explicit full and fault recovery are independent.
/// 四主页面固定底栏，仅横条局部更新；普通保留灰阶与内容区整理，快刷用完整黑白表及棋盘格亚克力。
/// All main screens retain navigation with local markers; ordinary uses soft gray differences and periodic body cleanup, fast uses monochrome/checkerboard acrylic.
enum EpdDrawError update_display_fast_page(EpdiyHighlevelState* hl);
/// 为下一次主页面输出启用固定底栏；标记书架切出与真正切页，避免同页重绘播放动画。
/// Arm fixed navigation for the next main-screen output; tag shelf exit and actual navigation so same-page repaints do not animate.
void display_main_transition_arm(const void* owner, bool leaving_shelf, bool changing_page);
/// 系统侧滑用主页灰阶水波纹，独立于阅读文字序列；区域必须是逻辑坐标。
/// System edge returns use main-gray ripple independently of reader text; the area uses logical coordinates.
enum EpdDrawError update_display_main_turn(EpdiyHighlevelState* hl, EpdRect area, e0470_turn_dir_t dir);
/// 当前主页面最多三个横向灰阶条带，其余内容按黑白驱动；无入口许可时忽略。
/// Register at most three horizontal gray bands on the armed main page; other content uses black/white. Ignore without permission.
void display_main_transition_gray_bands(const EpdRect* bands, unsigned count);
/// 书架分页加强白色擦除，保持底栏边界。/ Strengthen shelf-page whitening within the fixed navigation boundary.
void display_main_transition_shelf_page(void);
/// 解除尚未使用的入口许可。/ Disarm unused entry permission.
void display_main_transition_disarm(void);
/// 取消尚未使用的入口；不打断物理波形，无延迟补刷任务。
/// Cancel unused permission without interrupting a physical waveform; no deferred completion exists.
void display_main_transition_cancel(void);
enum EpdDrawError update_display_from_white(EpdiyHighlevelState* hl);
enum EpdDrawError update_display_from_white_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
);
/// 把前缓冲铺白再 GC16 全刷，物理屏回到白底。
/// Paint the front buffer white and GC16 the panel back to white.
enum EpdDrawError update_display_white(EpdiyHighlevelState* hl);
enum EpdDrawError update_display_full(EpdiyHighlevelState* hl);

/// 面板修复：不看 framebuffer 的整屏盲刷，专治刷新中途断电留下的条纹。
/// Panel repair: a blind full-screen drive that ignores the framebuffer, for the stripes a power
/// cut in the middle of a refresh leaves behind.
/// 返回最终整屏输出结果；失败时调用方不能报告成功。/ Return the final full-frame result; callers must not report success on failure.
enum EpdDrawError display_panel_repair(EpdiyHighlevelState* hl);
/// 图片页清除旧光学状态，再驱动完整灰阶。/ Clear the prior optical state and drive the full gray ladder for images.
enum EpdDrawError update_display_image_gray(EpdiyHighlevelState* hl);
enum EpdDrawError update_display_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
);
/// 灰阶图还在屏上时置位：菜单盖上来或离页先刷白，避免从中间灰差分。
/// Set while a gray image is still on panel: wipe to white before the menu or leave so the next update is not a mid-gray differential.
void display_hold_white_exit(bool hold);
bool display_take_white_exit(void);
enum EpdDrawError update_display_area_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
);
/// 动画定稿只驱动真实差异，不强制把区域内所有 GL16 像素重刷。
/// Animation settle drives real differences only instead of forcing every GL16 pixel in the area.
/// 在指定区域驱动全部像素，用于局部定稿和清残影。/ Drive all pixels within an area for local settling and ghost cleanup.
/// 控件局部反馈暂存后续主页刷新入口，不提前消耗其裁剪、灰阶和底栏保护。/ Local control feedback preserves the pending main crop, gray policy and footer protection.
enum EpdDrawError update_display_click_feedback(EpdiyHighlevelState* hl,EpdRect area);
enum EpdDrawError update_display_area_full_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
);
/// 防泛白：全像素 GL16 重推当前帧，未变化白底吃 1 帧 15→15 白推，深色/中灰会短暂变浅
/// 后回原灰阶（约 0.27s），无整屏黑白全刷；抑制静态画面久置后白底发灰/字边发暗。
/// Anti-fade: re-drive the frame with full-pixel GL16; unchanged white gets one 15->15 white push,
/// dark/mid-gray briefly lightens then returns (~0.27 s) with no whole-screen black/white flash,
/// suppressing the slow gray/dark drift of a static page.
enum EpdDrawError update_display_anti_fade(EpdiyHighlevelState* hl);
enum EpdDrawError update_display_area_diff_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
);
/// area始终为旋转后逻辑坐标，勿传物理epd_full_screen。/ area always uses rotated logical coordinates, never physical epd_full_screen.
/// 阅读页可选的真实错相 GL16 翻页；缺相位时回退现有 GL16，失败时恢复基准帧。
/// 纯文字水波纹复用柔和文字灰边，8带节拍不变；缺相回退GL16，扫描失败重建真实基准。
/// Staggered text phases retain eight-band pacing, hold unchanged grays and soften edge transients; missing phases fall back and failures rebuild the baseline.
enum EpdDrawError update_display_water_turn(EpdiyHighlevelState* hl, EpdRect area,
                                             e0470_turn_dir_t dir);
/// 水波纹·高清：rc100 揭页引擎 + 普通·高清校准 GL16 表 + FULL 标定扫描（11090us/帧），
/// 条带加密到最多 32 带（快刷仍 8 带/FAST/11.09ms），约 68 拍（默认 12ms），单次推屏。
/// HD water keeps rc100's ripple engine but drives the ordinary-HD calibrated GL16 table on the
/// FULL calibrated scan (11090 us/frame) with up to 32 bands (Fast keeps 8 bands/FAST/11.09 ms),
/// about 68 ticks at the default 12 ms, single pass.
enum EpdDrawError update_display_water_turn_hd(EpdiyHighlevelState* hl, EpdRect area,
                                                e0470_turn_dir_t dir);
/// 同步普通文字翻页沿用水波纹的全部灰阶相位，单带同时输出并恢复原节拍。/ Ordinary text uses all ripple gray phases in one synchronous band and restores pacing.
enum EpdDrawError update_display_text_turn(EpdiyHighlevelState* hl, EpdRect area, e0470_turn_dir_t dir);
/// 动画中间帧使用灰阶波形，但不累计周期清屏计数；动画最终帧走普通刷新出口。
/// Use grayscale for animation strips without advancing periodic cleanup; the final frame uses the normal path.

/// 当前像素时钟。/ Current pixel clock.
int display_pclk_mhz(void);
/// 出现供数不足就退回安全频率并整屏重刷，其它错误码原样忽略。
/// On underrun, drop to the safe clock and full-refresh; other error bits are ignored.
void guard_draw_result(EpdiyHighlevelState* hl, enum EpdDrawError result);

/// 切换全局反色：换向前把 back 基准映射到新方向，并请求下一次整屏全刷；帧缓冲仍保持逻辑灰阶。
/// Toggle global inversion; remap the back baseline for the new direction and request a full refresh next frame.
/// Framebuffers keep their logical gray values.
void display_set_inverted(EpdiyHighlevelState* hl, bool inverted);
/// 反色模式下把一块“原图”区域再翻一次，使扫描反色后仍显示原始灰阶（封面/插图用）。
/// Under inversion, flip one artwork region once more so the scan inversion cancels and the region
/// keeps its original tones (covers and illustrations). No-op when inversion is off.
void display_invert_area(uint8_t* fb, EpdRect area);
/// 深色模式翻页后补黑：只对近白底像素（反色后屏幕上的黑底）重驱动一次，字形与抗锯齿边
/// 保持不变；不改变整屏全刷节奏。只在纯文字页调用。
/// Dark-mode turn black settle: re-drive only near-white pixels (the physical black ground after
/// inversion) once; glyphs and AA fringes stay untouched, and the auto full-refresh cadence is
/// unchanged. Call on text-only pages.
void display_black_settle(EpdiyHighlevelState* hl, EpdRect area);
/// 白天模式翻页后补白：与补黑同一条地面掩码，只驱动纯白底；紧跟在翻页推屏之后、同一次
/// present 内执行，字形与抗锯齿边不进差分。只在纯文字页调用。
/// 保留给兜底/对照：present 现在改调 display_white_settle_ink（只补上一页有墨的像素），
/// 不再无条件整片推白，以免每页对 80–90% 的纯白背景重复过驱动。
/// Day-mode turn white settle: the same ground mask, driving only pure-white ground right after the
/// turn push inside the same present(); glyphs and AA fringes stay out of the difference. Text-only
/// pages only. Kept as a fallback/reference: present now calls display_white_settle_ink (only
/// previous-page ink pixels) instead of unconditionally over-driving the whole white ground.
void display_white_settle(EpdiyHighlevelState* hl, EpdRect area);
/// 白天模式「定向补白」：只对「上一页有墨、这一页已经纯白」的像素重推一次白色，其余像素不进
/// 差分；紧跟在翻页推屏之后、同一次 present 内执行。old_ink 是按 area 局部逻辑坐标打包的 1bpp
/// 掩码：stride=(area.width+7)/8，每字节高位在前（MSB first），1 表示上一页该像素有墨。
/// 反色模式下本函数为空操作（反色保持原补黑路径）。
/// Day-mode targeted white settle: re-drive only pixels that carried ink on the previous page and are
/// pure white now; every other pixel stays out of the differential. Runs inside the same present()
/// right after the turn push. old_ink is a 1bpp mask in area-local logical coordinates with
/// stride=(area.width+7)/8 and MSB-first bit order; 1 means the pixel was inked on the previous page.
/// No-op when the panel is inverted (that path keeps the unchanged black settle).
void display_white_settle_ink(EpdiyHighlevelState* hl, EpdRect area,
                              const uint8_t* old_ink, int stride);

#ifdef __cplusplus
}
#endif
