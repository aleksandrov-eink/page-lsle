/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 刷屏出口：按模式推屏、HV 轨空闲下电、pclk 欠载回退。
 *
 * Present path: push by mode, drop HV rails on idle, fall back pclk on
 * underrun.
 * 用户继续优化快刷响应：无灰阶条带时按32位并行归一八像素，已为黑白的字不重复写PSRAM；不删相位、不增加缓存或改变清残影和底栏边界。
 * User continues fast responsiveness tuning: normalize eight pixels per 32-bit word when no gray bands exist and avoid rewriting binary PSRAM words; retain phases, cleanup and navigation bounds without extra caches.
 * 用户修订：三种主页模式均固定底栏，仅局部移动横条；普通切页复用柔和灰阶表，黑白端点单向驱动、等灰保持，中灰保留校准相位。取消每三次全像素整理，仍每十二次完整清残影。快刷棋盘格输出、首次进入、解锁及手动全刷不变，不得伪造back。
 * User revision: all main modes retain navigation with local markers; ordinary transitions reuse soft grays with directional BW endpoints, held equal grays and calibrated changed midgrays. Remove third-page full-pixel settling but retain twelfth-page cleanup. Fast checkerboards, initial entry, unlock and manual full output remain; never fabricate back.
 * 用户2026-10-21恢复rc96显示/残影控制，保留127行预填防欠载和侧滑方向；普通阅读采用原rc97直接差分。
 * User revision 2026-10-21: restore rc96 display/cleanup, keeping 127-line underrun protection and directional back swipes; ordinary reading uses rc97 direct differences.
 * 用户2026-10-21残影反馈：普通文字改用校准GL16完整迁移并保持等灰像素，水波纹继续柔和文字序列；不增加相数或第二轮输出。
 * User ghosting feedback 2026-10-21: ordinary text uses calibrated GL16 transitions with equal-gray holds; ripple keeps soft text phases, without added phases or replay.
 * 用户修订：所有推屏及欠载恢复与 OTA 擦写共用递归锁；无升级任务时保持原波形、范围和节奏。
 * User revision: serialize all display output and underrun recovery with OTA flash operations; keep existing waveforms, bounds and cadence outside updates.
 * 用户要求加快主页水波纹：复用阅读的一拍一带调度，以8带37相共44拍、11090us完成；保留主页原灰阶序列、底栏边界、OTA锁及失败恢复。
 * User requests faster main-page ripple: reuse reader-style compact launches for eight bands/37 phases over 44 ticks at 11090us; retain main gray sequences, navigation bounds, OTA locking and recovery.
 * 用户修订：书架顶部文字、框线与封面/亚克力一起使用水波纹，不再拆分顶部差分刷新；底栏仍固定。
 * User revision: shelf headers, frames, covers and acrylic share one ripple instead of a separate header differential; navigation remains fixed.

 * 用户修订：普通书架上下文字区和中间书架区同一轮逐相输出，外侧柔和、封面/材质保留校准灰阶，留白仅向白擦除；不串行呈现分区。仅横条可变，底栏图标固定，保留统一故障恢复。
 * User revision: ordinary shelf chrome and art share each scan phase, with soft outer text, calibrated covers/furniture and directional whitespace erasure; never reveal regions serially. Only the marker may change within frozen navigation; retain common fault recovery.
 * 用户修订：纯文字水波纹复用柔和文字序列，保持未变灰边、减轻先粗后浅；8带/11090us、最终灰阶、主页水波纹和故障恢复保持。
 * User revision: pure-text ripple reuses soft text phases to hold unchanged grays and reduce dark-edge transients; retain eight bands/11090us, target grays, main ripple and fault recovery.

 */

#include "display.h"
#include "read_pico_board.h"
#include "ota_online.h"
#include "continuous_du.h"

#include <stdbool.h>
#include <stdint.h>
#include "app_config.h"
#include "e0470_epaper_waveform.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "settings.h"

#include <string.h>
#include "esp_heap_caps.h"
#include "display_main_waveform.h"
#include "display_reader_waveform.h"
#include "ui/ui_nav_layout.h"

static const char* TAG = "read_pico";
static bool s_bulk_io;
static bool s_full_refresh_requested;
void display_request_full_refresh(void) { s_full_refresh_requested = true; }

void display_set_inverted(EpdiyHighlevelState* hl, bool inverted) {    if (epd_get_inverted() == inverted) return;
    epd_set_inverted(inverted);
    // 水波纹/高清翻页自己缓存整套相位 LUT，换反色方向必须整份重建。
    // Ripple/HD turns cache their whole phase-LUT set, so rebuild it for the new direction.
    e0470_page_turn_release();
    epd_leading_skip_discard();
    if (hl != NULL) {
        // 反色只换解释方式，帧缓冲仍是逻辑灰阶；把 back 基准换算到同一物理画面在新映射下的逻辑值，
        // 下一次整屏差分会真正把整屏翻过来，而不是误判成“没有变化”。
        // Inversion changes interpretation only; convert the back baseline to the same physical frame under the
        // new mapping so the next full diff actually flips the panel instead of seeing no change.
        const size_t bytes = (size_t)epd_width() / 2 * (size_t)epd_height();
        for (size_t i = 0; i < bytes; ++i) hl->back_fb[i] = (uint8_t)~hl->back_fb[i];
    }
    display_request_full_refresh();
}

// 反色模式只翻界面文字与图形；封面/插图在这里先按原灰阶画出再翻一次，到扫描出口正好抵消。
// Dark mode inverts UI text and chrome; cover/illustration pixels are flipped once here so the
// global scan inversion cancels out and the artwork keeps its original tones.
void display_invert_area(uint8_t* fb, EpdRect area) {
    if (!fb || !epd_get_inverted() || area.width <= 0 || area.height <= 0) return;
    int x0 = area.x < 0 ? 0 : area.x;
    int y0 = area.y < 0 ? 0 : area.y;
    int x1 = area.x + area.width;
    int y1 = area.y + area.height;
    // area 是逻辑坐标：必须用旋转后的宽高裁剪。物理缓冲是 1216×684，竖屏逻辑是 684×1216，
    // 过去用物理高度裁剪会把竖屏 y>684 的封面整块跳过，于是只有下半屏的书封还反着色。
    // The area is logical: clip with the rotated dimensions. The physical buffer is 1216x684 while
    // the portrait canvas is 684x1216; clipping with the physical height used to skip every cover
    // below y=684, leaving only the lower shelf rows inverted.
    const int logical_w = epd_rotated_display_width();
    const int logical_h = epd_rotated_display_height();
    if (x1 > logical_w) x1 = logical_w;
    if (y1 > logical_h) y1 = logical_h;
    if (x0 >= x1 || y0 >= y1) return;
    const int lx[4] = {x0, x1 - 1, x1 - 1, x0};
    const int ly[4] = {y0, y0, y1 - 1, y1 - 1};
    int px[4], py[4];
    for (int i = 0; i < 4; ++i) {
        int tx = lx[i], ty = ly[i];
        switch (epd_get_rotation()) {
            case EPD_ROT_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                tx = epd_width() - tx - 1;
            } break;
            case EPD_ROT_INVERTED_LANDSCAPE:
                tx = epd_width() - tx - 1;
                ty = epd_height() - ty - 1;
                break;
            case EPD_ROT_INVERTED_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                ty = epd_height() - ty - 1;
            } break;
            default: break;
        }
        px[i] = tx;
        py[i] = ty;
    }
    int bx0 = px[0], bx1 = px[0], by0 = py[0], by1 = py[0];
    for (int i = 1; i < 4; ++i) {
        if (px[i] < bx0) bx0 = px[i];
        if (px[i] > bx1) bx1 = px[i];
        if (py[i] < by0) by0 = py[i];
        if (py[i] > by1) by1 = py[i];
    }
    const int stride = epd_width() / 2;
    for (int y = by0; y <= by1; ++y) {
        uint8_t* row = fb + (size_t)stride * y;
        const int b0 = bx0 / 2, b1 = bx1 / 2;
        for (int b = b0; b <= b1; ++b) {
            const uint8_t v = row[b];
            const uint8_t inv = (uint8_t)~v;
            uint8_t mask = 0xFF;
            // 偶数物理列是低半字节，奇数列是高半字节；区间边界只翻属于区间的那一半。
            // Even physical columns are the low nibble and odd columns the high nibble; at the
            // rect edges only the half inside the range is touched.
            if (b == b0 && (bx0 & 1)) mask &= 0xF0;
            if (b == b1 && !(bx1 & 1)) mask &= 0x0F;
            row[b] = (uint8_t)((v & (uint8_t)~mask) | (inv & mask));
        }
    }
}
static int s_pclk_mhz = DISPLAY_PCLK_DEFAULT_MHZ;

void display_set_bulk_io(bool active) {
    s_bulk_io = active;
    ESP_LOGI(TAG, "bulk I/O scan margin %s", active ? "on" : "off");
}

// 高压轨在连续操作间保留8秒，避免反复500ms放电；像素驱动在每轮结束时立即释放。
// Keep HV rails for an eight-second burst to avoid repeated 500ms discharge; release pixel drive after every output.
#define RAILS_IDLE_TIMEOUT_MS 8000
// 强光防泛白/防反黑：出口已逐轮把 VCOM_EN/XOE/MODE 放掉，但 SY7636A 的 DC-DC 高压轨默认保留 8 秒
// 给连续操作省掉放电等待；强光下把高压电场长时间挂在玻璃上会让画面缓慢发黑。开启该修复后，
// 最后一轮刷新结束 600ms 就整轨断电（连续触摸/打字仍会不断续期，不受影响）。
// Sun fading fix: the exit already drops VCOM_EN/XOE/MODE every round, but the SY7636A DC-DC rails
// normally stay up for 8 s to batch burst work; holding that field on the glass under strong light
// slowly darkens the image. With the fix on, the rails are dropped 600 ms after the last update
// (continuous touch/typing keeps re-arming and is unaffected).
#define RAILS_SUN_FADE_MS 600

// 0 表示轨道已断电；否则是到期时间（ms），到点后由低优先级任务断电。
// 0 means the rails are off; otherwise a deadline (ms) after which a low-priority task cuts power.
static int64_t rails_deadline_ms;
static int64_t drive_release_retry_ms;
static int64_t last_update_ms;

// 断电里有约 500ms 的放电等待：放主循环会吞输入，改到低优先级任务里做；主循环只发通知。
// epd_poweroff() includes a ~500 ms discharge wait. Running it in the main loop would swallow
// input, so a low-priority task does the blocking part while the loop only raises a notification.
#define RAILS_OFF_TASK_STACK 2560
static TaskHandle_t s_rails_off_task;
static volatile bool s_rails_off_request;
static volatile bool s_rails_off_busy;
static volatile bool s_rails_off_sun;
// 每次推屏自增：分段断电在放电等待期间若来了新推屏，epoch 变化就放弃 finish（EN 保持，
// 新推屏已经完整重建了轨道），避免把正在使用的轨切断。
// Bumped on every output: if a new output starts during the split power-off's discharge wait,
// the epoch changes and finish() is skipped (EN stays up; the new output already rebuilt the rails).
static volatile unsigned s_power_cut_epoch;

static void rails_off_task(void *arg) {
    (void)arg;
    for (;;) {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        bool held = pico_online_display_begin();
        if (!s_rails_off_request) {
            pico_online_display_end(held);
            continue;
        }
        s_rails_off_request = false;
        const bool sun = s_rails_off_sun;
        s_rails_off_busy = true;
        rails_deadline_ms = 0;
        drive_release_retry_ms = 0;
        const unsigned epoch = s_power_cut_epoch;
        // 先确保像素驱动已释放，再撤 VCOM_EN/ON_OFF；这一段很快，不阻塞主循环。
        // Release pixel drive first, then drop VCOM_EN/ON_OFF; this part is fast and does not block
        // the main loop.
        for (int i = 0; i < 3; ++i) {
            if (read_pico_epd_release_drive()) break;
            vTaskDelay(pdMS_TO_TICKS(5));
        }
        read_pico_epd_power_cut_begin();
        pico_online_display_end(held);
        // 放电等待放在任务里、不持显示锁：翻页/OTA/触摸都不需要等这 500ms。
        // The discharge wait runs in this task without the display lock: page turns, OTA and touch
        // never wait for these 500 ms.
        vTaskDelay(pdMS_TO_TICKS(read_pico_epd_poweroff_hold_ms()));
        held = pico_online_display_begin();
        if (epoch == s_power_cut_epoch) read_pico_epd_power_cut_finish();
        s_rails_off_busy = false;
        pico_online_display_end(held);
        // 逐页打 INFO 会刷屏（强光防反黑开启时每个翻页 burst 一次），只留调试级。
        // Keep this at debug level: with the sun fix on, one line per idle burst would flood the log.
        if (sun) ESP_LOGD(TAG, "sun fading fix: rails off (async)");
    }
}

static bool rails_off_task_ensure(void) {
    if (s_rails_off_task) return true;
    return xTaskCreate(rails_off_task, "rails_off", RAILS_OFF_TASK_STACK, NULL, 2,
                       &s_rails_off_task) == pdPASS;
}

// 睡眠/关机前等低优先级断电任务收尾，避免两路同时写 SY7636A。
// 先拿显示锁再清请求：worker 若已持锁在断电就等它做完；若还在等锁，它拿到锁后会看到请求已清而跳过。
// Wait for the low-priority power-off task before sleep/shutdown so two paths never touch SY7636A.
// Take the display lock before clearing the request: a worker already holding it finishes its cut;
// one still waiting for the lock will see the cleared request and skip.
void display_quiet_rails_off(void) {
    bool held = pico_online_display_begin();
    s_rails_off_request = false;
    pico_online_display_end(held);
    // 上界按实际放电时间推导，外加 300ms 给 I2C/调度余量。
    // Upper bound derived from the real discharge wait, plus 300 ms for I2C/scheduler slack.
    const int64_t wait_ms = (int64_t)read_pico_epd_poweroff_hold_ms() + 300;
    for (int64_t i = 0; i < wait_ms / 5 && s_rails_off_busy; ++i) vTaskDelay(pdMS_TO_TICKS(5));
}

void rails_keepalive(void) {
    bool held = pico_online_display_begin();
    const int64_t now_ms = esp_timer_get_time() / 1000;
    // 新的一轮推屏取消还在排队的提前断电；本次推送结束后主循环会重新计时。
    // A new update cancels a queued early power-off; the loop re-arms the countdown afterwards.
    s_rails_off_request = false;
    // 包括无变化和失败返回：释放像素驱动，不增加扫描或全刷。
    // Release pixel drive even after unchanged/failed output, without another scan or full refresh.
    drive_release_retry_ms = read_pico_epd_release_drive() ? 0 : now_ms + 50;
    rails_deadline_ms = now_ms + RAILS_IDLE_TIMEOUT_MS;
    last_update_ms = now_ms;
    ++s_power_cut_epoch;
    pico_online_display_end(held);
}

void rails_idle_check(int64_t now_ms, bool input_idle) {
    // 像素驱动释放失败的重试很短，留在主循环里做；真正的整轨断电交给任务。
    // The short drive-release retry stays in the loop; the blocking rail cut goes to the task.
    if (drive_release_retry_ms && now_ms >= drive_release_retry_ms) {
        bool held = pico_online_display_begin();
        if (drive_release_retry_ms && now_ms >= drive_release_retry_ms)
            drive_release_retry_ms = read_pico_epd_release_drive() ? 0 : now_ms + 50;
        pico_online_display_end(held);
    }
    if (s_rails_off_request) return;  // 任务已排队 / worker already queued
    const bool deadline_due = rails_deadline_ms != 0 && now_ms >= rails_deadline_ms;
    // 强光提前断电默认关闭；开启时只在输入空闲时提前（触摸、菜单、弹层、USB/OTA 走 8 秒兜底）。
    // The early sun power-off is off by default; when on it only fires while input is idle (touch,
    // menus, overlays, USB and OTA fall back to the 8 s deadline).
    const bool sun_due = input_idle && rails_deadline_ms != 0 && last_update_ms != 0 &&
        app_settings_sun_fade_fix() && now_ms - last_update_ms >= RAILS_SUN_FADE_MS;
    if (!deadline_due && !sun_due) return;
    if (rails_off_task_ensure()) {
        s_rails_off_sun = sun_due && !deadline_due;
        s_rails_off_request = true;
        xTaskNotifyGive(s_rails_off_task);
        return;
    }
    // 任务创建失败：退回主循环同步断电（仅极端内存情况，最多约 500ms 停顿）。
    // Task creation failed: fall back to a synchronous cut in the loop (only under extreme memory
    // pressure, costing up to ~500 ms once).
    bool held = pico_online_display_begin();
    rails_deadline_ms = 0;
    drive_release_retry_ms = 0;
    epd_poweroff();
    pico_online_display_end(held);
}

// 20 相完整/原厂 DU 按厂家时序走 FULL；只有触摸笔迹用的 8 帧跟随 DU 走 FAST。
// 20-phase full / vendor DU uses FULL timing; the 8-frame FOLLOW DU used for ink trails uses FAST.
static void use_scan_for(const EpdWaveform* waveform, enum EpdDrawMode mode) {
    const bool fast = (mode & 0xF) == MODE_DU && waveform == &E0470_FOLLOW_WAVEFORM;
    read_pico_epd_use_scan(fast ? READ_PICO_EPD_SCAN_FAST : READ_PICO_EPD_SCAN_FULL);
    // 高层刷新保持整屏扫描；两条63行可用队列在第127行入队前启动。
    // High-level updates scan the full panel; two 63-slot queues start before line 127 is enqueued.
    epd_lcd_set_prefill_lines(s_bulk_io ? 127 : (fast ? 64 : 32));
}

// 自上次整屏 GC16 以来的整页差分次数。局部反馈不计数，否则菜单按压几次就会触发黑白全刷。
// Whole-page differentials since the last full GC16. Local feedback is excluded so a few taps cannot trigger flashing.
static int s_page_refreshes;

static const void* s_main_armed;
static bool s_main_fault;
static bool s_main_shelf_page;
static EpdRect s_main_bands[3];
static unsigned s_main_band_count;
static bool s_main_shelf_exit;
static bool s_main_changing_page;
_Static_assert((UI_NAV_REFRESH_END & 31) == 0, "fixed navigation begins on an aligned framebuffer column");
_Static_assert(UI_NAV_REFRESH_END <= UI_NAV_TOP, "aligned refresh must stop above navigation and marker");
_Static_assert(UI_NAV_MARKER_SCAN_END <= UI_NAV_TOP + 27, "marker crop must stop before navigation icons");
_Static_assert((UI_NAV_MARKER_TOP & 1) && !(UI_NAV_MARKER_BOTTOM & 1), "marker nibble guards match current geometry");

static bool main_nav_geometry(void) {
    // 当前板为倒置竖屏：逻辑 y 对应物理 x。其他屏型保持原刷新路径。
    // On this inverted-portrait board logical y maps to physical x; other layouts keep the existing presenter.
    return epd_get_rotation() == EPD_ROT_INVERTED_PORTRAIT &&
           epd_width() == 1216 && epd_height() == 684;
}

static EpdRect main_body_area(void) {
    // 内容截止到 y=1087，32列对齐也不能扩展到 y=1097 的小横条。
    // Content ends at y=1087, so 32-column expansion cannot reach the marker at y=1097.
    return (EpdRect){0, 0, epd_rotated_display_width(), UI_NAV_REFRESH_END};
}

static uint8_t main_bw_byte(uint8_t value) {
    return (value & 0x0f) >= 8 ? ((value & 0xf0) >= 0x80 ? 0xff : 0x0f)
                             : ((value & 0xf0) >= 0x80 ? 0xf0 : 0x00);
}

static bool main_gray_column(int x) {
    for (unsigned i = 0; i < s_main_band_count; ++i)
        if (x >= s_main_bands[i].y && x < s_main_bands[i].y + s_main_bands[i].height) return true;
    return false;
}

static void main_normalize_body(EpdiyHighlevelState* hl) {
    const size_t stride = (size_t)epd_width() / 2;
    for (int y = 0; y < epd_height(); ++y) {
        uint8_t* row = hl->front_fb + y * stride;
        if (!s_main_band_count) {
            for (int x = 0; x < UI_NAV_REFRESH_END / 2; x += 4) {
                uint32_t value;
                memcpy(&value, row + x, sizeof(value));
                const uint32_t binary = ((value & UINT32_C(0x88888888)) >> 3) * 15u;
                if (value != binary) memcpy(row + x, &binary, sizeof(binary));
            }
            continue;
        }
        for (int x = 0; x < UI_NAV_REFRESH_END / 2; ++x)
            if (!main_gray_column(x * 2)) row[x] = main_bw_byte(row[x]);
    }
}

static bool main_body_changed(EpdiyHighlevelState* hl) {
    const size_t stride = (size_t)epd_width() / 2;
    for (int y = 0; y < epd_height(); ++y)
        if (memcmp(hl->front_fb + y * stride, hl->back_fb + y * stride, UI_NAV_REFRESH_END / 2)) return true;
    return false;
}

// 三条最终灰阶最多约90KiB；首帧跳过它们，实际输出成功才提交back。
// Three final gray bands cost at most about 90 KiB; skip them in the first pass and commit back only after successful output.
static size_t main_band_bytes(void) {
    size_t bytes = 0;
    for (unsigned i = 0; i < s_main_band_count; ++i) bytes += (size_t)s_main_bands[i].height * epd_height() / 2;
    return bytes;
}
static void main_band_copy(EpdiyHighlevelState *hl, uint8_t *cache, bool restore) {
    const size_t stride = (size_t)epd_width() / 2;
    for (unsigned i = 0; i < s_main_band_count; ++i) {
        const size_t bytes = (size_t)s_main_bands[i].height / 2;
        for (int y = 0; y < epd_height(); ++y) {
            uint8_t *row = hl->front_fb + y * stride + s_main_bands[i].y / 2;
            if (restore) memcpy(row, cache, bytes);
            else { memcpy(cache, row, bytes); memcpy(row, hl->back_fb + y * stride + s_main_bands[i].y / 2, bytes); }
            cache += bytes;
        }
    }
}

static void main_freeze_navigation(EpdiyHighlevelState* hl, bool update_marker) {
    const size_t stride = (size_t)epd_width() / 2;
    for (int y = 0; y < epd_height(); ++y) {
        uint8_t* front = hl->front_fb + y * stride;
        const uint8_t* back = hl->back_fb + y * stride;
        if (!update_marker) {
            memcpy(front + UI_NAV_REFRESH_END / 2, back + UI_NAV_REFRESH_END / 2,
                   stride - UI_NAV_REFRESH_END / 2);
            continue;
        }
        // 只保留目标横条的五行；起点为奇数像素，同行字节的分隔线半字节仍取真实 back。
        // Keep only the five target marker rows; at the odd first pixel retain the neighboring divider nibble from actual back.
        memcpy(front + UI_NAV_REFRESH_END / 2, back + UI_NAV_REFRESH_END / 2,
               (UI_NAV_MARKER_TOP - UI_NAV_REFRESH_END) / 2);
        const int first = UI_NAV_MARKER_TOP / 2;
        front[first] = (front[first] & 0xf0) | (back[first] & 0x0f);
        memcpy(front + UI_NAV_MARKER_BOTTOM / 2, back + UI_NAV_MARKER_BOTTOM / 2,
               stride - UI_NAV_MARKER_BOTTOM / 2);
    }
}

void display_main_transition_disarm(void) {
    s_main_armed = NULL;
    s_main_shelf_page = false;
    s_main_band_count = 0;
    s_main_shelf_exit = false;
    s_main_changing_page = false;
}

void display_main_transition_cancel(void) {
    display_main_transition_disarm();
}

void display_main_transition_arm(const void* owner, bool leaving_shelf, bool changing_page) {
    s_main_armed = owner;
    s_main_shelf_page = false;
    s_main_band_count = 0;
    s_main_shelf_exit = s_main_armed && leaving_shelf;
    s_main_changing_page = s_main_armed && changing_page;
}

void display_main_transition_gray_bands(const EpdRect *bands, unsigned count) {
    if (!s_main_armed) return;
    s_main_band_count = 0;
    if (!bands || count > 3) return;
    int last = 0;
    for (unsigned i = 0; i < count; ++i) {
        EpdRect b = bands[i];
        if (b.x || b.width != epd_rotated_display_width() || b.y < last || b.height <= 0 ||
            (b.y & 1) || (b.height & 1) || b.y > UI_NAV_REFRESH_END || b.height > UI_NAV_REFRESH_END - b.y) return;
        s_main_bands[i] = b; last = b.y + b.height;
    }
    s_main_band_count = count;
}

void display_main_transition_shelf_page(void) {
    s_main_shelf_page = s_main_armed != NULL;
}

static enum EpdDrawError main_recover(EpdiyHighlevelState* hl, enum EpdDrawError error) {
    // 扫描失败后光学状态未知，必须从白底重建，不能复用半途图的 back。
    // A failed scan leaves unknown optical state; rebuild from white instead of reusing an intermediate back.
    display_main_transition_cancel();
    if (error & EPD_DRAW_EMPTY_LINE_QUEUE) {
        s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
        read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    }
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_poweron();
    epd_clear();
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    enum EpdDrawError result = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    s_main_fault = result != EPD_DRAW_SUCCESS;
    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "main transition recovery error=%d result=%d", error, result);
    return result;
}

static bool main_begin(EpdiyHighlevelState* hl, enum EpdDrawError* result) {
    const void* owner = s_main_armed;
    const bool shelf_exit = s_main_shelf_exit || s_main_shelf_page;
    s_main_shelf_page = false;
    const bool changing_page = s_main_changing_page;
    s_main_changing_page = false;
    const int refresh_mode = app_settings_main_refresh_mode();
    const bool water = refresh_mode == APP_MAIN_REFRESH_WATER;
    const bool normal = refresh_mode == APP_MAIN_REFRESH_NORMAL;
    const bool fast = refresh_mode == APP_MAIN_REFRESH_FAST;
    s_main_shelf_exit = false;
    s_main_armed = NULL;
    if (!owner || !hl || !hl->front_fb || !hl->back_fb) return false;
    if (s_main_fault) { *result = main_recover(hl, EPD_DRAW_SUCCESS); return true; }
    if (!main_nav_geometry()) return false;
    // 8帧整页方案被实机否定；用户接受主页面黑白、亚克力灰阶，黑白改用完整20相。
    // Hardware rejected whole-page 8-frame output; the user accepted black/white main pages with gray acrylic. Use the full 20-phase black/white table.
    main_freeze_navigation(hl, true);
    if (fast) main_normalize_body(hl);
    const bool changed = main_body_changed(hl);
    uint8_t *cache = fast && changed && s_main_band_count
        ? heap_caps_aligned_alloc(16, main_band_bytes(), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT) : NULL;
    const bool gray_fallback = water || (fast && changed && s_main_band_count && !cache);
    // 黑白表的等灰迁移均不驱动；仅把有变化的横条并入同次扫描，固定图标保持原样。
    // The BW/exit tables hold every equal pair. Include only the changing marker
    // in this scan; frozen divider/labels/icons receive no drive. This removes
    // an additional comparison and eight-frame serial marker update.
    bool marker_with_body=fast&&changed&&!cache&&!gray_fallback;
    EpdRect body_area=main_body_area();
    if(marker_with_body)body_area.height=UI_NAV_MARKER_SCAN_END;
    if (cache) main_band_copy(hl, cache, false);
    const EpdWaveform* body_wave = normal ? display_main_normal_waveform() : gray_fallback ? display_main_gray_waveform()
        : shelf_exit ? display_main_shelf_exit_waveform() : display_main_bw_waveform();
    enum EpdDrawMode body_mode = normal || gray_fallback ? MODE_GL16 : MODE_DU;
    bool body_full = false;
    // 普通切页只驱动变化像素，完整中灰相位不缩短；每十二次仍用原表清理内容区。
    // Ordinary changes drive differing pixels without shortening midgray phases; the original table still cleans the body every twelfth change.
    if (normal && changed) {
        ++s_page_refreshes;
        if (APP_UI_FAST_GC16_EVERY > 0 && s_page_refreshes >= APP_UI_FAST_GC16_EVERY) {
            s_page_refreshes = 0;
            body_wave = &E0470_WAVEFORM;
            body_mode = MODE_GC16;
            body_full = true;
        }
    }
    const bool shelf_regions=normal&&changed&&s_main_band_count&&(changing_page||body_full);
    if(shelf_regions){marker_with_body=true;body_area.height=UI_NAV_MARKER_SCAN_END;}
    use_scan_for(body_wave, body_mode);
    epd_poweron();
    epd_hl_waveform(hl, body_wave);
    int64_t start = esp_timer_get_time();
    // 快刷/水波纹不攒强刷次数；普通的周期整理也不能进入底栏。
    // Fast/water accrue no forced-cleanup debt; ordinary periodic settling also excludes navigation.
    if(shelf_regions){
        // 同一帧逐列选择柔和/校准表，上下和中间一起开始，不显示串行的三段旧图。
        // Select soft/calibrated LUTs by columns in the same frame so chrome and art start together without three serial old-image regions.
        EpdRect last=s_main_bands[s_main_band_count-1];
        int top=s_main_bands[0].y&~31,bottom=(last.y+last.height+31)&~31;
        if(bottom>UI_NAV_REFRESH_END)bottom=UI_NAV_REFRESH_END;
        *result=e0470_update_regions(hl,body_area,(EpdRect){0,top,body_area.width,bottom-top},
            display_main_normal_waveform(),display_main_shelf_waveform(body_full?MODE_GC16:MODE_GL16),
            body_full?MODE_GC16:MODE_GL16);
        if(*result==EPD_DRAW_NO_PHASES_AVAILABLE){
            // 低内存仍一次输出整张目标；不退回分段等待或更改真实back。
            // Low memory still presents the whole target once, without serial waiting or a fabricated baseline.
            epd_hl_waveform(hl,display_main_normal_waveform());
            *result=epd_hl_update_area(hl,MODE_GL16,25,body_area);
        }
    } else if (water && changing_page && changed) {
        // 水波纹直接输出最终灰阶图，不先刷黑白、不追加整页灰阶；失败由统一恢复处理。
        // Water outputs the final gray target directly, without a BW prepass or a second whole-page gray update; common recovery handles failure.
        read_pico_epd_use_scan(READ_PICO_EPD_SCAN_FAST);
        epd_lcd_set_prefill_lines(127);
        EpdRect ripple = main_body_area();
        const int prior_tick=e0470_page_turn_tick_us();
        e0470_page_turn_set_tick_us(E0470_TURN_FAST_TICK_US);
        *result = e0470_page_turn_with_waveform_compact(hl, ripple, E0470_TURN_RTL,
                                                       display_main_water_waveform(), E0470_TURN_FAST_BANDS);
        e0470_page_turn_set_tick_us(prior_tick);
        if (*result == EPD_DRAW_NO_PHASES_AVAILABLE) {
            use_scan_for(body_wave, MODE_GL16);
            epd_hl_waveform(hl, body_wave);
            *result = epd_hl_update_area(hl, MODE_GL16, 25, ripple);
        }
        // 主页面动画不长期保留相位缓存，避免与联网和阅读资源争用。
        // Release main-animation LUTs instead of competing with networking and reader resources.
        e0470_page_turn_release();
    } else if (!changed) *result = EPD_DRAW_SUCCESS;
    else *result = body_full ? epd_hl_update_area_full(hl, body_mode, 25, body_area)
                            : epd_hl_update_area(hl, body_mode, 25, body_area);
    if (cache) {
        main_band_copy(hl, cache, true);
        heap_caps_free(cache);
        if (*result == EPD_DRAW_SUCCESS) {
            const EpdRect last = s_main_bands[s_main_band_count - 1];
            EpdRect gray = {0, s_main_bands[0].y, epd_rotated_display_width(), last.y + last.height - s_main_bands[0].y};
            // 采用原校准迁移，不自行按灰度比例截帧；等灰无需反复推动。
            // Retain calibrated transitions without scaling pulses by gray distance; equal grays need no repeated drive.
            epd_hl_waveform(hl, display_main_gray_waveform());
            use_scan_for(display_main_gray_waveform(), MODE_GL16);
            *result = epd_hl_update_area(hl, MODE_GL16, 25, gray);
        }
    }
    s_main_band_count = 0;
    if (*result == EPD_DRAW_SUCCESS && !marker_with_body) {
        const EpdRect marker = {0, UI_NAV_MARKER_TOP, epd_rotated_display_width(),
                               UI_NAV_MARKER_BOTTOM - UI_NAV_MARKER_TOP};
        // 同页重绘横条无变化时 highlevel 自动跳过；32列扩展范围中其余像素来自 back，保持不驱动。
        // Highlevel skips an unchanged marker; all other pixels in its expanded 32-column crop come from back and remain undriven.
        epd_hl_waveform(hl, &E0470_FOLLOW_WAVEFORM);
        use_scan_for(&E0470_FOLLOW_WAVEFORM, MODE_DU);
        *result = epd_hl_update_area(hl, MODE_DU, 25, marker);
    }
    if (*result != EPD_DRAW_SUCCESS) *result = main_recover(hl, *result);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    rails_keepalive();
    ESP_LOGD(TAG, "main refresh mode=%d shelf_exit=%d draw=%lldms result=%d", app_settings_main_refresh_mode(), shelf_exit, (esp_timer_get_time() - start) / 1000, *result);
    (void)start;
    return true;
}

// 其他显示出口只取消未用入口；主页面失败时先重建完整目标，绝不回放旧缓存。
// Other outputs disarm unused entry permission; a main-page failure first rebuilds the full current target, never replaying old cache.
static bool main_before_update(EpdiyHighlevelState* hl, enum EpdDrawError* result) {
    display_main_transition_cancel();
    if (s_main_fault) { *result = main_recover(hl, EPD_DRAW_SUCCESS); return true; }
    return false;
}

// 所有按 fb 刷屏的出口都经这里。GL16 必须全像素（白底补 1 帧靠它打到）。
// 整页差分刷攒够 APP_UI_GC16_EVERY 次就把这一次升为全像素 GC16：区域、fb 都不变，只换模式，
// 屏上内容仍由 fb 决定，不会丢；全像素是为了让未变化像素也过一遍 LUT，否则压不掉灰底。
// 跟随 DU 波形只有 DU 一张表，不计数也不升级。
// Every fb present goes through here. GL16 must be full-pixel (the extra white
// frame depends on that). After APP_UI_GC16_EVERY whole-page updates, this one is
// promoted to full-pixel GC16: area and fb stay the same, only the mode
// changes, so content is not lost. Full-pixel is so unchanged pixels also run
// the LUT; otherwise the gray floor will not clear. FOLLOW DU has only a DU
// table and does not count or promote.
static enum EpdDrawError hl_update(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode, bool full,
    const EpdRect* area, bool allow_gl16_diff
) {
    // 已显示主页面的局部封面或滚动更新同样向内裁剪，防止32列对齐带出小横条。
    // Local cover or scroll updates on an already displayed main page use the same inward crop, excluding the marker after alignment.
    if (area && s_main_shelf_page && app_settings_main_fast_refresh()) {
        enum EpdDrawError result;
        if (main_begin(hl, &result)) return result;
    }
    EpdRect clipped;
    const bool protected_area = area && s_main_armed && !s_main_fault && main_nav_geometry();
    if (protected_area) {
        main_freeze_navigation(hl, false);
        if (app_settings_main_fast_refresh()) main_normalize_body(hl);
        clipped = *area;
        if ((int64_t)clipped.y + clipped.height > UI_NAV_REFRESH_END)
            clipped.height = UI_NAV_REFRESH_END - clipped.y;
        if (clipped.height <= 0) { display_main_transition_disarm(); return EPD_DRAW_SUCCESS; }
        area = &clipped;
        // 显式短局刷不被主页模式改写，猫眼/秒针在普通与水波纹中采用同一动效。
        // Preserve explicit short partial updates so cat eyes and seconds share ordinary-mode motion in ripple mode.
        if (!full && waveform != &E0470_FOLLOW_WAVEFORM && (mode & 0x0f) != MODE_GC16 &&
            (app_settings_main_refresh_mode()!=APP_MAIN_REFRESH_NORMAL || (mode & 0x0f)==MODE_GL16)) {
            bool has_gray = !app_settings_main_fast_refresh();
            for (unsigned i = 0; i < s_main_band_count; ++i)
                has_gray |= clipped.y < s_main_bands[i].y + s_main_bands[i].height && clipped.y + clipped.height > s_main_bands[i].y;
            waveform = app_settings_main_refresh_mode()==APP_MAIN_REFRESH_NORMAL ? display_main_normal_waveform() :
                has_gray ? display_main_gray_waveform() : s_main_shelf_page
                ? display_main_shelf_exit_waveform() : display_main_bw_waveform();
            mode = has_gray ? MODE_GL16 : MODE_DU;
            allow_gl16_diff = true;
            epd_hl_waveform(hl, waveform);
        }
    }
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    if (waveform != &E0470_FOLLOW_WAVEFORM && area == NULL) {
        if ((mode & 0xF) == MODE_GC16) {
            s_page_refreshes = 0;
        } else if (APP_UI_GC16_EVERY > 0 && ++s_page_refreshes >= APP_UI_GC16_EVERY) {
            s_page_refreshes = 0;
            mode = (enum EpdDrawMode)((mode & ~0xF) | MODE_GC16);
            full = true;
            ESP_LOGI(TAG, "promote to GC16 after %d page transitions", APP_UI_GC16_EVERY);
        }
    }
    full = full || ((mode & 0xF) == MODE_GL16 && !allow_gl16_diff);
    // 比较完成后只切换一次扫描档，避免快刷前先切 FULL 再切 FAST。
    // Select scan timing once after comparison, without a FULL-to-FAST round trip before fast updates.
    use_scan_for(waveform, mode);
    enum EpdDrawError result;
    if (area != NULL) {
        result = full ? epd_hl_update_area_full(hl, mode, 25, *area)
                    : epd_hl_update_area(hl, mode, 25, *area);
    } else result = full ? epd_hl_update_screen_full(hl, mode, 25) : epd_hl_update_screen(hl, mode, 25);

    return protected_area && result != EPD_DRAW_SUCCESS ? main_recover(hl, result) : result;
}

static enum EpdDrawError update_display_mode_unlocked(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    epd_poweron();
    enum EpdDrawError result = hl_update(hl, &E0470_WAVEFORM, mode, false, NULL, false);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_mode_diff_unlocked(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    epd_poweron();
    enum EpdDrawError result = hl_update(hl, &E0470_WAVEFORM, mode, false, NULL, true);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_fast_page_unlocked(EpdiyHighlevelState* hl) {
    enum EpdDrawError navigation;
    if (main_begin(hl, &navigation)) return navigation;
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    if (APP_UI_FAST_GC16_EVERY > 0 && ++s_page_refreshes >= APP_UI_FAST_GC16_EVERY) {
        s_page_refreshes = 0;
        use_scan_for(&E0470_WAVEFORM, MODE_GC16);
        epd_poweron();
        epd_hl_waveform(hl, &E0470_WAVEFORM);
        enum EpdDrawError result = epd_hl_update_screen_full(hl, MODE_GC16, 25);

        rails_keepalive();
        ESP_LOGI(TAG, "fast navigation cleanup after %d transitions", APP_UI_FAST_GC16_EVERY);
        return result;
    }
    const bool ordinary = app_settings_main_refresh_mode() == APP_MAIN_REFRESH_NORMAL;
    const EpdWaveform* waveform = ordinary ? display_main_normal_waveform() : &E0470_WAVEFORM;
    use_scan_for(waveform, MODE_GL16);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    // 普通子页面与四主页使用同一柔和灰阶，不另加黑白预刷或延迟补刷；其他模式保留原周期。
    // Ordinary subpages share the roots' soft grayscale in one pass, without BW prepasses or delayed output; other modes retain their cadence.
    const bool settle = !ordinary && APP_UI_FAST_GL16_SETTLE_EVERY > 0 &&
                        s_page_refreshes % APP_UI_FAST_GL16_SETTLE_EVERY == 0;
    enum EpdDrawError result = settle ? epd_hl_update_screen_full(hl, MODE_GL16, 25)
                                      : epd_hl_update_screen(hl, MODE_GL16, 25);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_from_white_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    use_scan_for(waveform, mode);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = epd_hl_update_screen_from_white(hl, mode, 25);

    epd_hl_waveform(hl, &E0470_WAVEFORM);
    s_page_refreshes = 0;
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_from_white_unlocked(EpdiyHighlevelState* hl) {
    return update_display_from_white_with(hl, &E0470_WAVEFORM, MODE_GC16);
}

static enum EpdDrawError update_display_white_unlocked(EpdiyHighlevelState* hl) {
    epd_hl_set_all_white(hl);
    return update_display_full(hl);
}

static bool s_white_exit;

void display_hold_white_exit(bool hold) {
    s_white_exit = hold;
}

bool display_take_white_exit(void) {
    const bool hold = s_white_exit;
    s_white_exit = false;
    return hold;
}

static enum EpdDrawError update_display_full_unlocked(EpdiyHighlevelState* hl) {
    s_full_refresh_requested = false;
    display_main_transition_cancel();
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    epd_poweron();
    enum EpdDrawError result = hl_update(hl, &E0470_WAVEFORM, MODE_GC16, true, NULL, false);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_area_diff_with_unlocked(EpdiyHighlevelState*, const EpdWaveform*, enum EpdDrawMode, EpdRect);
static enum EpdDrawError update_display_area_full_with_unlocked(EpdiyHighlevelState*, const EpdWaveform*, enum EpdDrawMode, EpdRect);

static enum EpdDrawError update_display_image_gray_unlocked(EpdiyHighlevelState* hl) {
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    // 图片保留十六级原始灰阶；白底和完整 48 相波形稳定呈现层次。
    // Images keep sixteen source grays; a white baseline and the full 48-phase table preserve tones.
    use_scan_for(&E0470_FULL_WAVEFORM, MODE_GC16);
    epd_poweron();
    epd_clear();
    epd_hl_waveform(hl, &E0470_FULL_WAVEFORM);
    enum EpdDrawError result = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);

    epd_hl_waveform(hl, &E0470_WAVEFORM);
    s_page_refreshes = 0;
    rails_keepalive();
    return result;
}

// 指定波形整屏刷一次，刷完把默认波形装回去。用来 A/B 两条灰阶表。
// Present the whole screen with a given waveform, then restore the default. Used to A/B two gray tables.
static enum EpdDrawError update_display_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, false, NULL, false);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_area_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, false, &area, false);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_area_diff_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, false, &area, true);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_area_full_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, true, &area, false);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

// 普通阅读翻页用快速扫描时钟；快刷水波纹沿用 rc100 揭页引擎和 reader 灰阶波形，一次推屏完成；
// 高清水波纹例外：见 update_display_hd_water_unlocked——它切到 FULL 标定扫描（11090us/帧）并改用
// 普通·高清的校准 GL16 表，让抗锯齿中灰按标定脉宽推到位。清残影由 present 翻页后的补白/补黑负责。
// Ordinary reader turns scan with the fast clock; Fast water keeps rc100's ripple engine and the
// reader text waveform (one pass). HD water is the exception (see update_display_hd_water_unlocked):
// it switches to the FULL calibrated scan (11090 us/frame) and the ordinary-HD calibrated GL16
// table so the antialiased mid-grays are driven at calibrated pulse widths. present()'s white/black
// settle still clears the residue afterwards.
static enum EpdDrawError update_display_reader_turn_unlocked(EpdiyHighlevelState* hl, EpdRect area,
                                             e0470_turn_dir_t dir, unsigned bands,
                                             const EpdWaveform* waveform, bool commit_baseline) {
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    // 阅读普通翻页和水波纹共用灰阶扫描；主页保留独立路径。
    // 反色模式不再改扫描时钟：整帧时钟会让白字脉冲更长，字就从细变粗；黑色残留改为
    // 翻页完成后单独补一次 DU 全驱动（display_black_settle），只压黑底、不重设字形灰度。
    // Ordinary reader turns and ripple share gray scanning; main tabs retain their separate path.
    // Inverted mode no longer changes the scan clock: the full clock lengthens the white-glyph
    // pulses and makes text look bolder. Black residue is settled afterwards by a separate DU
    // pass (display_black_settle) that only re-drives the black ground.
    read_pico_epd_use_scan(READ_PICO_EPD_SCAN_FAST);
    // 真机首轮文字扫描在预绘制并发时出现欠载；使用现有127行上限预填，不扩大队列或改变帧节拍。
    // The first real text scan underruns during concurrent prepainting; prefill the existing 127-line limit without growing queues or changing frame pacing.
    epd_lcd_set_prefill_lines(127);
    epd_poweron();
    // 通用GL16连相同灰边也会重新压黑；文字序列保持等灰并提前少量回浅，直接用于条带LUT。
    // Generic GL16 re-drives even equal gray edges; text phases hold them and advance a few settling pulses in the band LUT.
    enum EpdDrawError result = e0470_page_turn_with_waveform_compact_commit(hl, area, dir,
        waveform, bands, commit_baseline);
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    rails_keepalive();
    if (result == EPD_DRAW_SUCCESS) return result;
    if (result == EPD_DRAW_NO_PHASES_AVAILABLE) {
        ESP_LOGW(TAG, "water turn phases unavailable; use regular GL16");
        return update_display_area_diff_with(hl, waveform, MODE_GL16, area);
    }
    // 中断可能把物理屏留在半途。清屏后按目标 front 重建整屏基准。
    // An interrupted scan may leave intermediate pixels. Rebuild the whole baseline from white.
    if (result & EPD_DRAW_EMPTY_LINE_QUEUE) {
        s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
        read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    }
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_clear();
    enum EpdDrawError recovered = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);

    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "water turn failed (%d), recovery=%d", result, recovered);
    return recovered;
}

// 高清水波纹条带数：比快刷密得多（最多 32 带）。揭页引擎每拍只启动下一条带、每条带的像素
// 收到完整的 37 相波形，所以条带越密，屏幕上同时存在的相位阶数越多、相邻带的灰度差越小，
// 揭页前沿就从「8 条粗台阶」变成「32 级细渐变」，抗锯齿过程本身就在动画里完成（仍是单次
// 推屏、结束提交基准，不追加第二遍）。代价：动画更长（8 带 44 拍 → 32 带 68 拍，约
// 0.53s → 0.82s），且每拍都要整屏扫描，高清档的扫描帧数多 55%，功耗/耗时相应增加；
// 快刷档与其它翻页路径不受影响。
// HD ripple uses many more bands than Fast water (up to 32). The engine launches one band per
// tick and every pixel still receives the full 37-phase waveform, so denser bands mean more
// simultaneous phase levels and a smaller gray gap between neighbours: the reveal front turns from
// eight coarse steps into a 32-level gradient. The antialiasing happens inside the single ripple
// pass (baseline still committed at the end, no second pass). Cost: a longer animation (8 bands/44
// ticks → 32 bands/68 ticks, ~0.53 s → ~0.82 s) and 55% more full-screen scan frames on the HD
// step, so power/latency grow accordingly; Fast water and every other turn path stay untouched.
// 供阅读页使用（span 684/1216）。若将来复用到小区域，下面的公式也保证行分带 bands ≤ span、
// 列分带每带 ≥32 像素，不会让引擎因空带返回 INVALID_CROP 而走整屏清屏恢复。
// Used by the reader area (span 684/1216). Should a small area reuse it, the formulas below still
// keep row bands within span and column bands at 32+ px, so the engine never sees an empty band and
// returns INVALID_CROP (which would force the expensive whole-screen clear recovery).
static unsigned hd_water_band_count(EpdRect area, e0470_turn_dir_t dir) {
    const bool lr = dir == E0470_TURN_LTR || dir == E0470_TURN_RTL;
    const int span = lr ? area.width : area.height;
    if (span <= 0) return E0470_TURN_FAST_BANDS;
    const enum EpdRotation rotation = epd_get_rotation();
    const bool landscape = rotation == EPD_ROT_LANDSCAPE || rotation == EPD_ROT_INVERTED_LANDSCAPE;
    // 版面相位轴与引擎 uses_line_phase() 保持一致：整行共相时按行分带，否则按列分带。
    // Match the engine's uses_line_phase(): whole-row phases band by rows, otherwise by columns.
    const bool line_phase = landscape ? !lr : lr;
    int bands;
    if (line_phase) {
        // 行分带：阅读区通常 684+ 像素宽，取上限 32；小区域最少每带 1 行。
        // Row bands: the reader area is normally 684+ px wide, so use the cap; small areas keep at
        // least one row per band.
        bands = span >= 256 ? 32 : (span >= 32 ? 16 : 1);
        if (bands > span) bands = span;
    } else {
        // 列分带：引擎按 16 像素步进，每带至少 32 像素才能保证每条带非空。
        // Column bands step by 16 px, so each band needs 32+ px to stay non-empty.
        bands = span / 32;
        if (bands > 32) bands = 32;
        if (bands < 1) bands = 1;
    }
    if (bands > 32) bands = 32;
    return (unsigned)bands;
}

// 高清水波纹：用「普通·高清」同一张校准 GL16 表（E0470_WAVEFORM），并把扫描时钟切到
// 标定档 FULL——行周期补到波形标定的 11090us/帧，每相脉宽与表完全一致，抗锯齿中间灰才推得准。
// rc100 的 FAST 扫描帧只有约 7ms（脉宽约为标定的 63%），中灰推不到位，字体边缘就粗糙；
// 这里按用户「把字体推得更细换抗锯齿」的要求改用标定脉宽，动画节拍不变（帧 11.09ms < 12ms/拍，
// 32 带 68 拍约 816ms），仍是单次推屏、结束提交基准，不追加第二遍定稿。
// HD water drives the same calibrated GL16 table as ordinary HD (E0470_WAVEFORM) and selects the
// calibrated FULL scan profile: the line period is padded to the waveform's 11090 us frame so every
// phase pulse matches the table and the antialiased mid-grays land correctly. rc100's FAST frame is
// only ~7 ms (about 63% pulse width), which under-drives those grays and leaves rough text edges;
// per the user's request we trade that for calibrated pulse widths. The tick stays unchanged (frame
// 11.09 ms < 12 ms/tick, 32 bands/68 ticks ≈ 816 ms); the pass is still single-shot with a
// committed baseline, no second settle pass.
static enum EpdDrawError update_display_hd_water_unlocked(EpdiyHighlevelState* hl, EpdRect area,
                                                          e0470_turn_dir_t dir) {
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    read_pico_epd_use_scan(READ_PICO_EPD_SCAN_FULL);
    epd_lcd_set_prefill_lines(127);
    epd_poweron();
    enum EpdDrawError result = e0470_page_turn_with_waveform_compact_commit(
        hl, area, dir, &E0470_WAVEFORM, hd_water_band_count(area, dir), true);
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    rails_keepalive();
    if (result == EPD_DRAW_SUCCESS) return result;
    if (result == EPD_DRAW_NO_PHASES_AVAILABLE) {
        ESP_LOGW(TAG, "HD water turn phases unavailable; use regular GL16");
        return update_display_area_diff_with(hl, &E0470_WAVEFORM, MODE_GL16, area);
    }
    // 中断可能把物理屏留在半途。清屏后按目标 front 重建整屏基准。
    // An interrupted scan may leave intermediate pixels. Rebuild the whole baseline from white.
    if (result & EPD_DRAW_EMPTY_LINE_QUEUE) {
        s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
        read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    }
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_clear();
    enum EpdDrawError recovered = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "HD water turn failed (%d), recovery=%d", result, recovered);
    return recovered;
}

static enum EpdDrawError update_display_water_turn_unlocked(EpdiyHighlevelState* hl, EpdRect area,
                                             e0470_turn_dir_t dir) {
    return update_display_reader_turn_unlocked(hl,area,dir,E0470_TURN_FAST_BANDS,
                                               display_reader_text_waveform(), true);
}

// 供数不足时的兜底：把频率退回安全值，整屏白一次，让后面的差分刷有干净参考帧。
// Underrun fallback: drop to the safe clock and wipe the panel white so later differentials have a clean reference.
int display_pclk_mhz(void) { return s_pclk_mhz; }

static void guard_draw_result_unlocked(EpdiyHighlevelState* hl, enum EpdDrawError result) {
    if (!(result & EPD_DRAW_EMPTY_LINE_QUEUE)) return;
    display_main_transition_cancel();
    s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
    read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_poweron();
    epd_clear();
    // 清物理屏后仅重置旧帧基准，保留目标页；否则局部刷新会留下整页白屏。
    // Reset only the old-frame baseline after clearing; preserving the target prevents blank pages after partial updates.
    enum EpdDrawError recovered = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);

    s_main_fault = recovered != EPD_DRAW_SUCCESS;

    if (recovered != EPD_DRAW_SUCCESS) ESP_LOGW(TAG, "underrun recovery failed (%d)", recovered);
    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "line queue underrun, pclk back to %d MHz, recovery=%d", DISPLAY_PCLK_SAFE_MHZ, recovered);
}

#ifdef KIIKO_LOCAL_LATENCY
int64_t local_display_elapsed_us;
#define LATENCY_DISPLAY_BEGIN() const int64_t local_display_start=esp_timer_get_time()
#define LATENCY_DISPLAY_END() (local_display_elapsed_us+=esp_timer_get_time()-local_display_start)
#else
#define LATENCY_DISPLAY_BEGIN() do {} while(0)
#define LATENCY_DISPLAY_END() do {} while(0)
#endif

// 连续相位全部完成后，back已是真实黑白画面；不因尚未补灰阶而多做一次整屏GC16。
// Once continuous phases finish, back is the real binary frame; pending gray restoration alone does not require full GC16.
static bool display_needs_full(void) { return s_full_refresh_requested; }

// 统一硬件出口，递归调用也必须覆盖整个扫描过程。/ Guard complete scans, including recursive fallback paths.
enum EpdDrawError update_display_mode(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_mode_unlocked(hl, mode);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_mode_diff(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_mode_diff_unlocked(hl, mode);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_fast_page(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_fast_page_unlocked(hl);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_from_white_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_from_white_with_unlocked(hl, waveform, mode);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_from_white(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_from_white_unlocked(hl);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_white(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    s_full_refresh_requested = false;
    enum EpdDrawError result = update_display_white_unlocked(hl);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_full(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = update_display_full_unlocked(hl);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 屏幕修复的遍数与单帧时长：遍数是盲刷黑/白走几轮，越多越彻底、整段也越久。
// Panel repair passes and per-frame time: the count is how many black/white rounds the blind drive
// walks -- more is more thorough and takes longer.
#define DISPLAY_REPAIR_CYCLES 6
#define DISPLAY_REPAIR_TIME 15
// 掉电保持时长：够面板把停在半帧的像素放掉，又不至于让用户等。
// How long the rails stay down: enough for pixels stuck mid-frame to let go, short enough to wait.
#define DISPLAY_REPAIR_OFF_MS 400

// 面板修复：整屏盲驱动，不看 framebuffer。刷新中途断电会让面板停在半帧状态，而这里所有常规
// 刷新都是差分的（只重写与 RAM 上一帧不同的像素与相位），停在半路的那些行永远轮不到重写——
// 现象就是怎么刷新都留着一道条纹。这条路把每一行按同一电平重新驱动几轮，最后停在白色。
// Panel repair: a blind full-screen drive that ignores the framebuffer. A power cut in the middle of
// a refresh leaves the panel stuck mid-frame, and every ordinary path here is differential -- it
// rewrites only what differs from the RAM frame -- so those rows are never driven again and the
// stripe survives every refresh. This drives every row to the same level for several rounds and ends
// on white.
enum EpdDrawError display_panel_repair(EpdiyHighlevelState* hl) {
    if (!hl || !hl->front_fb || !hl->back_fb) return EPD_DRAW_INVALID_CROP;
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    continuous_du_reset();
    s_full_refresh_requested = false;
    display_main_transition_cancel();
    // 先真掉一次电：VCOM/VGH/VGL 重新建立，停在半路的像素失去保持电压。
    // One real power cycle first: VCOM/VGH/VGL are rebuilt and pixels stuck mid-frame lose their hold.
    epd_poweroff();
    vTaskDelay(pdMS_TO_TICKS(DISPLAY_REPAIR_OFF_MS));
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_poweron();
    // 盲刷黑/白：与 framebuffer 无关；每轮之间让出 CPU，整段要几秒。
    // Blind black/white drive, independent of the framebuffer; the CPU is released between rounds
    // because the whole pass takes seconds.
    const EpdRect area = epd_full_screen();
    for (int cycle = 0; cycle < DISPLAY_REPAIR_CYCLES; ++cycle) {
        for (int i = 0; i < 10; ++i) epd_push_pixels(area, DISPLAY_REPAIR_TIME, 0);
        for (int i = 0; i < 13; ++i) epd_push_pixels(area, DISPLAY_REPAIR_TIME, 1);
        for (int i = 0; i < 3; ++i) epd_push_pixels(area, DISPLAY_REPAIR_TIME, 2);
        vTaskDelay(1);
    }
    // 面板刚被盲刷成白：把「面板显示的是白」这件事也写进基准，然后整屏推一次当前画面，连底栏
    // 一起推回去。这里不能用 epd_hl_set_all_white()——它清的是绘制缓冲（页面画在 front_fb 上），
    // 会把用户正看的那一页擦掉；修复只该动基准，画面由这一记整屏刷新重新落到面板上。
    // The blind drive left the panel white: the baseline is told so, and one full update pushes the
    // current frame -- navigation bar included -- back onto it. epd_hl_set_all_white() must not be
    // used here: it clears the *drawing* buffer (pages draw into front_fb) and would wipe the page
    // the user is looking at. The repair touches the baseline only; this full update re-lands the
    // frame on the panel.
    // 直接走受锁保护的整屏白底出口，包含底栏；不能被主页裁剪拦截，也不再重复推页。
    // Use the locked full-frame white-baseline path including navigation, without a main-page crop or duplicate page push.
    enum EpdDrawError result = update_display_from_white_with_unlocked(hl, &E0470_WAVEFORM, MODE_GC16);
    if (result != EPD_DRAW_SUCCESS) result = main_recover(hl, result);
    s_main_fault = result != EPD_DRAW_SUCCESS;
    if (s_main_fault) s_full_refresh_requested = true;
    rails_keepalive();
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_image_gray(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    s_full_refresh_requested = false;
    enum EpdDrawError result = update_display_image_gray_unlocked(hl);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_with_unlocked(hl, waveform, mode);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_area_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_area_with_unlocked(hl, waveform, mode, area);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_area_diff_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_area_diff_with_unlocked(hl, waveform, mode, area);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_click_feedback(EpdiyHighlevelState* hl,EpdRect area) {
    LATENCY_DISPLAY_BEGIN();
    bool held=pico_online_display_begin();
    // 控件只扫自身；显示成功后还原未消费的主页许可，不缓存或回放页面像素。
    // Scan only the control, then restore the unused main permission without caching or replaying page pixels.
    const void* owner=s_main_armed;
    bool shelf=s_main_shelf_page,exit=s_main_shelf_exit,changing=s_main_changing_page;
    EpdRect bands[3];memcpy(bands,s_main_bands,sizeof(bands));
    unsigned count=s_main_band_count;
    bool full=display_needs_full(),restore=owner&&!s_main_fault&&!full;
    display_main_transition_disarm();
    enum EpdDrawError result=full?update_display_full_unlocked(hl):
        update_display_area_diff_with_unlocked(hl,&E0470_FOLLOW_WAVEFORM,MODE_DU,area);
    if(restore&&result==EPD_DRAW_SUCCESS&&!s_main_fault) {
        s_main_armed=owner;s_main_shelf_page=shelf;s_main_shelf_exit=exit;
        s_main_changing_page=changing;s_main_band_count=count;memcpy(s_main_bands,bands,sizeof(bands));
    }
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_area_full_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_area_full_with_unlocked(hl, waveform, mode, area);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 防泛白（不整屏全刷）：用全像素 GL16 把当前帧重推一遍。GL16 裁剪表里只有未变化白底吃
// 1 帧 15→15 白推；黑字/中灰像素会先短暂变浅（0→0 是 11 帧擦白 + 13 帧压黑），约 0.27s 内
// 回到原灰阶；没有整屏黑白全刷。用来抑制同一画面久置后白底慢慢发灰、字边发暗（用户反馈阅读页/
// 票根久置反黑，但不接受为此做整屏 GC16 全刷）。
// Anti-fade without a full flash: re-drive the current frame with full-pixel GL16. In the trimmed
// GL16 table only unchanged white gets one 15->15 white push; black/mid-gray pixels briefly lighten
// (0->0 is 11 erase + 13 darken frames) and return to their gray within ~0.27 s, with no
// whole-screen black/white flash. It suppresses the slow gray/dark drift of a static page (reported
// for the reader and ticket lock, where a periodic GC16 flash was rejected).
enum EpdDrawError update_display_anti_fade(EpdiyHighlevelState* hl) {
    const EpdRect area = {0, 0, epd_rotated_display_width(), epd_rotated_display_height()};
    // 直接走全像素 GL16 出口：即使队列里有待处理的全刷请求也不改走整屏 GC16（那会闪屏）。
    // Drive the full-pixel GL16 path directly so a pending full-refresh request cannot turn this
    // into a whole-screen GC16 flash.
    bool held = pico_online_display_begin();
    enum EpdDrawError result = update_display_area_full_with_unlocked(hl, &E0470_WAVEFORM, MODE_GL16, area);
    pico_online_display_end(held);
    return result;
}

enum EpdDrawError update_display_water_turn(EpdiyHighlevelState* hl, EpdRect area,
                                             e0470_turn_dir_t dir) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_water_turn_unlocked(hl, area, dir);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 水波纹·高清：在 rc100 揭页引擎上按「标定脉宽 + 加密条带」驱动。与「水波纹·快刷」的区别：
//  - 快刷：rc100 FAST 扫描 + reader 文字灰阶波形 + 8 带 + 11.09ms/拍（44 拍，约 488ms）；
//  - 高清：FULL 标定扫描（11090us/帧，脉宽与 GL16 表一致）+ 普通·高清同一张 E0470_WAVEFORM
//    GL16 表 + 最多 32 带 + 默认 12ms/拍（68 拍，约 816ms）——每相脉宽回到校准值，抗锯齿中灰
//    推得准（字体边缘更细），同时用更长的动画换更细的揭页前沿；仍单次推屏、结束提交基准，
//    不追加第二遍定稿。补白仍在其后追加。
// HD water drives rc100's ripple engine with calibrated pulse widths and denser bands. Fast water
// keeps rc100's FAST scan, reader text waveform, 8 bands and 11.09 ms ticks (44 ticks, ~488 ms).
// HD uses the FULL calibrated scan (11090 us/frame, matching the GL16 table), the same
// E0470_WAVEFORM GL16 table as ordinary HD, up to 32 bands and the default 12 ms tick (68 ticks,
// ~816 ms): calibrated pulses make the antialiased mid-grays land correctly (finer glyph edges)
// while the longer animation buys a finer reveal front. It is still a single pass with a committed
// baseline and no second settle pass; the white settle is still appended.
enum EpdDrawError update_display_water_turn_hd(EpdiyHighlevelState* hl, EpdRect area,
                                                e0470_turn_dir_t dir) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl)
        : update_display_hd_water_unlocked(hl, area, dir);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 保留侧滑返回的方向和系统灰阶；其余刷新恢复原rc96。
// Keep directional system-gray edge returns; restore the remaining rc96 presentation path.
enum EpdDrawError update_display_main_turn(EpdiyHighlevelState* hl,EpdRect area,e0470_turn_dir_t dir) {
    LATENCY_DISPLAY_BEGIN();
    bool held=pico_online_display_begin();
    const int prior_tick=e0470_page_turn_tick_us();
    e0470_page_turn_set_tick_us(E0470_TURN_FAST_TICK_US);
    enum EpdDrawError result=display_needs_full()?update_display_full_unlocked(hl):
        update_display_reader_turn_unlocked(hl,area,dir,E0470_TURN_FAST_BANDS,
                                            display_main_ui_waveform(), true);
    e0470_page_turn_set_tick_us(prior_tick);
    pico_online_display_end(held);LATENCY_DISPLAY_END();return result;
}

// 速读黑白（rc100 算法，普通翻页的变体）：把目标页正文按 50% 阈值改成纯黑白，
// 再用原厂完整 DU 推屏一次（20 相、全速时钟，不叠加 8 帧跟随或水波纹节拍）。
// 抗锯齿边在这一档变成纯黑白，用画面层次换最快翻页；其余档位不受影响。
// Fast BW (the rc100 algorithm, an ordinary-turn variant): threshold the target page body to pure
// black/white at 50%, then push once with the vendor's complete DU (20 phases on the full scan
// clock, without 8-frame FOLLOW or ripple tick padding). Antialiased edges become black/white in
// this step, trading tone for the fastest turn; every other step is unaffected.
enum EpdDrawError update_display_text_turn(EpdiyHighlevelState* hl,EpdRect area,e0470_turn_dir_t dir) {
    (void)dir;
    // 防御：本出口只服务「普通·快刷」(effect 0)；其他档位仍走普通 GL16 差分。
    // Defensive: this outlet only serves Fast ordinary (effect 0); other steps keep plain GL16 diff.
    if (app_settings_reader_turn_effect() != 0)
        return update_display_area_diff_with(hl,display_main_gray_waveform(),MODE_GL16,area);
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = EPD_DRAW_SUCCESS;
    if (display_needs_full()) result = update_display_full_unlocked(hl);
    else if (main_before_update(hl, &result)) { /* 全局恢复优先 / Global recovery takes priority. */ }
    else if (!display_reader_fast_text_prepare(hl, area))
        result = update_display_area_diff_with_unlocked(hl, display_main_gray_waveform(), MODE_GL16, area);
    else {
        const EpdWaveform* waveform = display_reader_fast_text_waveform();
        use_scan_for(waveform, MODE_DU);
        epd_lcd_set_prefill_lines(127);
        epd_poweron();
        epd_hl_waveform(hl, waveform);
        result = epd_hl_update_area(hl, MODE_DU, 25, area);
        epd_hl_waveform(hl, &E0470_WAVEFORM);
        use_scan_for(&E0470_WAVEFORM, MODE_GL16);
        rails_keepalive();
        if (result == EPD_DRAW_NO_PHASES_AVAILABLE)
            result = update_display_area_diff_with_unlocked(hl, display_main_gray_waveform(), MODE_GL16, area);
        else if (result != EPD_DRAW_SUCCESS) result = main_recover(hl, result);
    }
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 反色模式的翻页补黑：白天清残影已按 rc100 的整体算法（差分 GL16 + 周期全刷）执行，不再走这里；
// 仍保留的只有反色模式（用户要求反色相关保持现有）——反色后物理地面是黑，差分同样不会驱动
// 恒黑的底色，于是上一页的字形抗锯齿残留在黑底上累积。这里的做法把 back 基准上“front 为纯白”
// 的底色像素改成 0，再走一遍 8 帧 FOLLOW/DU 差分，只对纯白底产生 0→15 的“往白一推”脉冲
// （反色扫描后表现为往黑推）；字形像素 back=front，差分里不出现，不会变细、不会变粗。
// Inverted-mode turn black settle only: day-time ghost handling now follows rc100's overall
// algorithm (differential GL16 plus the periodic full refresh) and never comes through here. What
// remains is inverted mode (kept as-is per the user): after inversion the physical ground is black
// and the differential never drives it, so the previous page's antialiased residue piles up there.
// Marking those front==white ground pixels black in the back baseline and running one 8-frame
// FOLLOW/DU pass drives them 0→15 (toward black after the inverted scan); glyph pixels keep
// back == front, so text is neither thinned nor thickened.
static void display_ground_mask(EpdiyHighlevelState* hl, EpdRect area) {
    if (!hl || !hl->front_fb || !hl->back_fb) return;
    const int logical_w = epd_rotated_display_width();
    const int logical_h = epd_rotated_display_height();
    if (logical_w <= 0 || logical_h <= 0) return;
    int x0 = area.x < 0 ? 0 : area.x;
    int y0 = area.y < 0 ? 0 : area.y;
    int x1 = area.x + area.width;
    int y1 = area.y + area.height;
    if (x1 > logical_w) x1 = logical_w;
    if (y1 > logical_h) y1 = logical_h;
    if (x0 >= x1 || y0 >= y1) return;
    // 逻辑区域四角映射到物理缓冲，得到需要扫描的物理范围（与 display_invert_area 同一套映射）。
    // Map the logical corners to the physical buffer with the same rotation used everywhere else.
    const int lx[4] = {x0, x1 - 1, x1 - 1, x0};
    const int ly[4] = {y0, y0, y1 - 1, y1 - 1};
    int px[4], py[4];
    for (int i = 0; i < 4; ++i) {
        int tx = lx[i], ty = ly[i];
        switch (epd_get_rotation()) {
            case EPD_ROT_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                tx = epd_width() - tx - 1;
            } break;
            case EPD_ROT_INVERTED_LANDSCAPE:
                tx = epd_width() - tx - 1;
                ty = epd_height() - ty - 1;
                break;
            case EPD_ROT_INVERTED_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                ty = epd_height() - ty - 1;
            } break;
            default: break;
        }
        px[i] = tx;
        py[i] = ty;
    }
    int bx0 = px[0], bx1 = px[0], by0 = py[0], by1 = py[0];
    for (int i = 1; i < 4; ++i) {
        if (px[i] < bx0) bx0 = px[i];
        if (px[i] > bx1) bx1 = px[i];
        if (py[i] < by0) by0 = py[i];
        if (py[i] > by1) by1 = py[i];
    }
    const int stride = epd_width() / 2;
    for (int physical_y = by0; physical_y <= by1; ++physical_y) {
        const uint8_t* frow = hl->front_fb + (size_t)stride * physical_y;
        uint8_t* brow = hl->back_fb + (size_t)stride * physical_y;
        for (int physical_x = bx0; physical_x <= bx1; ++physical_x) {
            int llx, lly;
            switch (epd_get_rotation()) {
                case EPD_ROT_PORTRAIT: llx = physical_y; lly = epd_width() - physical_x - 1; break;
                case EPD_ROT_INVERTED_LANDSCAPE:
                    llx = epd_width() - physical_x - 1; lly = epd_height() - physical_y - 1; break;
                case EPD_ROT_INVERTED_PORTRAIT:
                    llx = epd_height() - physical_y - 1; lly = physical_x; break;
                default: llx = physical_x; lly = physical_y; break;
            }
            if (llx < x0 || llx >= x1 || lly < y0 || lly >= y1) continue;
            const uint8_t raw = frow[physical_x >> 1];
            const uint8_t value = (physical_x & 1) ? (raw >> 4) : (raw & 0x0F);
            // 只有 0xF（纯白底）才补黑；0xE 可能已经是字形抗锯齿边缘，碰了字会变细/变色。
            // Only pure-white ground (0xF) is re-driven; 0xE may already be a glyph AA fringe,
            // and touching it would thin or tint the text.
            const uint8_t target = value == 0x0F ? 0x00 : value;
            uint8_t cur = brow[physical_x >> 1];
            if (physical_x & 1) cur = (uint8_t)((cur & 0x0F) | (target << 4));
            else cur = (uint8_t)((cur & 0xF0) | target);
            brow[physical_x >> 1] = cur;
        }
    }
}

// 最早版本的地面定稿：掩码后走标准 8 帧 FOLLOW/DU（满幅迁移往白/往黑各推 8 拍）。
// 白天清残影已按 rc100 整体替换，这里只服务反色模式的补黑；反色行为按用户要求保持现状，
// 不改算法、不改时序（仍由 present 内立即调用）。
// Earliest ground settle: mask first, then the standard 8-frame FOLLOW/DU pass (8 pushes for a
// full travel). Day-time ghost handling was replaced by rc100's algorithm as a whole, so this now
// only serves inverted-mode black settle, which the user asked to keep unchanged.
static void display_ground_settle(EpdiyHighlevelState* hl, EpdRect area) {
    display_ground_mask(hl, area);
    (void)update_display_area_diff_with(hl, &E0470_FOLLOW_WAVEFORM, MODE_DU, area);
}

// 深色模式补黑：只驱动黑底，字形和抗锯齿边保持不动。
// Dark-mode turn black settle: drive only the black ground, never glyphs or AA fringes.
void display_black_settle(EpdiyHighlevelState* hl, EpdRect area) {
    if (!epd_get_inverted()) return;
    display_ground_settle(hl, area);
}

// 白天模式整片补白（旧路径，保留兜底/对照）：同一个地面掩码只把纯白底再往白推一次，紧跟在
// 翻页那一次推屏之后，与翻页同一次 present 内完成。present 现在改调定向版
// display_white_settle_ink，只补上一页有墨的像素，不再无条件整片推白。
// Day-mode whole-ground white settle (legacy path, kept as a fallback/reference): the same ground
// mask pushes the pure-white ground once more immediately after the turn push, inside the same
// present(). present() now calls the targeted display_white_settle_ink instead, so only
// previous-page ink pixels are re-driven.
void display_white_settle(EpdiyHighlevelState* hl, EpdRect area) {
    if (epd_get_inverted()) return;
    display_ground_settle(hl, area);
}

// 定向补白：只把「上一页有墨、这一页已经纯白」的像素在 back 基准里改成 0，再走一次 8 帧
// FOLLOW/DU，让这些像素各自完成一次 0→15 的满幅往白迁移（8 拍）。与 display_ground_mask 的
// 区别是：不再对整片「本来就是白」的地面做全幅推白——每页那 80–90% 的纯白像素不再被额外过驱动，
// 只有旧字迹变白的像素补一次；页面本来就白、上一页也没墨的像素保持 back==front，不进差分。
// old_ink 是按 area 局部逻辑坐标打包的 1bpp 掩码（stride=(area.width+7)/8，每字节高位在前），
// 旋转映射与 display_ground_mask/display_invert_area 同一套；反色模式保持原补黑路径，本函数空操作。
// Targeted white settle: mark only pixels that carried ink on the previous page and are pure white
// now as black in the back baseline, then run one 8-frame FOLLOW/DU pass so exactly those pixels
// travel 0->15 (8 white pushes). Unlike display_ground_mask this never re-drives the whole
// already-white ground (80-90% of the body was over-driven on every page); pixels that were white
// before keep back==front and stay out of the differential. old_ink is a 1bpp mask in area-local
// logical coordinates, stride=(width+7)/8, MSB-first; the rotation mapping matches
// display_ground_mask/display_invert_area. No-op when the panel is inverted (that path keeps the
// unchanged black settle).
void display_white_settle_ink(EpdiyHighlevelState* hl, EpdRect area,
                              const uint8_t* old_ink, int stride) {
    if (epd_get_inverted()) return;
    if (!hl || !hl->front_fb || !hl->back_fb || !old_ink || stride <= 0) return;
    const int logical_w = epd_rotated_display_width();
    const int logical_h = epd_rotated_display_height();
    if (logical_w <= 0 || logical_h <= 0) return;
    int x0 = area.x < 0 ? 0 : area.x;
    int y0 = area.y < 0 ? 0 : area.y;
    int x1 = area.x + area.width;
    int y1 = area.y + area.height;
    if (x1 > logical_w) x1 = logical_w;
    if (y1 > logical_h) y1 = logical_h;
    if (x0 >= x1 || y0 >= y1) return;
    // 逻辑区域四角映射到物理缓冲，得到需要扫描的物理范围（与 display_ground_mask 同一套映射）。
    // Map the logical corners to the physical buffer with the same rotation used everywhere else.
    const int lx[4] = {x0, x1 - 1, x1 - 1, x0};
    const int ly[4] = {y0, y0, y1 - 1, y1 - 1};
    int px[4], py[4];
    for (int i = 0; i < 4; ++i) {
        int tx = lx[i], ty = ly[i];
        switch (epd_get_rotation()) {
            case EPD_ROT_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                tx = epd_width() - tx - 1;
            } break;
            case EPD_ROT_INVERTED_LANDSCAPE:
                tx = epd_width() - tx - 1;
                ty = epd_height() - ty - 1;
                break;
            case EPD_ROT_INVERTED_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                ty = epd_height() - ty - 1;
            } break;
            default: break;
        }
        px[i] = tx;
        py[i] = ty;
    }
    int bx0 = px[0], bx1 = px[0], by0 = py[0], by1 = py[0];
    for (int i = 1; i < 4; ++i) {
        if (px[i] < bx0) bx0 = px[i];
        if (px[i] > bx1) bx1 = px[i];
        if (py[i] < by0) by0 = py[i];
        if (py[i] > by1) by1 = py[i];
    }
    const int phys_stride = epd_width() / 2;
    size_t driven = 0;
    for (int physical_y = by0; physical_y <= by1; ++physical_y) {
        const uint8_t* frow = hl->front_fb + (size_t)phys_stride * physical_y;
        uint8_t* brow = hl->back_fb + (size_t)phys_stride * physical_y;
        for (int physical_x = bx0; physical_x <= bx1; ++physical_x) {
            int llx, lly;
            switch (epd_get_rotation()) {
                case EPD_ROT_PORTRAIT: llx = physical_y; lly = epd_width() - physical_x - 1; break;
                case EPD_ROT_INVERTED_LANDSCAPE:
                    llx = epd_width() - physical_x - 1; lly = epd_height() - physical_y - 1; break;
                case EPD_ROT_INVERTED_PORTRAIT:
                    llx = epd_height() - physical_y - 1; lly = physical_x; break;
                default: llx = physical_x; lly = physical_y; break;
            }
            if (llx < x0 || llx >= x1 || lly < y0 || lly >= y1) continue;
            const uint8_t fraw = frow[physical_x >> 1];
            const uint8_t value = (physical_x & 1) ? (fraw >> 4) : (fraw & 0x0F);
            // 掩码只覆盖上一页有墨的像素；front 仍为纯白才补，字形/抗锯齿边照旧保持 back==front。
            // Only previous-page ink pixels whose new value is still pure white are re-driven; glyphs
            // and AA fringes keep back==front.
            uint8_t target = value;
            if (value == 0x0F) {
                const int mx = llx - area.x, my = lly - area.y;
                if (mx >= 0 && my >= 0 && mx < area.width && my < area.height &&
                    (((old_ink[(size_t)my * (size_t)stride + ((size_t)mx >> 3)]) >>
                      (7 - (mx & 7))) & 1u)) {
                    target = 0x00;
                    ++driven;
                }
            }
            uint8_t cur = brow[physical_x >> 1];
            if (physical_x & 1) cur = (uint8_t)((cur & 0x0F) | (target << 4));
            else cur = (uint8_t)((cur & 0xF0) | target);
            brow[physical_x >> 1] = cur;
        }
    }
    ESP_LOGD(TAG, "targeted white settle: %u px of %d x %d area",
             (unsigned)driven, area.width, area.height);
    (void)update_display_area_diff_with(hl, &E0470_FOLLOW_WAVEFORM, MODE_DU, area);
}

void guard_draw_result(EpdiyHighlevelState* hl, enum EpdDrawError result) {    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    guard_draw_result_unlocked(hl, result);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
}
