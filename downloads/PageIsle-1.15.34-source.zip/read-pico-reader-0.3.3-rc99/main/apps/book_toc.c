/* SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 * 中文：目录只呈现章节导航，和书架列表、旧示例菜单完全分离。
 * English: The directory only navigates chapters and shares no shelf or demo-menu rendering.
 * 用户修复：书名与章名统一使用当前系统字体的标题路径；原生字号、整行字体来源和灰阶抗锯齿保持一致，不放大补充点阵。
 * User fix: book/chapter names share the active system title path with native sizes, stable whole-line font selection and gray antialiasing, without enlarged bitmap supplements.
 */
#include "book_toc.h"

#include <stdio.h>
#include <string.h>
#include "book_source.h"
#include "ui_kit.h"
#include "ui_nav.h"

enum { TOC_LEFT = 36, TOC_RIGHT = 648, TOC_ROW_TOP = 252,
       TOC_ROW_STEP = 108, TOC_ROW_HEIGHT = 94 };

// 横屏目录仍是每页 7 条，改成两列四行；app_book 里所有按 BOOK_TOC_ROWS 换算页号的代码因此不变。
// Landscape keeps seven entries per page but lays them out as two columns by four rows, so every
// page calculation in app_book (which divides by BOOK_TOC_ROWS) stays valid.
static bool toc_land(void) { return epd_rotated_display_width() > epd_rotated_display_height(); }
static int toc_w(void) { return epd_rotated_display_width(); }
static int toc_h(void) { return epd_rotated_display_height(); }
static int toc_jdx(void) { return toc_land() ? (toc_w() - 684) / 2 : 0; }
static int toc_jdy(void) { return toc_land() ? (toc_h() - 572) / 2 - 356 : 0; }

int book_toc_pages(size_t chapters) {
    return chapters ? (int)(1 + (chapters - 1) / BOOK_TOC_ROWS) : 1;
}

EpdRect book_toc_row_rect(int row) {
    if (toc_land()) {
        const int col = row & 1, line = row >> 1;
        return (EpdRect){36 + col * 582, 126 + line * 112, 562, 96};
    }
    return (EpdRect){TOC_LEFT, TOC_ROW_TOP + row * TOC_ROW_STEP,
                     TOC_RIGHT - TOC_LEFT, TOC_ROW_HEIGHT};
}

EpdRect book_toc_jump_rect(void) {
    return (EpdRect){44 + toc_jdx(), 356 + toc_jdy(), 596, 572};
}

// 把 EPUB/TXT 中的换行、制表符和控制符收敛为一个空格，防止绘制越过本行。
// Collapse line breaks, tabs and controls from EPUB/TXT to one space so glyphs stay in one row.
static void one_line(char *dst, size_t cap, const char *src) {
    if (!cap) return;
    size_t out = 0;
    bool gap = false;
    for (const unsigned char *p = (const unsigned char *)src; *p && out + 1 < cap;) {
        unsigned char c = *p;
        if (c <= 0x20 || c == 0x7f) { gap = out != 0; ++p; continue; }
        if (gap && out + 2 < cap) dst[out++] = ' ';
        gap = false;
        int bytes = c < 0x80 ? 1 : c >= 0xf0 ? 4 : c >= 0xe0 ? 3 : c >= 0xc0 ? 2 : 1;
        if (out + (size_t)bytes >= cap) break;
        for (int i = 0; i < bytes && *p; ++i) dst[out++] = (char)*p++;
    }
    while (out && dst[out - 1] == ' ') --out;
    dst[out] = 0;
}

static void fit_line(char *text, int px, int width) {
    size_t len = strlen(text);
    bool trimmed = false;
    while (len && (ui_text_fixed_width_px(px, text) > width || len > 96)) {
        do { --len; } while (len && ((unsigned char)text[len] & 0xc0) == 0x80);
        text[len] = 0;
        trimmed = true;
    }
    if (trimmed && len > 3) {
        // Cut a little more before adding the ellipsis so its glyph cannot cross the status area.
        // 添加省略号前预留字形宽度，避免跨过右侧当前章节标记。
        while (len && ui_text_fixed_width_px(px, text) + ui_text_fixed_width_px(px, "…") > width) {
            do { --len; } while (len && ((unsigned char)text[len] & 0xc0) == 0x80);
            text[len] = 0;
        }
        if (len + sizeof("…") <= 160) strcat(text, "…");
    }
}

// 用完整标题固定字体来源，截短后也不因缺字判断改变粗细。/ Keep the full title as the font sample so truncation cannot change the face or weight.
static void toc_title(uint8_t *fb, EpdRect box, int preferred_px, const char *text, uint8_t background) {
    char sample[160], shown[160];
    one_line(sample, sizeof(sample), text);
    memcpy(shown, sample, strlen(sample) + 1);
    int px = ui_text_effective_px(preferred_px);
    if (px > box.height - 2) px = box.height - 2;
    px = ui_text_title_fit(shown, px, box.width, sample);
    ui_text_title_background_vc(fb, box.x, box.y + box.height / 2, px, shown, sample,
                                EPD_DRAW_ALIGN_LEFT, background);
}

int book_toc_hit(uint16_t x, uint16_t y, int page, size_t chapters) {
    if (toc_land()) {
        if (x < 100 && y >= 4 && y < 76) return BOOK_TOC_BACK;
        if (y >= 592 && y < 656) {
            if (x >= 36 && x < 126) return BOOK_TOC_SKIP_PREV;
            if (x >= 134 && x < 244) return BOOK_TOC_PREV;
            if (x >= 410 && x < 520) return BOOK_TOC_NEXT;
            if (x >= 528 && x < 618) return BOOK_TOC_SKIP_NEXT;
            if (x >= 650 && x < 1180) return BOOK_TOC_JUMP;
        }
    } else {
        if (x < 100 && y >= 76 && y < 151) return BOOK_TOC_BACK;
        if (y >= 1018 && y < 1086) {
            if (x >= 36 && x < 136) return BOOK_TOC_SKIP_PREV;
            if (x >= 146 && x < 258) return BOOK_TOC_PREV;
            if (x >= 426 && x < 538) return BOOK_TOC_NEXT;
            if (x >= 548 && x < 648) return BOOK_TOC_SKIP_NEXT;
        }
        if (x >= 36 && x < 648 && y >= 1100 && y < 1174) return BOOK_TOC_JUMP;
    }
    for (int row = 0; row < BOOK_TOC_ROWS; ++row) {
        size_t index = (size_t)page * BOOK_TOC_ROWS + row;
        if (index >= chapters) break;
        if (ui_rect_hit(book_toc_row_rect(row), x, y)) return (int)index;
    }
    return -1;
}

int book_toc_jump_hit(uint16_t x, uint16_t y) {
    const int dx = toc_jdx(), dy = toc_jdy();
    if (x >= 75 + dx && x < 330 + dx && y >= 850 + dy && y < 907 + dy)
        return BOOK_TOC_JUMP_CANCEL;
    if (x >= 354 + dx && x < 609 + dx && y >= 850 + dy && y < 907 + dy)
        return BOOK_TOC_JUMP_CONFIRM;
    if (x >= 75 + dx && x < 609 + dx && y >= 600 + dy && y < 711 + dy)
        return BOOK_TOC_JUMP_TRACK;
    return -1;
}

int book_toc_jump_percent(uint16_t x) {
    const int dx = toc_jdx();
    if ((int)x <= 92 + dx) return 0;
    if ((int)x >= 592 + dx) return 100;
    return ((int)x - 92 - dx) * 100 / 500;
}

int book_toc_page_from_percent(int percent, int pages) {
    if (pages <= 1 || percent <= 0) return 0;
    if (percent >= 100) return pages - 1;
    int page = (percent * pages + 99) / 100 - 1;
    return page < pages ? page : pages - 1;
}

// 双像素深色轮廓让白色卡片在墨水屏上仍有清晰边界。/ Dark two-pixel outlines keep white cards legible on e-paper.
static void toc_border(uint8_t *fb, EpdRect rect, int radius, bool selected) {
    uint8_t gray = selected ? 0x38 : 0x60;
    ui_draw_round_rect(fb, rect, radius, gray);
    ui_draw_round_rect(fb, (EpdRect){rect.x + 1, rect.y + 1, rect.width - 2, rect.height - 2},
                       radius - 1, gray);
}

static void toc_pill(uint8_t *fb, EpdRect rect, const char *text, int px, bool selected) {
    ui_fill_round_rect(fb, rect, 20, selected ? 0xc0 : UI_GRAY_WHITE);
    toc_border(fb, rect, 20, selected);
    char label[160];
    one_line(label, sizeof(label), text);
    fit_line(label, px, rect.width - 16);
    ui_text_box(fb,ui_inset_rect(rect,8),px,label,EPD_DRAW_ALIGN_CENTER,false);
}

// 二级/三级目录缩进：层级越深越靠右，条目变窄；一级保持原布局。
// Second/third level entries are indented and narrowed; level 1 keeps the original layout.
static int toc_level_indent(size_t index) {
    const uint8_t level = book_navigation_level(index);
    return level > 1 ? ((level > 3 ? 3 : level) - 1) * 24 : 0;
}

void book_toc_render(uint8_t *fb, const char *book_title, size_t chapters,
                     size_t current, int page, const char *message) {
    ui_clear_page(fb);
    const bool land = toc_land();
    if (land) {
        ui_fill_rect_fast((EpdRect){0, 0, toc_w(), toc_h()}, 0xe0, fb);
        ui_nav_back(fb, 36, 12);
        ui_text_box(fb,(EpdRect){toc_w()/2-150,4,300,56},34,"目录",EPD_DRAW_ALIGN_CENTER,false);
    } else {
        ui_fill_rect_fast((EpdRect){0, 0, UI_LOCK_WIDTH, UI_LOCK_HEIGHT}, 0xe0, fb);
        ui_nav_status(fb);
        ui_nav_back(fb, TOC_LEFT, 79);
        ui_text_box(fb,(EpdRect){120,79,444,72},34,"目录",EPD_DRAW_ALIGN_CENTER,false);
    }

    char title[160];
    one_line(title, sizeof(title), book_title ? book_title : "");
    if (!title[0]) strcpy(title, "当前书籍");
    char total[48];
    snprintf(total, sizeof(total), "%u 节", (unsigned)chapters);
    if (land) {
        toc_title(fb, (EpdRect){120,66,toc_w()-480,42}, 22, title, 0xe0);
        ui_text_box(fb,(EpdRect){toc_w()-260,66,200,42},22,total,EPD_DRAW_ALIGN_RIGHT,false);
        ui_fill_rect_fast((EpdRect){36, 114, toc_w() - 72, 2}, 0x68, fb);
    } else {
        toc_title(fb, (EpdRect){TOC_LEFT,160,420,48}, 23, title, 0xe0);
        ui_text_box(fb,(EpdRect){482,160,166,48},23,total,EPD_DRAW_ALIGN_RIGHT,false);
        ui_fill_rect_fast((EpdRect){TOC_LEFT, 213, TOC_RIGHT - TOC_LEFT, 2}, 0x68, fb);
    }

    if (message && *message) {
        char info[160];one_line(info,sizeof(info),message);fit_line(info,ui_text_effective_px(23),540);
        ui_text_box(fb,(EpdRect){72,408,540,72},23,info,EPD_DRAW_ALIGN_CENTER,false);
    } else if (!chapters) {
        ui_text_box(fb,(EpdRect){72,408,540,72},25,"这本书没有可用目录",EPD_DRAW_ALIGN_CENTER,false);
    } else {
        for (int row = 0; row < BOOK_TOC_ROWS; ++row) {
            size_t index = (size_t)page * BOOK_TOC_ROWS + row;
            if (index >= chapters) break;
            size_t source_index = book_navigation_chapter(index);
            if (source_index == SIZE_MAX) break;
            EpdRect r = book_toc_row_rect(row);
            bool selected = index == current;
            ui_fill_round_rect(fb, r, 20, selected ? 0xc0 : UI_GRAY_WHITE);
            toc_border(fb, r, 20, selected);
            char number[16]; snprintf(number, sizeof(number), "%02u", (unsigned)index + 1);
            ui_text_box(fb,(EpdRect){r.x+14,r.y+11,58,72},21,number,EPD_DRAW_ALIGN_LEFT,false);
            char raw[160] = "", label[160];
            if (book_navigation_title(index, raw, sizeof(raw)) != ESP_OK || !raw[0])
                snprintf(raw, sizeof(raw), "第 %u 节", (unsigned)index + 1);
            char spine_default[32];
            snprintf(spine_default, sizeof(spine_default), "第 %u 节", (unsigned)source_index + 1);
            if (strcmp(raw, spine_default) == 0)
                snprintf(raw, sizeof(raw), "第 %u 节", (unsigned)index + 1);
            one_line(label, sizeof(label), raw);
            if (!label[0]) snprintf(label, sizeof(label), "第 %u 节", (unsigned)index + 1);
            const int level_indent = toc_level_indent(index);
            int title_w = (selected ? r.width - 192 : r.width - 117) - level_indent;
            if (title_w < 90) title_w = 90;
            toc_title(fb, (EpdRect){r.x+79+level_indent,r.y+9,title_w,r.height-20}, 30, label,
                       selected ? 0xc0 : UI_GRAY_WHITE);
            if (selected)
                ui_text_box(fb,(EpdRect){r.x+r.width-93,r.y+11,71,72},24,"当前",EPD_DRAW_ALIGN_RIGHT,false);
        }
    }
    const int pages = book_toc_pages(chapters);
    char position[32]; snprintf(position, sizeof(position), "%02d / %02d", page + 1, pages);
    char percent[24];
    snprintf(percent, sizeof(percent), "%d%%  ›", (page + 1) * 100 / pages);
    if (land) {
        toc_pill(fb, (EpdRect){36, 592, 90, 64}, "« 10页", 22, false);
        toc_pill(fb, (EpdRect){134, 592, 110, 64}, "‹ 上页", 24, false);
        toc_pill(fb, (EpdRect){252, 592, 150, 64}, position, 24, true);
        toc_pill(fb, (EpdRect){410, 592, 110, 64}, "下页 ›", 24, false);
        toc_pill(fb, (EpdRect){528, 592, 90, 64}, "10页 »", 22, false);
        EpdRect jump = {650, 592, 530, 64};
        ui_fill_round_rect(fb, jump, 20, UI_GRAY_WHITE);
        toc_border(fb, jump, 20, false);
        ui_text_box(fb,(EpdRect){676,600,300,48},26,"按百分比跳转",EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){976,600,180,48},26,percent,EPD_DRAW_ALIGN_RIGHT,false);
        return;
    }
    toc_pill(fb, (EpdRect){36, 1018, 100, 68}, "« 10页", 24, false);
    toc_pill(fb, (EpdRect){146, 1018, 112, 68}, "‹ 上页", 26, false);
    toc_pill(fb, (EpdRect){268, 1018, 148, 68}, position, 25, true);
    toc_pill(fb, (EpdRect){426, 1018, 112, 68}, "下页 ›", 26, false);
    toc_pill(fb, (EpdRect){548, 1018, 100, 68}, "10页 »", 24, false);
    EpdRect jump = {36, 1100, 612, 74};
    ui_fill_round_rect(fb, jump, 21, UI_GRAY_WHITE);
    toc_border(fb, jump, 21, false);
    ui_text_box(fb,(EpdRect){58,1109,388,56},28,"按百分比跳转",EPD_DRAW_ALIGN_LEFT,false);
    ui_text_box(fb,(EpdRect){468,1109,158,56},28,percent,EPD_DRAW_ALIGN_RIGHT,false);
}

void book_toc_render_jump(uint8_t *fb, size_t chapters, int percent) {
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;
    const int dx = toc_jdx(), dy = toc_jdy();
    EpdRect card = {44 + dx, 356 + dy, 596, 572};
    ui_fill_round_rect(fb, card, 30, UI_GRAY_WHITE);
    toc_border(fb, card, 30, true);
    ui_text_box(fb,(EpdRect){(342 + dx)-250,393 + dy,500,44},32,"跳到目录位置",EPD_DRAW_ALIGN_CENTER,false);
    ui_text_box(fb,(EpdRect){(342 + dx)-250,450 + dy,500,44},24,"选择百分比，先预览目标位置",
                  EPD_DRAW_ALIGN_CENTER, false);
    char value[24]; snprintf(value, sizeof(value), "%d%%", percent);
    ui_text_fixed(fb, 342 + dx, 515 + dy, 55, value,EPD_DRAW_ALIGN_CENTER,false);
    ui_fill_round_rect(fb, (EpdRect){92 + dx, 637 + dy, 500, 8}, 4, 0x80);
    int width = 500 * percent / 100;
    if (width) ui_fill_round_rect(fb, (EpdRect){92 + dx, 637 + dy, width, 8}, 4, 0x40);
    int knob = 92 + dx + width;
    epd_fill_circle(knob, 641 + dy, 25, UI_GRAY_WHITE, fb);
    epd_draw_circle(knob, 641 + dy, 25, 0x40, fb);
    static const char *ticks[] = {"0", "25", "50", "75", "100%"};
    for (int i = 0; i < 5; ++i)
        ui_text_box(fb,(EpdRect){(92 + dx + i * 125)-250,678 + dy,500,44},24,ticks[i],EPD_DRAW_ALIGN_CENTER,false);
    EpdRect target_card = {75 + dx, 740 + dy, 534, 84};
    ui_fill_round_rect(fb, target_card, 19, 0xe8);
    toc_border(fb, target_card, 19, false);
    ui_text_box(fb,(EpdRect){99 + dx,747 + dy,486,30},23,"目标位置",EPD_DRAW_ALIGN_LEFT,false);
    int pages = book_toc_pages(chapters);
    int target = book_toc_page_from_percent(percent, pages);
    size_t first = (size_t)target * BOOK_TOC_ROWS + 1;
    size_t last = first + BOOK_TOC_ROWS - 1;
    if (last > chapters) last = chapters;
    char summary[160];
    if (chapters)
        snprintf(summary, sizeof(summary), "约第 %d / %d 页 · 第 %u～%u 节",
                 target + 1, pages, (unsigned)first, (unsigned)last);
    else snprintf(summary, sizeof(summary), "这本书没有可用目录");
    fit_line(summary, 25, 486);
    ui_text_box(fb,(EpdRect){99 + dx,783 + dy,486,34},25,summary,EPD_DRAW_ALIGN_LEFT,false);
    toc_pill(fb, (EpdRect){75 + dx, 850 + dy, 255, 57}, "取消", 26, false);
    ui_fill_round_rect(fb, (EpdRect){354 + dx, 850 + dy, 255, 57}, 20, 0x40);
    ui_text_box(fb,(EpdRect){362 + dx,858 + dy,239,41},26,"跳转",EPD_DRAW_ALIGN_CENTER,true);
}
