/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 墨水屏刷新、HV 轨空闲超时、pclk 回退。
 *
 * EPD present, HV-rail idle timeout, and pclk fallback.
 */

#pragma once

#include <stdint.h>
#include <stdbool.h>

#include "epd_highlevel.h"
#include "epdiy.h"
#include "e0470_page_turn.h"
#include "read_pico_epd_timing.h"

#ifdef __cplusplus
extern "C" {
#endif

// LCD 像素时钟：只决定有效像素段占一行的多少，剩下的由行结束段补足——行周期被锁在
// 波形标定的帧周期上，所以调 pclk 不会让刷新变快，只影响 DMA 的供数余量。12MHz 是
// epdiy 的保守默认值，18MHz 实测稳定（前提是 PSRAM 跑在 120MHz，80MHz 下 16MHz
// 就喂不满 DMA），开机锁 18MHz 留足余量。
// LCD pixel clock: it only sets how much of the line the active pixels occupy;
// the line-end pad fills the rest. The line period is locked to the waveform
// frame time, so pclk does not make refresh faster — it only changes DMA slack.
// 12 MHz is epdiy's conservative default; 18 MHz is stable here when PSRAM runs
// at 120 MHz (at 80 MHz even 16 MHz starves DMA). Boot locks 18 MHz for margin.
#define DISPLAY_PCLK_DEFAULT_MHZ 18
// 出现供数不足（EPD_DRAW_EMPTY_LINE_QUEUE）时退回这个确定安全的频率。
// Fall back to this known-safe clock on underrun (EPD_DRAW_EMPTY_LINE_QUEUE).
#define DISPLAY_PCLK_SAFE_MHZ READ_PICO_EPD_PCLK_MIN_MHZ
// 工程页上还能继续往上试。行消隐与 CKV 宽度会跟着频率重解。
// The lab page can still step higher. Line blanking and CKV width re-solve with the clock.
#define DISPLAY_PCLK_MIN_MHZ READ_PICO_EPD_PCLK_MIN_MHZ
#define DISPLAY_PCLK_MAX_MHZ READ_PICO_EPD_PCLK_MAX_MHZ
#define DISPLAY_PCLK_STEP_MHZ 1

// ---- 浅色模式显示期维护 / Light-mode display maintenance ----
// 1.15.23：默认停用 1.15.22 新增的「活动期全像素 GL16 重推」。数值复盘（37 相裁剪 GL16 表）：
// 未变化的等灰对不是保持——白底 15→15 只吃 1 帧白推（清不掉旧墨），黑字 0→0 要 11 帧擦白 +
// 13 帧压黑、中灰等灰对 25–31 帧，即每次到点把整帧笔墨像素完整擦掉重写一遍。它既不是真正的
// 清屏复位（清不掉白底黑字残影），又是反复过驱动（1.13.1 白天补白、1.15.18 反复压黑同款教训），
// 在阅读/主页连续使用时反而加重残影。
// 旧路径保留可回滚：DISPLAY_LIGHT_ACTIVITY_ENABLE=1 恢复 1.15.22 行为（仅供 A/B，不建议出货）。
// 1.15.23: the 1.15.22 "full-pixel GL16 re-drive during active use" is disabled by default.
// Numeric review of the 37-phase trimmed GL16 table: unchanged equal pairs are NOT held -- white
// 15->15 gets only 1 white push (cannot clear old ink), black 0->0 runs 11 erase + 13 darken frames,
// mid-gray equal pairs take 25-31 frames. In other words every due tick erased and rewrote every ink
// pixel, which is neither a real cleanup (white-ground black residue survives) nor cheap: it
// repeatedly over-drives the panel (same lesson as the 1.13.1 daytime white settle and the 1.15.18
// repeated darken sweep) and made ghosting worse during continuous reading/home use.
// The old path stays behind a rollback switch: DISPLAY_LIGHT_ACTIVITY_ENABLE=1 restores the 1.15.22
// behaviour (A/B only, not for release).
#define DISPLAY_LIGHT_ACTIVITY_ENABLE 0
// 以下阈值只在 DISPLAY_LIGHT_ACTIVITY_ENABLE=1 时生效：页级输出数 / 局部输出数 / 静置毫秒数，任一
// 到点就整帧重推；GC16_EVERY>0 时每第 N 次升级成全像素 GC16。单个 0 = 该条件停用。
// Thresholds below only apply when DISPLAY_LIGHT_ACTIVITY_ENABLE=1: page-level outputs / partial
// outputs / elapsed ms; any due trigger re-drives the whole frame. GC16_EVERY>0 promotes every Nth
// such settle to a full-pixel GC16. A single 0 disables that trigger.
#define DISPLAY_LIGHT_ACTIVITY_PAGE_EVERY 10
#define DISPLAY_LIGHT_ACTIVITY_AREA_EVERY 600
#define DISPLAY_LIGHT_ACTIVITY_INTERVAL_MS 300000
#define DISPLAY_LIGHT_ACTIVITY_GC16_EVERY 5

// 浅色模式低频「真 GC16 清理」：真正的清屏复位（整屏全像素 48 相未裁剪 GC16，每像素完整
// 擦除→重写），专门清掉白底/无色区残留上一屏的黑字或图案，并释放累积残余电荷。与上面的
// GL16 重推不同：它按目标灰阶把每个像素推到过轨再写回，所以白底残影也会被擦掉，代价是一次
// 约 0.46–0.57s 的整屏刷（含底栏），因此频率必须保守。
// 触发（浅色模式专用，反色模式完全不进入）：
//   - 页级输出（面积 ≥ 逻辑画布 50%）自上次真清理以来累计 ≥ PAGE_EVERY 次；或
//   - 距上次真清理 ≥ INTERVAL_MS 且期间至少有 1 次**任意**浅色输出（局部输出也算“使用中”，
//     否则主页停留只有时钟/秒针局部差分时计时永远到不了点）；长时间完全没有输出的空档
//     （休眠/断电）不计入连续使用时长，从下一次输出重新计时，避免久置后第一下就整屏闪。
// 计数器在**任何页级全像素 GC16 成功**后归零（阅读每 15 页清理、主页进入清理等都会归零），
// 因此不会和页面层的周期清理叠加成两次连闪。
// 回滚/对照：CLEANUP_ENABLE=0 一键停用；PAGE_EVERY=0 只留计时；INTERVAL_MS=0 只留计数。
// CLEANUP_DEEP=1 时在 GC16 前追加一次 epd_clear 盲擦白（更深、多约 0.9s，A/B 用）。
// Light-mode low-frequency real-GC16 cleanup: a true panel reset (whole-screen full-pixel GC16 on
// the untrimmed 48-phase table: every pixel runs a complete erase->rewrite cycle) that clears black
// text/artwork residue left on white areas by a previous screen and releases accumulated charge.
// Unlike the GL16 re-drive above it pushes every pixel to the opposite rail before writing the target
// gray, so white-ground ghosts are erased too; the price is one whole-screen refresh (~0.46-0.57 s,
// navigation included), hence the conservative cadence.
// Triggers (light mode only; inverted mode never enters):
//   - page-level outputs (area >= 50% of the logical canvas) since the last real cleanup >= PAGE_EVERY; or
//   - >= INTERVAL_MS since the last real cleanup with at least one ANY light-mode output in between
//     (partial outputs count as "in use", otherwise the timer would never fire while home idles on
//     clock/second-hand diffs). A fully output-free gap (sleep/power-off) is not counted as
//     continuous-use time; the interval restarts from the next output so a long rest never ends in
//     an immediate whole-screen flash.
// Counters reset after ANY successful page-level full-pixel GC16 (reader's periodic page cleanup,
// home entry cleanup, ...), so the display layer never stacks a second flash right after a page-layer
// cleanup. Rollback: CLEANUP_ENABLE=0 disables everything; PAGE_EVERY=0 keeps only the timer;
// INTERVAL_MS=0 keeps only the counter. CLEANUP_DEEP=1 prepends one blind epd_clear white wipe
// (stronger, ~0.9 s extra) for A/B.
#define DISPLAY_LIGHT_CLEANUP_ENABLE 1
#define DISPLAY_LIGHT_CLEANUP_PAGE_EVERY 30
#define DISPLAY_LIGHT_CLEANUP_INTERVAL_MS 600000
#define DISPLAY_LIGHT_CLEANUP_DEEP 0

/// 保留高压轨并释放像素驱动，包括无变化刷新；不增加扫描。/ Retain HV rails and release pixel drive, including no-change updates, without another scan.
void rails_keepalive(void);
void rails_idle_check(int64_t now_ms, bool input_idle);
/// 睡眠/关机前等低优先级断电任务收尾，避免两路同时写 SY7636A。
/// Wait for the low-priority power-off task before sleep/shutdown so no two paths touch SY7636A.
void display_quiet_rails_off(void);

/// 大量文件I/O期间增加扫描预填，调用方离开时恢复。/ Increase scan prefill during bulk file I/O; caller restores on exit.
void display_set_bulk_io(bool active);

/// 请求下一张完成绘制的画面整屏清理一次，用于解锁。/ Clean the next completed frame once after unlock.
void display_request_full_refresh(void);
enum EpdDrawError update_display_mode(EpdiyHighlevelState* hl, enum EpdDrawMode mode);
/// 普通页面切换使用真实差分 GL16；未变化像素不进入 dirty map。
/// True differential GL16 for ordinary page transitions; unchanged pixels stay clean.
enum EpdDrawError update_display_mode_diff(EpdiyHighlevelState* hl, enum EpdDrawMode mode);
/// 系统子页只推最终差分，不因操作计数全刷；显式全刷和故障恢复独立。
/// System children present final differences without count-triggered full output; explicit full and fault recovery are independent.
/// 四主页面固定底栏，仅横条局部更新；普通保留灰阶与内容区整理，快刷用完整黑白表及棋盘格亚克力。
/// All main screens retain navigation with local markers; ordinary uses soft gray differences and periodic body cleanup, fast uses monochrome/checkerboard acrylic.
enum EpdDrawError update_display_fast_page(EpdiyHighlevelState* hl);
/// 为下一次主页面输出启用固定底栏；标记书架切出与真正切页，避免同页重绘播放动画。
/// Arm fixed navigation for the next main-screen output; tag shelf exit and actual navigation so same-page repaints do not animate.
void display_main_transition_arm(const void* owner, bool leaving_shelf, bool changing_page);
/// 系统侧滑用主页灰阶水波纹，独立于阅读文字序列；区域必须是逻辑坐标。
/// System edge returns use main-gray ripple independently of reader text; the area uses logical coordinates.
enum EpdDrawError update_display_main_turn(EpdiyHighlevelState* hl, EpdRect area, e0470_turn_dir_t dir);
/// 当前主页面最多三个横向灰阶条带，其余内容按黑白驱动；无入口许可时忽略。
/// Register at most three horizontal gray bands on the armed main page; other content uses black/white. Ignore without permission.
void display_main_transition_gray_bands(const EpdRect* bands, unsigned count);
/// 书架分页加强白色擦除，保持底栏边界。/ Strengthen shelf-page whitening within the fixed navigation boundary.
void display_main_transition_shelf_page(void);
/// 解除尚未使用的入口许可。/ Disarm unused entry permission.
void display_main_transition_disarm(void);
/// 取消尚未使用的入口；不打断物理波形，无延迟补刷任务。
/// Cancel unused permission without interrupting a physical waveform; no deferred completion exists.
void display_main_transition_cancel(void);
enum EpdDrawError update_display_from_white(EpdiyHighlevelState* hl);
enum EpdDrawError update_display_from_white_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
);
/// 把前缓冲铺白再 GC16 全刷，物理屏回到白底。
/// Paint the front buffer white and GC16 the panel back to white.
enum EpdDrawError update_display_white(EpdiyHighlevelState* hl);
enum EpdDrawError update_display_full(EpdiyHighlevelState* hl);

/// 面板修复：不看 framebuffer 的整屏盲刷，专治刷新中途断电留下的条纹。
/// Panel repair: a blind full-screen drive that ignores the framebuffer, for the stripes a power
/// cut in the middle of a refresh leaves behind.
/// 返回最终整屏输出结果；失败时调用方不能报告成功。/ Return the final full-frame result; callers must not report success on failure.
enum EpdDrawError display_panel_repair(EpdiyHighlevelState* hl);
/// 图片页清除旧光学状态，再驱动完整灰阶。/ Clear the prior optical state and drive the full gray ladder for images.
enum EpdDrawError update_display_image_gray(EpdiyHighlevelState* hl);
enum EpdDrawError update_display_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
);
/// 灰阶图还在屏上时置位：菜单盖上来或离页先刷白，避免从中间灰差分。
/// Set while a gray image is still on panel: wipe to white before the menu or leave so the next update is not a mid-gray differential.
void display_hold_white_exit(bool hold);
bool display_take_white_exit(void);
enum EpdDrawError update_display_area_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
);
/// 动画定稿只驱动真实差异，不强制把区域内所有 GL16 像素重刷。
/// Animation settle drives real differences only instead of forcing every GL16 pixel in the area.
/// 在指定区域驱动全部像素，用于局部定稿和清残影。/ Drive all pixels within an area for local settling and ghost cleanup.
/// 控件局部反馈暂存后续主页刷新入口，不提前消耗其裁剪、灰阶和底栏保护。/ Local control feedback preserves the pending main crop, gray policy and footer protection.
enum EpdDrawError update_display_click_feedback(EpdiyHighlevelState* hl,EpdRect area);
enum EpdDrawError update_display_area_full_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
);
/// 防泛白：全像素 GL16 重推当前帧，未变化白底吃 1 帧 15→15 白推，深色/中灰会短暂变浅
/// 后回原灰阶（约 0.27s），无整屏黑白全刷；抑制静态画面久置后白底发灰/字边发暗。
/// Anti-fade: re-drive the frame with full-pixel GL16; unchanged white gets one 15->15 white push,
/// dark/mid-gray briefly lightens then returns (~0.27 s) with no whole-screen black/white flash,
/// suppressing the slow gray/dark drift of a static page.
enum EpdDrawError update_display_anti_fade(EpdiyHighlevelState* hl);
enum EpdDrawError update_display_area_diff_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
);
/// area始终为旋转后逻辑坐标，勿传物理epd_full_screen。/ area always uses rotated logical coordinates, never physical epd_full_screen.
/// 阅读页可选的真实错相 GL16 翻页；缺相位时回退现有 GL16，失败时恢复基准帧。
/// 纯文字水波纹复用柔和文字灰边，8带节拍不变；缺相回退GL16，扫描失败重建真实基准。
/// Staggered text phases retain eight-band pacing, hold unchanged grays and soften edge transients; missing phases fall back and failures rebuild the baseline.
enum EpdDrawError update_display_water_turn(EpdiyHighlevelState* hl, EpdRect area,
                                             e0470_turn_dir_t dir);
/// 水波纹·高清：rc100 揭页引擎 + 普通·高清校准 GL16 表 + FULL 标定扫描（11090us/帧），
/// 8 带 / 11090us 拍（44 拍，约 0.49s，与快刷同速）；抗锯齿仍按校准脉宽执行，单次推屏。
/// HD water keeps rc100's ripple engine but drives the ordinary-HD calibrated GL16 table on the
/// FULL calibrated scan (11090 us/frame) with eight bands at the 11090 us tick (44 ticks, ~0.49 s,
/// as fast as Fast water); calibrated pulse widths keep the AA, single pass.
enum EpdDrawError update_display_water_turn_hd(EpdiyHighlevelState* hl, EpdRect area,
                                                e0470_turn_dir_t dir);
/// 同步普通文字翻页沿用水波纹的全部灰阶相位，单带同时输出并恢复原节拍。/ Ordinary text uses all ripple gray phases in one synchronous band and restores pacing.
enum EpdDrawError update_display_text_turn(EpdiyHighlevelState* hl, EpdRect area, e0470_turn_dir_t dir);
/// 动画中间帧使用灰阶波形，但不累计周期清屏计数；动画最终帧走普通刷新出口。
/// Use grayscale for animation strips without advancing periodic cleanup; the final frame uses the normal path.

/// 当前像素时钟。/ Current pixel clock.
int display_pclk_mhz(void);
/// 出现供数不足就退回安全频率并整屏重刷，其它错误码原样忽略。
/// On underrun, drop to the safe clock and full-refresh; other error bits are ignored.
void guard_draw_result(EpdiyHighlevelState* hl, enum EpdDrawError result);

/// 切换全局反色：换向前把 back 基准映射到新方向，并请求下一次整屏全刷；帧缓冲仍保持逻辑灰阶。
/// Toggle global inversion; remap the back baseline for the new direction and request a full refresh next frame.
/// Framebuffers keep their logical gray values.
void display_set_inverted(EpdiyHighlevelState* hl, bool inverted);
/// 反色模式下把一块“原图”区域再翻一次，使扫描反色后仍显示原始灰阶（封面/插图用）。
/// Under inversion, flip one artwork region once more so the scan inversion cancels and the region
/// keeps its original tones (covers and illustrations). No-op when inversion is off.
void display_invert_area(uint8_t* fb, EpdRect area);
/// 深色模式压黑清理：只对逻辑白底（反色后即物理黑底）执行压黑动作，字形、抗锯齿边和白字
/// 都不被驱动，因此不会出现整片白闪；用于翻页后和小游戏周期清理。只在反色模式生效。
/// 旧实现先改写 back 基准再走 FOLLOW/DU；反色下这等价于对物理黑底压黑，但会污染差分基准。
/// Dark-mode darken settle: drives the darken action only on the logical-white target (the physical
/// dark ground after inversion); glyphs, AA fringes and white text are never driven, so there is no
/// whole-screen white flash. Used after turns and for periodic game cleanup. Inverted mode only.
/// The old path rewrote the back baseline and ran FOLLOW/DU; that physically darkened the ground too
/// but polluted the differential baseline.
void display_dark_settle(EpdiyHighlevelState* hl);
/// 反色整屏清理（黑闪，非白闪）：全屏压黑后从「逻辑全黑」基准重绘整帧，等效旧版整屏 GC16 的
/// 擦洗+重绘；用于反色模式到页周期清理。调用前 framebuffer 必须已是目标内容。只在反色模式生效。
/// Inverted full cleanup (black flash, never white): darken the whole panel then repaint the frame
/// from a logical-black baseline, matching the old full GC16's erase+repaint. Used for periodic
/// page-count cleaning in inverted mode. The framebuffer must already hold the target content.
bool display_dark_refresh(EpdiyHighlevelState* hl);
/// 深色模式翻页后补黑：只驱动物理黑底，字形与抗锯齿边保持不动，不再白闪。只在纯文字页调用。
/// Dark-mode turn black settle: drive only the physical black ground, never glyphs/AA fringes, and
/// no longer flash white. Call on text-only pages; no-op outside inverted mode.
void display_black_settle(EpdiyHighlevelState* hl, EpdRect area);
/// 阅读页浅色白底修复（1.15.24）：只对「目标为纯白」的像素走一遍厂商完整 GC16 的等灰复位循环
/// （压黑到黑轨→白饱和），把白底上残留的旧黑字/图案真正擦掉；黑字、抗锯齿灰边、插图不是纯白
/// 目标，完全不驱动。浅色阅读页翻页成功后调用；反色模式空操作。
/// Reader light-mode white-ground repair (1.15.24): pure-white targets run the vendor full-GC16
/// equal-white reset cycle (darken to the black rail, then white saturation) so old black residue on
/// the white ground is erased; black glyphs, AA fringes and artwork are not pure-white targets and
/// stay undriven. Called after a successful light-mode reader page turn; no-op when inverted.
enum EpdDrawError display_reader_white_repair(EpdiyHighlevelState* hl, EpdRect area);
/// 白天模式翻页后补白：与补黑同一条地面掩码，只驱动纯白底；紧跟在翻页推屏之后、同一次
/// present 内执行，字形与抗锯齿边不进差分。只在纯文字页调用。
/// 保留给兜底/对照：present 现在改调 display_white_settle_ink（只补上一页有墨的像素），
/// 不再无条件整片推白，以免每页对 80–90% 的纯白背景重复过驱动。
/// Day-mode turn white settle: the same ground mask, driving only pure-white ground right after the
/// turn push inside the same present(); glyphs and AA fringes stay out of the difference. Text-only
/// pages only. Kept as a fallback/reference: present now calls display_white_settle_ink (only
/// previous-page ink pixels) instead of unconditionally over-driving the whole white ground.
void display_white_settle(EpdiyHighlevelState* hl, EpdRect area);
/// 白天模式「定向补白」：只对「上一页有墨、这一页已经纯白」的像素重推一次白色，其余像素不进
/// 差分；紧跟在翻页推屏之后、同一次 present 内执行。old_ink 是按 area 局部逻辑坐标打包的 1bpp
/// 掩码：stride=(area.width+7)/8，每字节高位在前（MSB first），1 表示上一页该像素有墨。
/// 反色模式下本函数为空操作（反色保持原补黑路径）。
/// Day-mode targeted white settle: re-drive only pixels that carried ink on the previous page and are
/// pure white now; every other pixel stays out of the differential. Runs inside the same present()
/// right after the turn push. old_ink is a 1bpp mask in area-local logical coordinates with
/// stride=(area.width+7)/8 and MSB-first bit order; 1 means the pixel was inked on the previous page.
/// No-op when the panel is inverted (that path keeps the unchanged black settle).
void display_white_settle_ink(EpdiyHighlevelState* hl, EpdRect area,
                              const uint8_t* old_ink, int stride);

#ifdef __cplusplus
}
#endif
