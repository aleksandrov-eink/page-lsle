# P0-6 阅读工具栏二级设置后「被盖住的文字」无抗锯齿 — 根因分析与修复

版本基线：PageIsle 1.15.21（源码快照 `work/src-11521-snapshot`，2026-10-29）。
本报告只基于**代码分析 + 单文件语法检查**；没有真机，因此所有结论标注「待真机验证」。

## 1. 现象与代码路径

用户原话（交接简报，唯一一句）：「点阅读工具栏二级设置后，被盖住的文字没有抗锯齿」。
理解为：阅读页打开工具栏的二级/三级设置（不透明白色 sheet）后，原被 sheet 盖住的正文区域不再有
灰阶抗锯齿（边缘成硬边/锯齿）。

关键调用链（app_book.c，行号以 1.15.21 快照为准，工作区可能因其它任务移动）：

1. 打开面板：`reader_tools_swipe()` / `reader_panel_action()` 的**所有**面板分支都返回
   `APP_REDRAW_PAGE`（本次逐一核对，`reader_panel_action` 内没有任何 `APP_REDRAW_AREA`）。
2. `present()`：`redraw == APP_REDRAW_PAGE` → `render(ctx, ctx->fb)` 整页重画（含正文），
   再走非 AREA 分支：`update_display_area_diff_with(ctx->hl, display_main_normal_waveform(),
   MODE_GL16, reader_full_rect())`（app_book.c:6452-6457）——**差分 GL16**。
3. `update_display_area_diff_with` → `hl_update(..., full=false, allow_gl16_diff=true)` →
   `epd_hl_update_area()`：只驱动 front≠back 的像素；推屏成功后 highlevel 把 front 回写 back
   （components/epdiy/src/highlevel.c:190-300）。

因此结论 1（先排除一个假设）：**面板动作不会用 AREA 只推 sheet**；面板开/关都会整页重画并做
整幅差分。「关闭时 s_area 只等于 sheet 矩形，所以正文永不重驱动」这一假设不成立。

## 2. 根因（两个真实缺陷，均可从代码证实）

### 2.1 缺陷 A：AA 是全局开关，界面文字的「始终 AA」契约只实现了一半

- `main/font/ttf_font.c` 的 `s_antialias` 是全局状态，`mix_ink()` 直接读它（二值化）。
- 只有 3 条路径临时 `ttf_set_antialias(true)` 并在之后恢复：字体设置面板
  (`draw_font_settings`)、字体名 (`draw_reading_font_name`)、`ui_kit` 的两个标题/仪表盘路径。
- 设计契约（CHANGELOG rc99：「界面标签不受正文抗锯齿开关影响」）要求**所有**界面文字始终灰阶
  抗锯齿，但共享的 UI 文本出口 `ui_ttf_draw_px()` / `ui_ttf_rescue_draw()`（`main/ui/ui_kit.c`）
  没有守卫，直接跟随全局开关：
  - 正文 AA 开关关闭时（字体设置面板里的「抗锯齿」开关，或用户误触——该卡片就在二级面板底部），
    工具栏/二级面板/卡片的标签会一起变硬边（只有字体设置面板例外）。
  - 任何 set/restore 漏配对（例如后续在两者之间加提前 return）都会把正文 AA 永久关掉；
    这是「AA 泄漏到全局」这一类问题的根源，而现有实现没有任何结构性防护。
  - 面板经由 `ui_use_builtin()` 在内建字体与 TTF 之间切换时，TTF 分支同样跟随全局开关，
    兜底互救路径（内建→TTF / TTF→内建）也在其中。

### 2.2 缺陷 B：差分会把「物理屏是二值、back 是 AA」的区域判成不变，AA 永远补不回来

- 默认「翻页效果」= 0 =「普通·快刷」：`display_reader_fast_text_prepare()`
  （main/display_reader_waveform.c:88-121）在推屏前**就地二值化 `hl->front_fb`（=app 的
  ctx->fb）正文区**，随后用原厂 DU 推屏；highlevel 推屏后 front→back。
  → 翻页后：front/back/物理屏都是二值，一致（这是该档位的既定取舍）。
- 但 `MODE_DU` 的**局部**推屏会制造错位：DU 只按 1bit 差分驱动（物理上只有黑白两级），
  而 highlevel 仍把 AA 的 front 原样回写 back。当前实现里至少两处：
  - `reader_indent_present()`（app_book.c 布局设置面板的缩进微调，`update_display_area_diff_with
    (&E0470_FOLLOW_WAVEFORM, MODE_DU, area)`）；
  - `paint_control()`（阅读工具栏图标按压反馈：`render()` 全页 AA 后 `s_mode = MODE_DU`，
    只推 `tool_rect(i)`）。
  → 这些区域：物理屏=二值、back=AA。之后任何「同一内容再画一遍」的差分（front==back）都
  **不会驱动**，硬边会一直留到整屏全刷；面板的开/关恰好大量依赖差分，于是用户在「打开二级
  设置后」注意到被 sheet 露出/盖住的正文、以及面板自身的 AA 文本停留在硬边。
- 参考数值（对 E0470_WAVEFORM 裁剪后 GL16 37 相查表，已用脚本核对）：
  - `to=mid, from=0/15`（AA 边从二值恢复）有 14–34 个有效相 → **差分只要判定为变化就能恢复**；
  - `to=0, from=0`（黑字等灰对）有 24 个有效相（11 擦白 + 13 压黑）→ **非差分全像素 GL16 会让
    正文短暂「消失/变淡」约 0.12 s**，因此不能用「整幅非差分 GL16 定稿」草率兜底；
  - `to=mid, from=mid`（AA 等灰对）有 25–31 个有效相 → 需要「只重驱动 AA 等灰对」的定制表才能
    无闪修复（见 §4 方案 B）。

## 3. 已改文件（我独占的字体/UI 文件）

1. `main/font/ttf_font.c` / `main/font/ttf_font.h`
   - 新增绘制期 AA 覆盖栈：`ttf_aa_override_begin(bool)` / `ttf_aa_override_end()` /
     `ttf_aa_override_reset()`；`mix_ink()` 改为读 `draw_antialias()`（覆盖优先，否则正文开关）。
     **覆盖不写全局开关**，嵌套安全（深度 4），从结构上消除「面板/标题临时开 AA 后泄漏到正文」
     这一类问题；正文绘制进不了覆盖，仍严格跟随用户开关。
2. `main/ui/ui_kit.c`
   - 所有 UI 文本的 TTF 出口统一加 AA 覆盖：`ui_ttf_draw_px()`、`ui_ttf_rescue_draw()`（bw=false
     时；bw=true 明确要求二值，保持不变）。
   - `ui_text_fixed_context_aa_vc()`、`ui_text_title_background_vc()` 的旧 `get/set` 改为覆盖
     begin/end（不再改写全局开关）。
   - 效果：工具栏/二级面板/标题/内建↔TTF 兜底路径的界面文字**始终灰阶抗锯齿**；正文 AA 开关
     只影响正文（符合设计契约）。
3. `main/font/app_font_context.c`
   - `app_font_activate_system()` / `app_font_activate_reading()` / `app_font_end_lock()` 三个
     字体上下文切换点调用 `ttf_aa_override_reset()`：即使有未配对的覆盖残留，切换字体上下文时
     也会回到「跟随正文开关」的干净状态。

语法检查（`C:\dshb\syntax_check.py`）：ttf_font.c / ui_kit.c / app_font_context.c 均 `exit: 0`，
无新增警告。头文件 `ttf_font.h` 单独跑语法检查会因 `#pragma once` 报
`-Werror=pragma-once-outside-header`（头文件不是独立编译单元，属于检查方式限制；随 .c 编译通过）。

## 4. 需要 Lead 应用的 app_book.c（以及可选 display 层）补丁

> 说明：以下定位串在 1.15.21 快照与我看到的当前工作区文件中均唯一。shelf-recent 正在改
> app_book.c，应用前请以其最新版本 re-grep 一次定位串，若被改动按同样语义（条件 + 调用）落位。

### 方案 A（最小、只改 app_book.c，建议先做）：面板层进/出时对正文做一次「非差分灰阶定稿」

理由：面板层切换是「被 sheet 盖住/露出的正文」重新上屏的时刻。差分只驱动变化的像素，遇到
§2.2 的 DU 错位或 front/back 恰好相同的情形就永远补不回 AA；非差分 GL16 会把整幅目标灰阶真正
驱动一次。为了不引入「黑字闪白」的副作用，只在**当前翻页档会二值化正文（effect 0）且刚发生过
一帧速读黑白推屏**时触发（正常 AA 档不额外付这一遍、不产生视觉变化）。

补丁 1：present() 内、`bool dark_settle_after = false;` 之后加一个静态标志的声明处（文件级
静态变量区，`static enum EpdDrawMode s_mode = MODE_GL16;` 附近）新增：

```c
// 「速读黑白」上一帧把 front 正文就地二值化过：下一次面板层切换时补一次非差分灰阶定稿。
// The last frame binarized the body in place (Fast BW): settle the body once when the panel layer
// changes again, so the antialiased targets are actually driven.
static bool s_reader_bw_stale;
```

补丁 2：present() 内 `const bool reader_entry=s_view==READING&&s_text&&s_presented_view!=(int)READING;`
这一行之后新增：

```c
    // 面板层进/出（正文 ↔ 工具栏/任一二三级 sheet）：被盖住/露出的正文需要一次真正的灰阶重驱动。
    // Panel layer enter/leave (body <-> toolbar or any sheet): the hidden/revealed body needs a real
    // gray re-drive instead of a diff that may consider it unchanged.
    const bool reader_panel_layer_changed = (s_reader_panel == READER_PANEL_NONE) !=
        (s_presented_panel == READER_PANEL_NONE);
```

补丁 3：记录「速读黑白帧」。在 `if (fast_water) e0470_page_turn_set_tick_us(prior_tick);` 这一行之后新增：

```c
        // 速读黑白在推屏前把 front 正文二值化（屏上暂时没有 AA）：记一笔，下一次面板层切换时
        // 用非差分 GL16 定稿把抗锯齿边补回来；其它档位不置位，不额外付这一遍。
        // Fast BW binarizes the body before the push (no AA on screen for now): remember it so the
        // next panel-layer transition re-drives the AA edges with a non-differential GL16 settle;
        // other turn modes do not set it, so they never pay this extra pass.
        if (err == EPD_DRAW_SUCCESS && s_reader_turn_pending && s_mode == MODE_GL16 &&
            !s_water_turn_pending && app_settings_reader_turn_effect() == 0 && s_view == READING &&
            s_presented_view == (int)READING && s_reader_panel == READER_PANEL_NONE && !s_toolbar &&
            !s_clear_confirm && book_layout_page_image_count(s_page) == 0 &&
            !app_settings_book_background_path()[0])
            s_reader_bw_stale = true;
```

补丁 4：把面板切换的 present 分支改成「需要时定稿、否则保持差分」。定位串（app_book.c:6452-6457 一带）：

```c
    else err = s_view == READING
        // 面板切换按 rc100：只推最终灰阶的差分 GL16，不把首次选择水波纹算作周期全刷。
        // Panel transitions follow rc100: differential GL16 to the final grays only, without
        // counting the first ripple selection as periodic cleanup.
        ? update_display_area_diff_with(ctx->hl,display_main_normal_waveform(),MODE_GL16,
              reader_full_rect())
        : update_display_fast_page(ctx->hl);
```

替换为：

```c
    else if (s_view == READING && reader_panel_layer_changed && s_reader_bw_stale) {
        // 速读黑白留下的二值正文在差分里可能被判成「没变化」，AA 边就永远回不来；面板层切换时
        // 对正文做一次非差分灰阶定稿，把目标灰阶真正写回屏面。
        // Body binarized by Fast BW can diff as "unchanged" and keep hard edges forever; on a panel
        // layer change run one non-differential gray settle over the body to write the targets back.
        s_reader_bw_stale = false;
        err = update_display_area_full_with(ctx->hl, &E0470_WAVEFORM, MODE_GL16, reader_area());
    } else err = s_view == READING
        // 面板内一级↔二级↔三级切换仍走差分，控制时延。
        // Sheet-internal level changes stay differential to keep latency low.
        ? update_display_area_diff_with(ctx->hl,display_main_normal_waveform(),MODE_GL16,
              reader_full_rect())
        : update_display_fast_page(ctx->hl);
```

耗时/风险：
- 37 相 GL16、FULL 标定扫描，**相数不变**：面板层切换本来就走 37 相差分 GL16（约 0.4 s），
  这里只是把「只驱动变化行」换成「驱动整幅正文」，显示时间基本不变；CPU 侧多算未变化行，几 ms。
- 只在 effect 0 且刚翻过页后的首次面板层切换触发一次，视觉上是「正文被重新擦写一遍」；
  由于 `reader_area()` 只含正文（不含状态栏/题头/页脚），不会整屏闪。**待真机确认**：打开工具栏时
  正文是否可见「变淡一下」——若明显，改用方案 B。
- 反色：`update_display_area_full_with(&E0470_WAVEFORM, MODE_GL16, ...)` 走 1k LUT，反色下
  逻辑 8–15 等灰对默认保持（不擦白，无白闪），只驱动真正的目标变化 + 中灰 AA 边，
  不会破坏现有压黑契约；但反色下逻辑 8–15 的 AA 边仍被 hold（与现有整屏 GL16 行为一致）。

### 方案 B（更稳，无「正文变淡」副作用；需要 display 层加一个修复波形，建议与 display-fade 协调）

新增 `display_main_waveform.c` 函数（与 `display_main_gray_waveform()` 同一套路）：

```c
// 面板层切换用的 AA 修复表：等灰对里只驱动中灰（1..14，即抗锯齿边缘），纯黑字 0→0 / 纯白底
// 15→15 一律保持，避免整幅非差分 GL16 让黑字短暂变白；非等灰对保留原 GL16 动作。
// AA-repair table for panel-layer transitions: among equal pairs only mid-grays (1..14, the
// antialiased fringes) are driven; pure black 0->0 and pure white 15->15 hold, so a full-pixel
// update cannot whit-out the text; non-equal pairs keep the original GL16 actions.
const EpdWaveform* display_aa_repair_waveform(void) {
    static uint8_t data[E0470_GL16_FRAMES][16][4];
    static const EpdWaveformPhases phases = {E0470_GL16_FRAMES, (const uint8_t*)data, NULL};
    static const EpdWaveformPhases* ranges[] = {&phases};
    static const EpdWaveformMode mode = {MODE_GL16, 1, ranges};
    static const EpdWaveformMode* modes[] = {&mode};
    static EpdWaveform wave = {.num_modes = 1, .num_temp_ranges = 1, .mode_data = modes};
    static bool ready;
    if (ready) return &wave;
    const EpdWaveformPhases* orig = e0470_waveform_phases(&E0470_WAVEFORM, MODE_GL16);
    if (!orig || !orig->luts || orig->phases != E0470_GL16_FRAMES || orig->phase_times)
        return &E0470_WAVEFORM;
    memcpy(data, orig->luts, sizeof(data));
    for (int f = 0; f < E0470_GL16_FRAMES; ++f)
        for (int v = 0; v < 16; ++v) {
            if (v != 0 && v != 15) continue;  // 中灰等灰对保留：AA 边需要重驱动
            const int shift = 6 - 2 * (v % 4);
            data[f][v][v / 4] &= (uint8_t)~(3u << shift);
        }
    wave.temp_intervals = E0470_WAVEFORM.temp_intervals;
    ready = true;
    return &wave;
}
```

`display_main_waveform.h` 加声明；app_book.c 的面板层分支改为（不再需要 `s_reader_bw_stale`）：

```c
    else if (s_view == READING && reader_panel_layer_changed)
        // 面板层进/出：用 AA 修复表做一次全像素定稿——中灰等灰对被重驱动、纯黑/纯白保持，
        // 被 sheet 盖住或露出的正文一定能补回抗锯齿边，且不会闪黑/闪白。
        // Panel layer enter/leave: one full-pixel settle with the AA-repair table; mid-gray equal
        // pairs are re-driven while pure black/white hold, so hidden/revealed body text recovers its
        // antialiased edges without flashing.
        err = update_display_area_full_with(ctx->hl, display_aa_repair_waveform(), MODE_GL16,
                                            reader_full_rect());
    else err = s_view == READING
        ? update_display_area_diff_with(ctx->hl,display_main_normal_waveform(),MODE_GL16,
              reader_full_rect())
        : update_display_fast_page(ctx->hl);
```

渲染层实现要点：非差分 `epd_hl_update_area_full` 仍用 `MODE_PACKING_1PPB_DIFFERENCE | MODE_GL16`
把每个像素的 (from=back, to=front) 交给波形表，因此「等灰对保留中灰动作」＝只重驱动 AA 边。

### 方案 C（修掉 DU 错位源，建议一并做；都是 app_book.c 局部小改）

1. `reader_indent_feedback()`（布局设置面板缩进微调）：`s_mode=MODE_DU` → `s_mode=MODE_GL16`，
   并把 `reader_indent_present()` 里的
   `update_display_area_diff_with(ctx->hl,&E0470_FOLLOW_WAVEFORM,MODE_DU,s_area)` 改为
   `update_display_area_full_with(ctx->hl,&E0470_WAVEFORM,MODE_GL16,s_area)`
   （面积仅 424×72/横屏 720×72，37 相但行数少，单次约 25–40 ms，可接受；不再把 AA 目标写进
   back 而只在屏上驱动成二值）。
2. `paint_control()` 阅读工具栏图标的按压反馈：`s_mode = MODE_DU` → `MODE_GL16`（该分支只在
   `s_view == READING && s_reader_panel == READER_PANEL_TOOLS` 时用到；图标格 114×120，代价小），
   避免工具栏图标/标签在按压后长期硬边。

## 5. 反色/浅色预期

- 浅色：方案 A/C 的定稿都只驱动目标灰阶与 AA 中灰；`reader_area()` 不含状态栏/题头/页脚，
  不会整屏闪。差分路径（其余面板内切换）零改动。
- 反色：GL16 走 1k LUT，`epd_inverted_mode` 下逻辑 8–15 等灰对默认被 hold（无白闪），
  本次补丁不改变该契约；反色下这部分 AA 边（逻辑 ≥8）仍不重驱动（与现有整屏 GL16 行为一致），
  属于既有取舍，不在本单范围内改动。

## 6. 风险

1. 方案 A 会在「effect 0 + 刚翻页」后的首次面板层切换触发一次正文灰阶定稿，真机可能出现正文
   短暂变淡（等灰对 erase 相），若可见请改用方案 B。
2. 方案 B 需要新增 display 层波形表（12 KB PSRAM，与现有表同量级；低内存时按现有 fallback
   约定回退 `E0470_WAVEFORM` 即可继续工作）。display_main_waveform.c 由 Lead 协调落盘。
3. `ui_kit` 现在把所有 UI 文本强制 AA：正文 AA 开关关闭时界面会比以前更平滑（符合 rc99
   设计契约「界面标签不受正文抗锯齿开关影响」），但属于可见行为变化，需在验收清单里写明。
4. 本修复未触及 `main/font/fallback.h`、`stb_truetype.h`、`build/`，未改 UI 字面量/日志字符串。

## 7. 真机待验（无真机，以下均未验证）

1. 阅读页（默认「普通·快刷」）翻几页 → 上滑打开工具栏 → 进「字体设置」→ 返回/完成：
   被 sheet 盖住过的正文恢复后边缘应是灰阶抗锯齿（无硬边/锯齿），且反复开关面板保持。
2. 同上流程但把「翻页效果」切到「普通·高清 / 水波纹」：不应出现额外闪动（方案 A 的条件不触发）。
3. 字体设置里把「抗锯齿」关掉：工具栏/二级面板/卡片标签应仍平滑（只有正文变硬边）；
   再打开抗锯齿后正文恢复。
4. 布局设置里长按缩进微调 +/−（方案 C）：按住/松开后三个按钮文字不出现硬边。
5. 工具栏图标按压（方案 C）：按压反馈后图标/标签不残留硬边。
6. 反色模式下重复 1/2/4/5：无白闪、无整屏变色，深色压黑行为与 1.15.21 一致。
7. 低内存/大字号/带插图/带阅读背景的书：字体兜底路径（内建↔TTF 互救）文字仍可见且平滑。
8. 若仍在「打开二级设置后」看到正文硬边：取回 `pageisle_font_diag.log` 并记录是否/如何关闭过
   「抗锯齿」开关、翻页效果档位、面板路径（一级/二级/三级）与是否反色，便于复现。
