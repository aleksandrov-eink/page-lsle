# P0-1 浅色模式阅读/主页淡墨：根因分析与修复（display.c/display.h）

- 任务：`task-1`（PageIsle 固件 1.15.21 → 1.15.22 内测）
- 源码基线：`C:\dshb\src2\read-pico-reader-0.3.3-rc99`（工作区 `_build/src2/read-pico-reader-0.3.3-rc99`）
- 修改文件：`main/display.c`、`main/display.h`（仅此两个源文件 + 本报告）
- 验证等级：**仅代码分析 + 单文件语法检查（syntax_check exit 0）**，未构建、未真机。

---

## 1. 结论摘要

浅色模式「阅读页和主页都淡墨」不是某一次改版引入的显示逻辑回归，而是**浅色模式的“活动期”没有任何防淡墨机制**：

1. 浅色阅读翻页与主页局部刷新都走**差分刷新**——未变化的纯白底和未变化的字迹像素根本不进差分、不进驱动；
2. 固件唯一的通用防淡墨机制 `update_display_anti_fade()` 由 `anti_fade_due()` 触发，条件是**静置满 5 分钟**（默认）；而阅读/主页连续使用时每次翻页、滑动、点按都会把 `last_input_ms` 重置，于是这条机制在“正在看书/看主页”时**永远等不到**；
3. 阅读页虽然有「每 15 页一次整屏 GC16」（`app_settings_reader_full_pages` 默认 15）和主页「每 12 次整页切换一次内容区 GC16」，但都属于**低频整页清理**，覆盖不了两页之间/停留期间（dwell）累积的电荷泄漏；主页停留时秒针/时钟动画只做局部差分，整页计数根本不增长（`hl_update` 只对 `area == NULL` 的整页输出计 `s_page_refreshes`）。
4. 1.15.20 新增的「深色→浅色首帧擦白」(`s_light_white_reset_pending`) 在阅读/主页首帧路径上**确实生效**（有调用链证据），但它只解决“深色残余电荷被带到浅色”的一次性场景，不解决浅色连续使用期间的白底/墨色漂移；且 1.15.21 里有若干“白基准整帧”旁路出口会把全刷请求清掉而**不消费该复位**（本次已硬化）。

**修复**：在显示出口（display.c）加入**浅色活动期防淡墨**：按“页级输出计数 / 局部输出计数 / 距上次整帧重推的时间”三个可配置阈值触发，到点用**全像素 GL16 重推当前帧**（与既有防泛白同一机制：白底吃 15→15 白推、黑字走完整等灰驱动，无整屏黑白闪），每第 5 次这样的整理升级为**一次全像素 GC16**（完整擦写，强清残影）。反色模式完全不进入这条路径，深色逐页压黑 / 整屏 GC16 复位 / LUT 镜像与保持契约零改动。

同时把「深→浅首帧擦白」收敛为共享函数，并让 every “白基准整帧”出口（全刷、from-white、图片灰阶、面板修复、欠载恢复、防泛白）都可靠消费一次该复位，杜绝 1.15.20/21 的旁路遗漏。

---

## 2. 现象与约束

- 用户主诉（P0）：**浅色模式**下，阅读页和主页都「淡墨」；使用一段时间后文字发灰变淡、对比度下降。
- 硬约束：
  - 禁止回到「整片推白过驱动」老坑（1.13.1 停用白天补白即因整片推白累积残影）；
  - 深色/反色路径不得回退：逐页压黑、深色 GC16 复位、1k LUT 镜像/保持契约都不能改坏；
  - 不改 UI 字面量/日志字符串；不新增编译警告；不改冻结波形头 / SY7636A / fallback.h / stb_truetype.h；
  - 不改 `build/`、不跑 `idf.py build`（Lead 统一构建）；无真机，不得声称真机通过。

---

## 3. 根因分析（调用链 + 证据）

### 3.1 浅色阅读翻页只驱动变化像素，未变化的纯白底/字迹不进差分

默认阅读翻页档位是 `reader_turn_effect == 0`（`main/settings.c:176` 静态初值，`main/settings.c:404-406` 仅 NVS 有效值覆盖），即「普通·快刷」。

调用链（阅读页翻页，`main/apps/app_book.c`）：

```
turn_page()  (app_book.c:8225，默认 effect 0)
  └─ paint_reading(ctx, MODE_GL16)                          (app_book.c:6537)
  └─ present(ctx, APP_REDRAW_AREA)                          (app_book.c:6242)
       └─ s_reader_turn_pending && effect==0 && 纯文字页
          ? update_display_text_turn(hl, turn_area, ...)     (app_book.c:6428)
              └─ display_reader_fast_text_prepare(hl, area)  (display_reader_waveform.c:88)
                  只把本轮正文/页脚阈值成纯黑白
              └─ epd_hl_update_area(hl, MODE_DU, 25, area)   (display.c update_display_text_turn)
```

`epd_hl_update_area` 的实现（`components/epdiy/src/highlevel.c:190-300`）：

- 先 `epd_difference_image_cropped(front_fb, back_fb, ...)` 算差分，只把**有差异**的行/列标脏；
- 然后 `epd_draw_base(..., MODE_PACKING_1PPB_DIFFERENCE | mode, ...)`，未变化像素的差分值为 0，`epd_build_1ppB_lut_1k` 里查到的动作是「保持」（`components/epdiy/src/output_common/lut.c:342-377`）。

**证据（数值）**：解析冻结波形表得到——
- `waveforms/du.h`：`(to=15,from=15)` 与 `(0,0)` 全部是 0（保持）；只有真正变化的迁移（0↔15）才有动作。
- `waveforms/gl16.h`：`(15,15)` 源表全保持；`e0470_gl16_white_tick()` 只在 **GL16 全像素**路径上给 `(15,15)` 挂 1 帧白推，注释原文（`components/e0470_epaper_waveform/e0470_epaper_waveform.c:139-143`）：
  > 差分会跳过未变白像素，GL16 必须走全像素这帧才打到白底。

也就是说：**差分刷新天生不会重推“上屏后没有变过”的白底和字迹**；它们只能靠“全像素”刷新（GL16 全像素 / GC16）来恢复。全像素刷新在浅色阅读/主页的活动路径里频率太低（见 3.2/3.3）。

同一条规律也存在于普通阅读翻页档位（effect 1，`app_book.c:6432-6435` 的 `update_display_area_diff_with`）和水波纹档（`e0470_page_turn_*` 同样只驱动变化像素），只是默认档位最典型。

### 3.2 唯一的活动期外防淡墨机制只在“静置满 5 分钟”后触发

`main/app/app_loop.c:1396-1411`：

```
anti_fade_blocked = idle_blocked || menu_open || ... ;
if (anti_fade_due(ctx.now_ms, last_input_ms, anti_fade_blocked)) {
    update_display_anti_fade(ctx.hl);      // 全像素 GL16 重推
}
```

`last_input_ms` 在每次触摸/按键/BLE 输入时更新（`app_loop.c:1349、1364`，触控 `app_loop.c:835`）。`anti_fade_due()`（`main/anti_fade.c:33-38`）要求：

```
now_ms - last_input_ms >= interval  且  now_ms - s_last_refresh_ms >= interval
```

默认 `interval = 5 分钟`（`anti_fade.c:9`，NVS `metalio_hw/antifade_min`）。**阅读时用户每次翻页、主页上每次点按/滑动都会重置 `last_input_ms`，所以只要操作间隔 < 5 分钟，这条机制在活动期间永远不会触发**。这就是交接背景里「update_display_anti_fade 只在静置满 5 分钟才触发；翻页/阅读期间不触发」的代码依据。

### 3.3 阅读/主页的周期整屏 GC16 覆盖不了活动期与停留期

- **阅读页**：`turn_page()` 用 `app_settings_reader_full_pages()`（默认 15，`settings.c:175、399-403`）累计 `s_turns`，到页后在 `present()` 走 `update_display_area_full_with(ctx->hl, &E0470_FULL_WAVEFORM, MODE_GC16, reader_full_rect())`（`app_book.c:6369-6371` 浅色分支）。这确实是一次整屏 GC16（48 相完整表，`(15,15)` 是 18 帧擦除 + 17 帧白饱和，能恢复白底与墨色）。但：
  - 15 页才一次，**两页之间的停留时间**里电荷泄漏照样累积；
  - 阅读一页若停留较久，用户看到的淡墨发生在下一次清理之前。
- **主页（dashboard）**：整页切换走 `update_display_fast_page` → `main_begin`，`normal && changed` 时每 `APP_UI_FAST_GC16_EVERY == 12` 次做一次内容区 GC16（`display.c` main_begin 内 `APP_UI_FAST_GC16_EVERY` 分支）；而主页停留时的秒针/时钟/组件刷新是**局部 AREA 差分**（`app_dashboard.c` present 的 `present_clock_motion`/`present_clock_area`），在 `hl_update()` 里 `area != NULL` 的调用**不累计** `s_page_refreshes`（`display.c` hl_update 只在 `waveform != &E0470_FOLLOW_WAVEFORM && area == NULL` 时计数）。所以**停在主页看时钟时，整页 GC16 计数不增长，永远等不到清理**。

### 3.4 1.15.20 的「深→浅首帧擦白」是否生效：确认生效，但有旁路缺口

`display_set_inverted(hl, false)`（`display.c:89-115`）会 `display_request_full_refresh()` + `s_light_white_reset_pending = true`。消费点在 `update_display_full_unlocked()` 的浅色分支（`display.c:831-877` 附近）。

阅读/主页两条路径**都能到**该消费点（这是 1.15.21 现状，不需要改 app 文件）：

- 切反色/夜间自动反色：`app_loop.c:297-303`（每次 present 的兜底）或 `app_loop.c:847-862`（5 秒轮询）→ `display_set_inverted(hl, want)` → `app_present(..., APP_REDRAW_FULL)`；
- app_book `present()`：`redraw == APP_REDRAW_FULL` → `update_display_full(ctx->hl)`（`app_book.c:6374`）→ 浅色分支消费 pending；
- dashboard `present()`：`redraw == APP_REDRAW_FULL || s_home_force_full_once` → `update_display_full`（`app_dashboard.c:961`）；
- app_home：`force_full` → `update_display_full`（`app_home.c:414-419`）。

**1.15.21 的缺口**（本次修复）：以下出口会**清掉 `s_full_refresh_requested` 或直接走全像素白基准整帧刷新，却不消费 `s_light_white_reset_pending`**：

| 出口 | 位置（1.15.21 基线） | 症状 |
| --- | --- | --- |
| `update_display_anti_fade`（静置防泛白） | `display.c` | 首帧恰好走防泛白时，pending 不消费；全刷请求也不消费（防泛白刻意绕过），复位被延后 |
| `update_display_image_gray` | 清 `s_full_refresh_requested` 后走 `epd_clear()+from_white` | pending 丢失（虽然它本身等价于复位） |
| `display_panel_repair` | 清 `s_full_refresh_requested` 后走 from-white | 同上 |
| `guard_draw_result_unlocked` 欠载恢复 | `epd_clear()+from_white` | pending 残留到之后某帧，触发多余整屏擦白 |

这些属于边角路径，但为了“深→浅首帧擦白在阅读/主页都可靠生效”，本次把它们统一收敛到共享复位函数，任一出口遇到 pending 都保证“擦白 + GC16 重写当前帧”只发生一次、且不会丢。

### 3.5 为什么不是 1.15.20/21 引入的显示回归（证据）

把 1.15.17 源码包（`work/gh-pageisle/downloads/PageIsle-1.15.17-source.zip`，用户确认浅色正常的稳定版基线）与当前 1.15.21 基线快照（`work/src-11521-snapshot`）做全树逐字节比较，**只有 7 个文件有差异**：

`components/epdiy/src/epdiy.h`、`components/epdiy/src/output_common/lut.c`、`main/app_main.c`、`main/display.c`、`main/pageisle_version.h`、`main/apps/app_book.c`、`main/apps/app_device_settings.c`。

其中浅色显示路径的差异只有：

- `display.c`：新增 `s_light_white_reset_pending`（深→浅首帧擦白）与 1.15.20 的注释/反色复位重写（反色专用）；
- `app_book.c`：reader entry / 周期清理的**浅色分支与 1.15.17 等价**（仍是 `update_display_area_full_with(E0470_FULL_WAVEFORM, GC16, reader_full_rect())`），差异都在反色分支与逐页压黑（仅反色）；
- `lut.c`/`epdiy.h`：`epd_set_inverted_dark_hold`（仅反色路径使用）。

结论：**浅色翻页/主页的刷新机制与 1.15.17 逐字节相同**，因此该淡墨是长期存在的“活动期维护缺口”，不是 1.15.20/21 引入的回归；不应回退 1.15.20 的深色修复。修复应补“浅色活动期”这一层，而不是改翻页/主页的既有刷新节奏。

---

## 4. 修复设计

### 4.1 浅色活动期防淡墨（display.c，新增）

在显示出口统一计数，到点追加一次**全像素整帧重推**（不改变主输出结果）：

- 计数/计时（三个可配置阈值，见 §5.1）：
  - `PAGE_EVERY`：每 N 次**页级输出**（面积 ≥ 逻辑画布一半：阅读翻页/整页刷新、主页切页、整屏 GL16/GC16 出口）触发；
  - `AREA_EVERY`：每 N 次**局部输出**（小面积差分，例如主页秒针、状态栏）触发，兜住“一直停在主页看动画”的场景；
  - `INTERVAL_MS`：距上次整帧重推超过该时间（默认 5 分钟，与产品既有防泛白间隔一致）且期间有任意浅色输出，就在下一次输出后补一次——直接覆盖“翻页间隔 < 5 分钟、静置防泛白永远不触发”的核心场景。
- 到点后执行 `update_display_area_full_with_unlocked(hl, &E0470_WAVEFORM, MODE_GL16, 全屏逻辑矩形)`：
  - 选择 **GL16 全像素**而不是“整片推白”：与既有 `update_display_anti_fade` 完全同一机制；白底只吃 1 帧 15→15 白推、黑字/中灰走完整等灰驱动（0→0 = 11 帧擦白 + 13 帧压黑，波形表实测），无整屏黑白闪；
  - **每第 `GC16_EVERY` 次**整理升级为 `MODE_GC16`（默认 trimmed 默认表 36 相）：`(15,15)` 是 11 帧擦除 + 17 帧白饱和，能强清白底/残影，强度等同现有阅读每 15 页/主页每 12 页的例行整屏清理，但频率更低（默认约每 25 分钟）。
- 触发只在**显示锁内**、在主输出成功之后追加；`full_cleanup` 场景（本次输出本身就是页级 GC16 清理，如阅读周期清理）只归零计数，不追加第二遍。
- 所有“整帧重推/白基准整帧”出口（全刷、from-white、图片灰阶、面板修复、欠载恢复、静置防泛白）都会重置计数与计时，避免重复。

### 4.2 为什么**不**重新启用 `display_white_settle_ink` / 白天补白

- `app_book.c:6479` 的既有设备结论：整片推白会过驱动累积残影；而定向补白（只推上一页有墨的像素）会让“上一页字迹比背景更白”（真机反馈），1.13.1 起停用；
- 因此本次不在每页追加任何“往白推”的差分脉冲，**没有回到整片推白老坑**；活动期维护用产品既有的全像素 GL16 防泛白机制，并只在低频（每 N 页/每 5 分钟）执行。

### 4.3 深→浅首帧擦白可靠化（display.c）

- 抽出 `display_light_white_reset_unlocked()`（`display.c:1038`）：`use_scan_for(E0470_FULL_WAVEFORM, GC16)` → `epd_clear()` 整屏擦白 → `epd_hl_update_screen_from_white(hl, MODE_GC16, 25)` 从白基准重写当前帧 → 恢复默认波形、清 `s_page_refreshes`、重置活动期计数；
- `update_display_full_unlocked` 浅色分支改为直接调用它（阅读/主页/设置等所有走全刷的页面都覆盖）；
- every “白基准整帧”旁路出口也会**消费** pending（见 §3.4 表格）：`update_display_from_white_with_unlocked`、`update_display_image_gray_unlocked`、`display_panel_repair`、`guard_draw_result_unlocked` 欠载恢复、`update_display_anti_fade`（首帧恰好先走防泛白时直接执行复位并返回）；
- 浅色→深色切换时清掉 pending（深色整屏复位本身会做真正的 GC16 擦写，避免残留到之后某次浅色首帧多触发一次全屏擦白）；
- 反色方向切换时同时重置活动期计数。

---

## 5. 逐文件改动

### 5.1 `main/display.h`

新增可配置常量（第 60-63 行，**调参只需改这里**）：

| 宏 | 默认 | 含义 |
| --- | --- | --- |
| `DISPLAY_LIGHT_ACTIVITY_PAGE_EVERY` | 10 | 每 N 次页级浅色输出追加一次整帧重推；0 = 停用该条件 |
| `DISPLAY_LIGHT_ACTIVITY_AREA_EVERY` | 600 | 每 N 次局部浅色输出追加一次；0 = 停用该条件 |
| `DISPLAY_LIGHT_ACTIVITY_INTERVAL_MS` | 300000（5 分钟） | 距上次整帧重推超过该时长且期间有浅色输出即补一次；0 = 停用该条件 |
| `DISPLAY_LIGHT_ACTIVITY_GC16_EVERY` | 5 | 每第 N 次整理升级为全像素 GC16；0 = 不升级（只做 GL16） |

三个阈值全 0 = 整体关闭（A/B 对照或回滚开关）。顶部注释中英双语说明“活动期防淡墨”的原理与反色隔离。

### 5.2 `main/display.c`

| 位置（当前行号） | 改动 |
| --- | --- |
| 59-74 | 新增活动期计数/时间戳状态（`s_light_activity_page_ops / area_ops / settles / last_ms`）与三个内部函数的前置声明 |
| 89-116 `display_set_inverted` | 深→浅置 pending，浅→深清 pending；换向后重置活动期计数（原有反色复位/LUT 重建逻辑不变） |
| 794-808 `update_display_from_white_with_unlocked` | 浅色下消费 pending（本出口=白基准整屏 GC16，等价复位）并重置活动期计数 |
| 840-882 `update_display_full_unlocked` | 深→浅首帧改为调用共享复位函数；浅色普通整屏 GC16 成功后重置活动期计数（反色分支一行未改） |
| 880-898 `update_display_image_gray_unlocked` | 浅色下消费 pending（本出口=epd_clear+白基准整屏 GC16）并重置计数 |
| 955-1054 | **新增**活动期防淡墨实现：`display_light_full_area()`、`display_light_activity_reset()`、`display_light_page_level_area()`、`display_light_activity_redrive_unlocked()`、`display_light_activity_tick_unlocked()`、`display_light_white_reset_unlocked()`（均带中英双语注释） |
| 1176-1195 `guard_draw_result_unlocked` | 欠载恢复（epd_clear+白基准整屏 GC16）后消费 pending 并重置计数 |
| 1218-1262 `update_display_mode / update_display_mode_diff / update_display_fast_page` | 非全刷输出成功后调用活动期 tick（全刷出口自身已重置） |
| 1319-1350 `display_panel_repair` | 浅色下消费 pending（面板修复=更强复位）并重置计数；后续盲刷流程未改 |
| 1381-1430 `update_display_with / update_display_area_with / update_display_area_diff_with` | 成功后 tick（按面积判定页级/局部） |
| 1450-1480 `update_display_area_full_with` | 成功后 tick；页级全像素 GC16 清理只归零计数（`full_cleanup`） |
| 1480-1502 `update_display_anti_fade` | 首帧 pending 时先做擦白+GC16 复位；之后按浅色/反色恢复原有行为；浅色成功后重置活动期计数（反色压黑补扫未改） |
| 1509-1572 `update_display_water_turn / update_display_water_turn_hd / update_display_main_turn` | 非全刷输出成功后 tick |
| 1574-1615 `update_display_text_turn` | 记录 `full` 标志；成功后 tick（默认阅读翻页主路径） |

未改动：`update_display_click_feedback`（触摸反馈不计数，避免干扰按压/主页面许可恢复）、所有反色压黑/整屏复位/LUT 相关函数、`display_white_settle*`、`display_ground_mask/settle`、波形与底栏几何。

---

## 6. 反色/深色路径为什么不受影响（逐条论证）

1. `display_light_activity_tick_unlocked()` 第一行就 `if (epd_get_inverted() ...) return;`——反色模式**不计数、不追加**任何刷新；
2. 活动期整理只会调用 `update_display_area_full_with_unlocked(..., MODE_GL16/MODE_GC16)`，**不会**触碰 `display_dark_settle*` / `display_dark_refresh*` / `epd_set_inverted_dark_hold`；
3. `s_light_white_reset_pending` 只在“切到浅色”时为 true，切到深色时被清 false；所有消费点都有 `!epd_get_inverted()` 保护，反色全刷分支仍先走 `display_dark_refresh_unlocked`（真 GC16 复位 + hold 临时关闭/恢复），逻辑未动；
4. 反色 LUT 的镜像与逻辑 8–15 等灰对保持（`components/epdiy/src/output_common/lut.c:342-377`）未改；逐页压黑 8 帧 / 周期清理 16 帧（`DISPLAY_DARK_SETTLE_FRAMES/DISPLAY_DARK_CLEANUP_FRAMES`）未改；
5. 反色下 `update_display_anti_fade` 仍按原逻辑“全像素 GL16 + 轻压黑”，只在“切到浅色首帧 pending”这个本就不属于反色的事件上新增一次复位；
6. 新增的计数只影响浅色；`display_set_inverted` 切换时清零，不会把上一模式的计数带过去。

---

## 7. 验证

- 单文件语法检查（ESP-IDF 工程真实编译参数，`-fsyntax-only`，不写对象、不碰 build/）：
  ```
  C:\dshb\pyenv-idf\Scripts\python.exe C:\dshb\syntax_check.py main/display.c
  → syntax check: ...\main\display.c
    exit: 0
  ```
  （`main/display.h` 通过 display.c 的 include 一并验证；无新增警告。）
- 未运行 `idf.py build`（按任务纪律由 Lead 统一构建），**未真机验证**。
- 静态自检清单：
  - 反色路径逐条未改（见 §6）；
  - 未改 UI 字面量/日志字符串（新增日志：无；新增注释双语）；
  - 未改冻结文件；未新增动态内存/缓存（仅 4 个静态计数/时间戳）；
  - 活动期整理在显示锁内串行执行，不增加任务/栈；单次额外耗时 GL16 ≈ 0.27–0.33s（前导保持跳过）、GC16 ≈ 0.4s，默认每 10 页或 5 分钟一次、每第 5 次整理才升级 GC16。

---

## 8. 风险与真机待验项

**风险**

1. 活动期 GL16 整帧重推会让黑字/中灰先短暂变浅再回原灰阶（波形表 0→0 = 11 帧擦白 + 13 帧压黑，约 0.27s；白底只 1 帧白推），默认每 5 分钟/每 10 页一次；属于既有静置防泛白的同款瞬态，但活动期可能更容易被注意到。
2. GC16 升级（默认每 5 次整理 ≈ 每 25 分钟或 50 次页级输出）是一次常规整屏 GC16 可见刷新，强度等同现有阅读每 15 页/主页每 12 页的清理，但会叠加一次频率；若真机觉得闪频，把 `DISPLAY_LIGHT_ACTIVITY_GC16_EVERY` 设为 0 或调大。
3. 极长连续滚动/手写轨迹期间若恰好到点，追加的整帧重推会带来一次约 0.3–0.4s 的停顿；已把局部触发阈值设为 600 次并把时间阈值设为 5 分钟。
4. 活动期整帧重推会驱动底栏/固定导航的等灰像素（与既有静置防泛白一致）；浅色主页切页的“仅横条可变/底栏图标固定”逻辑（main_begin）未改，本机制只在低频追加，不参与切页裁剪。

**真机待验（必须，无真机结论）**

1. 浅色阅读：连续翻 30–60 页、每页停留 1–5 分钟，文字/白底是否还会「越用越灰」；每次活动期整理（约每 10 页或 5 分钟）是否可接受（文字短暂变浅后回原灰阶，无整屏白闪）。
2. 浅色主页：停在主页看时钟 10–20 分钟（不动它、或每分钟点一下），主页静态文字/白底是否不再累积发灰；秒针动画是否因追加整理出现可感知停顿（若明显，调大 `INTERVAL_MS`）。
3. 深色/反色回归（不得回退）：①切反色立即正常深底白字；②深色连翻 20–30 页逐页压黑可读；③深色到页/手动全刷有真正 GC16 复位；④深色静置防泛白仍只做 GL16+压黑、无整屏白闪；⑤深色退出后浅色首帧仍先擦白再 GC16 重写（阅读页/主页各验一次）。
4. 浅色→深色→浅色快速切换（含夜间自动反色 21:00/07:00 跨点）：首帧不应多闪一次、不应残留整屏擦白。
5. 横屏阅读翻页/主页、图文页/带阅读背景图的书：活动期整理不破坏画面与翻页动画。
6. 若仍有淡墨：先记录是「操作后立刻淡」还是「停留后淡」、浅色/深色、竖/横屏、所在页面；可按 §5.1 下调 `DISPLAY_LIGHT_ACTIVITY_INTERVAL_MS`（如 180000）/`PAGE_EVERY`（如 6）后再验。

---

## 9. 需要 Lead 处理的跨文件补丁

**无必需跨文件改动**：修复全部在 `main/display.c` / `main/display.h` 内完成，阅读页与主页两条路径均已在显示层覆盖（阅读翻页默认档/水波纹/高清/普通差分、主页整页切页/局部动画、进书与周期清理、设置页等出口统一接入）。

说明：

- `app_book.c` 的白天定向补白（`display_white_settle_ink`）**保持停用**即可，不需要重新接线；`display_white_settle_ink()` 本身未改，仍可作为兜底入口。
- 本报告引用的 `app_book.c` / `app_dashboard.c` 行号以 1.15.21 基线（`work/src-11521-snapshot`）为准；当前工作区这两个文件正被 shelf-recent 任务修改，我的改动不依赖它们的任何修改。
- 1.15.22 发布说明可加一条（建议）：`· 修复浅色模式阅读/主页“用一段时间后淡墨”：在显示层加入活动期低频全像素重推（每约 10 页/5 分钟，无整屏白闪，每第 5 次升级整屏 GC16），并加固深色退出后首帧擦白复位`。

---

## 10. 分析工件（临时，位于构建工作区 tmp/，不入库）

- `C:\dshb\tmp\diff_full_11517_11521.txt`：1.15.17 发布源码 vs 1.15.21 基线全树 diff（§3.5 证据）；
- `C:\dshb\tmp\parse_waveforms.py`：解析冻结波形表，输出 (to,from) 动作序列（§3.1 证据）；
- `C:\dshb\tmp\display_fade_changes.diff`：本次 display.c/display.h 改动相对 1.15.21 基线的完整 diff（供 Lead 复核）。
