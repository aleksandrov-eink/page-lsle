# 1.15.23 浅色残影（页面层）：主页/阅读刷新策略根因分析与修复

- 任务：`task-7`（PageIsle 固件 1.15.23：浅色模式主页 + 阅读「残影过多」）
- 源码基线：`C:\dshb\src2\read-pico-reader-0.3.3-rc99`（工作区 `_build/src2/read-pico-reader-0.3.3-rc99`，同一份）
- 我（ghost-pages）的写权限：`main/apps/app_dashboard.c` + 本报告；`app_book.c`、`settings.c`、`display.c/h` 不归我写
- 验证等级：**仅代码分析 + 单文件语法检查（syntax_check exit 0）+ app_book.c 补丁在临时副本上语法检查通过**；本环境无真机、未构建（Lead 统一构建），**不得声称真机通过**

> 用户事实（Lead 2026-10-29 更新）：设备 1.15.22 内测，但用户明确说**浅色残影自 1.15.17 正式版就有、一直没解决**；阅读翻页效果为**水波纹·高清（effect 3）**；用户原话「残影是本应该是无色的地方却有黑色的文字或者图案残留」。

---

## 1. 结论摘要

浅色主页/阅读的「白底黑字残影」不是 1.15.22 的回归，而是**页面层长期把「真正的 GC16 擦写复位」当成低频甚至缺省的动作**：

1. **进入主页**：`app_dashboard` 的 `enter_full=false`（`app_dashboard.c:1407`），从阅读/其它 app 返回时主循环走 `APP_REDRAW_PAGE` → `update_display_fast_page()`（`app_loop.c:375`、`528`）。这条路径在「非主页面来源」（例如阅读页里 `reader_return()` 直接 `ui_nav_request(ctx,0)` 回首页，`app_book.c` 内）或主页面互切（`main_begin` 普通模式）时，**只驱动 `front_fb != back_fb` 的变化像素**（`display.c:556-564` 普通切页 / `display.c:769-783` 普通整页出口），上一屏黑色文字/图案只是被「目标变白」的差分脉冲擦一次，物理残留电荷仍在白底上；真正的整屏 GC16 只在「攒够 12 次整页输出」时才做（`APP_UI_FAST_GC16_EVERY=12`，`app_config.h:54`；`display.c:555-564`、`769-783`）。**因此回主页的第一次、以及最多 12 次切页之内，都能看到上一屏黑字残影**。
2. **停留主页看时钟**：时钟/日期只做小面积局部差分（`app_dashboard.c:942-945` 的 `present_clock_motion`、`app_dashboard.c:999-1038` 的局部候选/时钟分支；`update_display_area_diff_with`）。显示层旧计数只统计**面积 ≥ 半画布的页级输出**（`display.c:989`、`1126-1160`），局部刷新不累计；1.15.22 的活动期维护只是「全像素 GL16 重推」（**非复位**：裁剪 GL16 表里 `(15,15)` 只挂 1 帧白推，见 §4 数值证据），清不掉白底黑字，反而过驱动。现在该旧机制已由显示层队友 `ghost-display` 默认停用，并新增「10 分钟/30 页级输出」的**真 GC16 清理**（见 §6 分工）。
3. **阅读（水波纹·高清 effect 3）**：翻页走 `update_display_water_turn_hd()`（`app_book.c:6430-6433` → `display.c` 的 `update_display_hd_water_unlocked` → `e0470_page_turn_with_waveform_compact_commit`）。揭页引擎同样**先算差分再只刷脏行列**（`components/e0470_page_turn/e0470_page_turn.c:323-325`、`454-455`；`epd_draw_base(... MODE_PACKING_1PPB_DIFFERENCE | MODE_DU ...)` 在 `:368-377`），未变化的白底/字迹不进差分 → 上一页被擦成白但没擦干净的黑色残影留在白底上，逐页累积；唯一的真正清理是 `s_turns >= app_settings_reader_full_pages()` 时那一次整屏 GC16（`app_book.c:8318-8322` 计数，`app_book.c:6371-6386` 清理分支），原默认 **15 页**、且**没有时间上界**：翻得慢/停留久的读者，残影可以留几十分钟到几小时。
4. 1.15.22 看似相关的两个新增都不是复位：显示层活动期「全像素 GL16 重推」（现默认停用）与 `display_aa_repair_waveform()` 面板层全像素定稿（`display_main_waveform.c:135-150`，`app_book.c:6466-6474` 调用）。它们能重驱动某些像素，但**不是从白基准的 GC16 擦写**，清不掉白底黑字残影（AA 定稿只重驱动等灰中灰 1..14，纯黑白保持，反而对字形边缘过驱动）；后者由 `ghost-display` 单独给 Lead 精确补丁改成差分 GL16。

**修复（页面层，最小、可回滚）**：

- **主页进入**（`app_dashboard.c`，我落盘）：浅色下进入主页的首帧直接做一次**真 GC16 复位**，使用 `E0470_FULL_WAVEFORM`（48 相未裁剪表，擦除余量比裁剪 36 相大，见 §4）：
  - 「首页强刷」设置开启（**当前工作树默认 true**，见 §7）：整屏一次 48 相 GC16（≈0.53s），彻底清掉上一屏残影；
  - 设置关闭：只对**内容区**（`y=0..UI_NAV_REFRESH_END`，≈89% 画布）做 48 相 GC16，底栏图标不驱动（不整屏闪），再对底栏条带做一次 FOLLOW/DU 差分补活动横条/从阅读返回时的导航；
  - 反色模式完全不进入这条路径（`on_enter` 里 `!epd_get_inverted()` 门控），深色差分/压黑契约零改动。
- **主页停留**：**默认不在页面层加计时器**——显示层 `ghost-display` 已把「10 分钟 / 30 次页级输出」改为**真正的 48 相整屏 GC16**，且时间触发前置已按本任务建议改为「自上次真清理以来至少 1 次任意浅色输出」（局部时钟刷新也算），主页停留场景由它兜底；页面层保留 `HOME_GHOST_DWELL_CLEANUP`（默认 0，运行时关闭）备用开关，仅当 Lead 把 `DISPLAY_LIGHT_CLEANUP_ENABLE` 置 0 时才需要打开，避免两套全刷叠加闪屏。
- **阅读**（`app_book.c` 精确补丁交 Lead，见 §8）：周期清理从「仅页数」改为「**页数 OR 距上次真 GC16 满 10 分钟**」双触发（反色不进入时间触发），并把默认清理间隔 **15→10 页**（`settings.c` 工作树已改，见 §7），保留用户可选 5/10/15/30/关。进书首帧本来就是真 GC16（`app_book.c:6340-6353`），无需改。

---

## 2. 现象与约束

- 用户主诉：浅色模式（非反色）白底/无色区域残留上一屏的**黑色文字或图案**；主页、阅读都有；1.15.17 起一直存在。
- 硬约束：
  - 不改反色/深色刷新契约（逐页压黑、整屏 GC16 复位、1k LUT 保持、深→浅首帧擦白）；
  - 不回退 1.15.22 的淡墨/AA/书架/最近阅读/传书/蓝牙修复；
  - 不改 UI 字面量/日志字符串；注释中英双语；不新增编译警告；
  - 不改 `build/`、不跑 `idf.py build`；无真机不得声称真机通过；
  - 页面层修复优先「真正的 GC16 复位」，不用全像素 GL16 这类非复位重复驱动。

---

## 3. 根因分析（页面层，调用链 + 行号）

### 3.1 未变化像素永远不进差分：白底残留只能靠全像素 GC16 擦写清除

全部普通输出（主页差分、阅读水波纹/GL16 翻页、局部时钟）最终都走 epdiy 的差分刷新：

- `main/apps/app_book.c` 水波纹高清 → `display.c` `update_display_hd_water_unlocked()` → `e0470_page_turn_with_waveform_compact_commit()`（`display.c:1141-1142`）→ `page_turn_run()`：
  - `epd_difference_image_cropped(front_fb, back_fb, phys, difference_fb, dirty_lines, dirty_columns)`（`e0470_page_turn.c:323-325`、`:454-455`）；
  - 每拍只把有变化的条带行列标脏，`epd_draw_base(..., MODE_PACKING_1PPB_DIFFERENCE | MODE_DU, ...)`（`:368-377`）→ 差分值为 0 的像素 LUT 动作是「保持」。
- 主页整页/切页同理：`update_display_fast_page_unlocked()`（`display.c:764`）与 `main_begin()`（`display.c` 主页转场）走 `epd_hl_update_area/screen` 差分；`update_display_fast_page_unlocked` 的普通分支即 `epd_hl_update_screen(hl, MODE_GL16, 25)`（`display.c:786-796` 附近），只驱动 front≠back。
- 局部时钟刷新：`app_dashboard.c:942-945` `present_clock_motion()` 用 `&E0470_FOLLOW_WAVEFORM + MODE_DU` 短局刷；`app_dashboard.c:999-1038` 的分钟/秒点只用 `update_display_area_diff_with`。

**推论（与用户现象一致）**：上一屏黑色文字在新页面变成白底后，差分只给这些像素一次「黑→白」迁移；e-ink 的擦除残留（尤其水波纹/DU 类差分）不会消失，而是留在白底上形成黑字/图案残影；之后这些像素在「白→白」的差分里**永远为 0、永远不再被驱动**，直到一次真正的全像素 GC16。

### 3.2 主页进入：`enter_full=false` + 每 12 次才清理一次

调用链（从阅读页回主页，常见两条）：

```
[阅读页内 Home 键/返回手势] reader_return()  (app_book.c)
  └─ s_reader_return_home ? ui_nav_request(ctx,0) : ...      → 请求切到 app_dashboard
[主循环] switch_to() (app_loop.c:497-529)
  └─ app_present(ctx, next, next->enter_full ? FULL : PAGE)  (app_loop.c:528)
       └─ app_dashboard.enter_full=false  (app_dashboard.c:1407)
       └─ dashboard present() → update_display_fast_page()   (app_dashboard.c:1054-1069 分支)
            └─ display.c update_display_fast_page_unlocked() (display.c:764)
                 └─ 非主页面来源：按页级输出计数，每 APP_UI_FAST_GC16_EVERY(12) 次才整屏 GC16 (display.c:769-783)
                 └─ 其余：epd_hl_update_screen(MODE_GL16) 差分，只驱动变化像素
[从书架等主页面切回] switch_to → display_main_transition_arm(..., changing_page=true) (app_loop.c:527)
  └─ main_begin() 普通模式：body 差分 GL16 + 每 12 次才有 body GC16 (display.c:555-564)
```

- `s_page_refreshes` 只统计「整页输出」（`display.c:357`、`:769`、`:716`），**主页进入一次只 +1**；因此从阅读回到主页的最初一帧（以及之后最多 11 次切页）都是差分，上一屏黑字残影原样留在白底。
- 记录在案的历史：1.15.17 与 1.15.21 的浅色主页/翻页刷新代码逐字节相同（见 `docs/analysis/11522_issue1_light_fade.md` §3.5），所以这个缺陷在 1.15.17 就存在，与 1.15.22 无关。

### 3.3 主页停留：局部刷新不累计清理计数

- 停留在主页时，`on_tick` 只产生**小面积**输出：整点/分钟状态栏（`app_dashboard.c:1141-1146` 附近）、时钟秒点（`present_clock_motion`）、组件/封面局部（`APP_REDRAW_AREA`）。
- 显示层页级计数只在 `area` 面积 ≥ 逻辑画布一半时才 +1（`display.c:989` `display_light_page_level_area`；`display.c:1126-1160` 维护 tick），主页局部刷新全部小于该阈值 → **旧计数永远等不到清理**；1.15.22 的「每 600 次局部输出 / 5 分钟」触发的是**全像素 GL16 重推**（非复位）：白底 `(15,15)` 在该表里只挂 1 帧白推（`e0470_epaper_waveform.c:143-154` 的 `e0470_gl16_white_tick`），清不掉黑字残影；而未变化黑字 `(0,0)` 反而走「18 帧白推 + 18 帧压黑」整循环（§4）＝ 过驱动。
- 现状：`ghost-display` 已把该旧机制默认停用（`display.h` `DISPLAY_LIGHT_ACTIVITY_ENABLE 0`），并新增 10 分钟/30 页级输出的**真 GC16 清理**（`DISPLAY_LIGHT_CLEANUP_*`，`display.c:1126-1160`、`:1586-1587`），时间触发前置为「自上次真清理以来至少 1 次任意浅色输出」→ 覆盖主页停留。

### 3.4 阅读（水波纹·高清 effect 3）：差分翻页累积，清理只有页数触发

- 翻页：`turn_page()`（`app_book.c:8289`）在 effect 3 下设置 `s_water_turn_pending`，`present()` 的 `APP_REDRAW_AREA` 分支调 `update_display_water_turn_hd()`（`app_book.c:6430-6433`）→ `display.c` `update_display_hd_water_unlocked()`；揭页引擎差分驱动（§3.1），**只有 `front != back` 的像素被驱动**。
- 全页文本重排后，上一页旧笔画变白的像素只吃一次「黑→白」迁移，残影留在白底；**没有任何逐页复位**（水波纹高清是单次揭页扫描、不追加第二遍定稿，`app_book.c:6425-6429` 注释明确）。
- 唯一的清理：`turn_page()` 里 `s_turns` 累计到 `app_settings_reader_full_pages()` 时 `s_reader_cleanup=true`（`app_book.c:8318-8322`），下一次 `present()` 走浅色分支 `update_display_area_full_with(ctx->hl, &E0470_FULL_WAVEFORM, MODE_GC16, reader_full_rect())`（`app_book.c:6371-6386`；`reader_full_rect()` 为整逻辑画布，`app_book.c:777`）。这是真正 GC16 擦写，能清残影。
- 问题：默认 15 页（`settings.c` 工作树现为 10）才一次；**只按页数、没有时间上界**。慢读（1 页/几分钟）或在一页上停留很久的用户，残影可以在白底留几十分钟；快速连翻则在两次清理之间累积最多 N 页的残影。用户主诉「翻几页就有上一页黑字」与之吻合。
- 次要路径（用户不是这条）：默认「普通·快刷」effect 0 用 `display_reader_fast_text_prepare()` 二值化 + 原厂 DU 20 相（`display_reader_waveform.c:88-121`），DU 无擦除，残影更强；本修复的周期清理同样覆盖它。

### 3.5 面板层 AA 全像素定稿（1.15.22）不是残影清理

- `app_book.c:6466-6474`：正文 ↔ 工具栏/sheet 层级切换时对 `reader_full_rect()` 做 `update_display_area_full_with(display_aa_repair_waveform(), MODE_GL16, ...)`。
- `display_aa_repair_waveform()`（`display_main_waveform.c:135-150`）只在 GL16 表里驱动「等灰对中灰 1..14」，纯黑 0→0、纯白 15→15 保持 → **不驱动白底（不清理）、不对黑白残影起作用**，只是重驱动 AA 边缘；对 AA 边是「每次面板切换多推 25–31 帧」的过驱动来源（`ghost-display` 已判定并给 Lead 改为差分 GL16 的补丁，见 §6/§8）。
- 结论：它不是主页/阅读白底黑字残影的来源，但也**不是**清理；页面层修复不依赖它。

---

## 4. 数值/波形证据

### 4.1 差分路径（为什么未变化像素永远不驱动）

- `epd_difference_image_cropped` + `MODE_PACKING_1PPB_DIFFERENCE`：差分值 0 的像素在 LUT 里是「保持」（`epdiy` `hl_update_area()` 只回写 `dirty_lines` 覆盖到的行，`components/epdiy/src/highlevel.c:206-286`；揭页引擎 `e0470_page_turn.c:323-325`、`:368-377`）。
- 因此「上一屏黑字→本屏白底」这类像素只在变化那一帧被驱动一次；之后 `front == back == 白`，**差值恒 0，永远不会再被驱动**。

### 4.2 真 GC16（48 相未裁剪表）对等灰对做了什么

解析 `components/e0470_epaper_waveform/waveforms/gc16.h`（`E0470_FULL_GC16_FRAMES=48`，2-bit 动作：0 保持 / 1 压黑 / 2 白推）：

| (to, from) | 动作序列（去掉首尾保持） | 含义 |
| --- | --- | --- |
| (15,15) 白→白 | 18 帧压黑 + 17 帧白推 | 完整擦写循环：先把像素拉到黑轨再白饱和 → **能清掉白底上残留的黑** |
| (0,0) 黑→黑 | 18 帧白推 + 17 帧压黑 | 完整擦写循环 → 恢复墨色 |
| (7,7) 中灰→中灰 | 约 19 白 + 19 黑 + 灰阶尾 | 完整循环 |

裁剪默认表（`E0470_TRIM_ERASE_MAX=11`、`E0470_TRIM_SAT_CUT=5`、`E0470_TRIM_WHITE_SAT_CUT=0`、`E0470_TRIM_HOLD=3`，`components/e0470_epaper_waveform/include/e0470_epaper_waveform.h:62-65`）把擦除段从最多 19 相裁到 11 相；`e0470_waveform_trim.h` 顶部注释原文：

> 「代价是擦除余量变小，旧内容的残影会先出来，所以参数要上机看着残影调。」

→ **清理动作必须用 `E0470_FULL_WAVEFORM`（48 相未裁剪），不要用 `E0470_WAVEFORM`（36 相裁剪）**；本任务主页清理与阅读周期清理均使用 FULL 表（阅读原实现已经是 FULL 表，`app_book.c:6349/6383`）。

### 4.3 全像素 GL16 重推为什么不是清理（1.15.22 活动期机制的缺陷）

- 源表 `waveforms/gl16.h` 的 `(15,15)` 是**全保持**；`e0470_gl16_white_tick()` 只额外挂 **1 帧**白推（`e0470_epaper_waveform.c:143-154`，并在 `:311-312` 对完整表/裁剪表各执行一次）。→ 全像素 GL16 重推对未变化白底只有 1 帧白推，**清不掉黑字残影**。
- 同一张表 `(0,0)` 却是「18 帧白推 + 18 帧压黑」的整循环（未变化黑字被反复擦白再压黑），中灰 25–31 帧 → 反复施加 = **过驱动/残余电荷累积**（与 1.13.1 白天补白、1.15.18 取消反复压黑补扫同款教训）。
- 结论：显示层队友已把 1.15.22 活动期 GL16 重推默认停用（`DISPLAY_LIGHT_ACTIVITY_ENABLE 0`），页面层修复不依赖它。

---

## 5. 主页修复实现（`main/apps/app_dashboard.c`，我落盘）

### 5.1 改动点

| 位置（当前行号） | 改动 |
| --- | --- |
| 文件头用户修订注释 27-35 | 记录浅色残影修复说明（中英） |
| 150-169 | 新增 `s_home_cleanup_once`（浅色进入主页首帧复位）、`s_home_cleanup_area`/`s_home_cleanup_ms`（备用停留清理）、`HOME_GHOST_DWELL_CLEANUP`（默认 0）/`HOME_GHOST_DWELL_MS` |
| 947-977 | 新增 `home_ghost_cleanup(ctx, whole)`：`E0470_FULL_WAVEFORM + MODE_GC16` 内容区/整屏真 GC16；内容区模式随后重画底栏目标并对底栏条带做 FOLLOW/DU 差分 |
| 977-998 | `present()` 顶部新增「备用停留清理」分支（默认关闭，仅 tick 请求时生效） |
| 1054-1068 | 整页呈现分支顺序：显式 `APP_REDRAW_FULL`（开机首帧/KEY2/夜间反色）→ **浅色进入主页 48 相 GC16**（整屏或内容区）→ 旧 `首页强刷` 兜底 → 普通 `update_display_fast_page` |
| 1084-1103 | `on_enter()`：浅色进入主页时置 `s_home_cleanup_once`、复位停留计时；反色不置 |
| 1181-1276 | `on_tick()` 末尾新增备用停留清理触发（仅 `HOME_GHOST_DWELL_CLEANUP > 0` 且浅色且主页根视图且无按压时） |

### 5.2 关键代码（节选，实际代码见文件）

```c
static enum EpdDrawError home_ghost_cleanup(app_ctx_t *ctx, bool whole) {
    const int width=epd_rotated_display_width();
    const int height=epd_rotated_display_height();
    if(whole) {
        display_main_transition_cancel();
        const EpdRect full={0,0,width,height};
        return update_display_area_full_with(ctx->hl,&E0470_FULL_WAVEFORM,MODE_GC16,full);
    }
    const EpdRect body={0,0,width,UI_NAV_REFRESH_END};
    enum EpdDrawError result=update_display_area_full_with(ctx->hl,&E0470_FULL_WAVEFORM,MODE_GC16,body);
    if(result!=EPD_DRAW_SUCCESS)return result;
    ui_nav_draw(ctx->fb,0);
    const EpdRect footer={0,UI_NAV_REFRESH_END,width,height-UI_NAV_REFRESH_END};
    return update_display_area_diff_with(ctx->hl,&E0470_FOLLOW_WAVEFORM,MODE_DU,footer);
}
```

`present()` 中（`app_dashboard.c:1054-1068`）：

```c
else if(redraw==APP_REDRAW_FULL) {...update_display_full...}
else if(s_home_cleanup_once) {
    const bool whole=s_home_force_full_once;     // 「首页强刷」设置（当前工作树默认 true）
    s_home_force_full_once=false;s_home_cleanup_once=false;
    result=home_ghost_cleanup(ctx,whole);
    if(result==EPD_DRAW_NO_PHASES_AVAILABLE){render(ctx,ctx->fb);result=update_display_fast_page(ctx->hl);}
}
else if(s_home_force_full_once) {...update_display_full...}
else result=update_display_fast_page(ctx->hl);
```

### 5.3 为什么这样能清残影、代价多大

- **能清**：内容区/整屏全像素 48 相 GC16 对 `(15,15)` 执行「18 压黑 + 17 白推」完整擦写（§4.2）——这正是白底残留黑字的清除手段；GC16 结束会提交 back 基准，之后差分从干净基准开始。
- **代价**：
  - 「首页强刷」开启（当前默认）：每次进主页一次整屏 48 相 GC16 ≈ **48×11090us ≈ 0.53s** 的可见全屏闪（含底栏）；比旧默认 `update_display_full()` 的 36 相裁剪表（≈0.40s）略长但擦除余量大 7 相。
  - 设置关闭：内容区一次 48 相 GC16（≈0.53s，闪屏区域不含底栏）+ 底栏条带 FOLLOW/DU 差分（8 帧 ≈ 50–90ms，只扫变化行）→ 总时长与整屏接近，但底栏图标/文字不闪。
  - 每次进主页最多一次全刷，不改变主页内部的局部刷新节奏；显示层页级 GC16 计数会因这次清理归零（`display.c:1586-1587`），**不会在同一时刻再叠一次显示层整屏 GC16**。
- **可回滚**：「首页强刷」设置关掉即退回内容区清理；若要完全停用页面层进入清理，把 `s_home_cleanup_once=!epd_get_inverted()` 一行注释掉即可（或用后续 1.15.23 的宏化，见 §9）。

---

## 6. 与显示层（ghost-display，task-6）的分工与防叠加

显示层已落盘（`display.c/display.h`，他们的报告 `docs/analysis/11523_issue_ghost_display.md`）：

1. 1.15.22 活动期全像素 GL16 重推：**默认停用**（`display.h` `DISPLAY_LIGHT_ACTIVITY_ENABLE 0`，旧阈值保留可回滚）。
2. 新增浅色真 GC16 清理：整屏全像素 `E0470_FULL_WAVEFORM + MODE_GC16`（48 相，≈0.47–0.57s），触发 `DISPLAY_LIGHT_CLEANUP_PAGE_EVERY 30`（页级输出）**OR** `DISPLAY_LIGHT_CLEANUP_INTERVAL_MS 600000`（10 分钟，前置「自上次真清理以来至少 1 次任意浅色输出」，局部刷新也算——本任务要求的「主页停留缺口」已补）。
3. 任何**页级 full-pixel GC16 成功**（面积 ≥ 50% 画布，`display.c:1586-1587`）都会把显示层页计数+计时清零 → 我的主页进入清理（内容区 89% 或整屏 100%）会归零显示层计时，不会叠加双闪；阅读每 10 页清理同样归零。
4. 反色模式零改动（显示层维护第一行 `if (epd_get_inverted()) return;`，`display.c:1127-1130` 附近）。

因此：**主页进入清理**归页面层（本任务）；**主页停留/各页面长期停留**归显示层 10 分钟真 GC16；页面层 `HOME_GHOST_DWELL_CLEANUP` 默认 0，只在 `DISPLAY_LIGHT_CLEANUP_ENABLE=0` 时由 Lead 置 1 使用（此时 5 分钟触发会顺带把显示层计时清零，不会与它叠加）。

---

## 7. 工作树中已存在的 `settings.c` 改动（非本任务改动，需 Lead 确认保留）

当前工作树的 `main/settings.c`/`settings.h` 已包含与我/显示层建议一致的默认值改动（**不是我改的**）：

- `settings.c:137`：`static bool s_home_full_refresh = true;`（「首页强刷」默认开启，注释写明浅色主页残影修复）；`settings.h:37-39` 注释同步。→ 我的 `home_ghost_cleanup(whole=true)` 因此在当前默认下走整屏 48 相 GC16。
- `settings.c:182`、`:406`：`s_reader_full_pages` 默认 **15→10**（`settings.h:158-159` 注释同步）；这正是本任务建议的「缩短默认清理间隔」，用户仍可选 5/10/15/30/关（`app_book.c:8904` options）。

**建议**：
- `s_reader_full_pages` 默认 **10 保留**（本任务建议的「缩短默认清理间隔」，用户仍可选 5/10/15/30/关）。
- `s_home_full_refresh` 默认 **true 建议改回 false**：本任务已在 `app_dashboard.c` 里保证「浅色进入主页必做一次 48 相 GC16」，不依赖该设置；而该项为 true 时：
  - 浅色进入主页会走「整屏 48 相 GC16」（我的实现仍会清残影，但每次回主页整屏闪，体验不如内容区路径）；
  - **反色/深色进入主页会走 `update_display_full()` 的深色整屏复位（黑闪，≈0.5s）**——这是 1.15.22 没有的行为，等于改变了深色路径的进入手感（虽然复位本身仍是深色契约内的真复位）。
  若 Lead 认为深色进入主页做一次复位可以接受，保留 true 也能工作；若要严格保持深色既有手感，改回 false 即可（我的 `home_ghost_cleanup(whole=false)` 路径不受影响）。

---

## 8. 阅读 `app_book.c` 精确补丁（交 Lead 应用；我不写该文件）

补丁已在**临时副本**上做过语法检查（`C:\dshb\tmp\apply_book_patch.py` → `C:\dshb\tmp\app_book_patched.c`，`syntax_check.py` **exit 0**；唯一 warning `unused variable 'remove_rect'` 是 app_book.c 既有警告，与补丁无关）。以下定位串均为**唯一定位串**，按顺序应用即可（行号为当前工作树）。

### H1：新增清理时间戳与时间阈值（定位：`static int64_t s_poll_ms, s_last_turn_ms;` 两行）

定位串：

```c
static int64_t s_poll_ms, s_last_turn_ms;
static int64_t s_stats_last_ms, s_stats_activity_ms;
```

替换为：

```c
static int64_t s_poll_ms, s_last_turn_ms;
static int64_t s_stats_last_ms, s_stats_activity_ms;
// 浅色阅读上一次真正整屏 GC16 的时刻（0 = 尚未清理）。水波纹高清/GL16 只驱动变化像素，
// 白底上的旧黑字残影只有整屏 GC16 能清掉；页数没到但慢读/停留超过 READER_CLEANUP_INTERVAL_MS
// 时，本次翻页也做一次整屏 GC16，避免残影一直留到页数到点。
// Time of the last real light-mode reader full-screen GC16 (0 = none yet). HD water/GL16 turns drive
// only changed pixels, so old black-text residue on the white ground only a full-screen GC16 can
// clear; when the page count has not been reached but slow reading/dwell exceeds
// READER_CLEANUP_INTERVAL_MS this turn also runs one, instead of waiting for the count.
#define READER_CLEANUP_INTERVAL_MS 600000
static int64_t s_reader_cleanup_ms;
```

### H2：进书（打开成功）重置清理时刻（定位：`s_reader_notice[0] = 0;` 附近）

定位串：

```c
    s_reader_notice[0] = 0;
    s_turns = s_unsaved = 0;
    pending_mark_latest(s_path);
```

替换为：

```c
    s_reader_notice[0] = 0;
    s_turns = s_unsaved = 0;
    // 进书首帧本身就是一次整屏 GC16（present 的 reader_entry 分支），这里同步清理时刻。
    // The first reader frame already runs one full-screen GC16 (present's reader_entry branch), so
    // restart the cleanup clock here as well.
    s_reader_cleanup_ms = ctx->now_ms;
    pending_mark_latest(s_path);
```

### H3：周期清理改为「页数 OR 时间」双触发（定位：`turn_page()` 里 5 行计数块）

定位串：

```c
    uint8_t full_pages = app_settings_reader_full_pages();
    if (full_pages) ++s_turns;
    else s_turns = 0;
    s_reader_cleanup = full_pages > 0 && s_turns >= full_pages;
    if (s_reader_cleanup) s_turns = 0;
```

替换为：

```c
    uint8_t full_pages = app_settings_reader_full_pages();
    if (full_pages) ++s_turns;
    else s_turns = 0;
    // 页数到点，或距上次真 GC16 已满 READER_CLEANUP_INTERVAL_MS（慢读/久停）都清理一次：水波纹高清
    // 与普通 GL16 翻页是差分驱动，白底上的旧黑字残影只有整屏 GC16 擦写能清掉。反色模式保持原周期与
    // 压黑契约，不进入时间触发。
    // Cleanup fires on the page count, or once READER_CLEANUP_INTERVAL_MS has elapsed since the last real
    // GC16 (slow reading / long dwell): HD water and ordinary GL16 turns are differential, so old
    // black-text residue on the white ground only a full-screen GC16 erase/write can clear. Inverted
    // mode keeps its original cadence and darken contract and never takes the time trigger.
    const bool reader_stale = !epd_get_inverted() && full_pages > 0 && s_reader_cleanup_ms > 0 &&
        ctx->now_ms - s_reader_cleanup_ms >= READER_CLEANUP_INTERVAL_MS;
    s_reader_cleanup = full_pages > 0 && (s_turns >= full_pages || reader_stale);
    if (s_reader_cleanup) { s_turns = 0; s_reader_cleanup_ms = ctx->now_ms; }
```

### H4：手动强刷重置清理时刻（定位：`reader_manual_refresh()`）

定位串：

```c
    s_water_turn_pending = s_reader_cleanup = false;
    s_du_count = s_turns = 0;
    invalidate_prep();
    return APP_REDRAW_FULL;
```

替换为：

```c
    s_water_turn_pending = s_reader_cleanup = false;
    s_du_count = s_turns = 0;
    // 手动强刷本身就是整屏 GC16 复位，清理时刻同步重置。
    // A manual full refresh already is a whole-screen GC16 reset; restart the cleanup clock too.
    s_reader_cleanup_ms = ctx->now_ms;
    invalidate_prep();
    return APP_REDRAW_FULL;
```

### H5：改「自动全屏」设置（页数）时重置清理时刻（定位：`reading_settings_action()` 第一段）

定位串：

```c
        app_settings_set_reader_full_pages(options[next]);
        s_turns = 0;
```

替换为：

```c
        app_settings_set_reader_full_pages(options[next]);
        s_turns = 0;
        s_reader_cleanup_ms = ctx->now_ms;
```

### H6：回正文（reader_entry 成功）重置清理时刻（定位：`present()` 尾部）

定位串：

```c
    if(err==EPD_DRAW_SUCCESS) {
        s_presented_view = (int)s_view;
        s_presented_panel = s_reader_panel;
        if(reader_entry)s_turns=0;
    }
```

替换为：

```c
    if(err==EPD_DRAW_SUCCESS) {
        s_presented_view = (int)s_view;
        s_presented_panel = s_reader_panel;
        // 进书/TOC 回正文的首帧已经做过整屏 GC16，清理时刻同步重置。
        // The reader entry / TOC-return frame already ran a whole-screen GC16; restart the clock too.
        if(reader_entry){s_turns=0;s_reader_cleanup_ms=ctx->now_ms;}
    }
```

### H7：切换翻页效果时重置清理时刻（定位：`reading_settings_action()` 第二段注释）

定位串：

```c
        // Start a fresh cleanup cycle so the first turn does not inherit the previous effect's cleanup debt.
        s_turns=0;
```

替换为：

```c
        // Start a fresh cleanup cycle so the first turn does not inherit the previous effect's cleanup debt.
        s_turns=0;
        s_reader_cleanup_ms = ctx->now_ms;
```

**理由/影响**：默认每 10 页（`settings.c` 已改）或距上次真 GC16 满 10 分钟的下一次翻页，`present()` 会走现有浅色清理分支做一次 `E0470_FULL_WAVEFORM + MODE_GC16` 整屏擦写（`app_book.c:6371-6386`），把白底黑字残影清掉；该次翻页不再播水波纹动画（预期行为，用一次整屏刷新替代）。反色模式不进入时间触发，周期仍按用户设置（默认 10 页，较旧 15 页略频繁，属全局默认改动的副作用，若要严格保持反色 15 页可再给反色单独下限，建议先不动）。`READER_CLEANUP_INTERVAL_MS=600000` 可按真机反馈调（1200000 更省闪屏、600000 更积极）。

---

## 9. 回滚开关汇总

| 层 | 开关 | 默认 | 作用 |
| --- | --- | --- | --- |
| 页面层主页 | 设置「首页强刷」`app_settings_home_full_refresh()`（`settings.c:137`） | true（工作树已改） | true=进入主页整屏 48 相 GC16；false=内容区 48 相 GC16 + 底栏条带差分 |
| 页面层主页 | `HOME_GHOST_DWELL_CLEANUP`（`app_dashboard.c:166`） | 0（关） | 显示层清理关闭时的备用主页停留清理（5 分钟） |
| 页面层阅读 | `READER_CLEANUP_INTERVAL_MS`（app_book 补丁 H1） | 600000 | 时间触发上限；调大更省闪屏 |
| 页面层阅读 | 设置「自动全屏」页数（`settings.c:182/406`） | 10 | 用户可改 5/10/15/30/关 |
| 显示层 | `DISPLAY_LIGHT_CLEANUP_ENABLE` / `PAGE_EVERY` / `INTERVAL_MS` | 1 / 30 / 600000 | ghost-display 的整屏真 GC16 清理 |
| 显示层 | `DISPLAY_LIGHT_ACTIVITY_ENABLE` | 0 | 1.15.22 活动期 GL16 重推（回滚用） |

---

## 10. 验证

- 单文件语法检查（ESP-IDF 工程真实编译参数，`-fsyntax-only`，不写对象、不碰 build/）：

  ```
  C:\dshb\pyenv-idf\Scripts\python.exe C:\dshb\syntax_check.py main/apps/app_dashboard.c
  → syntax check: ...\main\apps\app_dashboard.c
    exit: 0
  ```

- app_book.c 补丁：在临时副本（`C:\dshb\tmp\app_book_patched.c`，由 `C:\dshb\tmp\apply_book_patch.py` 对当前工作树 `app_book.c` 应用 H1–H7 生成）上 `syntax_check.py` **exit 0**；唯一 warning 为 app_book.c 既有 `unused variable 'remove_rect'`，与本补丁无关。**工作树 `app_book.c` 未被修改**，等 Lead 应用。
- 未跑 `idf.py build`（按任务纪律由 Lead 统一构建）、未真机验证。
- 静态自检：
  - 反色路径：`on_enter` 的清理门控 `!epd_get_inverted()`；app_book 时间触发 `!epd_get_inverted()`；显示层清理自身有反色 return。反色逐页压黑/整屏复位/深→浅首帧擦白均未动。
  - 未改 UI 字面量/日志字符串（新增只有注释；无新增日志）。
  - 未改冻结文件、未新增动态内存（仅 2 个 bool + 1 个 int64 静态量在 dashboard，1 个 int64 + 1 个宏在 app_book）。
  - 主页进入清理使用公开 API（`update_display_area_full_with`/`update_display_area_diff_with`/`display_main_transition_cancel`），未改 display.c/h。
  - 失败兜底：主页清理 `EPD_DRAW_NO_PHASES_AVAILABLE` 时重画并按普通差分推屏；其它错误由 `guard_draw_result` 的欠载恢复处理。

---

## 11. 风险与真机待验

**风险**

1. **闪屏频率/时长**：「首页强刷」默认开启时每次回主页一次整屏 48 相 GC16 ≈0.53s；阅读每 10 页一次整屏 GC16（旧 15 页）。用户若觉得「每次回首页都闪」：把「首页强刷」关掉（→内容区 48 相 + 底栏不闪），或把「自动全屏」调 15/30。这是本修复的主要体验代价。
2. **续航/电源循环**：阅读默认从 15 页改 10 页，整屏 GC16 次数 +50%；主页每次进入多一次全刷。e-ink 全刷功耗与一次普通刷新同量级，预计可接受，需真机看续航与体感。
3. **慢读时间触发**：慢读用户可能每 ≈10 分钟看到一次整屏闪；若太频繁调大 `READER_CLEANUP_INTERVAL_MS`。
4. **1.15.22 不回退**：本修复不改 1.15.22 的淡墨/AA/书架/最近阅读/传书/蓝牙逻辑；AA 面板定稿的「差分 GL16」改动由 `ghost-display` 提供补丁，两补丁在 app_book.c 不同区域，可叠加。
5. **设置已存在的改动**：`settings.c` 的 `home_full=true`/`full_pages=10` 非本任务落盘。若 Lead 决定把 `home_full` 改回 false，我的实现自动走「内容区 48 相 GC16 + 底栏差分」路径（仍修复残影）；阅读回到 15 页时时间触发仍生效。**特别注意**：`home_full=true` 会让反色/深色进入主页也走 `update_display_full()` 深色整屏复位（黑闪，≈0.5s），这是 1.15.22 没有的进入手感，建议随 1.15.23 一并确认（§7）。
6. **未真机**：所有结论来自代码/波形静态分析；水波纹高清 + 48 相 GC16 在实屏的擦除效果、闪屏观感必须真机确认。

**真机待验（必须，无真机结论）**

1. 浅色：阅读「水波纹·高清」读 5–10 页 → 按 Home/返回进主页：首帧应有一次内容区/整屏 GC16（白底干净、无上一页黑字残影）；反复「主页↔阅读↔书架」切换 10 次，主页不再累积残影。
2. 浅色主页停留 10–20 分钟（不动或只点局部）：显示层 10 分钟整屏 GC16 触发一次，主页时钟/日历区域残影被清；观察闪屏时机是否可接受（时间触发不应在久置休眠后立刻闪）。
3. 浅色阅读连翻 30–60 页（水波纹高清）：每 10 页一次整屏 GC16，白底黑字残影不随页数累积；第 10 页的翻页不再播水波纹、直接整屏复位是否可接受。
4. 慢读场景：一页停留 >10 分钟后翻页，应触发一次整屏 GC16（本次翻页无动画）。
5. 设置项回归：「自动全屏」改 5/10/15/30/关；「首页强刷」开/关各验一次（开=整屏闪、关=内容区闪+底栏不动，二者主页都无残影）。
6. 反色/深色回归（不得回退）：切反色后阅读翻页仍逐页压黑、到页/手动全刷仍真 GC16 复位、深色退出后浅色首帧仍先擦白再 GC16、夜间自动反色跨 21:00/07:00 正常。
7. 阅读进入/退出（TOC 回正文、章内跳转、手动强刷、面板开关）无布局/进度/闪烁异常；AA 面板补丁合入后正文 AA 正常。
8. 横屏阅读（水波纹高清）翻页/清理正常；清屏/切书无残影。
9. 开机首帧仍整屏 GC16（不因主页清理分支多刷一次或漏刷）；开机进主页无异常。
10. 若仍有残影：记录「哪个页面/深浅色/竖横屏/操作序列（翻几页/停留多久/从哪个页面返回）」，先确认是页面进入残影还是同页累积残影；不要用全像素 GL16 重推「压一压」（会过驱动）。

---

## 12. 分析/验证工件（临时，位于构建工作区 tmp/，不入库）

- `C:\dshb\tmp\apply_book_patch.py`：把 §8 的 H1–H7 应用到 app_book.c 副本并报告每个定位串命中次数（全部 exactly 1）；
- `C:\dshb\tmp\app_book_patched.c`：应用后的临时副本（仅用于 syntax_check，未写回工作树）。

---

## 13. 给 Lead 的集成清单

1. 应用 §8 的 app_book.c 补丁 H1–H7（与 `ghost-display` 的 AA 定稿→差分 GL16 补丁不冲突）；应用后 `syntax_check.py main/apps/app_book.c`（预期 exit 0）。
2. 确认 `settings.c` 现有默认（`home_full=true`、`full_pages=10`）是否为 1.15.23 期望值：
   - `full_pages=10` 建议保留；
   - `home_full=true` 建议改回 **false**（理由见 §7：浅色进入主页已由本任务代码兜底；true 会让深色进入主页也整屏复位/黑闪，改变深色进入手感，且浅色会整屏闪）。如保留 true，我的实现走整屏 48 相 GC16，同样能清残影。
3. 合并 `ghost-display` 的 display.c/h（`DISPLAY_LIGHT_ACTIVITY_ENABLE 0` + `DISPLAY_LIGHT_CLEANUP_*` 真 GC16 清理）；两层的全刷计数已约定互相归零（`display.c:1586-1587`），不会双闪。
4. 版本/说明书：建议 1.15.23 修复条目写「修复浅色模式主页/阅读白底黑字残影：进入主页做一次真正的 GC16 复位，阅读自动全刷默认 15→10 页并增加 10 分钟兜底，显示层低频真 GC16 清理替代非复位的全像素 GL16 重推」。
5. 真机验收按 §11 第 1–10 项执行；本环境无真机，不得声称真机通过。
