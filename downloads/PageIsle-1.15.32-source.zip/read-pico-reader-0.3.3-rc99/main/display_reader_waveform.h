/* SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include "epdiy.h"
#include <stdbool.h>

/// 柔和文字序列：白底到中灰的少量回浅脉冲提前；具体阅读模式由板级出口选择。
/// Soft text phases advance a few gray-edge settling pulses; board output selects the reading modes that use them.
const EpdWaveform* display_reader_text_waveform(void);

/// 速读黑白：复用原厂完整 DU 表（20 相，含末尾保持相），不改表、不调脉宽。
/// Fast BW: the vendor's complete DU table (20 phases, trailing holds included), tables and pulse widths untouched.
const EpdWaveform* display_reader_fast_text_waveform(void);

/// 速读黑白准备：把本轮正文/页脚目标区域（逻辑坐标）按 50% 阈值改成纯黑白，
/// 真实旧灰阶与区域外像素保持不动；返回 false 时调用方回退普通 GL16 差分。
/// Fast BW prepare: threshold this turn's body/footer target area to pure BW at 50%, leaving real
/// old grays and outside pixels untouched; false means the caller falls back to plain GL16 diff.
bool display_reader_fast_text_prepare(EpdiyHighlevelState* hl, EpdRect area);
