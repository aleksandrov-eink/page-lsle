/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 刷屏出口：按模式推屏、HV 轨空闲下电、pclk 欠载回退。
 *
 * Present path: push by mode, drop HV rails on idle, fall back pclk on
 * underrun.
 * 用户继续优化快刷响应：无灰阶条带时按32位并行归一八像素，已为黑白的字不重复写PSRAM；不删相位、不增加缓存或改变清残影和底栏边界。
 * User continues fast responsiveness tuning: normalize eight pixels per 32-bit word when no gray bands exist and avoid rewriting binary PSRAM words; retain phases, cleanup and navigation bounds without extra caches.
 * 用户修订：三种主页模式均固定底栏，仅局部移动横条；普通切页复用柔和灰阶表，黑白端点单向驱动、等灰保持，中灰保留校准相位。取消每三次全像素整理，仍每十二次完整清残影。快刷棋盘格输出、首次进入、解锁及手动全刷不变，不得伪造back。
 * User revision: all main modes retain navigation with local markers; ordinary transitions reuse soft grays with directional BW endpoints, held equal grays and calibrated changed midgrays. Remove third-page full-pixel settling but retain twelfth-page cleanup. Fast checkerboards, initial entry, unlock and manual full output remain; never fabricate back.
 * 用户2026-10-21恢复rc96显示/残影控制，保留127行预填防欠载和侧滑方向；普通阅读采用原rc97直接差分。
 * User revision 2026-10-21: restore rc96 display/cleanup, keeping 127-line underrun protection and directional back swipes; ordinary reading uses rc97 direct differences.
 * 用户2026-10-21残影反馈：普通文字改用校准GL16完整迁移并保持等灰像素，水波纹继续柔和文字序列；不增加相数或第二轮输出。
 * User ghosting feedback 2026-10-21: ordinary text uses calibrated GL16 transitions with equal-gray holds; ripple keeps soft text phases, without added phases or replay.
 * 用户修订：所有推屏及欠载恢复与 OTA 擦写共用递归锁；无升级任务时保持原波形、范围和节奏。
 * User revision: serialize all display output and underrun recovery with OTA flash operations; keep existing waveforms, bounds and cadence outside updates.
 * 用户要求加快主页水波纹：复用阅读的一拍一带调度，以8带37相共44拍、11090us完成；保留主页原灰阶序列、底栏边界、OTA锁及失败恢复。
 * User requests faster main-page ripple: reuse reader-style compact launches for eight bands/37 phases over 44 ticks at 11090us; retain main gray sequences, navigation bounds, OTA locking and recovery.
 * 用户修订：书架顶部文字、框线与封面/亚克力一起使用水波纹，不再拆分顶部差分刷新；底栏仍固定。
 * User revision: shelf headers, frames, covers and acrylic share one ripple instead of a separate header differential; navigation remains fixed.

 * 用户修订：普通书架上下文字区和中间书架区同一轮逐相输出，外侧柔和、封面/材质保留校准灰阶，留白仅向白擦除；不串行呈现分区。仅横条可变，底栏图标固定，保留统一故障恢复。
 * User revision: ordinary shelf chrome and art share each scan phase, with soft outer text, calibrated covers/furniture and directional whitespace erasure; never reveal regions serially. Only the marker may change within frozen navigation; retain common fault recovery.
 * 用户修订：纯文字水波纹复用柔和文字序列，保持未变灰边、减轻先粗后浅；8带/11090us、最终灰阶、主页水波纹和故障恢复保持。
 * User revision: pure-text ripple reuses soft text phases to hold unchanged grays and reduce dark-edge transients; retain eight bands/11090us, target grays, main ripple and fault recovery.

 */

#include "display.h"
#include "read_pico_board.h"
#include "ota_online.h"
#include "continuous_du.h"

#include <stdbool.h>
#include <stdint.h>
#include "app_config.h"
#include "e0470_epaper_waveform.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "settings.h"

#include <string.h>
#include "esp_heap_caps.h"
#include "display_main_waveform.h"
#include "display_reader_waveform.h"
#include "ui/ui_nav_layout.h"

static const char* TAG = "read_pico";
static bool s_bulk_io;
static bool s_full_refresh_requested;
// 从深色切回浅色后的第一帧：先整屏擦白再用 GC16 重写，清掉深色期间积累的残余电荷，
// 解决「开启深色模式过后白色模式淡墨」。
// First light-mode frame after leaving dark mode: wipe the panel to white then rewrite with GC16,
// clearing the charge accumulated in dark mode (the "faded ink after dark mode" report).
static bool s_light_white_reset_pending;
// 浅色活动期防淡墨的计数与时间戳，含义见 display.h 的 DISPLAY_LIGHT_ACTIVITY_* 说明。
// Light-mode activity anti-fade counters/timestamp; see DISPLAY_LIGHT_ACTIVITY_* in display.h.
// 1.15.23 起该路径默认停用（宏可回滚），计数仍保留给 A/B。
// Disabled by default since 1.15.23 (macro rollback); the counters stay for A/B.
static unsigned s_light_activity_page_ops;
static unsigned s_light_activity_area_ops;
static unsigned s_light_activity_settles;
static int64_t s_light_activity_last_ms;
// 浅色真 GC16 清理的页级输出计数与时间戳，含义见 display.h 的 DISPLAY_LIGHT_CLEANUP_* 说明。
// Light-mode real-GC16 cleanup page counter/timestamp; see DISPLAY_LIGHT_CLEANUP_* in display.h.
static unsigned s_light_cleanup_page_ops;
static int64_t s_light_cleanup_last_ms;
// 自上次真清理以来是否出现过任意浅色输出（页级或局部），以及上一次输出的时间戳。局部输出也要
// 计入“使用中”：主页停留只有时钟/秒针的局部差分；长时间无输出的空档则从下一次输出重新计时。
// Whether any light-mode output (page-level or partial) happened since the last real cleanup, and the
// previous output timestamp. Partial outputs count as "in use" too (home idle only runs clock/second
// diffs); an output-free gap restarts the interval from the next output.
static bool s_light_cleanup_activity_seen;
static int64_t s_light_cleanup_last_output_ms;
void display_request_full_refresh(void) { s_full_refresh_requested = true; }

// 深色→浅色首帧复位、浅色维护（调用方已持显示锁）。
// Dark->light first-frame reset and light-mode maintenance (caller already holds the display lock).
static enum EpdDrawError display_light_white_reset_unlocked(EpdiyHighlevelState* hl);
static void display_light_activity_reset(void);
static void display_light_activity_tick_unlocked(EpdiyHighlevelState* hl, EpdRect area, bool full_cleanup);
static void display_light_maintenance_reset(void);
static void display_light_maintenance_tick_unlocked(EpdiyHighlevelState* hl, EpdRect area, bool full_cleanup);
static enum EpdDrawError display_light_gc16_cleanup_unlocked(EpdiyHighlevelState* hl);

// 反色压黑清理（调用方已持显示锁）。/ Inverted-mode darken settle (caller already holds the display lock).
static bool display_dark_settle_unlocked(EpdiyHighlevelState* hl);
// 反色压黑清理（指定帧数，供例行清理加强）。/ Darken settle with an explicit frame count for periodic cleanup.
static bool display_dark_settle_frames_unlocked(EpdiyHighlevelState* hl, int frames);
// 反色整屏清理：先全屏压黑再按「逻辑全黑」基准重绘内容（黑闪，非白闪）。
// Inverted full cleanup: darken the whole panel, then repaint from a logical-black baseline (black flash, never white).
static bool display_dark_refresh_unlocked(EpdiyHighlevelState* hl);
// 例行清理用的压黑帧数：8 帧是翻页级强度，16 帧给到页/主页周期清理更强的残影重推。
// Darken frame count for routine cleanup: 8 frames is turn-level strength; 16 gives page-count and
// home periodic cleanup a stronger residue push.
#define DISPLAY_DARK_CLEANUP_FRAMES 16
// 翻页/滑动级的压黑帧数（8 帧≈89ms，恢复 1.15.17 之前的反黑算法强度）。
// Turn/swipe-level darken frames (8 frames ≈ 89 ms, restoring the pre-1.15.18 darken strength).
#define DISPLAY_DARK_SETTLE_FRAMES 8

void display_set_inverted(EpdiyHighlevelState* hl, bool inverted) {    if (epd_get_inverted() == inverted) return;
    epd_set_inverted(inverted);
    // 水波纹/高清翻页自己缓存整套相位 LUT，换反色方向必须整份重建。
    // Ripple/HD turns cache their whole phase-LUT set, so rebuild it for the new direction.
    e0470_page_turn_release();
    epd_leading_skip_discard();
    if (hl != NULL) {
        // 反色只换解释方式，帧缓冲仍是逻辑灰阶；把 back 基准换算到同一物理画面在新映射下的逻辑值，
        // 下一次整屏差分会真正把整屏翻过来，而不是误判成“没有变化”。
        // Inversion changes interpretation only; convert the back baseline to the same physical frame under the
        // new mapping so the next full diff actually flips the panel instead of seeing no change.
        const size_t bytes = (size_t)epd_width() / 2 * (size_t)epd_height();
        for (size_t i = 0; i < bytes; ++i) hl->back_fb[i] = (uint8_t)~hl->back_fb[i];
    }
    display_request_full_refresh();
    // 深色→浅色：下一帧先擦白再 GC16 重写，清掉深色期间的残余电荷（修浅色淡墨）。
    // Dark -> light: the next full frame wipes white then rewrites with GC16 to clear residual charge
    // from the dark session (fixes the light-mode faded ink).
    // 浅色→深色：深色整屏复位本身会做真正的 GC16 擦写，清掉待处理的浅色复位请求，避免残留到
    // 之后某次浅色首帧再触发一次多余的全屏擦白。
    // Light -> dark: the dark full reset already runs a real GC16 erase/write, so drop any pending
    // light reset instead of firing an extra full wipe on some later light-mode frame.
    s_light_white_reset_pending = !inverted;
    // 换向后重新积累浅色维护计数，不把上一模式的输出数带过来。
    // Restart the light-mode maintenance counters after a direction change so counts never carry across modes.
    display_light_maintenance_reset();
}

// 反色模式只翻界面文字与图形；封面/插图在这里先按原灰阶画出再翻一次，到扫描出口正好抵消。
// Dark mode inverts UI text and chrome; cover/illustration pixels are flipped once here so the
// global scan inversion cancels out and the artwork keeps its original tones.
void display_invert_area(uint8_t* fb, EpdRect area) {
    if (!fb || !epd_get_inverted() || area.width <= 0 || area.height <= 0) return;
    int x0 = area.x < 0 ? 0 : area.x;
    int y0 = area.y < 0 ? 0 : area.y;
    int x1 = area.x + area.width;
    int y1 = area.y + area.height;
    // area 是逻辑坐标：必须用旋转后的宽高裁剪。物理缓冲是 1216×684，竖屏逻辑是 684×1216，
    // 过去用物理高度裁剪会把竖屏 y>684 的封面整块跳过，于是只有下半屏的书封还反着色。
    // The area is logical: clip with the rotated dimensions. The physical buffer is 1216x684 while
    // the portrait canvas is 684x1216; clipping with the physical height used to skip every cover
    // below y=684, leaving only the lower shelf rows inverted.
    const int logical_w = epd_rotated_display_width();
    const int logical_h = epd_rotated_display_height();
    if (x1 > logical_w) x1 = logical_w;
    if (y1 > logical_h) y1 = logical_h;
    if (x0 >= x1 || y0 >= y1) return;
    const int lx[4] = {x0, x1 - 1, x1 - 1, x0};
    const int ly[4] = {y0, y0, y1 - 1, y1 - 1};
    int px[4], py[4];
    for (int i = 0; i < 4; ++i) {
        int tx = lx[i], ty = ly[i];
        switch (epd_get_rotation()) {
            case EPD_ROT_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                tx = epd_width() - tx - 1;
            } break;
            case EPD_ROT_INVERTED_LANDSCAPE:
                tx = epd_width() - tx - 1;
                ty = epd_height() - ty - 1;
                break;
            case EPD_ROT_INVERTED_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                ty = epd_height() - ty - 1;
            } break;
            default: break;
        }
        px[i] = tx;
        py[i] = ty;
    }
    int bx0 = px[0], bx1 = px[0], by0 = py[0], by1 = py[0];
    for (int i = 1; i < 4; ++i) {
        if (px[i] < bx0) bx0 = px[i];
        if (px[i] > bx1) bx1 = px[i];
        if (py[i] < by0) by0 = py[i];
        if (py[i] > by1) by1 = py[i];
    }
    const int stride = epd_width() / 2;
    for (int y = by0; y <= by1; ++y) {
        uint8_t* row = fb + (size_t)stride * y;
        const int b0 = bx0 / 2, b1 = bx1 / 2;
        for (int b = b0; b <= b1; ++b) {
            const uint8_t v = row[b];
            const uint8_t inv = (uint8_t)~v;
            uint8_t mask = 0xFF;
            // 偶数物理列是低半字节，奇数列是高半字节；区间边界只翻属于区间的那一半。
            // Even physical columns are the low nibble and odd columns the high nibble; at the
            // rect edges only the half inside the range is touched.
            if (b == b0 && (bx0 & 1)) mask &= 0xF0;
            if (b == b1 && !(bx1 & 1)) mask &= 0x0F;
            row[b] = (uint8_t)((v & (uint8_t)~mask) | (inv & mask));
        }
    }
}
static int s_pclk_mhz = DISPLAY_PCLK_DEFAULT_MHZ;

void display_set_bulk_io(bool active) {
    s_bulk_io = active;
    ESP_LOGI(TAG, "bulk I/O scan margin %s", active ? "on" : "off");
}

// 高压轨在连续操作间保留8秒，避免反复500ms放电；像素驱动在每轮结束时立即释放。
// Keep HV rails for an eight-second burst to avoid repeated 500ms discharge; release pixel drive after every output.
#define RAILS_IDLE_TIMEOUT_MS 8000
// 强光防泛白/防反黑：出口已逐轮把 VCOM_EN/XOE/MODE 放掉，但 SY7636A 的 DC-DC 高压轨默认保留 8 秒
// 给连续操作省掉放电等待；强光下把高压电场长时间挂在玻璃上会让画面缓慢发黑。开启该修复后，
// 最后一轮刷新结束 600ms 就整轨断电（连续触摸/打字仍会不断续期，不受影响）。
// Sun fading fix: the exit already drops VCOM_EN/XOE/MODE every round, but the SY7636A DC-DC rails
// normally stay up for 8 s to batch burst work; holding that field on the glass under strong light
// slowly darkens the image. With the fix on, the rails are dropped 600 ms after the last update
// (continuous touch/typing keeps re-arming and is unaffected).
#define RAILS_SUN_FADE_MS 600

// 0 表示轨道已断电；否则是到期时间（ms），到点后由低优先级任务断电。
// 0 means the rails are off; otherwise a deadline (ms) after which a low-priority task cuts power.
static int64_t rails_deadline_ms;
static int64_t drive_release_retry_ms;
static int64_t last_update_ms;

// 断电里有约 500ms 的放电等待：放主循环会吞输入，改到低优先级任务里做；主循环只发通知。
// epd_poweroff() includes a ~500 ms discharge wait. Running it in the main loop would swallow
// input, so a low-priority task does the blocking part while the loop only raises a notification.
#define RAILS_OFF_TASK_STACK 2560
static TaskHandle_t s_rails_off_task;
static volatile bool s_rails_off_request;
static volatile bool s_rails_off_busy;
static volatile bool s_rails_off_sun;
// 每次推屏自增：分段断电在放电等待期间若来了新推屏，epoch 变化就放弃 finish（EN 保持，
// 新推屏已经完整重建了轨道），避免把正在使用的轨切断。
// Bumped on every output: if a new output starts during the split power-off's discharge wait,
// the epoch changes and finish() is skipped (EN stays up; the new output already rebuilt the rails).
static volatile unsigned s_power_cut_epoch;

static void rails_off_task(void *arg) {
    (void)arg;
    for (;;) {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        bool held = pico_online_display_begin();
        if (!s_rails_off_request) {
            pico_online_display_end(held);
            continue;
        }
        s_rails_off_request = false;
        const bool sun = s_rails_off_sun;
        s_rails_off_busy = true;
        rails_deadline_ms = 0;
        drive_release_retry_ms = 0;
        const unsigned epoch = s_power_cut_epoch;
        // 先确保像素驱动已释放，再撤 VCOM_EN/ON_OFF；这一段很快，不阻塞主循环。
        // Release pixel drive first, then drop VCOM_EN/ON_OFF; this part is fast and does not block
        // the main loop.
        for (int i = 0; i < 3; ++i) {
            if (read_pico_epd_release_drive()) break;
            vTaskDelay(pdMS_TO_TICKS(5));
        }
        read_pico_epd_power_cut_begin();
        pico_online_display_end(held);
        // 放电等待放在任务里、不持显示锁：翻页/OTA/触摸都不需要等这 500ms。
        // The discharge wait runs in this task without the display lock: page turns, OTA and touch
        // never wait for these 500 ms.
        vTaskDelay(pdMS_TO_TICKS(read_pico_epd_poweroff_hold_ms()));
        held = pico_online_display_begin();
        if (epoch == s_power_cut_epoch) read_pico_epd_power_cut_finish();
        s_rails_off_busy = false;
        pico_online_display_end(held);
        // 逐页打 INFO 会刷屏（强光防反黑开启时每个翻页 burst 一次），只留调试级。
        // Keep this at debug level: with the sun fix on, one line per idle burst would flood the log.
        if (sun) ESP_LOGD(TAG, "sun fading fix: rails off (async)");
    }
}

static bool rails_off_task_ensure(void) {
    if (s_rails_off_task) return true;
    return xTaskCreate(rails_off_task, "rails_off", RAILS_OFF_TASK_STACK, NULL, 2,
                       &s_rails_off_task) == pdPASS;
}

// 睡眠/关机前等低优先级断电任务收尾，避免两路同时写 SY7636A。
// 先拿显示锁再清请求：worker 若已持锁在断电就等它做完；若还在等锁，它拿到锁后会看到请求已清而跳过。
// Wait for the low-priority power-off task before sleep/shutdown so two paths never touch SY7636A.
// Take the display lock before clearing the request: a worker already holding it finishes its cut;
// one still waiting for the lock will see the cleared request and skip.
void display_quiet_rails_off(void) {
    bool held = pico_online_display_begin();
    s_rails_off_request = false;
    pico_online_display_end(held);
    // 上界按实际放电时间推导，外加 300ms 给 I2C/调度余量。
    // Upper bound derived from the real discharge wait, plus 300 ms for I2C/scheduler slack.
    const int64_t wait_ms = (int64_t)read_pico_epd_poweroff_hold_ms() + 300;
    for (int64_t i = 0; i < wait_ms / 5 && s_rails_off_busy; ++i) vTaskDelay(pdMS_TO_TICKS(5));
}

void rails_keepalive(void) {
    bool held = pico_online_display_begin();
    const int64_t now_ms = esp_timer_get_time() / 1000;
    // 新的一轮推屏取消还在排队的提前断电；本次推送结束后主循环会重新计时。
    // A new update cancels a queued early power-off; the loop re-arms the countdown afterwards.
    s_rails_off_request = false;
    // 包括无变化和失败返回：释放像素驱动，不增加扫描或全刷。
    // Release pixel drive even after unchanged/failed output, without another scan or full refresh.
    drive_release_retry_ms = read_pico_epd_release_drive() ? 0 : now_ms + 50;
    rails_deadline_ms = now_ms + RAILS_IDLE_TIMEOUT_MS;
    last_update_ms = now_ms;
    ++s_power_cut_epoch;
    pico_online_display_end(held);
}

void rails_idle_check(int64_t now_ms, bool input_idle) {
    // 像素驱动释放失败的重试很短，留在主循环里做；真正的整轨断电交给任务。
    // The short drive-release retry stays in the loop; the blocking rail cut goes to the task.
    if (drive_release_retry_ms && now_ms >= drive_release_retry_ms) {
        bool held = pico_online_display_begin();
        if (drive_release_retry_ms && now_ms >= drive_release_retry_ms)
            drive_release_retry_ms = read_pico_epd_release_drive() ? 0 : now_ms + 50;
        pico_online_display_end(held);
    }
    if (s_rails_off_request) return;  // 任务已排队 / worker already queued
    const bool deadline_due = rails_deadline_ms != 0 && now_ms >= rails_deadline_ms;
    // 强光提前断电默认关闭；开启时只在输入空闲时提前（触摸、菜单、弹层、USB/OTA 走 8 秒兜底）。
    // The early sun power-off is off by default; when on it only fires while input is idle (touch,
    // menus, overlays, USB and OTA fall back to the 8 s deadline).
    const bool sun_due = input_idle && rails_deadline_ms != 0 && last_update_ms != 0 &&
        app_settings_sun_fade_fix() && now_ms - last_update_ms >= RAILS_SUN_FADE_MS;
    if (!deadline_due && !sun_due) return;
    if (rails_off_task_ensure()) {
        s_rails_off_sun = sun_due && !deadline_due;
        s_rails_off_request = true;
        xTaskNotifyGive(s_rails_off_task);
        return;
    }
    // 任务创建失败：退回主循环同步断电（仅极端内存情况，最多约 500ms 停顿）。
    // Task creation failed: fall back to a synchronous cut in the loop (only under extreme memory
    // pressure, costing up to ~500 ms once).
    bool held = pico_online_display_begin();
    rails_deadline_ms = 0;
    drive_release_retry_ms = 0;
    epd_poweroff();
    pico_online_display_end(held);
}

// 20 相完整/原厂 DU 按厂家时序走 FULL；只有触摸笔迹用的 8 帧跟随 DU 走 FAST。
// 20-phase full / vendor DU uses FULL timing; the 8-frame FOLLOW DU used for ink trails uses FAST.
static void use_scan_for(const EpdWaveform* waveform, enum EpdDrawMode mode) {
    const bool fast = (mode & 0xF) == MODE_DU && waveform == &E0470_FOLLOW_WAVEFORM;
    read_pico_epd_use_scan(fast ? READ_PICO_EPD_SCAN_FAST : READ_PICO_EPD_SCAN_FULL);
    // 高层刷新保持整屏扫描；两条63行可用队列在第127行入队前启动。
    // High-level updates scan the full panel; two 63-slot queues start before line 127 is enqueued.
    epd_lcd_set_prefill_lines(s_bulk_io ? 127 : (fast ? 64 : 32));
}

// 自上次整屏 GC16 以来的整页差分次数。局部反馈不计数，否则菜单按压几次就会触发黑白全刷。
// Whole-page differentials since the last full GC16. Local feedback is excluded so a few taps cannot trigger flashing.
static int s_page_refreshes;

static const void* s_main_armed;
static bool s_main_fault;
static bool s_main_shelf_page;
static EpdRect s_main_bands[3];
static unsigned s_main_band_count;
static bool s_main_shelf_exit;
static bool s_main_changing_page;
_Static_assert((UI_NAV_REFRESH_END & 31) == 0, "fixed navigation begins on an aligned framebuffer column");
_Static_assert(UI_NAV_REFRESH_END <= UI_NAV_TOP, "aligned refresh must stop above navigation and marker");
_Static_assert(UI_NAV_MARKER_SCAN_END <= UI_NAV_TOP + 27, "marker crop must stop before navigation icons");
_Static_assert((UI_NAV_MARKER_TOP & 1) && !(UI_NAV_MARKER_BOTTOM & 1), "marker nibble guards match current geometry");

static bool main_nav_geometry(void) {
    // 当前板为倒置竖屏：逻辑 y 对应物理 x。其他屏型保持原刷新路径。
    // On this inverted-portrait board logical y maps to physical x; other layouts keep the existing presenter.
    return epd_get_rotation() == EPD_ROT_INVERTED_PORTRAIT &&
           epd_width() == 1216 && epd_height() == 684;
}

static EpdRect main_body_area(void) {
    // 内容截止到 y=1087，32列对齐也不能扩展到 y=1097 的小横条。
    // Content ends at y=1087, so 32-column expansion cannot reach the marker at y=1097.
    return (EpdRect){0, 0, epd_rotated_display_width(), UI_NAV_REFRESH_END};
}

static uint8_t main_bw_byte(uint8_t value) {
    return (value & 0x0f) >= 8 ? ((value & 0xf0) >= 0x80 ? 0xff : 0x0f)
                             : ((value & 0xf0) >= 0x80 ? 0xf0 : 0x00);
}

static bool main_gray_column(int x) {
    for (unsigned i = 0; i < s_main_band_count; ++i)
        if (x >= s_main_bands[i].y && x < s_main_bands[i].y + s_main_bands[i].height) return true;
    return false;
}

static void main_normalize_body(EpdiyHighlevelState* hl) {
    const size_t stride = (size_t)epd_width() / 2;
    for (int y = 0; y < epd_height(); ++y) {
        uint8_t* row = hl->front_fb + y * stride;
        if (!s_main_band_count) {
            for (int x = 0; x < UI_NAV_REFRESH_END / 2; x += 4) {
                uint32_t value;
                memcpy(&value, row + x, sizeof(value));
                const uint32_t binary = ((value & UINT32_C(0x88888888)) >> 3) * 15u;
                if (value != binary) memcpy(row + x, &binary, sizeof(binary));
            }
            continue;
        }
        for (int x = 0; x < UI_NAV_REFRESH_END / 2; ++x)
            if (!main_gray_column(x * 2)) row[x] = main_bw_byte(row[x]);
    }
}

static bool main_body_changed(EpdiyHighlevelState* hl) {
    const size_t stride = (size_t)epd_width() / 2;
    for (int y = 0; y < epd_height(); ++y)
        if (memcmp(hl->front_fb + y * stride, hl->back_fb + y * stride, UI_NAV_REFRESH_END / 2)) return true;
    return false;
}

// 三条最终灰阶最多约90KiB；首帧跳过它们，实际输出成功才提交back。
// Three final gray bands cost at most about 90 KiB; skip them in the first pass and commit back only after successful output.
static size_t main_band_bytes(void) {
    size_t bytes = 0;
    for (unsigned i = 0; i < s_main_band_count; ++i) bytes += (size_t)s_main_bands[i].height * epd_height() / 2;
    return bytes;
}
static void main_band_copy(EpdiyHighlevelState *hl, uint8_t *cache, bool restore) {
    const size_t stride = (size_t)epd_width() / 2;
    for (unsigned i = 0; i < s_main_band_count; ++i) {
        const size_t bytes = (size_t)s_main_bands[i].height / 2;
        for (int y = 0; y < epd_height(); ++y) {
            uint8_t *row = hl->front_fb + y * stride + s_main_bands[i].y / 2;
            if (restore) memcpy(row, cache, bytes);
            else { memcpy(cache, row, bytes); memcpy(row, hl->back_fb + y * stride + s_main_bands[i].y / 2, bytes); }
            cache += bytes;
        }
    }
}

static void main_freeze_navigation(EpdiyHighlevelState* hl, bool update_marker) {
    const size_t stride = (size_t)epd_width() / 2;
    for (int y = 0; y < epd_height(); ++y) {
        uint8_t* front = hl->front_fb + y * stride;
        const uint8_t* back = hl->back_fb + y * stride;
        if (!update_marker) {
            memcpy(front + UI_NAV_REFRESH_END / 2, back + UI_NAV_REFRESH_END / 2,
                   stride - UI_NAV_REFRESH_END / 2);
            continue;
        }
        // 只保留目标横条的五行；起点为奇数像素，同行字节的分隔线半字节仍取真实 back。
        // Keep only the five target marker rows; at the odd first pixel retain the neighboring divider nibble from actual back.
        memcpy(front + UI_NAV_REFRESH_END / 2, back + UI_NAV_REFRESH_END / 2,
               (UI_NAV_MARKER_TOP - UI_NAV_REFRESH_END) / 2);
        const int first = UI_NAV_MARKER_TOP / 2;
        front[first] = (front[first] & 0xf0) | (back[first] & 0x0f);
        memcpy(front + UI_NAV_MARKER_BOTTOM / 2, back + UI_NAV_MARKER_BOTTOM / 2,
               stride - UI_NAV_MARKER_BOTTOM / 2);
    }
}

void display_main_transition_disarm(void) {
    s_main_armed = NULL;
    s_main_shelf_page = false;
    s_main_band_count = 0;
    s_main_shelf_exit = false;
    s_main_changing_page = false;
}

void display_main_transition_cancel(void) {
    display_main_transition_disarm();
}

void display_main_transition_arm(const void* owner, bool leaving_shelf, bool changing_page) {
    s_main_armed = owner;
    s_main_shelf_page = false;
    s_main_band_count = 0;
    s_main_shelf_exit = s_main_armed && leaving_shelf;
    s_main_changing_page = s_main_armed && changing_page;
}

void display_main_transition_gray_bands(const EpdRect *bands, unsigned count) {
    if (!s_main_armed) return;
    s_main_band_count = 0;
    if (!bands || count > 3) return;
    int last = 0;
    for (unsigned i = 0; i < count; ++i) {
        EpdRect b = bands[i];
        if (b.x || b.width != epd_rotated_display_width() || b.y < last || b.height <= 0 ||
            (b.y & 1) || (b.height & 1) || b.y > UI_NAV_REFRESH_END || b.height > UI_NAV_REFRESH_END - b.y) return;
        s_main_bands[i] = b; last = b.y + b.height;
    }
    s_main_band_count = count;
}

void display_main_transition_shelf_page(void) {
    s_main_shelf_page = s_main_armed != NULL;
}

static enum EpdDrawError main_recover(EpdiyHighlevelState* hl, enum EpdDrawError error) {
    // 扫描失败后光学状态未知，必须从白底重建，不能复用半途图的 back。
    // A failed scan leaves unknown optical state; rebuild from white instead of reusing an intermediate back.
    display_main_transition_cancel();
    if (error & EPD_DRAW_EMPTY_LINE_QUEUE) {
        s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
        read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    }
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_poweron();
    epd_clear();
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    enum EpdDrawError result = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    s_main_fault = result != EPD_DRAW_SUCCESS;
    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "main transition recovery error=%d result=%d", error, result);
    return result;
}

static bool main_begin(EpdiyHighlevelState* hl, enum EpdDrawError* result) {
    const void* owner = s_main_armed;
    const bool shelf_exit = s_main_shelf_exit || s_main_shelf_page;
    s_main_shelf_page = false;
    const bool changing_page = s_main_changing_page;
    s_main_changing_page = false;
    const int refresh_mode = app_settings_main_refresh_mode();
    const bool water = refresh_mode == APP_MAIN_REFRESH_WATER;
    const bool normal = refresh_mode == APP_MAIN_REFRESH_NORMAL;
    const bool fast = refresh_mode == APP_MAIN_REFRESH_FAST;
    s_main_shelf_exit = false;
    s_main_armed = NULL;
    if (!owner || !hl || !hl->front_fb || !hl->back_fb) return false;
    if (s_main_fault) { *result = main_recover(hl, EPD_DRAW_SUCCESS); return true; }
    if (!main_nav_geometry()) return false;
    // 8帧整页方案被实机否定；用户接受主页面黑白、亚克力灰阶，黑白改用完整20相。
    // Hardware rejected whole-page 8-frame output; the user accepted black/white main pages with gray acrylic. Use the full 20-phase black/white table.
    main_freeze_navigation(hl, true);
    if (fast) main_normalize_body(hl);
    const bool changed = main_body_changed(hl);
    uint8_t *cache = fast && changed && s_main_band_count
        ? heap_caps_aligned_alloc(16, main_band_bytes(), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT) : NULL;
    const bool gray_fallback = water || (fast && changed && s_main_band_count && !cache);
    // 黑白表的等灰迁移均不驱动；仅把有变化的横条并入同次扫描，固定图标保持原样。
    // The BW/exit tables hold every equal pair. Include only the changing marker
    // in this scan; frozen divider/labels/icons receive no drive. This removes
    // an additional comparison and eight-frame serial marker update.
    bool marker_with_body=fast&&changed&&!cache&&!gray_fallback;
    EpdRect body_area=main_body_area();
    if(marker_with_body)body_area.height=UI_NAV_MARKER_SCAN_END;
    if (cache) main_band_copy(hl, cache, false);
    const EpdWaveform* body_wave = normal ? display_main_normal_waveform() : gray_fallback ? display_main_gray_waveform()
        : shelf_exit ? display_main_shelf_exit_waveform() : display_main_bw_waveform();
    enum EpdDrawMode body_mode = normal || gray_fallback ? MODE_GL16 : MODE_DU;
    bool body_full = false;
    // 普通切页只驱动变化像素，完整中灰相位不缩短；每十二次仍用原表清理内容区。
    // Ordinary changes drive differing pixels without shortening midgray phases; the original table still cleans the body every twelfth change.
    if (normal && changed) {
        ++s_page_refreshes;
        if (APP_UI_FAST_GC16_EVERY > 0 && s_page_refreshes >= APP_UI_FAST_GC16_EVERY) {
            s_page_refreshes = 0;
            body_wave = &E0470_WAVEFORM;
            body_mode = MODE_GC16;
            body_full = true;
        }
    }
    const bool shelf_regions=normal&&changed&&s_main_band_count&&(changing_page||body_full);
    if(shelf_regions){marker_with_body=true;body_area.height=UI_NAV_MARKER_SCAN_END;}
    use_scan_for(body_wave, body_mode);
    epd_poweron();
    epd_hl_waveform(hl, body_wave);
    int64_t start = esp_timer_get_time();
    // 快刷/水波纹不攒强刷次数；普通的周期整理也不能进入底栏。
    // Fast/water accrue no forced-cleanup debt; ordinary periodic settling also excludes navigation.
    if(shelf_regions){
        // 同一帧逐列选择柔和/校准表，上下和中间一起开始，不显示串行的三段旧图。
        // Select soft/calibrated LUTs by columns in the same frame so chrome and art start together without three serial old-image regions.
        EpdRect last=s_main_bands[s_main_band_count-1];
        int top=s_main_bands[0].y&~31,bottom=(last.y+last.height+31)&~31;
        if(bottom>UI_NAV_REFRESH_END)bottom=UI_NAV_REFRESH_END;
        *result=e0470_update_regions(hl,body_area,(EpdRect){0,top,body_area.width,bottom-top},
            display_main_normal_waveform(),display_main_shelf_waveform(body_full?MODE_GC16:MODE_GL16),
            body_full?MODE_GC16:MODE_GL16);
        if(*result==EPD_DRAW_NO_PHASES_AVAILABLE){
            // 低内存仍一次输出整张目标；不退回分段等待或更改真实back。
            // Low memory still presents the whole target once, without serial waiting or a fabricated baseline.
            epd_hl_waveform(hl,display_main_normal_waveform());
            *result=epd_hl_update_area(hl,MODE_GL16,25,body_area);
        }
    } else if (water && changing_page && changed) {
        // 水波纹直接输出最终灰阶图，不先刷黑白、不追加整页灰阶；失败由统一恢复处理。
        // Water outputs the final gray target directly, without a BW prepass or a second whole-page gray update; common recovery handles failure.
        read_pico_epd_use_scan(READ_PICO_EPD_SCAN_FAST);
        epd_lcd_set_prefill_lines(127);
        EpdRect ripple = main_body_area();
        const int prior_tick=e0470_page_turn_tick_us();
        e0470_page_turn_set_tick_us(E0470_TURN_FAST_TICK_US);
        *result = e0470_page_turn_with_waveform_compact(hl, ripple, E0470_TURN_RTL,
                                                       display_main_water_waveform(), E0470_TURN_FAST_BANDS);
        e0470_page_turn_set_tick_us(prior_tick);
        if (*result == EPD_DRAW_NO_PHASES_AVAILABLE) {
            use_scan_for(body_wave, MODE_GL16);
            epd_hl_waveform(hl, body_wave);
            *result = epd_hl_update_area(hl, MODE_GL16, 25, ripple);
        }
        // 主页面动画不长期保留相位缓存，避免与联网和阅读资源争用。
        // Release main-animation LUTs instead of competing with networking and reader resources.
        e0470_page_turn_release();
    } else if (!changed) *result = EPD_DRAW_SUCCESS;
    else *result = body_full ? epd_hl_update_area_full(hl, body_mode, 25, body_area)
                            : epd_hl_update_area(hl, body_mode, 25, body_area);
    if (cache) {
        main_band_copy(hl, cache, true);
        heap_caps_free(cache);
        if (*result == EPD_DRAW_SUCCESS) {
            const EpdRect last = s_main_bands[s_main_band_count - 1];
            EpdRect gray = {0, s_main_bands[0].y, epd_rotated_display_width(), last.y + last.height - s_main_bands[0].y};
            // 采用原校准迁移，不自行按灰度比例截帧；等灰无需反复推动。
            // Retain calibrated transitions without scaling pulses by gray distance; equal grays need no repeated drive.
            epd_hl_waveform(hl, display_main_gray_waveform());
            use_scan_for(display_main_gray_waveform(), MODE_GL16);
            *result = epd_hl_update_area(hl, MODE_GL16, 25, gray);
        }
    }
    s_main_band_count = 0;
    // 反色下这类例行清理的整屏 GC16 同样被 1k LUT 保持深色等灰对：可见的全刷和黑底清理都会
    // 消失。补一遍 16 帧满幅压黑（FULL 扫描，只调 drive 不改 back 基准，不白闪）。
    // Under inversion this routine full-screen GC16 also holds the dark equal pairs, hiding both the
    // visible cleanup and the ground cleaning. Append a 16-frame full darken settle (FULL scan, only
    // drives pixels and never touches the back baseline, so no white flash).
    if (*result == EPD_DRAW_SUCCESS && body_full && epd_get_inverted())
        (void)display_dark_settle_frames_unlocked(hl, DISPLAY_DARK_CLEANUP_FRAMES);
    if (*result == EPD_DRAW_SUCCESS && !marker_with_body) {
        const EpdRect marker = {0, UI_NAV_MARKER_TOP, epd_rotated_display_width(),
                               UI_NAV_MARKER_BOTTOM - UI_NAV_MARKER_TOP};
        // 同页重绘横条无变化时 highlevel 自动跳过；32列扩展范围中其余像素来自 back，保持不驱动。
        // Highlevel skips an unchanged marker; all other pixels in its expanded 32-column crop come from back and remain undriven.
        epd_hl_waveform(hl, &E0470_FOLLOW_WAVEFORM);
        use_scan_for(&E0470_FOLLOW_WAVEFORM, MODE_DU);
        *result = epd_hl_update_area(hl, MODE_DU, 25, marker);
    }
    // 反色主页/子页左右滑动：整屏深色底被 1k LUT 保持，滑动本身只驱动变化像素，换页留下的
    // 残影不会自行消失。每次真正发生变化的滑动完成后补一遍 8 帧满幅压黑（FULL 扫描，只调
    // drive、不改 back 基准、不白闪），让主页残影不随滑动累积；浅色模式不追加，滑动行为不变。
    // Inverted home/subpage swipes: the dark ground is held by the 1 KiB LUT, so a swipe only drives
    // the changed pixels and its residue never clears. After every real change, append an 8-frame
    // full darken settle (FULL scan; drives pixels only, never touches back, no white flash) so home
    // ghosting cannot pile up while swiping. Light mode appends nothing and keeps its swipe behaviour.
    if (*result == EPD_DRAW_SUCCESS && changed && changing_page && !body_full && epd_get_inverted())
        (void)display_dark_settle_frames_unlocked(hl, DISPLAY_DARK_SETTLE_FRAMES);
    if (*result != EPD_DRAW_SUCCESS) *result = main_recover(hl, *result);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    rails_keepalive();
    ESP_LOGD(TAG, "main refresh mode=%d shelf_exit=%d draw=%lldms result=%d", app_settings_main_refresh_mode(), shelf_exit, (esp_timer_get_time() - start) / 1000, *result);
    (void)start;
    return true;
}

// 其他显示出口只取消未用入口；主页面失败时先重建完整目标，绝不回放旧缓存。
// Other outputs disarm unused entry permission; a main-page failure first rebuilds the full current target, never replaying old cache.
static bool main_before_update(EpdiyHighlevelState* hl, enum EpdDrawError* result) {
    display_main_transition_cancel();
    if (s_main_fault) { *result = main_recover(hl, EPD_DRAW_SUCCESS); return true; }
    return false;
}

// 所有按 fb 刷屏的出口都经这里。GL16 必须全像素（白底补 1 帧靠它打到）。
// 整页差分刷攒够 APP_UI_GC16_EVERY 次就把这一次升为全像素 GC16：区域、fb 都不变，只换模式，
// 屏上内容仍由 fb 决定，不会丢；全像素是为了让未变化像素也过一遍 LUT，否则压不掉灰底。
// 跟随 DU 波形只有 DU 一张表，不计数也不升级。
// Every fb present goes through here. GL16 must be full-pixel (the extra white
// frame depends on that). After APP_UI_GC16_EVERY whole-page updates, this one is
// promoted to full-pixel GC16: area and fb stay the same, only the mode
// changes, so content is not lost. Full-pixel is so unchanged pixels also run
// the LUT; otherwise the gray floor will not clear. FOLLOW DU has only a DU
// table and does not count or promote.
static enum EpdDrawError hl_update(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode, bool full,
    const EpdRect* area, bool allow_gl16_diff
) {
    // 已显示主页面的局部封面或滚动更新同样向内裁剪，防止32列对齐带出小横条。
    // Local cover or scroll updates on an already displayed main page use the same inward crop, excluding the marker after alignment.
    if (area && s_main_shelf_page && app_settings_main_fast_refresh()) {
        enum EpdDrawError result;
        if (main_begin(hl, &result)) return result;
    }
    EpdRect clipped;
    const bool protected_area = area && s_main_armed && !s_main_fault && main_nav_geometry();
    if (protected_area) {
        main_freeze_navigation(hl, false);
        if (app_settings_main_fast_refresh()) main_normalize_body(hl);
        clipped = *area;
        if ((int64_t)clipped.y + clipped.height > UI_NAV_REFRESH_END)
            clipped.height = UI_NAV_REFRESH_END - clipped.y;
        if (clipped.height <= 0) { display_main_transition_disarm(); return EPD_DRAW_SUCCESS; }
        area = &clipped;
        // 显式短局刷不被主页模式改写，猫眼/秒针在普通与水波纹中采用同一动效。
        // Preserve explicit short partial updates so cat eyes and seconds share ordinary-mode motion in ripple mode.
        if (!full && waveform != &E0470_FOLLOW_WAVEFORM && (mode & 0x0f) != MODE_GC16 &&
            (app_settings_main_refresh_mode()!=APP_MAIN_REFRESH_NORMAL || (mode & 0x0f)==MODE_GL16)) {
            bool has_gray = !app_settings_main_fast_refresh();
            for (unsigned i = 0; i < s_main_band_count; ++i)
                has_gray |= clipped.y < s_main_bands[i].y + s_main_bands[i].height && clipped.y + clipped.height > s_main_bands[i].y;
            waveform = app_settings_main_refresh_mode()==APP_MAIN_REFRESH_NORMAL ? display_main_normal_waveform() :
                has_gray ? display_main_gray_waveform() : s_main_shelf_page
                ? display_main_shelf_exit_waveform() : display_main_bw_waveform();
            mode = has_gray ? MODE_GL16 : MODE_DU;
            allow_gl16_diff = true;
            epd_hl_waveform(hl, waveform);
        }
    }
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    if (waveform != &E0470_FOLLOW_WAVEFORM && area == NULL) {
        if ((mode & 0xF) == MODE_GC16) {
            s_page_refreshes = 0;
        } else if (APP_UI_GC16_EVERY > 0 && ++s_page_refreshes >= APP_UI_GC16_EVERY) {
            s_page_refreshes = 0;
            mode = (enum EpdDrawMode)((mode & ~0xF) | MODE_GC16);
            full = true;
            ESP_LOGI(TAG, "promote to GC16 after %d page transitions", APP_UI_GC16_EVERY);
        }
    }
    full = full || ((mode & 0xF) == MODE_GL16 && !allow_gl16_diff);
    // 比较完成后只切换一次扫描档，避免快刷前先切 FULL 再切 FAST。
    // Select scan timing once after comparison, without a FULL-to-FAST round trip before fast updates.
    use_scan_for(waveform, mode);
    enum EpdDrawError result;
    if (area != NULL) {
        result = full ? epd_hl_update_area_full(hl, mode, 25, *area)
                    : epd_hl_update_area(hl, mode, 25, *area);
    } else result = full ? epd_hl_update_screen_full(hl, mode, 25) : epd_hl_update_screen(hl, mode, 25);

    // 反色下整屏 GC16（显式全刷或攒够次数升级）的深色等灰对被 1k LUT 保持，黑底残影不会被
    // 这次全刷清掉；补一遍 16 帧满幅压黑（FULL 扫描，不白闪）。整屏 GL16 不补，避免每次主页
    // 更新都多扫 16 帧。
    // Under inversion a whole-screen GC16 (explicit full refresh or the promoted cleanup) holds the
    // dark equal pairs, so its dark ground is not cleaned; append a 16-frame full darken settle
    // (FULL scan, no white flash). Whole-screen GL16 is left alone to keep ordinary page updates cheap.
    if (result == EPD_DRAW_SUCCESS && area == NULL && epd_get_inverted() &&
        (mode & 0xF) == MODE_GC16) {
        (void)display_dark_settle_frames_unlocked(hl, DISPLAY_DARK_CLEANUP_FRAMES);
    }
    return protected_area && result != EPD_DRAW_SUCCESS ? main_recover(hl, result) : result;
}

static enum EpdDrawError update_display_mode_unlocked(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    epd_poweron();
    enum EpdDrawError result = hl_update(hl, &E0470_WAVEFORM, mode, false, NULL, false);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_mode_diff_unlocked(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    epd_poweron();
    enum EpdDrawError result = hl_update(hl, &E0470_WAVEFORM, mode, false, NULL, true);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_fast_page_unlocked(EpdiyHighlevelState* hl) {
    enum EpdDrawError navigation;
    if (main_begin(hl, &navigation)) return navigation;
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    if (APP_UI_FAST_GC16_EVERY > 0 && ++s_page_refreshes >= APP_UI_FAST_GC16_EVERY) {
        s_page_refreshes = 0;
        use_scan_for(&E0470_WAVEFORM, MODE_GC16);
        epd_poweron();
        epd_hl_waveform(hl, &E0470_WAVEFORM);
        enum EpdDrawError result = epd_hl_update_screen_full(hl, MODE_GC16, 25);
        // 反色下整屏 GC16 的深色等灰对已被 1k LUT 保持（不再白闪），代价是黑底残影不会被这次
        // GC16 清掉；补一遍只压黑底的清理，不驱动字形/白字。
        // Under inversion the full GC16 holds the dark equal pairs through the 1 KiB LUT (no more white
        // flash), so its dark-ground residue survives; append a darken-only settle that never drives
        // glyphs or white text.
        if (result == EPD_DRAW_SUCCESS && epd_get_inverted()) (void)display_dark_settle_unlocked(hl);

        rails_keepalive();
        ESP_LOGI(TAG, "fast navigation cleanup after %d transitions", APP_UI_FAST_GC16_EVERY);
        return result;
    }
    const bool ordinary = app_settings_main_refresh_mode() == APP_MAIN_REFRESH_NORMAL;
    const EpdWaveform* waveform = ordinary ? display_main_normal_waveform() : &E0470_WAVEFORM;
    use_scan_for(waveform, MODE_GL16);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    // 普通子页面与四主页使用同一柔和灰阶，不另加黑白预刷或延迟补刷；其他模式保留原周期。
    // Ordinary subpages share the roots' soft grayscale in one pass, without BW prepasses or delayed output; other modes retain their cadence.
    const bool settle = !ordinary && APP_UI_FAST_GL16_SETTLE_EVERY > 0 &&
                        s_page_refreshes % APP_UI_FAST_GL16_SETTLE_EVERY == 0;
    enum EpdDrawError result = settle ? epd_hl_update_screen_full(hl, MODE_GL16, 25)
                                      : epd_hl_update_screen(hl, MODE_GL16, 25);
    // 反色下整页刷新（设置/二级页面/切页等）只走差分 GL16 时，深色等灰对会被 1k LUT 保持，
    // 背景残影不会自行消失；每次整页成功推屏后补一遍压黑清理（差分页 8 帧、全像素整理 16 帧）。
    // Under inversion a whole-page refresh that only runs a differential GL16 holds the dark equal
    // pairs, so background residue never clears; append a darken settle after every successful
    // whole-page push (8 frames for differential pages, 16 for the full-pixel settle).
    if (result == EPD_DRAW_SUCCESS && epd_get_inverted())
        (void)display_dark_settle_frames_unlocked(
            hl, settle ? DISPLAY_DARK_CLEANUP_FRAMES : DISPLAY_DARK_SETTLE_FRAMES);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_from_white_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    // 本出口就是按白基准的整屏 GC16，等价于深→浅首帧复位：浅色下一次性满足待处理请求，
    // 并把活动期防淡墨重新计时。反色模式不碰（深色走 display_dark_refresh 的复位契约）。
    // This exit is a whole-screen GC16 from the white baseline, equivalent to the dark->light
    // first-frame reset: in light mode it satisfies a pending request once and restarts the activity
    // schedule. Inverted mode is untouched (it uses display_dark_refresh's reset contract).
    if (!epd_get_inverted()) {
        s_light_white_reset_pending = false;
        display_light_maintenance_reset();
    }
    use_scan_for(waveform, mode);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = epd_hl_update_screen_from_white(hl, mode, 25);

    epd_hl_waveform(hl, &E0470_WAVEFORM);
    s_page_refreshes = 0;
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_from_white_unlocked(EpdiyHighlevelState* hl) {
    return update_display_from_white_with(hl, &E0470_WAVEFORM, MODE_GC16);
}

static enum EpdDrawError update_display_white_unlocked(EpdiyHighlevelState* hl) {
    epd_hl_set_all_white(hl);
    return update_display_full(hl);
}

static bool s_white_exit;

void display_hold_white_exit(bool hold) {
    s_white_exit = hold;
}

bool display_take_white_exit(void) {
    const bool hold = s_white_exit;
    s_white_exit = false;
    return hold;
}

static enum EpdDrawError update_display_full_unlocked(EpdiyHighlevelState* hl) {
    s_full_refresh_requested = false;
    display_main_transition_cancel();
    // 反色下整屏全刷 = 真正的 GC16 复位（临时关闭深色保持，整屏擦白+压黑），恢复纯黑底与墨色。
    // 浅色模式 = 普通整屏 GC16；若刚从深色切回浅色，先擦白再 GC16 重写，清掉残余电荷防淡墨。
    // Under inversion a full refresh is a real GC16 reset (hold temporarily off: full erase+write) to
    // restore the black ground and ink density. Light mode keeps the plain full GC16; right after
    // leaving dark mode it first wipes the panel white, then rewrites with GC16, clearing residual
    // charge that caused the light-mode "faded ink".
    if (epd_get_inverted()) {
        bool ok = display_dark_refresh_unlocked(hl);
        rails_keepalive();
        if (ok) return EPD_DRAW_SUCCESS;
        // 兜底：复位失败时按原基准整屏重推，保证画面内容正确。
        // Fallback: repaint from the existing baseline so the content stays correct.
        epd_hl_waveform(hl, &E0470_WAVEFORM);
        epd_poweron();
        enum EpdDrawError repaint = hl_update(hl, &E0470_WAVEFORM, MODE_GC16, true, NULL, false);
        rails_keepalive();
        return repaint;
    }
    // 深色→浅色首帧：统一走 display_light_white_reset_unlocked（整屏擦白 + 白基准 GC16 重写），
    // 阅读/主页/设置等所有走全刷出口的页面都能可靠生效。
    // Dark->light first frame: run the shared display_light_white_reset_unlocked (whole-panel white
    // wipe + GC16 rewrite from the white baseline) so it lands reliably on every full-refresh exit
    // (reader, home, settings, ...).
    if (s_light_white_reset_pending) return display_light_white_reset_unlocked(hl);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    epd_poweron();
    enum EpdDrawError result = hl_update(hl, &E0470_WAVEFORM, MODE_GC16, true, NULL, false);
    // 整屏 GC16 已重推整帧（真复位），浅色维护重新计时。
    // The whole-screen GC16 re-drove the frame (a real reset); restart the light-mode schedule.
    display_light_maintenance_reset();
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_area_diff_with_unlocked(EpdiyHighlevelState*, const EpdWaveform*, enum EpdDrawMode, EpdRect);
static enum EpdDrawError update_display_area_full_with_unlocked(EpdiyHighlevelState*, const EpdWaveform*, enum EpdDrawMode, EpdRect);

static enum EpdDrawError update_display_image_gray_unlocked(EpdiyHighlevelState* hl) {
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    // 图片出口本身就是 epd_clear + 白基准整屏 GC16，等价于深→浅首帧复位：浅色下一次性满足
    // 待处理请求并重置活动期防淡墨计时（反色模式保持原深色契约）。
    // The image exit already does epd_clear + a whole-screen GC16 from the white baseline, which is
    // the dark->light reset itself: in light mode satisfy a pending request once and restart the
    // activity schedule (inverted mode keeps its dark contract).
    if (!epd_get_inverted()) {
        s_light_white_reset_pending = false;
        display_light_maintenance_reset();
    }
    // 图片保留十六级原始灰阶；白底和完整 48 相波形稳定呈现层次。
    // Images keep sixteen source grays; a white baseline and the full 48-phase table preserve tones.
    use_scan_for(&E0470_FULL_WAVEFORM, MODE_GC16);
    epd_poweron();
    epd_clear();
    epd_hl_waveform(hl, &E0470_FULL_WAVEFORM);
    enum EpdDrawError result = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);

    epd_hl_waveform(hl, &E0470_WAVEFORM);
    s_page_refreshes = 0;
    rails_keepalive();
    return result;
}

// 指定波形整屏刷一次，刷完把默认波形装回去。用来 A/B 两条灰阶表。
// Present the whole screen with a given waveform, then restore the default. Used to A/B two gray tables.
static enum EpdDrawError update_display_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, false, NULL, false);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_area_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, false, &area, false);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_area_diff_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, false, &area, true);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

static enum EpdDrawError update_display_area_full_with_unlocked(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, true, &area, false);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

// ---- 浅色活动期防淡墨 / Light-mode activity anti-fade ----
// 逻辑画布（旋转后）整屏矩形。/ Whole logical (rotated) canvas rectangle.
static EpdRect display_light_full_area(void) {
    return (EpdRect){0, 0, epd_rotated_display_width(), epd_rotated_display_height()};
}

// 计数归零并把计时推到当前：刚刚发生过一次整帧重推或反色方向切换。
// Clear the counters and move the timestamp to now: a full re-drive or an inversion change just ran.
static void display_light_activity_reset(void) {
    s_light_activity_page_ops = 0;
    s_light_activity_area_ops = 0;
    s_light_activity_settles = 0;
    s_light_activity_last_ms = esp_timer_get_time() / 1000;
}

// 页级输出：覆盖逻辑画布一半以上（阅读翻页/整页刷新、主页切页）；否则按局部输出计。
// Page-level output: covers at least half of the logical canvas (reader turns/full pages, main-page
// switches); anything smaller counts as a partial output.
static bool display_light_page_level_area(EpdRect area) {
    const int w = epd_rotated_display_width();
    const int h = epd_rotated_display_height();
    if (w <= 0 || h <= 0 || area.width <= 0 || area.height <= 0) return false;
    return (int64_t)area.width * (int64_t)area.height * 2 >= (int64_t)w * (int64_t)h;
}

// 整帧重推当前帧：全像素 GL16（与防泛白同一机制，不整屏黑白闪）；每第 N 次升级为全像素
// GC16（完整擦写清残影）。浅色模式专用；失败不改变主输出结果。
// Re-drive the current frame with full-pixel GL16 (the anti-fade mechanism, no whole-screen
// black/white flash); every Nth time use a full-pixel GC16 (complete erase/write cleanup) instead.
// Light mode only; a failure does not change the caller's output result.
static void display_light_activity_redrive_unlocked(EpdiyHighlevelState* hl) {
    bool deep = false;
    if (DISPLAY_LIGHT_ACTIVITY_GC16_EVERY > 0 &&
        ++s_light_activity_settles >= DISPLAY_LIGHT_ACTIVITY_GC16_EVERY) {
        s_light_activity_settles = 0;
        deep = true;
    }
    (void)update_display_area_full_with_unlocked(
        hl, &E0470_WAVEFORM, deep ? MODE_GC16 : MODE_GL16, display_light_full_area());
    s_light_activity_page_ops = 0;
    s_light_activity_area_ops = 0;
    s_light_activity_last_ms = esp_timer_get_time() / 1000;
}

// 每次成功的浅色输出后调用：页级/局部计数或静置超时到点，就整帧重推一次，避免连续使用期
// 间未变化的像素一直不进差分、电荷泄漏累积成淡墨。full_cleanup=本次输出本身已是页级 GC16
// 清理，直接归零，不再追加第二遍。
// 1.15.23：该路径默认停用（DISPLAY_LIGHT_ACTIVITY_ENABLE=0，清不掉的残影正是它的问题），
// 仅作 A/B 回滚保留；浅色维护统一走 display_light_maintenance_tick_unlocked。
// Call after every successful light-mode output: when the page/partial counters or the elapsed
// interval are due, re-drive the whole frame once so pixels that stay out of the differential cannot
// accumulate leaked charge into faded ink during continuous use. full_cleanup: this output already is
// a page-level GC16 cleanup, so reset instead of appending a second pass.
// 1.15.23: disabled by default (DISPLAY_LIGHT_ACTIVITY_ENABLE=0; this pass could not clear the
// residue it was meant to fix) and kept for A/B rollback only; light-mode maintenance now goes
// through display_light_maintenance_tick_unlocked.
static void display_light_activity_tick_unlocked(EpdiyHighlevelState* hl, EpdRect area, bool full_cleanup) {
    // 三个阈值全为 0 表示关闭活动期整理（A/B 对照或回滚开关）；单个阈值 0 = 该触发条件停用。
    // All three thresholds at 0 disables the activity maintenance entirely (A/B or rollback switch);
    // a single threshold at 0 disables only that trigger.
    if (DISPLAY_LIGHT_ACTIVITY_PAGE_EVERY == 0 && DISPLAY_LIGHT_ACTIVITY_AREA_EVERY == 0 &&
        DISPLAY_LIGHT_ACTIVITY_INTERVAL_MS == 0) return;
    if (epd_get_inverted() || hl == NULL || hl->front_fb == NULL || hl->back_fb == NULL) return;
    if (full_cleanup) {
        display_light_activity_reset();
        return;
    }
    const int64_t now = esp_timer_get_time() / 1000;
    if (s_light_activity_last_ms == 0) s_light_activity_last_ms = now;
    if (display_light_page_level_area(area)) ++s_light_activity_page_ops;
    else ++s_light_activity_area_ops;
    const bool due =
        (DISPLAY_LIGHT_ACTIVITY_PAGE_EVERY > 0 &&
         s_light_activity_page_ops >= DISPLAY_LIGHT_ACTIVITY_PAGE_EVERY) ||
        (DISPLAY_LIGHT_ACTIVITY_AREA_EVERY > 0 &&
         s_light_activity_area_ops >= DISPLAY_LIGHT_ACTIVITY_AREA_EVERY) ||
        (DISPLAY_LIGHT_ACTIVITY_INTERVAL_MS > 0 &&
         now - s_light_activity_last_ms >= DISPLAY_LIGHT_ACTIVITY_INTERVAL_MS);
    if (!due) return;
    display_light_activity_redrive_unlocked(hl);
}

// ---- 浅色真 GC16 清理 / Light-mode real-GC16 cleanup ----
// 清零浅色维护计数：真 GC16 复位（页级）已完成，或反色方向切换。
// Clear the light-mode maintenance counters: a page-level real GC16 reset just ran, or inversion changed.
static void display_light_maintenance_reset(void) {
    display_light_activity_reset();
    s_light_cleanup_page_ops = 0;
    s_light_cleanup_activity_seen = false;
    s_light_cleanup_last_ms = esp_timer_get_time() / 1000;
}

// 浅色真 GC16 清理：整屏全像素 GC16（未裁剪 48 相完整表），每个像素完整走一遍擦除→重写，
// 清掉白底/无色区残留的上一屏黑字或图案并释放残余电荷。不进入反色模式。
// 失败只记日志、不改变调用方主输出结果；成功则把维护计数归零。
// Real light-mode GC16 cleanup: whole-screen full-pixel GC16 on the untrimmed 48-phase table; every
// pixel runs a complete erase->rewrite cycle, clearing black text/artwork residue left on white areas
// by the previous screen and releasing residual charge. Never runs in inverted mode. A failure is
// only logged (the caller's main result is unchanged); success resets the maintenance counters.
static enum EpdDrawError display_light_gc16_cleanup_unlocked(EpdiyHighlevelState* hl) {
    if (hl == NULL || hl->front_fb == NULL || hl->back_fb == NULL) return EPD_DRAW_INVALID_CROP;
    // 真复位会重写整帧，待处理的整屏刷新请求与主页转场许可都已经被这次输出满足/消费。
    // The real reset rewrites the whole frame, so a pending full-refresh request and any main
    // transition permission are satisfied/consumed by this pass.
    display_main_transition_cancel();
    s_full_refresh_requested = false;
    use_scan_for(&E0470_FULL_WAVEFORM, MODE_GC16);
    epd_poweron();
    enum EpdDrawError result;
    if (DISPLAY_LIGHT_CLEANUP_DEEP) {
        // 深清理：先整屏盲擦白，再从白基准写回；物理与逻辑基线一致，不会把“从”灰阶用错。
        // Deep mode: blind white wipe first, then rewrite from the white baseline so the physical and
        // logical "from" states agree.
        epd_clear();
        epd_hl_waveform(hl, &E0470_FULL_WAVEFORM);
        result = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    } else {
        // 常规清理：从当前已提交基准整屏全像素 GC16；等灰对也各走完整擦除+重写。
        // Normal mode: full-pixel GC16 from the committed baseline; equal pairs also run the complete
        // erase+rewrite cycle.
        epd_hl_waveform(hl, &E0470_FULL_WAVEFORM);
        result = epd_hl_update_screen_full(hl, MODE_GC16, 25);
    }
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    s_page_refreshes = 0;
    display_light_maintenance_reset();
    rails_keepalive();
    if (result != EPD_DRAW_SUCCESS) {
        // 清理失败时屏幕可能停在半途；请求下一帧整屏重画，调用方的成功结果不受影响。
        // A failed cleanup may leave the panel mid-scan; request a full repaint on the next frame
        // without changing the caller's successful result.
        s_full_refresh_requested = true;
        ESP_LOGW(TAG, "light GC16 cleanup failed (%d)", result);
    } else {
        ESP_LOGI(TAG, "light GC16 cleanup ok");
    }
    return result;
}

// 每次成功的浅色输出后统一入口：先按宏决定是否恢复 1.15.22 的 GL16 重推（默认否），再跑低频
// 真 GC16 清理。full_cleanup=本次输出本身就是页级全像素 GC16（页面层清理），只归零计数、不再追加。
// 计时触发的“用过”条件按任意浅色输出计：主页停留时只有时钟/秒针的局部差分（area 级），若只认
// 页级输出，10 分钟计时永远不会到点，主页残影就没有兜底。另外长时间完全没有输出（休眠/断电）
// 之后的第一帧不算连续使用时长，直接从那时重新计时，避免久置后第一下就整屏闪。
// 反色模式完全不进入；页级计数触发（PAGE_EVERY）与计时触发（INTERVAL_MS）是 OR 关系。
// Single entry called after every successful light-mode output: optionally restore the 1.15.22 GL16
// re-drive (default off), then run the low-frequency real GC16 cleanup. full_cleanup: this output is
// itself a page-level full-pixel GC16 (a page-layer cleanup), so only reset and never append.
// The timer trigger counts ANY light-mode output as "used": while idling on the home screen only
// local clock/second-hand diffs (area-level) run, so a page-level-only condition would never fire and
// home residue would have no safety net. A long gap with no output at all (sleep/power-off) is not
// counted as continuous-use time; the interval simply restarts from the next output so a first touch
// after a long rest does not immediately flash the whole screen. Inverted mode never enters. The
// page-count trigger (PAGE_EVERY) and the timer trigger (INTERVAL_MS) are OR-ed.
static void display_light_maintenance_tick_unlocked(EpdiyHighlevelState* hl, EpdRect area, bool full_cleanup) {
    if (DISPLAY_LIGHT_ACTIVITY_ENABLE) display_light_activity_tick_unlocked(hl, area, full_cleanup);
    if (!DISPLAY_LIGHT_CLEANUP_ENABLE) return;
    if (DISPLAY_LIGHT_CLEANUP_PAGE_EVERY == 0 && DISPLAY_LIGHT_CLEANUP_INTERVAL_MS == 0) return;
    if (epd_get_inverted() || hl == NULL || hl->front_fb == NULL || hl->back_fb == NULL) return;
    if (full_cleanup) {
        display_light_maintenance_reset();
        return;
    }
    if (display_light_page_level_area(area)) ++s_light_cleanup_page_ops;
    const int64_t now = esp_timer_get_time() / 1000;
    if (s_light_cleanup_last_ms == 0) s_light_cleanup_last_ms = now;
    // 长时间无任何输出的空档不计入连续使用时长：从这里重新开始计时。
    // A long output-free gap does not count as continuous-use time: restart the interval here.
    if (DISPLAY_LIGHT_CLEANUP_INTERVAL_MS > 0 && s_light_cleanup_last_output_ms != 0 &&
        now - s_light_cleanup_last_output_ms >= DISPLAY_LIGHT_CLEANUP_INTERVAL_MS) {
        s_light_cleanup_last_ms = now;
        s_light_cleanup_activity_seen = false;
    }
    s_light_cleanup_last_output_ms = now;
    s_light_cleanup_activity_seen = true;
    const bool page_due = DISPLAY_LIGHT_CLEANUP_PAGE_EVERY > 0 &&
                          s_light_cleanup_page_ops >= DISPLAY_LIGHT_CLEANUP_PAGE_EVERY;
    const bool time_due = DISPLAY_LIGHT_CLEANUP_INTERVAL_MS > 0 && s_light_cleanup_activity_seen &&
                          now - s_light_cleanup_last_ms >= DISPLAY_LIGHT_CLEANUP_INTERVAL_MS;
    if (!page_due && !time_due) return;
    (void)display_light_gc16_cleanup_unlocked(hl);
}

// 深色→浅色首帧复位：先 epd_clear 整屏擦白，再按白基准 GC16 重写当前帧，清掉深色期间积累的
// 残余电荷。由全刷出口与其它“白基准整帧”出口共用，保证阅读/主页等首帧都能可靠生效。
// Dark->light first-frame reset: epd_clear wipes the panel white, then the current frame is
// rewritten with a GC16 from the white baseline, clearing residue accumulated during the dark
// session. Shared by the full-refresh exit and every other white-baseline whole-frame exit so the
// first frame lands reliably on reader/home/settings pages.
static enum EpdDrawError display_light_white_reset_unlocked(EpdiyHighlevelState* hl) {
    // 这次整屏擦白 + GC16 重写已经满足“下一帧整屏刷新”的请求，避免之后再来一次多余的整屏 GC16。
    // This white wipe + GC16 rewrite already satisfies the pending "full refresh next frame" request,
    // so no extra whole-screen GC16 fires afterwards.
    s_light_white_reset_pending = false;
    s_full_refresh_requested = false;
    display_main_transition_cancel();
    use_scan_for(&E0470_FULL_WAVEFORM, MODE_GC16);
    epd_poweron();
    epd_clear();
    epd_hl_waveform(hl, &E0470_FULL_WAVEFORM);
    enum EpdDrawError result = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    s_page_refreshes = 0;
    display_light_maintenance_reset();
    rails_keepalive();
    return result;
}

// 普通阅读翻页用快速扫描时钟；快刷水波纹沿用 rc100 揭页引擎和 reader 灰阶波形，一次推屏完成；
// 高清水波纹例外：见 update_display_hd_water_unlocked——它切到 FULL 标定扫描（11090us/帧）并改用
// 普通·高清的校准 GL16 表，让抗锯齿中灰按标定脉宽推到位。清残影由 present 翻页后的补白/补黑负责。
// Ordinary reader turns scan with the fast clock; Fast water keeps rc100's ripple engine and the
// reader text waveform (one pass). HD water is the exception (see update_display_hd_water_unlocked):
// it switches to the FULL calibrated scan (11090 us/frame) and the ordinary-HD calibrated GL16
// table so the antialiased mid-grays are driven at calibrated pulse widths. present()'s white/black
// settle still clears the residue afterwards.
static enum EpdDrawError update_display_reader_turn_unlocked(EpdiyHighlevelState* hl, EpdRect area,
                                             e0470_turn_dir_t dir, unsigned bands,
                                             const EpdWaveform* waveform, bool commit_baseline) {
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    // 阅读普通翻页和水波纹共用灰阶扫描；主页保留独立路径。
    // 反色模式不再改扫描时钟：整帧时钟会让白字脉冲更长，字就从细变粗；黑色残留改为
    // 翻页完成后单独补一次 DU 全驱动（display_black_settle），只压黑底、不重设字形灰度。
    // Ordinary reader turns and ripple share gray scanning; main tabs retain their separate path.
    // Inverted mode no longer changes the scan clock: the full clock lengthens the white-glyph
    // pulses and makes text look bolder. Black residue is settled afterwards by a separate DU
    // pass (display_black_settle) that only re-drives the black ground.
    read_pico_epd_use_scan(READ_PICO_EPD_SCAN_FAST);
    // 真机首轮文字扫描在预绘制并发时出现欠载；使用现有127行上限预填，不扩大队列或改变帧节拍。
    // The first real text scan underruns during concurrent prepainting; prefill the existing 127-line limit without growing queues or changing frame pacing.
    epd_lcd_set_prefill_lines(127);
    epd_poweron();
    // 通用GL16连相同灰边也会重新压黑；文字序列保持等灰并提前少量回浅，直接用于条带LUT。
    // Generic GL16 re-drives even equal gray edges; text phases hold them and advance a few settling pulses in the band LUT.
    enum EpdDrawError result = e0470_page_turn_with_waveform_compact_commit(hl, area, dir,
        waveform, bands, commit_baseline);
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    rails_keepalive();
    if (result == EPD_DRAW_SUCCESS) return result;
    if (result == EPD_DRAW_NO_PHASES_AVAILABLE) {
        ESP_LOGW(TAG, "water turn phases unavailable; use regular GL16");
        return update_display_area_diff_with(hl, waveform, MODE_GL16, area);
    }
    // 中断可能把物理屏留在半途。清屏后按目标 front 重建整屏基准。
    // An interrupted scan may leave intermediate pixels. Rebuild the whole baseline from white.
    if (result & EPD_DRAW_EMPTY_LINE_QUEUE) {
        s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
        read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    }
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_clear();
    enum EpdDrawError recovered = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);

    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "water turn failed (%d), recovery=%d", result, recovered);
    return recovered;
}

// 高清水波纹条带数：与快刷相同的 8 带。条带数只决定揭页前沿分几级台阶，每个像素收到的仍是
// 完整 37 相校准波形，所以抗锯齿质量不变；从 32 带 68 拍降到 8 带 44 拍，配合 11090us 标定拍，
// 单次揭页从约 0.82s 降到约 0.49s（与快刷相同），仍是单次推屏、结束提交基准，不追加第二遍。
// HD ripple keeps fast-water's 8 bands. Band count only changes how many steps the reveal front
// shows; every pixel still receives the full 37-phase calibrated waveform, so AA quality is
// unchanged. Dropping from 32 bands/68 ticks to 8 bands/44 ticks at the 11090 us calibrated tick
// cuts the pass from ~0.82 s to ~0.49 s (same as Fast water), still single-shot with a committed
// baseline and no second settle pass.
#define HD_WATER_BANDS E0470_TURN_FAST_BANDS

// 高清水波纹：用「普通·高清」同一张校准 GL16 表（E0470_WAVEFORM），并把扫描时钟切到
// 标定档 FULL——行周期补到波形标定的 11090us/帧，每相脉宽与表完全一致，抗锯齿中间灰才推得准。
// rc100 的 FAST 扫描帧只有约 7ms（脉宽约为标定的 63%），中灰推不到位，字体边缘就粗糙；
// 这里按用户「把字体推得更细换抗锯齿」的要求改用标定脉宽，并把节拍压到 11090us/拍、条带降到
// 8 带（44 拍约 0.49s），速度回到快刷档，抗锯齿仍按校准脉宽执行。
// HD water drives the same calibrated GL16 table as ordinary HD (E0470_WAVEFORM) and selects the
// calibrated FULL scan profile: the line period is padded to the waveform's 11090 us frame so every
// phase pulse matches the table and the antialiased mid-grays land correctly. rc100's FAST frame is
// only ~7 ms (about 63% pulse width), which under-drives those grays and leaves rough text edges;
// per the user's request we keep calibrated pulse widths but pace at 11090 us/tick with 8 bands
// (44 ticks ≈ 0.49 s), so the HD step is as fast as Fast water while the AA stays calibrated.
static enum EpdDrawError update_display_hd_water_unlocked(EpdiyHighlevelState* hl, EpdRect area,
                                                          e0470_turn_dir_t dir) {
    enum EpdDrawError intercepted;
    if (main_before_update(hl, &intercepted)) return intercepted;
    // 标定拍 11090us 与 FULL 扫描帧一致，不再按 12ms 补等；8 带 44 拍约 0.49s。
    // The calibrated 11090 us tick matches the FULL scan frame (no 12 ms padding): 8 bands/44 ticks.
    const int prior_tick = e0470_page_turn_tick_us();
    e0470_page_turn_set_tick_us(E0470_TURN_FAST_TICK_US);
    read_pico_epd_use_scan(READ_PICO_EPD_SCAN_FULL);
    epd_lcd_set_prefill_lines(127);
    epd_poweron();
    enum EpdDrawError result = e0470_page_turn_with_waveform_compact_commit(
        hl, area, dir, &E0470_WAVEFORM, HD_WATER_BANDS, true);
    e0470_page_turn_set_tick_us(prior_tick);
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    rails_keepalive();
    if (result == EPD_DRAW_SUCCESS) return result;
    if (result == EPD_DRAW_NO_PHASES_AVAILABLE) {
        ESP_LOGW(TAG, "HD water turn phases unavailable; use regular GL16");
        return update_display_area_diff_with(hl, &E0470_WAVEFORM, MODE_GL16, area);
    }
    // 中断可能把物理屏留在半途。清屏后按目标 front 重建整屏基准。
    // An interrupted scan may leave intermediate pixels. Rebuild the whole baseline from white.
    if (result & EPD_DRAW_EMPTY_LINE_QUEUE) {
        s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
        read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    }
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_clear();
    enum EpdDrawError recovered = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "HD water turn failed (%d), recovery=%d", result, recovered);
    return recovered;
}

static enum EpdDrawError update_display_water_turn_unlocked(EpdiyHighlevelState* hl, EpdRect area,
                                             e0470_turn_dir_t dir) {
    return update_display_reader_turn_unlocked(hl,area,dir,E0470_TURN_FAST_BANDS,
                                               display_reader_text_waveform(), true);
}

// 供数不足时的兜底：把频率退回安全值，整屏白一次，让后面的差分刷有干净参考帧。
// Underrun fallback: drop to the safe clock and wipe the panel white so later differentials have a clean reference.
int display_pclk_mhz(void) { return s_pclk_mhz; }

static void guard_draw_result_unlocked(EpdiyHighlevelState* hl, enum EpdDrawError result) {
    if (!(result & EPD_DRAW_EMPTY_LINE_QUEUE)) return;
    display_main_transition_cancel();
    s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
    read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_poweron();
    epd_clear();
    // 清物理屏后仅重置旧帧基准，保留目标页；否则局部刷新会留下整页白屏。
    // Reset only the old-frame baseline after clearing; preserving the target prevents blank pages after partial updates.
    enum EpdDrawError recovered = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);

    s_main_fault = recovered != EPD_DRAW_SUCCESS;
    // 欠载恢复是 epd_clear + 白基准整屏 GC16，等价于深→浅复位：浅色下满足待处理请求并重置
    // 活动期计时，避免恢复后残留一次多余的全屏擦白。
    // Underrun recovery is epd_clear + a whole-screen GC16 from the white baseline, i.e. the
    // dark->light reset itself: in light mode satisfy a pending request and restart the activity
    // schedule so no extra wipe can fire after recovery.
    if (!epd_get_inverted()) {
        s_light_white_reset_pending = false;
        display_light_maintenance_reset();
    }
    if (recovered != EPD_DRAW_SUCCESS) ESP_LOGW(TAG, "underrun recovery failed (%d)", recovered);
    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "line queue underrun, pclk back to %d MHz, recovery=%d", DISPLAY_PCLK_SAFE_MHZ, recovered);
}

#ifdef KIIKO_LOCAL_LATENCY
int64_t local_display_elapsed_us;
#define LATENCY_DISPLAY_BEGIN() const int64_t local_display_start=esp_timer_get_time()
#define LATENCY_DISPLAY_END() (local_display_elapsed_us+=esp_timer_get_time()-local_display_start)
#else
#define LATENCY_DISPLAY_BEGIN() do {} while(0)
#define LATENCY_DISPLAY_END() do {} while(0)
#endif

// 连续相位全部完成后，back已是真实黑白画面；不因尚未补灰阶而多做一次整屏GC16。
// Once continuous phases finish, back is the real binary frame; pending gray restoration alone does not require full GC16.
static bool display_needs_full(void) { return s_full_refresh_requested; }

// 统一硬件出口，递归调用也必须覆盖整个扫描过程。/ Guard complete scans, including recursive fallback paths.
enum EpdDrawError update_display_mode(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    const bool full = display_needs_full();
    enum EpdDrawError result = full
        ? update_display_full_unlocked(hl) : update_display_mode_unlocked(hl, mode);
    if (!full && result == EPD_DRAW_SUCCESS)
        display_light_maintenance_tick_unlocked(hl, display_light_full_area(), false);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_mode_diff(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    const bool full = display_needs_full();
    enum EpdDrawError result = full
        ? update_display_full_unlocked(hl) : update_display_mode_diff_unlocked(hl, mode);
    if (!full && result == EPD_DRAW_SUCCESS)
        display_light_maintenance_tick_unlocked(hl, display_light_full_area(), false);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_fast_page(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    const bool full = display_needs_full();
    enum EpdDrawError result = full
        ? update_display_full_unlocked(hl) : update_display_fast_page_unlocked(hl);
    if (!full && result == EPD_DRAW_SUCCESS)
        display_light_maintenance_tick_unlocked(hl, display_light_full_area(), false);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_from_white_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_from_white_with_unlocked(hl, waveform, mode);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_from_white(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = display_needs_full()
        ? update_display_full_unlocked(hl) : update_display_from_white_unlocked(hl);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_white(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    s_full_refresh_requested = false;
    enum EpdDrawError result = update_display_white_unlocked(hl);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_full(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = update_display_full_unlocked(hl);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 屏幕修复的遍数与单帧时长：遍数是盲刷黑/白走几轮，越多越彻底、整段也越久。
// Panel repair passes and per-frame time: the count is how many black/white rounds the blind drive
// walks -- more is more thorough and takes longer.
#define DISPLAY_REPAIR_CYCLES 6
#define DISPLAY_REPAIR_TIME 15
// 掉电保持时长：够面板把停在半帧的像素放掉，又不至于让用户等。
// How long the rails stay down: enough for pixels stuck mid-frame to let go, short enough to wait.
#define DISPLAY_REPAIR_OFF_MS 400

// 面板修复：整屏盲驱动，不看 framebuffer。刷新中途断电会让面板停在半帧状态，而这里所有常规
// 刷新都是差分的（只重写与 RAM 上一帧不同的像素与相位），停在半路的那些行永远轮不到重写——
// 现象就是怎么刷新都留着一道条纹。这条路把每一行按同一电平重新驱动几轮，最后停在白色。
// Panel repair: a blind full-screen drive that ignores the framebuffer. A power cut in the middle of
// a refresh leaves the panel stuck mid-frame, and every ordinary path here is differential -- it
// rewrites only what differs from the RAM frame -- so those rows are never driven again and the
// stripe survives every refresh. This drives every row to the same level for several rounds and ends
// on white.
enum EpdDrawError display_panel_repair(EpdiyHighlevelState* hl) {
    if (!hl || !hl->front_fb || !hl->back_fb) return EPD_DRAW_INVALID_CROP;
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    continuous_du_reset();
    s_full_refresh_requested = false;
    display_main_transition_cancel();
    // 面板修复先真掉电再盲刷黑白，最后按白基准整帧重推：等价于一次更强的深→浅复位，
    // 浅色下直接满足待处理复位请求并重置活动期计时（反色模式保持原契约）。
    // Panel repair does a real power cycle, a blind black/white drive and then one whole-frame push
    // from the white baseline: a stronger dark->light reset. In light mode satisfy a pending reset
    // and restart the activity schedule (inverted mode keeps its contract).
    if (!epd_get_inverted()) {
        s_light_white_reset_pending = false;
        display_light_maintenance_reset();
    }
    // 先真掉一次电：VCOM/VGH/VGL 重新建立，停在半路的像素失去保持电压。
    // One real power cycle first: VCOM/VGH/VGL are rebuilt and pixels stuck mid-frame lose their hold.
    epd_poweroff();
    vTaskDelay(pdMS_TO_TICKS(DISPLAY_REPAIR_OFF_MS));
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_poweron();
    // 盲刷黑/白：与 framebuffer 无关；每轮之间让出 CPU，整段要几秒。
    // Blind black/white drive, independent of the framebuffer; the CPU is released between rounds
    // because the whole pass takes seconds.
    const EpdRect area = epd_full_screen();
    for (int cycle = 0; cycle < DISPLAY_REPAIR_CYCLES; ++cycle) {
        for (int i = 0; i < 10; ++i) epd_push_pixels(area, DISPLAY_REPAIR_TIME, 0);
        for (int i = 0; i < 13; ++i) epd_push_pixels(area, DISPLAY_REPAIR_TIME, 1);
        for (int i = 0; i < 3; ++i) epd_push_pixels(area, DISPLAY_REPAIR_TIME, 2);
        vTaskDelay(1);
    }
    // 面板刚被盲刷成白：把「面板显示的是白」这件事也写进基准，然后整屏推一次当前画面，连底栏
    // 一起推回去。这里不能用 epd_hl_set_all_white()——它清的是绘制缓冲（页面画在 front_fb 上），
    // 会把用户正看的那一页擦掉；修复只该动基准，画面由这一记整屏刷新重新落到面板上。
    // The blind drive left the panel white: the baseline is told so, and one full update pushes the
    // current frame -- navigation bar included -- back onto it. epd_hl_set_all_white() must not be
    // used here: it clears the *drawing* buffer (pages draw into front_fb) and would wipe the page
    // the user is looking at. The repair touches the baseline only; this full update re-lands the
    // frame on the panel.
    // 直接走受锁保护的整屏白底出口，包含底栏；不能被主页裁剪拦截，也不再重复推页。
    // Use the locked full-frame white-baseline path including navigation, without a main-page crop or duplicate page push.
    enum EpdDrawError result = update_display_from_white_with_unlocked(hl, &E0470_WAVEFORM, MODE_GC16);
    if (result != EPD_DRAW_SUCCESS) result = main_recover(hl, result);
    s_main_fault = result != EPD_DRAW_SUCCESS;
    if (s_main_fault) s_full_refresh_requested = true;
    rails_keepalive();
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_image_gray(EpdiyHighlevelState* hl) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    s_full_refresh_requested = false;
    enum EpdDrawError result = update_display_image_gray_unlocked(hl);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    const bool full = display_needs_full();
    enum EpdDrawError result = full
        ? update_display_full_unlocked(hl) : update_display_with_unlocked(hl, waveform, mode);
    if (!full && result == EPD_DRAW_SUCCESS)
        display_light_maintenance_tick_unlocked(hl, display_light_full_area(), false);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_area_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    const bool full = display_needs_full();
    enum EpdDrawError result = full
        ? update_display_full_unlocked(hl) : update_display_area_with_unlocked(hl, waveform, mode, area);
    if (!full && result == EPD_DRAW_SUCCESS)
        display_light_maintenance_tick_unlocked(hl, area, false);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_area_diff_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    const bool full = display_needs_full();
    enum EpdDrawError result = full
        ? update_display_full_unlocked(hl) : update_display_area_diff_with_unlocked(hl, waveform, mode, area);
    if (!full && result == EPD_DRAW_SUCCESS)
        display_light_maintenance_tick_unlocked(hl, area, false);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_click_feedback(EpdiyHighlevelState* hl,EpdRect area) {
    LATENCY_DISPLAY_BEGIN();
    bool held=pico_online_display_begin();
    // 控件只扫自身；显示成功后还原未消费的主页许可，不缓存或回放页面像素。
    // Scan only the control, then restore the unused main permission without caching or replaying page pixels.
    const void* owner=s_main_armed;
    bool shelf=s_main_shelf_page,exit=s_main_shelf_exit,changing=s_main_changing_page;
    EpdRect bands[3];memcpy(bands,s_main_bands,sizeof(bands));
    unsigned count=s_main_band_count;
    bool full=display_needs_full(),restore=owner&&!s_main_fault&&!full;
    display_main_transition_disarm();
    enum EpdDrawError result=full?update_display_full_unlocked(hl):
        update_display_area_diff_with_unlocked(hl,&E0470_FOLLOW_WAVEFORM,MODE_DU,area);
    if(restore&&result==EPD_DRAW_SUCCESS&&!s_main_fault) {
        s_main_armed=owner;s_main_shelf_page=shelf;s_main_shelf_exit=exit;
        s_main_changing_page=changing;s_main_band_count=count;memcpy(s_main_bands,bands,sizeof(bands));
    }
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

enum EpdDrawError update_display_area_full_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    const bool full = display_needs_full();
    enum EpdDrawError result = full
        ? update_display_full_unlocked(hl) : update_display_area_full_with_unlocked(hl, waveform, mode, area);
    if (!full && result == EPD_DRAW_SUCCESS) {
        // 页级全像素 GC16 本身就是一次完整清理，只归零计数，不再追加第二遍。
        // A page-level full-pixel GC16 already is a complete cleanup: reset the counters instead of
        // appending another pass.
        const bool full_cleanup = (mode & 0xF) == MODE_GC16 && display_light_page_level_area(area);
        display_light_maintenance_tick_unlocked(hl, area, full_cleanup);
    }
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 防泛白（不整屏全刷）：用全像素 GL16 把当前帧重推一遍。GL16 裁剪表里只有未变化白底吃
// 1 帧 15→15 白推；黑字/中灰像素会先短暂变浅（0→0 是 11 帧擦白 + 13 帧压黑），约 0.27s 内
// 回到原灰阶；没有整屏黑白全刷。用来抑制同一画面久置后白底慢慢发灰、字边发暗（用户反馈阅读页/
// 票根久置反黑，但不接受为此做整屏 GC16 全刷）。
// Anti-fade without a full flash: re-drive the current frame with full-pixel GL16. In the trimmed
// GL16 table only unchanged white gets one 15->15 white push; black/mid-gray pixels briefly lighten
// (0->0 is 11 erase + 13 darken frames) and return to their gray within ~0.27 s, with no
// whole-screen black/white flash. It suppresses the slow gray/dark drift of a static page (reported
// for the reader and ticket lock, where a periodic GC16 flash was rejected).
enum EpdDrawError update_display_anti_fade(EpdiyHighlevelState* hl) {
    const EpdRect area = {0, 0, epd_rotated_display_width(), epd_rotated_display_height()};
    // 直接走全像素 GL16 出口：即使队列里有待处理的全刷请求也不改走整屏 GC16（那会闪屏）。
    // Drive the full-pixel GL16 path directly so a pending full-refresh request cannot turn this
    // into a whole-screen GC16 flash.
    bool held = pico_online_display_begin();
    // 深→浅首帧若先碰到防泛白出口，也在这里完成擦白 + GC16 复位，待处理请求不会丢。
    // If the anti-fade exit is the first one to see a pending dark->light reset, run the white wipe +
    // GC16 reset here so the pending request can never be dropped.
    if (!epd_get_inverted() && s_light_white_reset_pending && hl != NULL) {
        enum EpdDrawError wipe = display_light_white_reset_unlocked(hl);
        pico_online_display_end(held);
        return wipe;
    }
    const bool inverted = epd_get_inverted();
    enum EpdDrawError result = update_display_area_full_with_unlocked(hl, &E0470_WAVEFORM, MODE_GL16, area);
    // 反色下深色等灰对已被 1k LUT 保持，整片黑底不会被擦白；文字/AA 仍吃 GL16 的白推整理
    // （防止白字久置变灰）。反色下再补一遍轻压黑（深色模式可读性必需，用户要求保留）。
    // Under inversion the 1k LUT holds the dark equal pairs, so the black ground is not erased
    // toward white; glyphs/AA still get their GL16 white refresh. Append the darken settle again:
    // dark-mode readability needs it (explicit user request).
    if (inverted && result == EPD_DRAW_SUCCESS) (void)display_dark_settle_unlocked(hl);
    // 防泛白本身就是一次全像素整帧重推：浅色下把它记作一次整帧整理，重新计时。
    // The anti-fade pass already re-drives the whole frame: count it as a full re-drive in light mode.
    if (!inverted && result == EPD_DRAW_SUCCESS) display_light_activity_reset();
    pico_online_display_end(held);
    return result;
}

enum EpdDrawError update_display_water_turn(EpdiyHighlevelState* hl, EpdRect area,
                                             e0470_turn_dir_t dir) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    const bool full = display_needs_full();
    enum EpdDrawError result = full
        ? update_display_full_unlocked(hl) : update_display_water_turn_unlocked(hl, area, dir);
    if (!full && result == EPD_DRAW_SUCCESS)
        display_light_maintenance_tick_unlocked(hl, area, false);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 水波纹·高清：在 rc100 揭页引擎上按「标定脉宽 + 加密条带」驱动。与「水波纹·快刷」的区别：
//  - 快刷：rc100 FAST 扫描 + reader 文字灰阶波形 + 8 带 + 11.09ms/拍（44 拍，约 488ms）；
//  - 高清：FULL 标定扫描（11090us/帧，脉宽与 GL16 表一致）+ 普通·高清同一张 E0470_WAVEFORM
//    GL16 表 + 最多 32 带 + 默认 12ms/拍（68 拍，约 816ms）——每相脉宽回到校准值，抗锯齿中灰
//    推得准（字体边缘更细），同时用更长的动画换更细的揭页前沿；仍单次推屏、结束提交基准，
//    不追加第二遍定稿。补白仍在其后追加。
// HD water drives rc100's ripple engine with calibrated pulse widths and denser bands. Fast water
// keeps rc100's FAST scan, reader text waveform, 8 bands and 11.09 ms ticks (44 ticks, ~488 ms).
// HD uses the FULL calibrated scan (11090 us/frame, matching the GL16 table), the same
// E0470_WAVEFORM GL16 table as ordinary HD, up to 32 bands and the default 12 ms tick (68 ticks,
// ~816 ms): calibrated pulses make the antialiased mid-grays land correctly (finer glyph edges)
// while the longer animation buys a finer reveal front. It is still a single pass with a committed
// baseline and no second settle pass; the white settle is still appended.
enum EpdDrawError update_display_water_turn_hd(EpdiyHighlevelState* hl, EpdRect area,
                                                e0470_turn_dir_t dir) {
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    const bool full = display_needs_full();
    enum EpdDrawError result = full
        ? update_display_full_unlocked(hl)
        : update_display_hd_water_unlocked(hl, area, dir);
    if (!full && result == EPD_DRAW_SUCCESS)
        display_light_maintenance_tick_unlocked(hl, area, false);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 保留侧滑返回的方向和系统灰阶；其余刷新恢复原rc96。
// Keep directional system-gray edge returns; restore the remaining rc96 presentation path.
enum EpdDrawError update_display_main_turn(EpdiyHighlevelState* hl,EpdRect area,e0470_turn_dir_t dir) {
    LATENCY_DISPLAY_BEGIN();
    bool held=pico_online_display_begin();
    const int prior_tick=e0470_page_turn_tick_us();
    const bool full=display_needs_full();
    e0470_page_turn_set_tick_us(E0470_TURN_FAST_TICK_US);
    enum EpdDrawError result=full?update_display_full_unlocked(hl):
        update_display_reader_turn_unlocked(hl,area,dir,E0470_TURN_FAST_BANDS,
                                            display_main_ui_waveform(), true);
    e0470_page_turn_set_tick_us(prior_tick);
    if(!full&&result==EPD_DRAW_SUCCESS)display_light_maintenance_tick_unlocked(hl,area,false);
    pico_online_display_end(held);LATENCY_DISPLAY_END();return result;
}

// 速读黑白（rc100 算法，普通翻页的变体）：把目标页正文按 50% 阈值改成纯黑白，
// 再用原厂完整 DU 推屏一次（20 相、全速时钟，不叠加 8 帧跟随或水波纹节拍）。
// 抗锯齿边在这一档变成纯黑白，用画面层次换最快翻页；其余档位不受影响。
// Fast BW (the rc100 algorithm, an ordinary-turn variant): threshold the target page body to pure
// black/white at 50%, then push once with the vendor's complete DU (20 phases on the full scan
// clock, without 8-frame FOLLOW or ripple tick padding). Antialiased edges become black/white in
// this step, trading tone for the fastest turn; every other step is unaffected.
enum EpdDrawError update_display_text_turn(EpdiyHighlevelState* hl,EpdRect area,e0470_turn_dir_t dir) {
    (void)dir;
    // 防御：本出口只服务「普通·快刷」(effect 0)；其他档位仍走普通 GL16 差分。
    // Defensive: this outlet only serves Fast ordinary (effect 0); other steps keep plain GL16 diff.
    if (app_settings_reader_turn_effect() != 0)
        return update_display_area_diff_with(hl,display_main_gray_waveform(),MODE_GL16,area);
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    enum EpdDrawError result = EPD_DRAW_SUCCESS;
    const bool full = display_needs_full();
    if (full) result = update_display_full_unlocked(hl);
    else if (main_before_update(hl, &result)) { /* 全局恢复优先 / Global recovery takes priority. */ }
    else if (!display_reader_fast_text_prepare(hl, area))
        result = update_display_area_diff_with_unlocked(hl, display_main_gray_waveform(), MODE_GL16, area);
    else {
        const EpdWaveform* waveform = display_reader_fast_text_waveform();
        use_scan_for(waveform, MODE_DU);
        epd_lcd_set_prefill_lines(127);
        epd_poweron();
        epd_hl_waveform(hl, waveform);
        result = epd_hl_update_area(hl, MODE_DU, 25, area);
        epd_hl_waveform(hl, &E0470_WAVEFORM);
        use_scan_for(&E0470_WAVEFORM, MODE_GL16);
        rails_keepalive();
        if (result == EPD_DRAW_NO_PHASES_AVAILABLE)
            result = update_display_area_diff_with_unlocked(hl, display_main_gray_waveform(), MODE_GL16, area);
        else if (result != EPD_DRAW_SUCCESS) result = main_recover(hl, result);
    }
    // 浅色活动期防淡墨：本出口是阅读翻页主路径，按页级输出计数。
    // Light-mode activity anti-fade: this is the main reader-turn exit, count it as a page-level output.
    if (!full && result == EPD_DRAW_SUCCESS)
        display_light_maintenance_tick_unlocked(hl, area, false);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 地面掩码（保留给白天整片补白兜底路径）：把 back 基准上“front 为纯白”的底色像素改成 0，
// 再走一遍 8 帧 FOLLOW/DU 差分，只对纯白底产生 0→15 的“往白一推”脉冲；字形像素 back=front，
// 差分里不出现，不会变细、不会变粗。反色模式的补黑已改用 display_dark_settle（不再改写 back
// 基准、不会再出现整片白闪），本掩码只剩 display_white_settle 这个对照/兜底入口在用。
// Ground mask, kept only for the legacy day-time whole-ground white settle: marks front==white
// ground pixels black in the back baseline and runs one 8-frame FOLLOW/DU differential, so only
// pure-white ground gets the 0->15 white push while glyph pixels keep back == front. Inverted-mode
// black settle now uses display_dark_settle (no baseline rewrite, no white flash); this mask is only
// reached from the reference/fallback display_white_settle entry.
static void display_ground_mask(EpdiyHighlevelState* hl, EpdRect area) {
    if (!hl || !hl->front_fb || !hl->back_fb) return;
    const int logical_w = epd_rotated_display_width();
    const int logical_h = epd_rotated_display_height();
    if (logical_w <= 0 || logical_h <= 0) return;
    int x0 = area.x < 0 ? 0 : area.x;
    int y0 = area.y < 0 ? 0 : area.y;
    int x1 = area.x + area.width;
    int y1 = area.y + area.height;
    if (x1 > logical_w) x1 = logical_w;
    if (y1 > logical_h) y1 = logical_h;
    if (x0 >= x1 || y0 >= y1) return;
    // 逻辑区域四角映射到物理缓冲，得到需要扫描的物理范围（与 display_invert_area 同一套映射）。
    // Map the logical corners to the physical buffer with the same rotation used everywhere else.
    const int lx[4] = {x0, x1 - 1, x1 - 1, x0};
    const int ly[4] = {y0, y0, y1 - 1, y1 - 1};
    int px[4], py[4];
    for (int i = 0; i < 4; ++i) {
        int tx = lx[i], ty = ly[i];
        switch (epd_get_rotation()) {
            case EPD_ROT_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                tx = epd_width() - tx - 1;
            } break;
            case EPD_ROT_INVERTED_LANDSCAPE:
                tx = epd_width() - tx - 1;
                ty = epd_height() - ty - 1;
                break;
            case EPD_ROT_INVERTED_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                ty = epd_height() - ty - 1;
            } break;
            default: break;
        }
        px[i] = tx;
        py[i] = ty;
    }
    int bx0 = px[0], bx1 = px[0], by0 = py[0], by1 = py[0];
    for (int i = 1; i < 4; ++i) {
        if (px[i] < bx0) bx0 = px[i];
        if (px[i] > bx1) bx1 = px[i];
        if (py[i] < by0) by0 = py[i];
        if (py[i] > by1) by1 = py[i];
    }
    const int stride = epd_width() / 2;
    for (int physical_y = by0; physical_y <= by1; ++physical_y) {
        const uint8_t* frow = hl->front_fb + (size_t)stride * physical_y;
        uint8_t* brow = hl->back_fb + (size_t)stride * physical_y;
        for (int physical_x = bx0; physical_x <= bx1; ++physical_x) {
            int llx, lly;
            switch (epd_get_rotation()) {
                case EPD_ROT_PORTRAIT: llx = physical_y; lly = epd_width() - physical_x - 1; break;
                case EPD_ROT_INVERTED_LANDSCAPE:
                    llx = epd_width() - physical_x - 1; lly = epd_height() - physical_y - 1; break;
                case EPD_ROT_INVERTED_PORTRAIT:
                    llx = epd_height() - physical_y - 1; lly = physical_x; break;
                default: llx = physical_x; lly = physical_y; break;
            }
            if (llx < x0 || llx >= x1 || lly < y0 || lly >= y1) continue;
            const uint8_t raw = frow[physical_x >> 1];
            const uint8_t value = (physical_x & 1) ? (raw >> 4) : (raw & 0x0F);
            // 只有 0xF（纯白底）才补黑；0xE 可能已经是字形抗锯齿边缘，碰了字会变细/变色。
            // Only pure-white ground (0xF) is re-driven; 0xE may already be a glyph AA fringe,
            // and touching it would thin or tint the text.
            const uint8_t target = value == 0x0F ? 0x00 : value;
            uint8_t cur = brow[physical_x >> 1];
            if (physical_x & 1) cur = (uint8_t)((cur & 0x0F) | (target << 4));
            else cur = (uint8_t)((cur & 0xF0) | target);
            brow[physical_x >> 1] = cur;
        }
    }
}

// 最早版本的地面定稿：掩码后走标准 8 帧 FOLLOW/DU（满幅迁移往白/往黑各推 8 拍）。
// 白天清残影已按 rc100 整体替换，这里只服务白天整片补白的兜底/对照入口 display_white_settle。
// Earliest ground settle: mask first, then the standard 8-frame FOLLOW/DU pass (8 pushes for a
// full travel). Day-time ghost handling was replaced by rc100's algorithm as a whole, so this now
// only serves the reference/fallback day-time white-settle entry display_white_settle.
static void display_ground_settle(EpdiyHighlevelState* hl, EpdRect area) {
    display_ground_mask(hl, area);
    (void)update_display_area_diff_with(hl, &E0470_FOLLOW_WAVEFORM, MODE_DU, area);
}

// ---- 反色压黑清理 / Inverted-mode darken settle ----
// 反色下逻辑白底就是物理黑底，整屏 GL16/GC16 对深色等灰对的擦白驱动已在 1k LUT 层保持（见
// epd_build_1ppB_lut_1k），代价是黑底残影不会被整屏刷新清掉。这里用一张自建相位表做补黑：
// 只给差分为 (to<<4)|from 且 to=15（逻辑白底 = 物理黑底）的像素动作 1（压黑），其余像素全部保持；
// 字形、抗锯齿边和白字一个都不会被驱动，因此全程不可能出现白光。
// Under inversion the logical-white target is the physical black ground. The 1 KiB LUT now holds the
// dark equal pairs so full-pixel GL16/GC16 can no longer erase the ground toward white -- at the cost
// of not cleaning its residue. This settle builds its own phase LUT where only pixels whose target is
// logical 15 (physical black ground) get action 1 (darken); everything else holds, so glyphs, AA
// fringes and white text are never driven and no white flash is possible.
static bool display_dark_settle_frames_unlocked(EpdiyHighlevelState* hl, int frames) {
    if (!hl || !hl->front_fb || !hl->back_fb || !hl->difference_fb || !hl->dirty_lines ||
        !hl->dirty_columns || !epd_get_inverted()) {
        return false;
    }
    const int w = epd_width();
    const int h = epd_height();
    if (frames < 1) frames = 1;
    // 1024B = 1k 相位表（256 个 32bit 表项）；每行一个相位号，全 0 走第一张表。
    // 1024 B = 1 KiB phase LUT (256 32-bit entries); one phase index per line, all zero = table 0.
    static uint8_t* s_lut;
    static int8_t* s_phase;
    if (s_lut == NULL) s_lut = heap_caps_malloc(1024, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (s_phase == NULL) s_phase = heap_caps_malloc((size_t)h, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (s_lut == NULL || s_phase == NULL) return false;
    // 1k 表的每个表项是一个 32bit 字，只有低 2 bit 是动作（0 保持 / 1 压黑 / 2 擦白）。
    // Each 1 KiB LUT entry is a 32-bit word; only the low 2 bits are the action (0 hold/1 darken/2 erase).
    memset(s_lut, 0, 1024);
    for (int i = 0xF0; i <= 0xFF; ++i) ((uint32_t*)s_lut)[i] = 1;
    memset(s_phase, 0, (size_t)h);
    epd_difference_image_cropped(hl->front_fb, hl->back_fb, epd_full_screen(), hl->difference_fb,
                                 hl->dirty_lines, hl->dirty_columns);
    // 真机教训：这是固件里唯一的「整屏 + 1ppb 差分 + FAST」路径，FAST 每行只有约 10us，
    // 供数带宽（121.6MB/s）追不上时 line queue 在第 1 帧就欠载，扫描行提前结束——物理行
    // y=683-逻辑x，于是逻辑左半完全没被驱动（用户反馈「左半边清不掉、手动全刷也清不掉」）。
    // 改用 FULL 标定扫描（每行约 16us，76MB/s）+ 127 行预填（翻页引擎同档同样是 127），
    // 压黑脉宽更强且不再欠载；欠载失败不再静默，记日志并返回 false 让调用方知道。
    // Device lesson: this is the only full-screen FAST + 1ppb-difference path in the firmware. FAST
    // gives only ~10 us/line, so when the PSRAM feed (121.6 MB/s) cannot keep up the line queue
    // underruns on the first frame and the scan ends early. Physical row y = 683 - logical x, so the
    // logical LEFT half is never driven (user report: left half never clears, not even manual full
    // refresh). Use the calibrated FULL scan (~16 us/line, 76 MB/s) plus 127-line prefill (the turn
    // engine uses 127 for the same reason): stronger darken pulses and no underrun. Failures are no
    // longer silent: log and return false so callers know the screen was only partially driven.
    read_pico_epd_use_scan(READ_PICO_EPD_SCAN_FULL);
    epd_lcd_set_prefill_lines(127);
    epd_poweron();
    const uint8_t* luts[1] = {s_lut};
    bool ok = true;
    for (int frame = 0; frame < frames; ++frame) {
        memset(hl->dirty_lines, 1, sizeof(bool) * (size_t)h);
        memset(hl->dirty_columns, 0xFF, (size_t)w / 2);
        // epd_draw_base 启动时把相位表交给渲染上下文并立即清掉全局登记，所以每帧都要重设。
        // epd_draw_base hands the phase LUTs to the render context then clears the registration,
        // so re-arm them before every frame.
        epd_set_line_phase_luts(luts, s_phase);
        enum EpdDrawError result = epd_draw_base(
            epd_full_screen(), hl->difference_fb, epd_full_screen(),
            MODE_PACKING_1PPB_DIFFERENCE | MODE_DU, 25, hl->dirty_lines, hl->dirty_columns,
            &E0470_APPLY_WAVEFORM);
        if (result != EPD_DRAW_SUCCESS) {
            ok = false;
            ESP_LOGE(TAG, "dark settle frame %d/%d failed (%d); screen partially driven",
                     frame + 1, frames, result);
            break;
        }
    }
    epd_clear_phase_luts();
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    rails_keepalive();
    return ok;
}

static bool display_dark_settle_unlocked(EpdiyHighlevelState* hl) {
    return display_dark_settle_frames_unlocked(hl, DISPLAY_DARK_SETTLE_FRAMES);
}

// 反色整屏清理（用户确认接受「黑闪」）：先全屏压黑把深底残留重推一遍，再把 back 基准设成
// 「逻辑全黑」重绘整帧——背景等灰对被 1k LUT 保持（物理已是黑，不会白闪），文字/AA/图片按目标
// 灰阶从黑底重新驱动。等效旧版整屏 GC16 的擦洗 + 重绘，但整个过程不会出现整屏白光。
// Inverted full cleanup (user approved a "black flash"): darken the whole panel to re-drive the dark
// ground residue, then set the back baseline to logical black and repaint the frame — the ground's
// equal dark pairs stay held by the 1 KiB LUT (already physically black, so no white flash) while
// text/AA/images are driven back to their target grays from black. This matches the old full GC16's
// erase+repaint without ever flashing the whole screen white.
static bool display_dark_refresh_unlocked(EpdiyHighlevelState* hl) {
    if (!hl || !hl->front_fb || !hl->back_fb || !epd_get_inverted()) return false;
    // 临时关闭 1k LUT 的深色等灰对保持，让整屏（含深色底）走一次真正的 GC16 擦白+压黑：
    // 反复只压黑会让残影越积越多、墨色越来越淡；真正的 GC16 能清残影并恢复墨色密度。
    // Disable the 1 KiB LUT's dark-pair hold so the whole panel (dark ground included) runs one real
    // GC16 erase+write cycle: repeated darken-only passes accumulate residue and fade the ink; a real
    // GC16 clears the residue and restores ink density.
    epd_set_inverted_dark_hold(false);
    epd_hl_waveform(hl, &E0470_FULL_WAVEFORM);
    use_scan_for(&E0470_FULL_WAVEFORM, MODE_GC16);
    epd_poweron();
    enum EpdDrawError result = epd_hl_update_screen_full(hl, MODE_GC16, 25);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    epd_set_inverted_dark_hold(true);
    rails_keepalive();
    if (result != EPD_DRAW_SUCCESS) {
        ESP_LOGE(TAG, "dark GC16 reset failed (%d)", result);
        return false;
    }
    return true;
}

// 深色模式补黑：只驱动物理黑底，字形与抗锯齿边保持不动，不再白闪。只在纯文字页/周期清理调用。
// Dark-mode darken settle: drive only the physical black ground, never glyphs/AA fringes, and never
// flash white. Called after text-page turns and for periodic cleanup.
void display_black_settle(EpdiyHighlevelState* hl, EpdRect area) {
    (void)area;
    if (!epd_get_inverted()) return;
    display_dark_settle(hl);
}

// 深色模式压黑清理的公开入口（自己取显示锁）；反色关闭时为空操作。
// Public inverted-mode darken settle (takes the display lock itself); no-op outside inverted mode.
void display_dark_settle(EpdiyHighlevelState* hl) {
    if (!hl || !epd_get_inverted()) return;
    bool held = pico_online_display_begin();
    (void)display_dark_settle_unlocked(hl);
    pico_online_display_end(held);
}

// 反色整屏清理的公开入口（自己取显示锁）：黑闪式清理，用于到页周期清理。
// Public inverted full-cleanup entry (takes the display lock): black-flash cleanup for periodic
// page-count cleaning. Callers must repaint the frame content first, exactly like a full refresh.
bool display_dark_refresh(EpdiyHighlevelState* hl) {
    if (!hl || !epd_get_inverted()) return false;
    bool held = pico_online_display_begin();
    bool ok = display_dark_refresh_unlocked(hl);
    pico_online_display_end(held);
    return ok;
}

// 阅读页浅色白底推白（1.15.27）：只对「目标为纯白」的像素施加纯白推帧（8 帧，约 95ms），不含
// 任何压黑帧——1.15.24–1.15.26 的先压黑再白饱和在真机上就是「每页闪黑两次」；白底本来就白，
// 纯白推在视觉上不可见，同时仍把白底残留的旧黑字/图案逐步往白推。黑字、抗锯齿灰边、插图都不是
// 纯白目标，不驱动。浅色阅读页翻页成功后调用；反色模式空操作。残影的彻底清理仍走低频整屏 GC16。
// Reader light-mode white-ground push (1.15.27): pure-white targets get only white-push frames
// (8 frames, ~95 ms) and never a darken frame — the 1.15.24–1.15.26 darken-then-white reset looked
// like two black flashes per page on the device. On an already-white ground the white push is
// visually invisible while still nudging old black residue toward white. Black glyphs, AA fringes and
// artwork are not pure-white targets and stay undriven. Called after a light-mode reader page turn;
// no-op in inverted mode. Deep cleanup still belongs to the low-frequency full-screen GC16 reset.
enum EpdDrawError display_reader_white_repair(EpdiyHighlevelState* hl, EpdRect area) {
    const EpdWaveform* waveform = display_reader_white_repair_waveform();
    if (hl == NULL || waveform == NULL || epd_get_inverted() ||
        area.width <= 0 || area.height <= 0) return EPD_DRAW_SUCCESS;
    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    // 复位循环需要标定脉宽，走 FULL 扫描；翻页期间预取在跑，保持 127 行预填防欠载。
    // The reset cycle needs calibrated pulse widths, so use the FULL scan; page prefetch is running,
    // so keep the 127-line prefill to avoid underruns.
    read_pico_epd_use_scan(READ_PICO_EPD_SCAN_FULL);
    epd_lcd_set_prefill_lines(127);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = epd_hl_update_area_full(hl, MODE_GL16, 25, area);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    rails_keepalive();
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
    return result;
}

// 白天模式整片补白（旧路径，保留兜底/对照）：同一个地面掩码只把纯白底再往白推一次，紧跟在
// 翻页那一次推屏之后，与翻页同一次 present 内完成。present 现在改调定向版
// display_white_settle_ink，只补上一页有墨的像素，不再无条件整片推白。
// Day-mode whole-ground white settle (legacy path, kept as a fallback/reference): the same ground
// mask pushes the pure-white ground once more immediately after the turn push, inside the same
// present(). present() now calls the targeted display_white_settle_ink instead, so only
// previous-page ink pixels are re-driven.
void display_white_settle(EpdiyHighlevelState* hl, EpdRect area) {
    if (epd_get_inverted()) return;
    display_ground_settle(hl, area);
}

// 定向补白：只把「上一页有墨、这一页已经纯白」的像素在 back 基准里改成 0，再走一次 8 帧
// FOLLOW/DU，让这些像素各自完成一次 0→15 的满幅往白迁移（8 拍）。与 display_ground_mask 的
// 区别是：不再对整片「本来就是白」的地面做全幅推白——每页那 80–90% 的纯白像素不再被额外过驱动，
// 只有旧字迹变白的像素补一次；页面本来就白、上一页也没墨的像素保持 back==front，不进差分。
// old_ink 是按 area 局部逻辑坐标打包的 1bpp 掩码（stride=(area.width+7)/8，每字节高位在前），
// 旋转映射与 display_ground_mask/display_invert_area 同一套；反色模式保持原补黑路径，本函数空操作。
// Targeted white settle: mark only pixels that carried ink on the previous page and are pure white
// now as black in the back baseline, then run one 8-frame FOLLOW/DU pass so exactly those pixels
// travel 0->15 (8 white pushes). Unlike display_ground_mask this never re-drives the whole
// already-white ground (80-90% of the body was over-driven on every page); pixels that were white
// before keep back==front and stay out of the differential. old_ink is a 1bpp mask in area-local
// logical coordinates, stride=(width+7)/8, MSB-first; the rotation mapping matches
// display_ground_mask/display_invert_area. No-op when the panel is inverted (that path keeps the
// unchanged black settle).
void display_white_settle_ink(EpdiyHighlevelState* hl, EpdRect area,
                              const uint8_t* old_ink, int stride) {
    if (epd_get_inverted()) return;
    if (!hl || !hl->front_fb || !hl->back_fb || !old_ink || stride <= 0) return;
    const int logical_w = epd_rotated_display_width();
    const int logical_h = epd_rotated_display_height();
    if (logical_w <= 0 || logical_h <= 0) return;
    int x0 = area.x < 0 ? 0 : area.x;
    int y0 = area.y < 0 ? 0 : area.y;
    int x1 = area.x + area.width;
    int y1 = area.y + area.height;
    if (x1 > logical_w) x1 = logical_w;
    if (y1 > logical_h) y1 = logical_h;
    if (x0 >= x1 || y0 >= y1) return;
    // 逻辑区域四角映射到物理缓冲，得到需要扫描的物理范围（与 display_ground_mask 同一套映射）。
    // Map the logical corners to the physical buffer with the same rotation used everywhere else.
    const int lx[4] = {x0, x1 - 1, x1 - 1, x0};
    const int ly[4] = {y0, y0, y1 - 1, y1 - 1};
    int px[4], py[4];
    for (int i = 0; i < 4; ++i) {
        int tx = lx[i], ty = ly[i];
        switch (epd_get_rotation()) {
            case EPD_ROT_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                tx = epd_width() - tx - 1;
            } break;
            case EPD_ROT_INVERTED_LANDSCAPE:
                tx = epd_width() - tx - 1;
                ty = epd_height() - ty - 1;
                break;
            case EPD_ROT_INVERTED_PORTRAIT: {
                int t = tx; tx = ty; ty = t;
                ty = epd_height() - ty - 1;
            } break;
            default: break;
        }
        px[i] = tx;
        py[i] = ty;
    }
    int bx0 = px[0], bx1 = px[0], by0 = py[0], by1 = py[0];
    for (int i = 1; i < 4; ++i) {
        if (px[i] < bx0) bx0 = px[i];
        if (px[i] > bx1) bx1 = px[i];
        if (py[i] < by0) by0 = py[i];
        if (py[i] > by1) by1 = py[i];
    }
    const int phys_stride = epd_width() / 2;
    size_t driven = 0;
    for (int physical_y = by0; physical_y <= by1; ++physical_y) {
        const uint8_t* frow = hl->front_fb + (size_t)phys_stride * physical_y;
        uint8_t* brow = hl->back_fb + (size_t)phys_stride * physical_y;
        for (int physical_x = bx0; physical_x <= bx1; ++physical_x) {
            int llx, lly;
            switch (epd_get_rotation()) {
                case EPD_ROT_PORTRAIT: llx = physical_y; lly = epd_width() - physical_x - 1; break;
                case EPD_ROT_INVERTED_LANDSCAPE:
                    llx = epd_width() - physical_x - 1; lly = epd_height() - physical_y - 1; break;
                case EPD_ROT_INVERTED_PORTRAIT:
                    llx = epd_height() - physical_y - 1; lly = physical_x; break;
                default: llx = physical_x; lly = physical_y; break;
            }
            if (llx < x0 || llx >= x1 || lly < y0 || lly >= y1) continue;
            const uint8_t fraw = frow[physical_x >> 1];
            const uint8_t value = (physical_x & 1) ? (fraw >> 4) : (fraw & 0x0F);
            // 掩码只覆盖上一页有墨的像素；front 仍为纯白才补，字形/抗锯齿边照旧保持 back==front。
            // Only previous-page ink pixels whose new value is still pure white are re-driven; glyphs
            // and AA fringes keep back==front.
            uint8_t target = value;
            if (value == 0x0F) {
                const int mx = llx - area.x, my = lly - area.y;
                if (mx >= 0 && my >= 0 && mx < area.width && my < area.height &&
                    (((old_ink[(size_t)my * (size_t)stride + ((size_t)mx >> 3)]) >>
                      (7 - (mx & 7))) & 1u)) {
                    target = 0x00;
                    ++driven;
                }
            }
            uint8_t cur = brow[physical_x >> 1];
            if (physical_x & 1) cur = (uint8_t)((cur & 0x0F) | (target << 4));
            else cur = (uint8_t)((cur & 0xF0) | target);
            brow[physical_x >> 1] = cur;
        }
    }
    ESP_LOGD(TAG, "targeted white settle: %u px of %d x %d area",
             (unsigned)driven, area.width, area.height);
    (void)update_display_area_diff_with(hl, &E0470_FOLLOW_WAVEFORM, MODE_DU, area);
}

void guard_draw_result(EpdiyHighlevelState* hl, enum EpdDrawError result) {    LATENCY_DISPLAY_BEGIN();
    bool held = pico_online_display_begin();
    guard_draw_result_unlocked(hl, result);
    pico_online_display_end(held);
    LATENCY_DISPLAY_END();
}
