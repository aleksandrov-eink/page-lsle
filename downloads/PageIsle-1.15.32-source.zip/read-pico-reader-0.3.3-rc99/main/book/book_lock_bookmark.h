/* SPDX-License-Identifier: LicenseRef-Kiikoread-Personal-Study-1.0
 * 中文：当前页面上的透明PNG书封；输入framebuffer即底图，不加载书籍。
 * English: Transparent PNG cover over the current framebuffer; never load a book for its background.
 */
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "epdiy.h"
/// 输出中途卡I/O失败可能留下未完成像素；返回false时调用方必须绘制锁屏兜底，不能再次叠图。
/// Mid-output SD errors may leave incomplete pixels; on false callers must draw fallback art rather than composite again.
bool book_lock_bookmark_draw(uint8_t *fb,const char *png);
/// 预览缓存：按目标框等比解码 PNG 层并去白，只占一小块 PSRAM；不复制整屏、不依赖 SD 缓存。
/// 设置页的「预览透明书封」用它替代整屏画布，修复图片能选中却无法预览的问题。
/// Preview cache: decode the PNG layer at the target box size and remove white; it keeps only a small
/// PSRAM block, copies no frame and needs no SD cache. The settings preview uses it instead of a
/// full-screen canvas, fixing "the image can be picked but not previewed".
void book_lock_bookmark_preview_release(void);
bool book_lock_bookmark_preview_ready(void);
bool book_lock_bookmark_preview_build(const char *png,unsigned max_w,unsigned max_h);
void book_lock_bookmark_preview_draw(uint8_t *fb,EpdRect area);
