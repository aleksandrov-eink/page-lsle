/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 书目录与 FAT 容量查询；调用方负责先显示首次初始化提示。
 * Book directories and FAT capacity queries; callers show initialization feedback first.
 *
 * 冻结：不格式化 SD；内置 storage 分区按需挂载，失败不影响可用 SD。
 * Frozen: never format SD; mount internal storage on demand without blocking usable SD on failure.
 * 冻结：有卡但挂载失效时不把上传静默切换到内置存储；拔卡不复用旧容量。
 * Frozen: present but invalid media must not silently redirect uploads to flash; never reuse removed-card capacity.
 * 冻结：用户确认后仅删已挂载书根内的直接普通书籍；书架条目可位于书根多级目录或卡内任意位置，
 * 走 book_store_delete_shelf 并对相对路径逐段校验；文件与进度部分失败必须返回，不通知 UI 版本。
 * Frozen: after user confirmation, delete only direct regular books in mounted roots. Shelf entries
 * may live in nested root directories or anywhere on the card, go through book_store_delete_shelf
 * with per-component path validation; report partial failures without notifying UI revision.
 * 冻结：删除前清除同名普通覆盖备份；仅有备份时先恢复，失败保留可恢复的原书。
 * Frozen: clear a matching regular replacement backup before deletion; restore backup-only books first and preserve recovery on failure.
 */
#include "book_store.h"
#include "book_progress.h"
#include "settings.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <unistd.h>
#include "esp_log.h"
#include "esp_vfs_fat.h"
#include "read_pico_sd.h"
#include "wear_levelling.h"

static const char* TAG = "book_store";
static wl_handle_t s_wl = WL_INVALID_HANDLE;
static unsigned s_revision;
static bool s_roots_degraded;

void book_store_notify_changed(void) { ++s_revision; }
unsigned book_store_revision(void) { return s_revision; }
bool book_store_roots_degraded(void) { return s_roots_degraded; }

static esp_err_t ensure_dir(const char* path) {
    if (mkdir(path, 0777) == 0) return ESP_OK;
    if (errno == EEXIST) {
        struct stat st;
        if (stat(path, &st) == 0 && S_ISDIR(st.st_mode)) return ESP_OK;
    }
    ESP_LOGW(TAG, "book directory unavailable: %s (%d)", path, errno);
    return ESP_FAIL;
}

static bool sd_ready(void) {
    read_pico_sd_info_t info = {0};
    read_pico_sd_get_info(&info);
    return info.present && info.mounted;
}

static esp_err_t flash_root(book_store_root_t* out) {
    if (!book_store_flash_ready()) {
        const esp_vfs_fat_mount_config_t config = {
            .format_if_mount_failed = true,
            .max_files = 4,
            .allocation_unit_size = 4096,
        };
        esp_err_t err = esp_vfs_fat_spiflash_mount_rw_wl("/flash", "storage", &config, &s_wl);
        if (err != ESP_OK) {
            s_wl = WL_INVALID_HANDLE;
            ESP_LOGW(TAG, "flash mount: %s", esp_err_to_name(err));
            return err;
        }
    }
    esp_err_t err = ensure_dir("/flash/books");
    if (err == ESP_OK) *out = (book_store_root_t){.path = "/flash/books", .is_flash = true};
    return err;
}

esp_err_t book_store_roots(book_store_root_t out[BOOK_STORE_ROOT_MAX], int* n) {
    if (out == NULL || n == NULL) return ESP_ERR_INVALID_ARG;
    *n = 0;
    s_roots_degraded = false;
    memset(out, 0, sizeof(*out) * BOOK_STORE_ROOT_MAX);
    if (sd_ready()) {
        // Also show books already copied to a singular `book` directory.
        struct stat legacy;
        if (!strcmp(app_settings_books_dir(), "/sdcard/books") && stat("/sdcard/book", &legacy) == 0 && S_ISDIR(legacy.st_mode))
            out[(*n)++] = (book_store_root_t){.path = "/sdcard/book", .is_flash = false};
        if (ensure_dir(app_settings_books_dir()) == ESP_OK)
            snprintf(out[(*n)++].path, sizeof(out[0].path), "%s", app_settings_books_dir());
        else s_roots_degraded = true;
    } else {
        read_pico_sd_info_t info = {0};
        read_pico_sd_get_info(&info);
        if (info.present) s_roots_degraded = true;
    }
    esp_err_t err = flash_root(&out[*n]);
    if (err == ESP_OK) ++*n;
    else s_roots_degraded = true;
    return *n > 0 ? ESP_OK : err;
}

esp_err_t book_store_upload_root(book_store_root_t* out) {
    if (out == NULL) return ESP_ERR_INVALID_ARG;
    memset(out, 0, sizeof(*out));
    if (!sd_ready()) {
        read_pico_sd_info_t info = {0};
        read_pico_sd_get_info(&info);
        // 有卡但挂载失效时让用户显式重挂，不能悄悄改写内置目录。
        // Present but invalid media requires an explicit remount, not silent flash redirection.
        if (info.present) return ESP_ERR_INVALID_STATE;
        return flash_root(out);
    }
    esp_err_t err = ensure_dir(app_settings_books_dir());
    if (err == ESP_OK) snprintf(out->path, sizeof(out->path), "%s", app_settings_books_dir());
    return err;
}

size_t book_store_file_limit(const book_store_root_t* root) {
    if (root == NULL) return 0;
    return root->is_flash ? BOOK_STORE_FLASH_FILE_MAX : SIZE_MAX;
}

uint64_t book_store_free_bytes(const book_store_root_t* root) {
    if (root == NULL) return 0;
    if (!root->is_flash && !sd_ready()) return 0;
    uint64_t total = 0, free_bytes = 0;
    esp_err_t err = esp_vfs_fat_info(root->is_flash ? "/flash" : "/sdcard", &total, &free_bytes);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "FAT capacity: %s", esp_err_to_name(err));
        return 0;
    }
    return free_bytes;
}

bool book_store_flash_ready(void) {
    return s_wl != WL_INVALID_HANDLE;
}

// 书架同时列出书根多级目录内的书，以及从文件管理打开过、位于卡内任意位置的 TXT/EPUB/Markdown。
// 书架删除必须覆盖同一范围，但仍逐级校验相对路径：拒绝空段、"."、".."、反斜杠和冒号，绝不越出媒体根。
// The shelf lists books in nested root directories and books opened from the file manager
// anywhere on the card. Shelf deletion covers that same scope but still validates every relative
// path component: empty, ".", "..", backslash and colon are rejected so it can never leave the mount.
static bool delete_relative_path_valid(const char* relative, bool nested) {
    size_t length = strlen(relative);
    if (!length || relative[length - 1] == '/') return false;
    if (!nested && strchr(relative, '/')) return false;   // 严格模式只接受直接子文件 / direct child only
    const char* at = relative;
    while (*at) {
        const char* start = at;
        while (*at && *at != '/') {
            const unsigned char c = (const unsigned char)*at;
            if (c < 32 || c == 127 || c == '\\' || c == ':') return false;
            ++at;
        }
        const size_t part = (size_t)(at - start);
        if (!part || part > 255) return false;   // FAT 单段上限 / FAT per-component limit
        if (part == 1 && start[0] == '.') return false;
        if (part == 2 && start[0] == '.' && start[1] == '.') return false;
        if (*at == '/') ++at;
    }
    return true;
}
// 删除白名单同时约束“删除书籍”与“覆盖备份恢复”；Markdown 与 TXT/EPUB 同等对待。
// The deletion whitelist also governs backup restoration; Markdown is treated like TXT/EPUB.
static bool delete_book_suffix(const char* relative) {
    const char* base = strrchr(relative, '/');
    base = base ? base + 1 : relative;
    const char* ext = strrchr(base, '.');
    return ext && (!strcasecmp(ext, ".txt") || !strcasecmp(ext, ".epub") ||
                   !strcasecmp(ext, ".md") || !strcasecmp(ext, ".markdown"));
}

// nested=false 保持原冻结契约（仅书根直接子文件）；nested=true 用于删除书架条目：
// 书根任意层级、或已挂载媒体上任意位置的书籍文件。两者共用同一套路径与后缀校验。
// nested=false keeps the frozen direct-child contract; nested=true serves shelf entries: any
// depth inside a book root, or a book file anywhere on mounted media. Both share the same path
// and suffix validation.
static esp_err_t delete_impl(const char* path, bool nested, bool* removed) {
    if (!removed) return ESP_ERR_INVALID_ARG;
    *removed = false;
    if (!path || strnlen(path, BOOK_STORE_PATH_MAX) >= BOOK_STORE_PATH_MAX) return ESP_ERR_INVALID_ARG;
    const char* books_dir = app_settings_books_dir();
    const size_t books_len = strlen(books_dir);
    const char* root;
    const char* relative;
    if (!strncmp(path, books_dir, books_len) && path[books_len] == '/') {
        root = books_dir; relative = path + books_len + 1;
        if (!sd_ready()) return ESP_ERR_INVALID_STATE;
    } else if (!strcmp(books_dir, "/sdcard/books") && !strncmp(path, "/sdcard/book/", 13)) {
        root = "/sdcard/book"; relative = path + 13;
        if (!sd_ready()) return ESP_ERR_INVALID_STATE;
    } else if (!strncmp(path, "/flash/books/", 13)) {
        root = "/flash/books"; relative = path + 13;
        if (!book_store_flash_ready()) return ESP_ERR_INVALID_STATE;
    } else if (!nested) {
        return ESP_ERR_INVALID_ARG;
    } else if (!strncmp(path, "/sdcard/", 8)) {
        root = "/sdcard"; relative = path + 8;
        if (!sd_ready()) return ESP_ERR_INVALID_STATE;
    } else if (!strncmp(path, "/flash/", 7)) {
        root = "/flash"; relative = path + 7;
        if (!book_store_flash_ready()) return ESP_ERR_INVALID_STATE;
    } else return ESP_ERR_INVALID_ARG;
    if (!delete_relative_path_valid(relative, nested)) return ESP_ERR_INVALID_ARG;
    if (!delete_book_suffix(relative)) return ESP_ERR_INVALID_ARG;
    struct stat st;
    if (stat(root, &st) != 0 || !S_ISDIR(st.st_mode)) return ESP_ERR_INVALID_STATE;
    // FAT 没有符号链接；主机测试用 lstat，确保不会跟随主机链接删其他文件。
    // FAT has no symlinks; host builds use lstat to reject host links rather than follow them.
#ifdef ESP_PLATFORM
    int result = stat(path, &st);
#else
    int result = lstat(path, &st);
#endif
    bool exists = result == 0;
    if (!exists && errno != ENOENT) return ESP_FAIL;
    if (exists && !S_ISREG(st.st_mode)) return ESP_ERR_INVALID_ARG;
    // 显式删除也处理覆盖备份，避免下次传书启动恢复已删图书。
    // Explicit deletion handles replacement backups so transfer startup cannot resurrect deleted books.
    const char suffix[] = ".rename-backup";
    const char* base = strrchr(relative, '/');
    base = base ? base + 1 : relative;
    if (strlen(base) + sizeof(suffix) - 1 <= 255) {
        char backup[BOOK_STORE_PATH_MAX + sizeof(suffix)];
        snprintf(backup, sizeof(backup), "%s%s", path, suffix);
#ifdef ESP_PLATFORM
        result = stat(backup, &st);
#else
        result = lstat(backup, &st);
#endif
        if (result != 0) {
            if (errno != ENOENT) return ESP_FAIL;
        } else {
            if (!S_ISREG(st.st_mode)) return ESP_ERR_INVALID_ARG;
            if (exists) {
                if (unlink(backup) != 0 && errno != ENOENT) return ESP_FAIL;
            } else {
                // 未完成覆盖先恢复旧书；后续删除失败时仍保留可见原书。
                // Restore an interrupted replacement first, keeping the old book visible if deletion fails.
                if (rename(backup, path) != 0) return ESP_FAIL;
                exists = true;
            }
        }
    }
    if (exists) {
        if (unlink(path) != 0 && errno != ENOENT) return ESP_FAIL;
    }
    *removed = true;
    return book_progress_forget(path);
}

esp_err_t book_store_delete(const char* path, bool* removed) {
    return delete_impl(path, false, removed);
}

esp_err_t book_store_delete_shelf(const char* path, bool* removed) {
    return delete_impl(path, true, removed);
}
