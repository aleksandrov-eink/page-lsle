/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 * 中文：Markdown 书源：按文件偏移建章节目录，把一章 md 解析成块表与行内样式 run 表。
 * English: Markdown source: build a chapter index from file offsets and parse one chapter into
 * blocks plus inline style runs.
 * 冻结：同样输入与同样度量必然输出同样字节；不写文件、不联网；大缓冲一律 PSRAM。
 * Frozen: the same input and metrics always produce the same bytes; never writes files, never
 * uses the network; every large buffer lives in PSRAM.
 */
#include "book_md.h"

#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "esp_heap_caps.h"
#include "esp_log.h"
#include "ttf_font.h"

#define PSRAM_CAPS (MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)
#define MD_READ_BLOCK (64 * 1024) ///< 索引与切分流式读块 / streaming read block used by indexing
#define MD_LINE_CAP 256 ///< 索引阶段单行前缀上限 / per-line prefix cap while indexing
#define MD_TITLE_MAX 48 ///< UTF-8 目录标题容量 / UTF-8 title capacity
#define MD_PART_TARGET (48 * 1024) ///< 无标题时目标章长 / target chapter span without headings
#define MD_SOURCE_MAX (96 * 1024) ///< 单章源字节硬上限 / hard per-chapter source span
#define MD_SOURCE_READ_MAX (384 * 1024) ///< 异常超长章只读这么多 / read cap for abnormal oversized chapters
#define MD_TABLE_COLS_MAX 16 ///< 表格列上限 / table column cap
#define MD_TABLE_ROWS_MAX 256 ///< 表格行上限 / table row cap
#define MD_TABLE_TEXT_MAX (64 * 1024) ///< 整表单元格文本上限 / cell text budget of one table
// 表格行目标宽度上限：布局只在旋转/字号/边距/字距变化时按现有正文重排而不重新解析，
// 横屏（正文宽约 1100px）排出的表格行回到竖屏（正文宽最小 588px）会被二次折行散架。
// 压到 560px（≤ 588）后同一份表格行在两种方向都不会被折行；横屏只是表格不铺满。
// Table row width cap: the layout can re-typeset the existing body without re-parsing it when the
// screen rotates or type size changes, so a row parsed for the ~1100px landscape body would be
// re-wrapped by the ~588px portrait body. 560px is below every body width, so no row ever wraps;
// landscape simply keeps the table narrower than the body.
#define MD_TABLE_MAX_WIDTH 560
#define MD_TITLE_LIMIT (MD_TITLE_MAX * 2) ///< 拼后续章标题用 / room for a continuation suffix

// 预排块（代码行、表格行）用 align=3：book_layout 只在 1 时居中、2 时右对齐，其余按左对齐，
// 且只有 align==0 的块首行才吃阅读设置的首行缩进。3 因此等于“免缩进 + 左对齐 + 保留行首空格”，
// 让预排文本的行宽可以精确用满正文宽。该语义已与 Lead / style-layout 确认。
// Preformatted blocks (code lines and table rows) use align=3: book_layout centres only on 1 and
// right-aligns only on 2, treating every other value as left, and only align==0 blocks take the
// reader's first-line indent. 3 therefore means "no indent + left aligned + leading spaces kept",
// so pre-typeset lines can use the full body width.
#define MD_RAW_ALIGN 3u
// 分隔线：输出一行横线。/ Horizontal rule: one line of box-drawing characters.
#define MD_RULE "————————"
// 图片只保留替代文字，这是固定前缀。/ Images keep only their alt text behind this fixed prefix.
#define MD_IMAGE "[图] "

static const char *TAG = "book_md";

/* ---- UTF-8 基础 / UTF-8 primitives ---- */

// 解码一个 UTF-8 标量；非法序列只消费首字节并给出替换符。/ Decode one scalar; invalid bytes consume one and yield U+FFFD.
static size_t md_utf8(const unsigned char *s, size_t n, uint32_t *cp) {
    *cp = 0xfffd;
    if (!n) return 0;
    if (s[0] < 0x80) { *cp = s[0]; return 1; }
    size_t k = s[0] >= 0xc2 && s[0] <= 0xdf ? 2 : s[0] >= 0xe0 && s[0] <= 0xef ? 3 : s[0] >= 0xf0 && s[0] <= 0xf4 ? 4 : 0;
    if (!k || k > n) return 1;
    uint32_t c = s[0] & (0x7f >> k);
    for (size_t j = 1; j < k; ++j) { if ((s[j] & 0xc0) != 0x80) return 1; c = (c << 6) | (s[j] & 63); }
    if ((k == 2 && c < 0x80) || (k == 3 && c < 0x800) || (k == 4 && c < 0x10000) ||
        (c >= 0xd800 && c <= 0xdfff) || c > 0x10ffff) return 1;
    *cp = c;
    return k;
}

// 编码一个标量，返回字节数；调用方保证缓冲不少于四字节。/ Encode one scalar; the caller owns at least four bytes.
static size_t md_encode(uint32_t cp, char out[4]) {
    if (!cp || (cp >= 0xd800 && cp <= 0xdfff) || cp > 0x10ffff) cp = 0xfffd;
    if (cp < 0x80) { out[0] = (char)cp; return 1; }
    if (cp < 0x800) { out[0] = (char)(0xc0 | (cp >> 6)); out[1] = (char)(0x80 | (cp & 63)); return 2; }
    if (cp < 0x10000) {
        out[0] = (char)(0xe0 | (cp >> 12)); out[1] = (char)(0x80 | ((cp >> 6) & 63));
        out[2] = (char)(0x80 | (cp & 63)); return 3;
    }
    out[0] = (char)(0xf0 | (cp >> 18)); out[1] = (char)(0x80 | ((cp >> 12) & 63));
    out[2] = (char)(0x80 | ((cp >> 6) & 63)); out[3] = (char)(0x80 | (cp & 63)); return 4;
}

static bool md_ascii_word(unsigned char c) {
    return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}

static bool md_escapable(unsigned char c) {
    return strchr("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~", c) != NULL;
}

// 中日韩与全角字符：段落内跨行拼接时两侧不加空格。/ CJK and fullwidth: no space when joining wrapped lines.
static bool md_cjk(uint32_t cp) {
    return (cp >= 0x2e80 && cp <= 0x9fff) || (cp >= 0xf900 && cp <= 0xfaff) ||
           (cp >= 0xff00 && cp <= 0xffef);
}

// 一行的最后一个码点；行尾截断位置必须是 UTF-8 起始字节。/ Last codepoint of a line slice.
static uint32_t md_last_cp(const unsigned char *p, size_t n) {
    size_t i = n;
    while (i > 0 && (p[i - 1] & 0xc0) == 0x80) --i;
    if (!i) return 0;
    --i;
    uint32_t cp = 0;
    (void)md_utf8(p + i, n - i, &cp);
    return cp;
}

// 去掉切片尾部空白；块内容不允许以空格结尾。/ Drop trailing blanks; a block body never ends in a space.
static void md_trim_tail(const unsigned char *p, size_t *n) {
    while (*n && (p[*n - 1] == ' ' || p[*n - 1] == '\t')) --*n;
}

/* ---- 书籍状态与目录索引 / Book state and chapter index ---- */

typedef struct { uint32_t offset; char title[MD_TITLE_MAX]; } md_entry_t;

typedef struct {
    FILE *file; ///< 只读句柄 / read-only handle
    md_entry_t *entries; ///< PSRAM 目录 / PSRAM chapter index
    size_t count; ///< 章数 / chapter count
    uint32_t total; ///< 文件字节数 / file size in bytes
    uint32_t bom; ///< 文件头 BOM 字节数 / BOM size at the file start
} md_book_t;

static md_book_t s_book;
static int s_metrics_width; ///< 表格用正文宽 / body width used by tables
static int s_metrics_px; ///< 表格用字号 / font size used by tables
static int s_metrics_tracking; ///< 表格用字距，与布局同一个值 / tracking shared with the layout

typedef struct {
    FILE *file;
    unsigned char bytes[MD_READ_BLOCK + 4]; ///< 跨块字符余量 / room for a split character
    size_t pos, used;
    uint32_t offset;
} md_reader_t;

static bool md_room(void) { return s_book.count < BOOK_MD_CHAPTER_MAX; }

// 复制标题，超长时按 UTF-8 边界截断。/ Copy a title, truncating on a UTF-8 boundary.
static void md_title_copy(char *dst, const char *src) {
    size_t n = strlen(src);
    if (n > MD_TITLE_MAX - 1) {
        n = MD_TITLE_MAX - 1;
        while (n && ((unsigned char)src[n] & 0xc0) == 0x80) --n;
    }
    memcpy(dst, src, n);
    dst[n] = 0;
}

static bool md_add_entry(uint32_t offset, const char *title) {
    if (!md_room()) return false;
    md_entry_t *entry = &s_book.entries[s_book.count++];
    entry->offset = offset;
    if (title) md_title_copy(entry->title, title);
    else snprintf(entry->title, sizeof(entry->title), "Part %u", (unsigned)s_book.count);
    return true;
}

static esp_err_t md_reader_reset(md_reader_t *reader, uint32_t offset) {
    memset(reader, 0, sizeof(*reader));
    reader->file = s_book.file;
    reader->offset = offset;
    clearerr(s_book.file);
    return fseek(s_book.file, (long)offset, SEEK_SET) ? ESP_FAIL : ESP_OK;
}

// 读一个码点；文件尾返回 false。缓冲区尾部保留四字节以容纳跨块字符。
// Read one codepoint; false at end of file. Four trailing bytes keep a split character intact.
static bool md_reader_next(md_reader_t *reader, uint32_t *cp) {
    if (reader->used - reader->pos < 4) {
        size_t tail = reader->used - reader->pos;
        memmove(reader->bytes, reader->bytes + reader->pos, tail);
        reader->used = tail + fread(reader->bytes + tail, 1, MD_READ_BLOCK, reader->file);
        reader->pos = 0;
    }
    size_t n = reader->used - reader->pos;
    if (!n) return false;
    size_t k = md_utf8(reader->bytes + reader->pos, n, cp);
    reader->pos += k;
    reader->offset += (uint32_t)k;
    return true;
}

static md_entry_t *md_alloc_table(void) {
    return heap_caps_malloc(sizeof(md_entry_t) * BOOK_MD_CHAPTER_MAX, PSRAM_CAPS);
}

// ATX 标题层级：最多三个前导空格、1..6 个 #、后面是空白或行尾，否则不是标题。
// ATX heading level: up to three leading spaces, 1..6 hashes, then whitespace or end of line.
static int md_atx_level(const char *line, size_t len) {
    size_t i = 0;
    while (i < 3 && i < len && line[i] == ' ') ++i;
    size_t h = 0;
    while (i + h < len && line[i + h] == '#') ++h;
    if (h < 1 || h > 6) return 0;
    if (i + h < len && line[i + h] != ' ' && line[i + h] != '\t') return 0;
    return (int)h;
}

// 标题正文与目录标题：去掉 #、行尾闭合 #，并清除粗体、斜体、代码、高亮标记；非法字节换替换符。
// Heading body and index title: strip hashes, closing hashes and emphasis/code markers.
static void md_heading_text(char *out, const char *line, size_t len, int level, bool plain) {
    size_t i = 0;
    while (i < 3 && i < len && line[i] == ' ') ++i;
    i += (size_t)level;
    while (i < len && (line[i] == ' ' || line[i] == '\t')) ++i;
    size_t end = len;
    while (end > i && (line[end - 1] == ' ' || line[end - 1] == '\t')) --end;
    size_t hash = end;
    while (hash > i && line[hash - 1] == '#') --hash;
    if (hash == i || (hash > i && (line[hash - 1] == ' ' || line[hash - 1] == '\t'))) end = hash;
    while (end > i && (line[end - 1] == ' ' || line[end - 1] == '\t')) --end;
    size_t used = 0;
    const unsigned char *p = (const unsigned char *)line + i;
    size_t n = end - i;
    while (n && used + 4 < MD_TITLE_MAX) {
        uint32_t cp;
        size_t k = md_utf8(p, n, &cp);
        p += k;
        n -= k;
        if (cp == '\r' || cp == '\n') continue;
        if (plain && (cp == '*' || cp == '_' || cp == '`' || cp == '=' || cp == '~')) continue;
        char bytes[4];
        size_t bn = md_encode(cp, bytes);
        memcpy(out + used, bytes, bn);
        used += bn;
    }
    out[used] = 0;
}

// 围栏起点：最多三个前导空格后连续至少三个 ` 或 ~。返回 run 长度，body 给出 run 结束位置。
// Fence start: up to three leading spaces then at least three ` or ~. Returns the run length.
static int md_fence(const char *line, size_t len, char *fc, size_t *body) {
    size_t i = 0;
    while (i < 3 && i < len && line[i] == ' ') ++i;
    if (i + 3 > len) return 0;
    char c = line[i];
    if (c != '`' && c != '~') return 0;
    size_t n = 0;
    while (i + n < len && line[i + n] == c) ++n;
    if (n < 3) return 0;
    *fc = c;
    *body = i + n;
    return (int)n;
}

static bool md_fence_open(const char *line, size_t len, char *fc, int *fn) {
    size_t body;
    int n = md_fence(line, len, fc, &body);
    if (!n) return false;
    *fn = n;
    return true;
}

// 闭合围栏：同字符、run 不短于开围栏，且其后只剩空白。/ Closing fence: same char, run at least as long, rest blank.
static bool md_fence_close(const char *line, size_t len, char fc, int fn) {
    char c;
    size_t body;
    int n = md_fence(line, len, &c, &body);
    if (!n || c != fc || n < fn) return false;
    for (size_t i = body; i < len; ++i) if (line[i] != ' ' && line[i] != '\t') return false;
    return true;
}

typedef struct {
    md_reader_t *reader;
    md_entry_t *h1, *h2; ///< H1 与（尚无 H1 时的）H2 候选 / H1 and pre-H1 H2 candidates
    size_t h1n, h2n;
    bool text_seen; ///< 已经见过非空白正文 / non-blank body bytes seen
    bool h1_preamble, h2_preamble; ///< 首个候选标题前是否有正文 / body bytes before the first candidate
    bool oom;
    char fence;
    int fence_len;
} md_scan_t;

static void md_scan_line(md_scan_t *scan, const char *line, size_t len, uint32_t offset) {
    if (scan->fence) {
        if (md_fence_close(line, len, scan->fence, scan->fence_len)) scan->fence = 0;
        return;
    }
    char fc;
    int fn = 0;
    if (md_fence_open(line, len, &fc, &fn)) {
        scan->fence = fc;
        scan->fence_len = fn;
        return;
    }
    int level = md_atx_level(line, len);
    if (level == 1) {
        if (!scan->h1) {
            scan->h1 = md_alloc_table();
            if (!scan->h1) { scan->oom = true; return; }
        }
        if (scan->h1n == BOOK_MD_CHAPTER_MAX) return; // 到上限就停止收章，最后一段自然延到文件尾 / cap reached: later chapters fold into the last one
        if (!scan->h1n) scan->h1_preamble = scan->text_seen;
        scan->h1[scan->h1n].offset = offset;
        md_heading_text(scan->h1[scan->h1n].title, line, len, level, true);
        ++scan->h1n;
        free(scan->h2);
        scan->h2 = NULL;
        scan->h2n = 0;
    } else if (level == 2 && !scan->h1) {
        if (!scan->h2) {
            scan->h2 = md_alloc_table();
            if (!scan->h2) { scan->oom = true; return; }
        }
        if (scan->h2n == BOOK_MD_CHAPTER_MAX) return;
        if (!scan->h2n) scan->h2_preamble = scan->text_seen;
        scan->h2[scan->h2n].offset = offset;
        md_heading_text(scan->h2[scan->h2n].title, line, len, level, true);
        ++scan->h2n;
    } else {
        for (size_t i = 0; i < len; ++i) {
            if (line[i] != ' ' && line[i] != '\t') { scan->text_seen = true; break; }
        }
    }
}

static esp_err_t md_scan_file(md_scan_t *scan) {
    esp_err_t err = md_reader_reset(scan->reader, s_book.bom);
    if (err) return err;
    char line[MD_LINE_CAP];
    size_t len = 0;
    uint32_t start = s_book.bom;
    uint32_t cp;
    while (md_reader_next(scan->reader, &cp)) {
        if (cp == '\n') {
            md_scan_line(scan, line, len, start);
            start = scan->reader->offset;
            len = 0;
        } else if (cp != '\r') {
            char bytes[4];
            size_t n = md_encode(cp, bytes);
            if (len + n <= sizeof(line) - 1) { memcpy(line + len, bytes, n); len += n; }
        }
        if (scan->oom) return ESP_ERR_NO_MEM;
    }
    if (ferror(s_book.file)) return ESP_FAIL;
    if (len || start < s_book.total) md_scan_line(scan, line, len, start);
    return scan->oom ? ESP_ERR_NO_MEM : ESP_OK;
}

// 在 (part, end) 里找下一个切章点：优先超过目标长度后的空行边界，硬上限处退回行首或码点边界。
// Find the next split inside (part, end): a blank-line boundary once past the target, else the line or
// codepoint boundary at the hard cap.
static uint32_t md_find_split(md_reader_t *reader, uint32_t part, uint32_t end) {
    if (md_reader_reset(reader, part) != ESP_OK) return end;
    uint32_t boundary = 0;
    uint32_t line_start = part;
    bool blank = true;
    uint32_t cp;
    while (reader->offset < end && md_reader_next(reader, &cp)) {
        if (cp == '\n') {
            if (blank) boundary = reader->offset;
            line_start = reader->offset;
            blank = true;
            if (boundary > part && boundary - part >= MD_PART_TARGET) return boundary;
        } else if (cp != ' ' && cp != '\t' && cp != '\r') {
            blank = false;
        }
        if (reader->offset - part >= MD_SOURCE_MAX) {
            if (boundary > part && boundary - part >= MD_PART_TARGET / 2) return boundary;
            return line_start > part ? line_start : reader->offset;
        }
    }
    return end;
}

static void md_span_title(char *out, const char *base, unsigned part) {
    if (part <= 1) snprintf(out, MD_TITLE_LIMIT, "%s", base);
    else snprintf(out, MD_TITLE_LIMIT, "%s (%u)", base, part);
}

// 把一个标题区间装进目录；超长时在空行处切成若干续章，标题加 (2)(3) 后缀。
// Turn one heading span into chapters; an oversized span is split at blank lines with (2)(3) suffixes.
static void md_build_span(md_reader_t *reader, uint32_t start, uint32_t end, const char *title) {
    if (end <= start) {
        if (!s_book.count) (void)md_add_entry(start, title);
        return;
    }
    unsigned part = 1;
    while (start < end && md_room()) {
        char label[MD_TITLE_LIMIT];
        if (title) md_span_title(label, title, part);
        if (end - start <= MD_SOURCE_MAX) {
            (void)md_add_entry(start, title ? label : NULL);
            return;
        }
        uint32_t split = md_find_split(reader, start, end);
        if (split <= start || split > end) split = end;
        (void)md_add_entry(start, title ? label : NULL);
        start = split;
        ++part;
    }
}

static esp_err_t md_build_index(md_reader_t *reader) {
    unsigned char head[3];
    s_book.bom = 0;
    if (md_reader_reset(reader, 0) != ESP_OK) return ESP_FAIL;
    size_t got = fread(head, 1, sizeof(head), s_book.file);
    if (ferror(s_book.file)) return ESP_FAIL;
    if (got == sizeof(head) && !memcmp(head, "\xef\xbb\xbf", 3)) s_book.bom = 3;
    md_scan_t scan = { .reader = reader };
    esp_err_t err = md_scan_file(&scan);
    if (err != ESP_OK) { free(scan.h1); free(scan.h2); return err; }
    md_entry_t *use = NULL;
    size_t use_count = 0;
    bool preamble = false;
    if (scan.h1n) {
        use = scan.h1;
        use_count = scan.h1n;
        preamble = scan.h1_preamble;
        scan.h1 = NULL;
    } else if (scan.h2n) {
        use = scan.h2;
        use_count = scan.h2n;
        preamble = scan.h2_preamble;
        scan.h2 = NULL;
    }
    if (use) {
        if (preamble) (void)md_add_entry(0, "前言");
        for (size_t i = 0; i < use_count && md_room(); ++i) {
            uint32_t start = use[i].offset;
            uint32_t stop = i + 1 < use_count ? use[i + 1].offset : s_book.total;
            if (stop <= start) continue;
            md_build_span(reader, start, stop, use[i].title);
        }
        // 首个标题前只有空白时把第一章起点收回文件头，与 TXT 的进度语义一致。
        // When only blanks precede the first heading, pull chapter one back to the file start like TXT.
        if (!preamble && s_book.count && s_book.entries[0].offset) s_book.entries[0].offset = 0;
    } else {
        md_build_span(reader, 0, s_book.total, NULL);
    }
    free(use);
    free(scan.h1);
    free(scan.h2);
    for (size_t i = 0; i < s_book.count; ++i) {
        if (!s_book.entries[i].title[0]) snprintf(s_book.entries[i].title, sizeof(s_book.entries[i].title), "第 %u 节", (unsigned)(i + 1));
    }
    return ESP_OK;
}

esp_err_t book_md_open(const char *path) {
    book_md_close();
    if (!path || !*path) return ESP_ERR_INVALID_ARG;
    FILE *file = fopen(path, "rb");
    if (!file) return ESP_ERR_NOT_FOUND;
    if (fseek(file, 0, SEEK_END)) { fclose(file); return ESP_FAIL; }
    long size = ftell(file);
    if (size < 0 || (unsigned long)size > UINT32_MAX || size > LONG_MAX - 4) {
        fclose(file);
        return ESP_ERR_INVALID_SIZE;
    }
    s_book.file = file;
    s_book.total = (uint32_t)size;
    s_book.entries = heap_caps_malloc(sizeof(md_entry_t) * BOOK_MD_CHAPTER_MAX, PSRAM_CAPS);
    md_reader_t *reader = s_book.entries ? heap_caps_malloc(sizeof(*reader), PSRAM_CAPS) : NULL;
    if (!reader) { book_md_close(); return ESP_ERR_NO_MEM; }
    esp_err_t err = md_build_index(reader);
    free(reader);
    if (err != ESP_OK) { book_md_close(); return err; }
    return ESP_OK;
}

void book_md_close(void) {
    if (s_book.file) fclose(s_book.file);
    free(s_book.entries);
    memset(&s_book, 0, sizeof(s_book));
}

size_t book_md_chapter_count(void) { return s_book.count; }

esp_err_t book_md_chapter_title(size_t chapter, char *buf, size_t cap) {
    if (!buf || !cap || chapter >= s_book.count) return ESP_ERR_INVALID_ARG;
    size_t n = strlen(s_book.entries[chapter].title);
    if (n >= cap) { buf[0] = 0; return ESP_ERR_INVALID_SIZE; }
    memcpy(buf, s_book.entries[chapter].title, n + 1);
    return ESP_OK;
}

uint32_t book_md_total_bytes(void) { return s_book.total; }

uint32_t book_md_chapter_offset(size_t chapter) {
    return chapter < s_book.count ? s_book.entries[chapter].offset : 0;
}

void book_md_set_metrics(int body_width_px, int font_px, int tracking_px) {
    // 越界视为未设置，表格退化为不折行的单列拼接。/ Out-of-range means unset and tables degrade.
    s_metrics_width = body_width_px > 0 && body_width_px <= 8192 ? body_width_px : 0;
    s_metrics_px = font_px > 0 && font_px <= 256 ? font_px : 0;
    s_metrics_tracking = tracking_px >= -64 && tracking_px <= 64 ? tracking_px : 0;
}

/* ---- 输出缓冲与样式 run / Output sink and style runs ---- */

typedef struct {
    char *text; ///< 已输出的 UTF-8 正文 / emitted UTF-8 text
    size_t len, cap, limit;
    html_run_t *runs; ///< 被块表借用的 run 表 / run table borrowed by the blocks
    size_t run_count, run_cap;
    size_t base; ///< 当前块在 text 中的起点 / text offset of the current block
    uint8_t style; ///< 当前打开的 run 样式 / style of the open run
    uint8_t fail; ///< 1 输出超限，2 内存不足 / 1 output cap, 2 out of memory
    bool open; ///< 有一段 run 正在累计 / a style run is being accumulated
} md_sink_t;

static void md_sink_reserve(md_sink_t *sink, size_t extra) {
    if (sink->fail) return;
    if (extra > sink->limit - sink->len) { sink->fail = 1; return; }
    size_t need = sink->len + extra + 1;
    if (need <= sink->cap) return;
    size_t cap = sink->cap ? sink->cap : 1024;
    while (cap < need) {
        if (cap > (sink->limit + 1) / 2) { cap = sink->limit + 1; break; }
        cap *= 2;
    }
    char *text = heap_caps_realloc(sink->text, cap, PSRAM_CAPS);
    if (!text) { sink->fail = 2; return; }
    sink->text = text;
    sink->cap = cap;
}

static bool md_sink_run(md_sink_t *sink, size_t offset, size_t len, uint8_t style) {
    if (sink->run_count == HTML_RUN_MAX) return false;
    if (sink->run_count == sink->run_cap) {
        size_t cap = sink->run_cap ? sink->run_cap * 2 : 32;
        if (cap > HTML_RUN_MAX) cap = HTML_RUN_MAX;
        html_run_t *runs = heap_caps_realloc(sink->runs, cap * sizeof(*runs), PSRAM_CAPS);
        if (!runs) return false;
        sink->runs = runs;
        sink->run_cap = cap;
    }
    sink->runs[sink->run_count++] = (html_run_t){
        .offset = offset, .len = len, .slot = 0, .style = style,
    };
    return true;
}

// 写一段正文并累计样式 run。run 偏移相对块起点，普通文字不占 run 表。
// Append body bytes and accumulate a style run. Run offsets are block relative; plain text costs no run.
static void md_sink_text(md_sink_t *sink, const char *bytes, size_t n, uint8_t style) {
    if (sink->fail || !n) return;
    if (sink->open && style != sink->style) sink->open = false;
    md_sink_reserve(sink, n);
    if (sink->fail) return;
    if (!sink->open && style) {
        if (md_sink_run(sink, sink->len - sink->base, 0, style)) {
            sink->open = true;
            sink->style = style;
        } else {
            style = 0;
        }
    }
    memcpy(sink->text + sink->len, bytes, n);
    sink->len += n;
    sink->text[sink->len] = 0;
    if (sink->open) sink->runs[sink->run_count - 1].len += n;
}

// 写一个码点；回车与换行直接丢弃，输出里不允许残留 \r。
// Append one codepoint; drop CR and LF because the normalized text must not carry them.
static void md_sink_cp(md_sink_t *sink, uint32_t cp, uint8_t style) {
    if (cp == '\r' || cp == '\n') return;
    char bytes[4];
    size_t n = md_encode(cp, bytes);
    md_sink_text(sink, bytes, n, style);
}

// 把一段原文按码点清洗后写入（代码块等不解析行内标记的场合）。
// Copy literal source bytes codepoint by codepoint (code blocks never parse inline markers).
static void md_sink_literal(md_sink_t *sink, const unsigned char *p, size_t n, uint8_t style) {
    while (n && !sink->fail) {
        uint32_t cp;
        size_t k = md_utf8(p, n, &cp);
        md_sink_cp(sink, cp, style);
        p += k;
        n -= k;
    }
}

/* ---- 行内解析 / Inline parser ---- */

// 从 from 起找一段长度不短于 need 的标记 run，跳过转义与行内代码；返回 run 起点或 SIZE_MAX。
// Find a marker run of at least need bytes from `from`, skipping escapes and code spans.
static size_t md_find_mark(const unsigned char *p, size_t n, size_t from, unsigned char c,
                           size_t need, bool word) {
    size_t i = from;
    while (i < n) {
        if (p[i] == '\\' && i + 1 < n) { i += 2; continue; }
        if (p[i] == '`') {
            size_t run = 1;
            while (i + run < n && p[i + run] == '`') ++run;
            size_t j = i + run;
            bool closed = false;
            while (j < n) {
                if (p[j] == '`') {
                    size_t r = 1;
                    while (j + r < n && p[j + r] == '`') ++r;
                    if (r == run) { j += r; closed = true; break; }
                    j += r;
                } else {
                    ++j;
                }
            }
            i = closed ? j : i + run;
            continue;
        }
        if (p[i] == c) {
            size_t run = 1;
            while (i + run < n && p[i + run] == c) ++run;
            bool ok = run >= need;
            // 下划线强调的闭合标记：前面不能是空格，后面不能是字母数字；开标记的单词边界由调用方判断。
            // Closing underscores: no space before, no alphanumeric after; the opening word boundary is
            // the caller's job.
            if (ok && word && i > 0 && p[i - 1] == ' ') ok = false;
            if (ok && word && i + run < n && md_ascii_word(p[i + run])) ok = false;
            if (ok) return i;
            i += run;
            continue;
        }
        ++i;
    }
    return SIZE_MAX;
}

// 解析一行内联 Markdown。depth 限制嵌套层数，超过后按普通文字输出。
// Parse one line of inline Markdown; depth caps nesting, beyond which text is emitted plain.
static void md_inline(md_sink_t *sink, const unsigned char *p, size_t n, uint8_t style, int depth) {
    if (depth > 5) { md_sink_literal(sink, p, n, 0); return; }
    size_t i = 0;
    while (i < n && !sink->fail) {
        uint32_t cp;
        size_t k = md_utf8(p + i, n - i, &cp);
        if (cp == '\\') {
            uint32_t next = 0;
            size_t nk = i + 1 < n ? md_utf8(p + i + 1, n - i - 1, &next) : 0;
            if (nk && next < 128 && md_escapable((unsigned char)next)) {
                md_sink_cp(sink, next, style);
                i += 1 + nk;
            } else {
                md_sink_cp(sink, '\\', style);
                i += k;
            }
            continue;
        }
        if (cp == '`') {
            size_t run = 1;
            while (i + run < n && p[i + run] == '`') ++run;
            size_t j = i + run;
            size_t close = SIZE_MAX;
            while (j < n) {
                if (p[j] == '`') {
                    size_t r = 1;
                    while (j + r < n && p[j + r] == '`') ++r;
                    if (r == run) { close = j; break; }
                    j += r;
                } else {
                    ++j;
                }
            }
            if (close != SIZE_MAX) {
                size_t from = i + run, to = close;
                if (to - from >= 2 && p[from] == ' ' && p[to - 1] == ' ') {
                    bool spaced = true;
                    for (size_t t = from; t < to; ++t) if (p[t] != ' ') { spaced = false; break; }
                    if (!spaced) { ++from; --to; }
                }
                md_sink_literal(sink, p + from, to - from, (uint8_t)(style | HTML_STYLE_BOLD));
                i = close + run;
            } else {
                for (size_t r = 0; r < run; ++r) md_sink_cp(sink, '`', style);
                i += run;
            }
            continue;
        }
        if (cp == '!' && i + 1 < n && p[i + 1] == '[') {
            size_t close = i + 2;
            while (close < n && p[close] != ']') {
                if (p[close] == '\\') ++close;
                ++close;
            }
            if (close < n) {
                size_t end = close + 1;
                bool target = false;
                if (end < n && p[end] == '(') {
                    size_t r = end + 1;
                    while (r < n && p[r] != ')') ++r;
                    if (r < n) { end = r + 1; target = true; }
                } else if (end < n && p[end] == '[') {
                    size_t r = end + 1;
                    while (r < n && p[r] != ']') ++r;
                    if (r < n) { end = r + 1; target = true; }
                }
                if (target) {
                    md_sink_text(sink, MD_IMAGE, sizeof(MD_IMAGE) - 1, style);
                    md_inline(sink, p + i + 2, close - i - 2, style, depth + 1);
                    i = end;
                    continue;
                }
            }
            md_sink_cp(sink, '!', style);
            i += k;
            continue;
        }
        if (cp == '[') {
            size_t close = i + 1;
            while (close < n && p[close] != ']') {
                if (p[close] == '\\') ++close;
                ++close;
            }
            if (close < n) {
                size_t end = close + 1;
                bool target = false;
                if (end < n && p[end] == '(') {
                    size_t r = end + 1;
                    while (r < n && p[r] != ')') ++r;
                    if (r < n) { end = r + 1; target = true; }
                } else if (end < n && p[end] == '[') {
                    size_t r = end + 1;
                    while (r < n && p[r] != ']') ++r;
                    if (r < n) { end = r + 1; target = true; }
                }
                if (target) {
                    md_inline(sink, p + i + 1, close - i - 1, style, depth + 1);
                    i = end;
                    continue;
                }
            }
            md_sink_cp(sink, '[', style);
            ++i;
            continue;
        }
        if (cp == '=' && i + 1 < n && p[i + 1] == '=') {
            size_t close = md_find_mark(p, n, i + 2, '=', 2, false);
            if (close != SIZE_MAX) {
                md_inline(sink, p + i + 2, close - i - 2,
                          (uint8_t)(style | HTML_STYLE_HIGHLIGHT), depth + 1);
                i = close + 2;
                continue;
            }
        }
        if (cp == '*' || cp == '_') {
            size_t run = 1;
            while (i + run < n && p[i + run] == (unsigned char)cp) ++run;
            size_t use = run >= 3 ? 3 : run;
            uint8_t bit = use == 3 ? (uint8_t)(HTML_STYLE_BOLD | HTML_STYLE_ITALIC) :
                          use == 2 ? HTML_STYLE_BOLD : HTML_STYLE_ITALIC;
            bool word = cp == '_';
            bool ok = !(style & bit);
            if (ok && word && i > 0 && md_ascii_word(p[i - 1])) ok = false;
            if (ok && i + use < n && p[i + use] == ' ') ok = false;
            if (ok) {
                size_t close = md_find_mark(p, n, i + use, (unsigned char)cp, use, word);
                if (close != SIZE_MAX) {
                    md_inline(sink, p + i + use, close - i - use, (uint8_t)(style | bit), depth + 1);
                    i = close + use;
                    continue;
                }
            }
            for (size_t r = 0; r < run && !sink->fail; ++r) md_sink_cp(sink, cp, style);
            i += run;
            continue;
        }
        md_sink_cp(sink, cp, style);
        i += k;
    }
}

/* ---- 块表构建 / Block builder ---- */

typedef struct {
    md_sink_t sink;
    blk_t *blocks;
    size_t count, cap;
    size_t sep; ///< 块前分隔符的位置 / offset before the block separator
    size_t start; ///< 块正文起点 / block body start
    size_t run_first; ///< 本块首个 run 下标 / first run index of this block
    bool open;
    bool pending_blank; ///< 表格后欠一个空行 / a spacer line is owed after a table
    bool last_blank; ///< 上一块是空行 / the previous block is the spacer
    bool heading, line_break;
    uint8_t level, align, before, after;
} md_doc_t;

static bool md_doc_grow(md_doc_t *doc) {
    if (doc->count < doc->cap) return true;
    size_t cap = doc->cap ? doc->cap * 2 : 64;
    if (cap > HTML_TEXT_MAX_BLOCKS) cap = HTML_TEXT_MAX_BLOCKS;
    blk_t *blocks = heap_caps_realloc(doc->blocks, cap * sizeof(*blocks), PSRAM_CAPS);
    if (!blocks) { doc->sink.fail = 2; return false; }
    doc->blocks = blocks;
    doc->cap = cap;
    return true;
}

static void md_block_abort(md_doc_t *doc) {
    if (!doc->open) return;
    doc->open = false;
    doc->sink.open = false;
    doc->sink.len = doc->sep;
    if (doc->sink.text) doc->sink.text[doc->sink.len] = 0;
    doc->sink.run_count = doc->run_first;
}

static void md_block_start(md_doc_t *doc, bool heading, uint8_t level, bool line_break,
                           uint8_t align, uint8_t before, uint8_t after) {
    if (doc->sink.fail || doc->open) return;
    if (doc->count == HTML_TEXT_MAX_BLOCKS) { doc->sink.fail = 1; return; }
    if (!md_doc_grow(doc)) return;
    doc->sep = doc->sink.len;
    if (doc->count) md_sink_text(&doc->sink, "\n", 1, 0);
    if (doc->sink.fail) return;
    doc->start = doc->sink.len;
    doc->sink.base = doc->start;
    doc->run_first = doc->sink.run_count;
    doc->heading = heading;
    doc->level = level;
    doc->line_break = line_break;
    doc->align = align;
    doc->before = before;
    doc->after = after;
    doc->open = true;
}

static void md_block_end(md_doc_t *doc) {
    if (!doc->open) return;
    doc->sink.open = false;
    if (doc->sink.fail) { md_block_abort(doc); return; }
    doc->open = false;
    size_t len = doc->sink.len - doc->start;
    if (!len) { doc->open = true; md_block_abort(doc); return; }
    doc->blocks[doc->count++] = (blk_t){
        .offset = doc->start, .len = len, .heading = doc->heading,
        .heading_level = doc->level, .line_break_after = doc->line_break,
        .align = doc->align, .margin_before_percent = doc->before,
        .margin_after_percent = doc->after, .image = -1,
        .run_first = doc->run_first, .run_count = doc->sink.run_count - doc->run_first,
    };
    doc->last_blank = false;
}

// 一个空行块无法用零长度表示（布局拒绝空块），用一个空格表示一行空白。
// A blank line cannot be a zero-length block (the layout rejects empty blocks), so a single
// space stands in for it.
static void md_block_blank(md_doc_t *doc) {
    md_block_start(doc, false, 0, true, 0, 0, 0);
    if (!doc->open) return;
    md_sink_text(&doc->sink, " ", 1, 0);
    md_block_end(doc);
    if (!doc->sink.fail) doc->last_blank = true;
}

static void md_doc_flush(md_doc_t *doc) {
    if (!doc->pending_blank) return;
    doc->pending_blank = false;
    md_block_blank(doc);
}

static void md_doc_open(md_doc_t *doc, bool heading, uint8_t level, bool line_break,
                        uint8_t align, uint8_t before, uint8_t after) {
    md_doc_flush(doc);
    md_block_start(doc, heading, level, line_break, align, before, after);
}

// 块内至少写一个字节：标题、引用、列表内容为空时用空格占位，避免零长度块。
// Ensure a block has at least one byte: an empty heading/quote/list item becomes one space.
static void md_block_ensure(md_doc_t *doc) {
    if (doc->open && !doc->sink.fail && doc->sink.len == doc->start) {
        md_sink_text(&doc->sink, " ", 1, 0);
    }
}

/* ---- 行与块识别 / Lines and block kinds ---- */

typedef struct {
    size_t eol; ///< 换行符位置 / newline position
    size_t text_len; ///< 不含行尾 \r 的长度 / length excluding a trailing CR
    size_t next; ///< 下一行起点 / next line start
} md_line_t;

static void md_line_at(const unsigned char *src, size_t len, size_t pos, md_line_t *line) {
    size_t eol = pos;
    while (eol < len && src[eol] != '\n') ++eol;
    size_t text = eol;
    if (text > pos && src[text - 1] == '\r') --text;
    line->eol = eol;
    line->text_len = text - pos;
    line->next = eol < len ? eol + 1 : len;
}

static bool md_line_blank(const unsigned char *p, size_t n) {
    for (size_t i = 0; i < n; ++i) if (p[i] != ' ' && p[i] != '\t') return false;
    return true;
}

static size_t md_indent(const unsigned char *p, size_t n) {
    size_t i = 0;
    while (i < 3 && i < n && p[i] == ' ') ++i;
    return i;
}

// 分隔线：仅由同一字符 - * _ 组成（可含空白），至少三个。/ Thematic break: one of - * _ repeated with blanks, at least three.
static bool md_rule(const unsigned char *p, size_t n) {
    size_t i = md_indent(p, n);
    if (i >= n) return false;
    unsigned char c = p[i];
    if (c != '-' && c != '*' && c != '_') return false;
    size_t count = 0;
    for (size_t t = i; t < n; ++t) {
        if (p[t] == c) ++count;
        else if (p[t] != ' ' && p[t] != '\t') return false;
    }
    return count >= 3;
}

static bool md_quote(const unsigned char *p, size_t n, size_t *body) {
    size_t i = md_indent(p, n);
    if (i >= n || p[i] != '>') return false;
    ++i;
    if (i < n && (p[i] == ' ' || p[i] == '\t')) ++i;
    *body = i;
    return true;
}

// 列表项：无序 - * + 或有序 1. / 1)；写出项目前缀（无序用中点，有序保留原编号）。
// List item prefix; unordered uses a middle dot, ordered keeps the source number.
static bool md_list_item(const unsigned char *p, size_t n, size_t *body, char *prefix, size_t cap) {
    size_t i = md_indent(p, n);
    if (i >= n) return false;
    unsigned char c = p[i];
    if (c == '-' || c == '*' || c == '+') {
        if (i + 1 < n && p[i + 1] != ' ' && p[i + 1] != '\t') return false;
        size_t b = i + 1;
        while (b < n && (p[b] == ' ' || p[b] == '\t')) ++b;
        *body = b;
        snprintf(prefix, cap, "· ");
        return true;
    }
    if (c >= '0' && c <= '9') {
        size_t digits = 0;
        unsigned value = 0;
        while (i + digits < n && digits < 9 && p[i + digits] >= '0' && p[i + digits] <= '9') {
            value = value * 10 + (unsigned)(p[i + digits] - '0');
            ++digits;
        }
        size_t mark = i + digits;
        if (mark >= n || (p[mark] != '.' && p[mark] != ')')) return false;
        if (mark + 1 < n && p[mark + 1] != ' ' && p[mark + 1] != '\t') return false;
        size_t b = mark + 1;
        while (b < n && (p[b] == ' ' || p[b] == '\t')) ++b;
        *body = b;
        snprintf(prefix, cap, "%u. ", value);
        return true;
    }
    return false;
}

typedef struct { size_t off, len; } md_slice_t;

// 按未转义管道切单元格；外层管道产生的首尾空单元丢弃。/ Split cells on unescaped pipes and drop outer empty cells.
static size_t md_split_cells(const unsigned char *line, size_t len, md_slice_t *cells, size_t max) {
    size_t count = 0;
    size_t start = 0;
    for (size_t i = 0; i <= len; ++i) {
        bool cut = i == len;
        if (!cut && line[i] == '\\' && i + 1 < len) { ++i; continue; }
        if (!cut && line[i] == '|') cut = true;
        if (!cut) continue;
        if (count < max) {
            size_t a = start, b = i;
            while (a < b && (line[a] == ' ' || line[a] == '\t')) ++a;
            while (b > a && (line[b - 1] == ' ' || line[b - 1] == '\t')) --b;
            cells[count].off = a;
            cells[count].len = b - a;
            ++count;
        }
        start = i + 1;
    }
    if (count && !cells[0].len) { memmove(cells, cells + 1, (count - 1) * sizeof(*cells)); --count; }
    if (count && !cells[count - 1].len) --count;
    return count;
}

static bool md_delim_cell(const unsigned char *p, size_t n) {
    size_t i = 0;
    while (i < n && (p[i] == ' ' || p[i] == '\t')) ++i;
    size_t end = n;
    while (end > i && (p[end - 1] == ' ' || p[end - 1] == '\t')) --end;
    if (i < end && p[i] == ':') ++i;
    size_t dashes = 0;
    while (i < end && p[i] == '-') { ++i; ++dashes; }
    if (!dashes) return false;
    if (i < end && p[i] == ':') ++i;
    return i == end;
}

// 识别表头行 + 分隔行；成功时给出列数、各列对齐与数据行起点。
// Recognize a header row plus delimiter row; yields column count and per-column alignment.
static bool md_table_head(const unsigned char *src, size_t len, size_t pos, const md_line_t *line,
                          size_t *cols, uint8_t *align) {
    bool pipe = false;
    for (size_t i = 0; i < line->text_len; ++i) {
        if (src[pos + i] == '|') { pipe = true; break; }
    }
    if (!pipe || line->next >= len) return false;
    md_line_t sep;
    md_line_at(src, len, line->next, &sep);
    if (!sep.text_len) return false;
    md_slice_t dcells[MD_TABLE_COLS_MAX + 2];
    md_slice_t hcells[MD_TABLE_COLS_MAX + 2];
    size_t dn = md_split_cells(src + line->next, sep.text_len, dcells, MD_TABLE_COLS_MAX + 2);
    size_t hn = md_split_cells(src + pos, line->text_len, hcells, MD_TABLE_COLS_MAX + 2);
    if (!dn || dn > MD_TABLE_COLS_MAX || hn != dn) return false;
    for (size_t i = 0; i < dn; ++i) {
        if (!md_delim_cell(src + line->next + dcells[i].off, dcells[i].len)) return false;
    }
    for (size_t i = 0; i < dn; ++i) {
        const unsigned char *q = src + line->next + dcells[i].off;
        size_t m = dcells[i].len;
        bool left_mark = m && q[0] == ':';
        bool right_mark = m > (left_mark ? 1u : 0u) && q[m - 1] == ':';
        align[i] = left_mark && right_mark ? 1 : right_mark ? 2 : 0;
    }
    *cols = dn;
    return true;
}

// 段落内遇到这些块起始就断开。/ These block starts interrupt a paragraph.
static bool md_block_break(const unsigned char *src, size_t len, size_t pos, const md_line_t *line) {
    const unsigned char *p = src + pos;
    size_t n = line->text_len;
    char fc;
    int fn = 0;
    if (md_fence_open((const char *)p, n, &fc, &fn)) return true;
    if (md_atx_level((const char *)p, n)) return true;
    if (md_rule(p, n)) return true;
    size_t body;
    if (md_quote(p, n, &body)) return true;
    char prefix[16];
    if (md_list_item(p, n, &body, prefix, sizeof(prefix))) return true;
    size_t cols;
    uint8_t aligns[MD_TABLE_COLS_MAX];
    return md_table_head(src, len, pos, line, &cols, aligns);
}

/* ---- 表格 / Tables ---- */

typedef struct { uint32_t off, len, run_first, run_count; } md_cell_t;

typedef struct {
    char *text; ///< 共享单元格文本 arena，每个单元格以零结尾 / shared cell text arena, NUL after every cell
    size_t text_len, text_cap;
    html_run_t *runs;
    size_t run_count, run_cap;
    md_cell_t *cells;
    size_t cell_cap;
    size_t rows, cols;
    uint8_t align[MD_TABLE_COLS_MAX];
} md_table_t;

static bool md_table_init(md_table_t *table) {
    table->text_cap = 512;
    table->text = heap_caps_malloc(table->text_cap, PSRAM_CAPS);
    if (!table->text) return false;
    table->text[0] = 0;
    return true;
}

static void md_table_free(md_table_t *table) {
    free(table->text);
    free(table->runs);
    free(table->cells);
    memset(table, 0, sizeof(*table));
}

static bool md_table_grow(md_table_t *table, size_t rows) {
    size_t need = rows * table->cols;
    if (need <= table->cell_cap) return true;
    size_t cap = table->cell_cap ? table->cell_cap * 2 : 32;
    while (cap < need) cap *= 2;
    md_cell_t *cells = heap_caps_realloc(table->cells, cap * sizeof(*cells), PSRAM_CAPS);
    if (!cells) return false;
    table->cells = cells;
    table->cell_cap = cap;
    return true;
}

// 解析一行表格并把它追加到表格；单元格文本进共享 arena，run 偏移相对各自单元格。
// Parse one table row: cell text goes into the shared arena and runs are cell relative.
static bool md_table_row(md_table_t *table, const unsigned char *base, const md_slice_t *cells, size_t count) {
    if (table->rows == MD_TABLE_ROWS_MAX) return false;
    if (!md_table_grow(table, table->rows + 1)) return false;
    md_cell_t *out = &table->cells[table->rows * table->cols];
    for (size_t c = 0; c < table->cols; ++c) {
        size_t off = table->text_len;
        size_t first = table->run_count;
        if (c < count && cells[c].len) {
            md_sink_t cell = {
                .text = table->text, .len = table->text_len, .cap = table->text_cap,
                .limit = MD_TABLE_TEXT_MAX, .runs = table->runs, .run_count = table->run_count,
                .run_cap = table->run_cap, .base = table->text_len,
            };
            md_inline(&cell, base + cells[c].off, cells[c].len, 0, 0);
            table->text = cell.text;
            table->text_len = cell.len;
            table->text_cap = cell.cap;
            table->runs = cell.runs;
            table->run_count = cell.run_count;
            table->run_cap = cell.run_cap;
            if (cell.fail) return false;
        }
        // 容量与总预算：每个单元格后写零，量宽与切行可以直接拿指针用。
        // Capacity and budget: append a NUL after every cell so measuring and wrapping need no copy.
        if (table->text_len + 1 > MD_TABLE_TEXT_MAX) return false;
        if (table->text_len + 1 > table->text_cap) {
            size_t cap = table->text_cap ? table->text_cap * 2 : 512;
            while (cap < table->text_len + 1) cap *= 2;
            char *text = heap_caps_realloc(table->text, cap, PSRAM_CAPS);
            if (!text) return false;
            table->text = text;
            table->text_cap = cap;
        }
        table->text[table->text_len] = 0;
        out[c].off = (uint32_t)off;
        out[c].len = (uint32_t)(table->text_len - off);
        out[c].run_first = (uint32_t)first;
        out[c].run_count = (uint32_t)(table->run_count - first);
        ++table->text_len;
    }
    ++table->rows;
    return true;
}

static int md_space_px(int px) {
    int width = ttf_text_width_px(px, " ");
    // 字体没有空格推进量时按半个字宽估算，避免除零。/ Fall back to half an em when the face has no space advance.
    if (width <= 0) width = px / 2;
    return width > 0 ? width : 1;
}

// 行宽模型与 book_layout 的 candidate 完全一致：段宽 = Σ字宽 + (字数-1)*字距，行首字不加字距。
// The width model matches book_layout's candidate exactly: sum of advances plus (glyphs - 1) tracking.
static long md_measure_run(const char *text, size_t from, size_t to, int px, int tracking, size_t *glyphs) {
    long width = 0;
    size_t count = 0;
    size_t i = from;
    while (i < to) {
        uint32_t cp;
        size_t k = md_utf8((const unsigned char *)text + i, to - i, &cp);
        char glyph[5];
        size_t gn = md_encode(cp, glyph);
        glyph[gn] = 0;
        if (count) width += tracking;
        width += ttf_text_width_px(px, glyph);
        ++count;
        i += k;
    }
    if (glyphs) *glyphs = count;
    return width;
}

// 行内折行：返回本行结束字节，next 给出下一行起点；CJK 任意断，拉丁优先在空格断。
// Wrap one line: returns this line's end and the next start; CJK breaks anywhere, Latin prefers spaces.
static size_t md_wrap_next(const char *text, size_t len, int limit, int px, int tracking,
                           size_t from, size_t *next) {
    size_t i = from;
    long width = 0;
    size_t count = 0;
    size_t word = SIZE_MAX;
    size_t end = len;
    bool done = false;
    while (i < len) {
        uint32_t cp;
        size_t k = md_utf8((const unsigned char *)text + i, len - i, &cp);
        char glyph[5];
        size_t gn = md_encode(cp, glyph);
        glyph[gn] = 0;
        long delta = ttf_text_width_px(px, glyph) + (count ? tracking : 0);
        if (count && width + delta > limit) {
            if (cp == ' ') end = i;
            else if (word != SIZE_MAX && word > from) end = word;
            else end = i;
            done = true;
            break;
        }
        width += delta;
        ++count;
        i += k;
        if (cp == ' ') word = i;
    }
    if (!done) end = len;
    while (end > from && text[end - 1] == ' ') --end;
    if (end < from) end = from;
    *next = end;
    while (*next < len && text[*next] == ' ') ++*next;
    if (*next <= from) *next = from + 1 < len ? from + 1 : len;
    return end;
}

static int md_cell_lines(const char *text, size_t len, int limit, int px, int tracking) {
    int lines = 0;
    size_t at = 0;
    while (at < len) {
        size_t next;
        (void)md_wrap_next(text, len, limit, px, tracking, at, &next);
        at = next;
        ++lines;
        if (lines > 1024) break;
    }
    return lines ? lines : 1;
}

static bool md_cell_segment(const char *text, size_t len, int limit, int px, int tracking, int line,
                            size_t *from, size_t *to) {
    size_t at = 0;
    for (int index = 0;; ++index) {
        if (at >= len) {
            if (index != line) return false;
            *from = *to = len;
            return true;
        }
        size_t next;
        size_t end = md_wrap_next(text, len, limit, px, tracking, at, &next);
        if (index == line) {
            *from = at;
            *to = end;
            return true;
        }
        at = next;
    }
}

// 一行在布局里的像素推进量：行首字不加字距，其后每个字（含空格）先加一次字距。
// Pixel advance in the layout: no tracking before the first glyph, once before every later glyph.
typedef struct { long x; long glyphs; } md_row_t;

static void md_row_add(md_row_t *row, long advance, size_t glyphs, int tracking) {
    if (!glyphs) return;
    if (row->glyphs) row->x += tracking;
    row->x += advance;
    row->glyphs += (long)glyphs;
}

// 还要补几个空格才能不越过 target。行首第一个空格不加字距，其余每个按 space+tracking 前进。
// Spaces needed to reach `target` without passing it; the first space of a line takes no tracking.
static size_t md_pad_count(const md_row_t *row, long target, int space, int tracking) {
    long step = (long)space + tracking;
    if (step <= 0) return 0;
    long room = target - row->x;
    if (row->glyphs) return room > 0 ? (size_t)(room / step) : 0;
    if (room < space) return 0;
    return (size_t)(1 + (room - space) / step);
}

static long md_spaces_advance(size_t count, int space, int tracking) {
    if (!count) return 0;
    return (long)count * space + (long)(count - 1) * tracking;
}

static void md_row_spaces(md_doc_t *doc, md_row_t *row, size_t count, int space, int tracking) {
    for (size_t i = 0; i < count && !doc->sink.fail; ++i) md_sink_text(&doc->sink, " ", 1, 0);
    if (count) md_row_add(row, md_spaces_advance(count, space, tracking), count, tracking);
}

// 把单元格片段写进当前块：写文字，再把与该片段相交的样式 run 平移到块坐标。
// Append one cell slice to the open block, translating the style runs that intersect it.
static void md_emit_cell(md_doc_t *doc, const md_table_t *table, const md_cell_t *cell,
                         size_t from, size_t to) {
    md_sink_t *sink = &doc->sink;
    if (sink->fail || to <= from) return;
    size_t at = sink->len - doc->start;
    md_sink_text(sink, table->text + cell->off + from, to - from, 0);
    if (sink->fail) return;
    for (size_t r = 0; r < cell->run_count; ++r) {
        const html_run_t *run = &table->runs[cell->run_first + r];
        size_t a = run->offset;
        size_t b = run->offset + run->len;
        if (b <= from || a >= to) continue;
        if (a < from) a = from;
        if (b > to) b = to;
        if (!md_sink_run(sink, at + (a - from), b - a, run->style)) break;
    }
}

// 度量未设置或列太多时退化为“单元格 | 单元格”单行输出，不折行、不对齐。
// Without metrics, or with too many columns, rows degrade to plain "cell | cell" lines.
static void md_table_plain(md_doc_t *doc, const md_table_t *table) {
    for (size_t r = 0; r < table->rows; ++r) {
        md_doc_open(doc, false, 0, true, 0, 0, 0);
        if (!doc->open) return;
        // 末列没有文字时把分隔符收成“ |”，行尾不留空格。
        // When the last cell is empty, close it with " |" so the row never ends in a space.
        bool last_empty = !table->cells[r * table->cols + table->cols - 1].len;
        for (size_t c = 0; c < table->cols; ++c) {
            if (c) {
                const char *separator = c + 1 == table->cols && last_empty ? " |" : " | ";
                md_sink_text(&doc->sink, separator, strlen(separator), 0);
            }
            const md_cell_t *cell = &table->cells[r * table->cols + c];
            md_emit_cell(doc, table, cell, 0, cell->len);
        }
        md_block_ensure(doc);
        md_block_end(doc);
        if (doc->sink.fail) return;
    }
}

// 预对齐表格：按像素算列宽、单元格内折行、空格补到列边界，行尾不留空格。
// Pre-aligned table: pixel column widths, cells wrapped inside columns, space padding up to the
// column edge and never past the last cell so rows never end in a space.
static void md_table_aligned(md_doc_t *doc, const md_table_t *table) {
    int px = s_metrics_px;
    int tracking = s_metrics_tracking;
    int space = md_space_px(px);
    int separator = ttf_text_width_px(px, "|");
    if (separator <= 0) separator = space;
    // 字距为负且把空格或分隔符的推进量吃光时无法用空格对齐，退回单空格分隔的降级路径。
    // Negative tracking can eat the space or separator advance; degrade to plain single spaces.
    if (space + tracking <= 0 || (table->cols > 1 && separator + tracking <= 0)) {
        md_table_plain(doc, table);
        return;
    }
    long width = s_metrics_width < MD_TABLE_MAX_WIDTH ? s_metrics_width : MD_TABLE_MAX_WIDTH;
    int colw[MD_TABLE_COLS_MAX];
    long columns = 0;
    for (size_t c = 0; c < table->cols; ++c) {
        long widest = 0;
        for (size_t r = 0; r < table->rows; ++r) {
            const md_cell_t *cell = &table->cells[r * table->cols + c];
            long cell_width = md_measure_run(table->text + cell->off, 0, cell->len, px, tracking, NULL);
            if (tracking > 0 && c) cell_width += tracking; // 非首列前面还会多一次字距 / one extra gap for non-first columns
            if (cell_width > widest) widest = cell_width;
        }
        long col = widest + px; // 两侧各半个字宽的留白 / half an em of gutter on each side
        if (col < 2L * px) col = 2L * px;
        colw[c] = (int)col;
        columns += col;
    }
    long seps = (long)(table->cols - 1) * ((long)separator + tracking);
    if (columns + seps > width) {
        long usable = width - seps;
        if (usable < 2L * px * (long)table->cols) { md_table_plain(doc, table); return; }
        long scaled = 0;
        for (size_t c = 0; c < table->cols; ++c) {
            long value = (long)colw[c] * usable / columns;
            if (value < 2L * px) value = 2L * px;
            colw[c] = (int)value;
            scaled += value;
        }
        long total = scaled + seps;
        while (total > width) {
            size_t big = 0;
            for (size_t c = 1; c < table->cols; ++c) if (colw[c] > colw[big]) big = c;
            if (colw[big] <= 2 * px) { md_table_plain(doc, table); return; }
            --colw[big];
            --total;
        }
    }
    int start[MD_TABLE_COLS_MAX];
    int edge[MD_TABLE_COLS_MAX];
    long position = 0;
    for (size_t c = 0; c < table->cols; ++c) {
        start[c] = (int)position;
        position += colw[c];
        if (c + 1 < table->cols) position += (long)separator + tracking;
        edge[c] = (int)position;
    }
    for (size_t r = 0; r < table->rows; ++r) {
        int lines = 1;
        for (size_t c = 0; c < table->cols; ++c) {
            const md_cell_t *cell = &table->cells[r * table->cols + c];
            int limit = colw[c] - px - (tracking > 0 && c ? tracking : 0);
            if (limit < px) limit = px;
            int count = md_cell_lines(table->text + cell->off, cell->len, limit, px, tracking);
            if (count > lines) lines = count;
        }
        for (int line = 0; line < lines; ++line) {
            md_doc_open(doc, false, 0, true, MD_RAW_ALIGN, 0, 0);
            if (!doc->open) return;
            md_row_t row = {0, 0};
            for (size_t c = 0; c < table->cols; ++c) {
                const md_cell_t *cell = &table->cells[r * table->cols + c];
                int limit = colw[c] - px - (tracking > 0 && c ? tracking : 0);
                if (limit < px) limit = px;
                size_t from = 0, to = 0;
                bool has = md_cell_segment(table->text + cell->off, cell->len, limit, px, tracking,
                                           line, &from, &to);
                size_t glyphs = 0;
                long advance = 0;
                if (has && to > from) {
                    advance = md_measure_run(table->text + cell->off, from, to, px, tracking, &glyphs);
                }
                if (glyphs) {
                    long content = advance + (row.glyphs ? tracking : 0);
                    if (content < 0) content = 0; // 负字距极端时避免对齐目标失控 / clamp negative advances under extreme tracking
                    long target = 0;
                    bool pad = false;
                    if (table->align[c] == 2) {
                        target = edge[c] - content;
                        pad = true;
                    } else if (table->align[c] == 1) {
                        target = start[c] + (colw[c] - content) / 2;
                        pad = true;
                    }
                    if (pad) {
                        size_t count = md_pad_count(&row, target, space, tracking);
                        md_row_spaces(doc, &row, count, space, tracking);
                    }
                    md_emit_cell(doc, table, cell, from, to);
                    md_row_add(&row, advance, glyphs, tracking);
                }
                if (c + 1 < table->cols) {
                    size_t count = md_pad_count(&row, edge[c], space, tracking);
                    md_row_spaces(doc, &row, count, space, tracking);
                    md_sink_text(&doc->sink, "|", sizeof("|") - 1, 0);
                    md_row_add(&row, separator, 1, tracking);
                }
            }
            md_block_end(doc);
            if (doc->sink.fail) return;
        }
    }
}

static size_t md_parse_table(md_doc_t *doc, const unsigned char *src, size_t len, size_t pos,
                             const md_line_t *line, size_t cols, const uint8_t *align) {
    md_table_t table = {0};
    table.cols = cols;
    memcpy(table.align, align, cols);
    if (!md_table_init(&table)) {
        // 内存不足：把表头行当普通段落写出来，数据行留给主循环继续按段落处理。
        // Out of memory: emit the header as a paragraph and let the main loop treat rows as text.
        md_doc_open(doc, false, 0, false, 0, 0, 0);
        if (doc->open) {
            md_inline(&doc->sink, src + pos, line->text_len, 0, 0);
            md_block_ensure(doc);
            md_block_end(doc);
        }
        return line->next;
    }
    md_doc_flush(doc);
    if (doc->count && !doc->last_blank) md_block_blank(doc);
    bool ok = true;
    size_t at = line->next;
    if (!doc->sink.fail) {
        md_line_t sep;
        md_line_at(src, len, line->next, &sep);
        at = sep.next;
        md_slice_t hcells[MD_TABLE_COLS_MAX + 2];
        size_t hn = md_split_cells(src + pos, line->text_len, hcells, MD_TABLE_COLS_MAX + 2);
        ok = md_table_row(&table, src + pos, hcells, hn);
    }
    while (ok && at < len) {
        md_line_t row;
        md_line_at(src, len, at, &row);
        if (!row.text_len) break;
        bool pipe = false;
        for (size_t i = 0; i < row.text_len; ++i) {
            if (src[at + i] == '|') { pipe = true; break; }
        }
        if (!pipe) break;
        md_slice_t cells[MD_TABLE_COLS_MAX + 2];
        size_t cn = md_split_cells(src + at, row.text_len, cells, MD_TABLE_COLS_MAX + 2);
        if (!md_table_row(&table, src + at, cells, cn)) break;
        at = row.next;
    }
    if (!table.rows) {
        // 一个单元格都没装下：表头按普通段落输出，数据行交给主循环。
        // Nothing fit: emit the header as a paragraph and let the main loop handle the rest.
        md_doc_open(doc, false, 0, false, 0, 0, 0);
        if (doc->open) {
            md_inline(&doc->sink, src + pos, line->text_len, 0, 0);
            md_block_ensure(doc);
            md_block_end(doc);
        }
        md_table_free(&table);
        return line->next;
    }
    if (!ok) md_table_plain(doc, &table);
    else if (s_metrics_width > 0 && s_metrics_px > 0) md_table_aligned(doc, &table);
    else md_table_plain(doc, &table);
    doc->pending_blank = true;
    md_table_free(&table);
    return at;
}

/* ---- 章节解析 / Chapter parser ---- */

static esp_err_t md_parse_chapter(const unsigned char *src, size_t len, html_text_t *out) {
    md_doc_t doc = { .sink = { .limit = BOOK_MD_CHAPTER_OUTPUT_MAX } };
    doc.sink.cap = 1024;
    doc.sink.text = heap_caps_malloc(doc.sink.cap, PSRAM_CAPS);
    if (!doc.sink.text) return ESP_ERR_NO_MEM;
    doc.sink.text[0] = 0;

    char fence = 0;
    int fence_len = 0;
    size_t pos = 0;
    while (pos < len && !doc.sink.fail) {
        md_line_t line;
        md_line_at(src, len, pos, &line);
        const unsigned char *p = src + pos;
        size_t n = line.text_len;
        if (fence) {
            if (md_fence_close((const char *)p, n, fence, fence_len)) {
                fence = 0;
            } else {
                md_doc_open(&doc, false, 0, true, MD_RAW_ALIGN, 0, 0);
                if (doc.open) {
                    md_sink_literal(&doc.sink, p, n, 0);
                    md_block_ensure(&doc);
                    md_block_end(&doc);
                }
            }
            pos = line.next;
            continue;
        }
        char fc;
        int fn = 0;
        if (md_fence_open((const char *)p, n, &fc, &fn)) {
            fence = fc;
            fence_len = fn;
            pos = line.next;
            continue;
        }
        if (md_line_blank(p, n)) { pos = line.next; continue; }
        int level = md_atx_level((const char *)p, n);
        if (level) {
            size_t from = md_indent(p, n) + (size_t)level;
            while (from < n && (p[from] == ' ' || p[from] == '\t')) ++from;
            size_t to = n;
            while (to > from && (p[to - 1] == ' ' || p[to - 1] == '\t')) --to;
            size_t hash = to;
            while (hash > from && p[hash - 1] == '#') --hash;
            if (hash == from || (hash > from && (p[hash - 1] == ' ' || p[hash - 1] == '\t'))) to = hash;
            while (to > from && (p[to - 1] == ' ' || p[to - 1] == '\t')) --to;
            md_doc_open(&doc, true, (uint8_t)level, false, 0, 0, 0);
            if (doc.open) {
                md_inline(&doc.sink, p + from, to - from, 0, 0);
                md_block_ensure(&doc);
                md_block_end(&doc);
            }
            pos = line.next;
            continue;
        }
        if (md_rule(p, n)) {
            md_doc_open(&doc, false, 0, false, 0, 0, 0);
            if (doc.open) {
                md_sink_text(&doc.sink, MD_RULE, sizeof(MD_RULE) - 1, 0);
                md_block_end(&doc);
            }
            pos = line.next;
            continue;
        }
        size_t body = 0;
        if (md_quote(p, n, &body)) {
            size_t quote_len = n - body;
            md_trim_tail(p + body, &quote_len);
            md_doc_open(&doc, false, 0, true, 0, 0, 0);
            if (doc.open) {
                md_sink_text(&doc.sink, quote_len ? "> " : ">", quote_len ? sizeof("> ") - 1 : sizeof(">") - 1, 0);
                md_inline(&doc.sink, p + body, quote_len, HTML_STYLE_ITALIC, 0);
                md_block_ensure(&doc);
                md_block_end(&doc);
            }
            pos = line.next;
            continue;
        }
        char prefix[16];
        if (md_list_item(p, n, &body, prefix, sizeof(prefix))) {
            size_t item_len = n - body;
            md_trim_tail(p + body, &item_len);
            md_doc_open(&doc, false, 0, true, 0, 0, 0);
            if (doc.open) {
                md_sink_text(&doc.sink, prefix, strlen(prefix), 0);
                md_inline(&doc.sink, p + body, item_len, 0, 0);
                md_block_ensure(&doc);
                md_block_end(&doc);
            }
            pos = line.next;
            continue;
        }
        size_t cols;
        uint8_t aligns[MD_TABLE_COLS_MAX];
        if (md_table_head(src, len, pos, &line, &cols, aligns)) {
            pos = md_parse_table(&doc, src, len, pos, &line, cols, aligns);
            continue;
        }
        // 段落：连续的非块起始行拼成一个块；相邻两侧都不是中日韩时才补一个空格。
        // Paragraph: join consecutive plain lines into one block, adding a space only when neither
        // side of the join is CJK.
        md_doc_open(&doc, false, 0, false, 0, 0, 0);
        bool first = true;
        uint32_t previous = 0;
        while (pos < len && doc.open && !doc.sink.fail) {
            md_line_t row;
            md_line_at(src, len, pos, &row);
            const unsigned char *q = src + pos;
            size_t m = row.text_len;
            if (md_line_blank(q, m)) break;
            if (!first && md_block_break(src, len, pos, &row)) break;
            while (m && (q[m - 1] == ' ' || q[m - 1] == '\t')) --m;
            if (!first && m) {
                uint32_t next_cp = 0;
                (void)md_utf8(q, m, &next_cp);
                if (!md_cjk(previous) && !md_cjk(next_cp)) md_sink_text(&doc.sink, " ", 1, 0);
            }
            md_inline(&doc.sink, q, m, 0, 0);
            if (m) previous = md_last_cp(q, m);
            first = false;
            pos = row.next;
        }
        if (doc.open) {
            md_block_ensure(&doc);
            md_block_end(&doc);
        }
    }
    if (doc.open) md_block_abort(&doc);
    if (doc.sink.fail == 2) {
        free(doc.sink.text);
        free(doc.sink.runs);
        free(doc.blocks);
        return ESP_ERR_NO_MEM;
    }
    if (doc.sink.fail == 1) ESP_LOGW(TAG, "chapter truncated at the %u byte output cap", (unsigned)doc.sink.len);
    doc.sink.text[doc.sink.len] = 0;
    out->utf8 = doc.sink.text;
    out->len = doc.sink.len;
    out->blocks = doc.blocks;
    out->count = doc.count;
    out->runs = doc.sink.runs;
    out->run_count = doc.sink.run_count;
    out->images = NULL;
    out->image_count = 0;
    return ESP_OK;
}

esp_err_t book_md_chapter_load(size_t chapter, html_text_t *out) {
    if (!out) return ESP_ERR_INVALID_ARG;
    memset(out, 0, sizeof(*out));
    if (!s_book.file || chapter >= s_book.count) return ESP_ERR_INVALID_ARG;
    uint32_t from = s_book.entries[chapter].offset;
    uint32_t to = chapter + 1 < s_book.count ? s_book.entries[chapter + 1].offset : s_book.total;
    if (!from) from = s_book.bom;
    if (from > s_book.total || to > s_book.total || to < from) return ESP_ERR_INVALID_SIZE;
    size_t span = (size_t)(to - from);
    if (span > MD_SOURCE_READ_MAX) span = MD_SOURCE_READ_MAX;
    unsigned char *src = heap_caps_malloc(span ? span : 1, PSRAM_CAPS);
    if (!src) return ESP_ERR_NO_MEM;
    clearerr(s_book.file);
    bool ok = fseek(s_book.file, (long)from, SEEK_SET) == 0;
    if (ok && span) ok = fread(src, 1, span, s_book.file) == span;
    if (ferror(s_book.file)) ok = false;
    esp_err_t err = ok ? md_parse_chapter(src, span, out) : ESP_FAIL;
    free(src);
    return err;
}

esp_err_t book_md_load_target(size_t chapter, size_t source_offset, size_t *text_offset,
                              html_text_t *out) {
    (void)source_offset;
    if (text_offset) *text_offset = 0;
    return book_md_chapter_load(chapter, out);
}
