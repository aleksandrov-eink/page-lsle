/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：坚果云阅读进度双向同步。
 *  - 身份：id = FNV-1a32(小写化「相对书库根路径」) 再混入文件大小 4 字节；rel 随条目保存，
 *    供新设备按「书库根 + rel」探测恢复；id 对不上时用 basename+size 唯一兜底（改名/移动）。
 *  - 合并：本机 L、上次同步快照 S（NVS rp_sync/meta，只存 id→值指纹）、云端 R 三方逐书裁决；
 *    L==S 取云端、L!=S 本机优先、无 S 首次按「大小相同且云端百分比更大」取云端；
 *    S 有而本机记录消失 = 用户清进度/删书 → 删除云端条目（隐式墓碑）。
 *  - 存储：云端固定 <同步文件夹>/PageIsle-progress.dat，行式 TSV；本机 book_progress 的
 *    记录格式/NVS 布局一个字都不动（只调用冻结的 list/save 接口）。
 *  - 时钟：合并完全不依赖本机时钟；updated 只用于展示与 apply 排序。
 * English: two-way Jianguoyun reading-progress sync. Identity = FNV-1a32 of the lowercase
 * book-root-relative path mixed with the file size; rel is carried for recovery on a new device,
 * with a unique basename+size fallback for renames. Merge is three-way (local L, last-sync
 * snapshot S in NVS rp_sync/meta, remote R): L==S takes the remote, L!=S keeps local, no S uses
 * "same size and larger remote percentage"; a vanished local record deletes the remote entry.
 * Cloud storage is the line-based TSV <sync folder>/PageIsle-progress.dat. The frozen
 * book_progress record format and NVS layout are never modified; only list/save are called.
 * Merging never needs a wall clock; updated is display/apply-order only.
 */
#include "book_progress_sync.h"

#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>

#include "book_progress.h"
#include "book_store.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "nvs.h"
#include "settings.h"
#include "webdav_client.h"


#define PS_NS "rp_sync"
#define PS_META_KEY "meta"
#define PS_META_MAGIC UINT32_C(0x50534D31) ///< 'PSM1'
#define PS_META_VERSION 1u
#define PS_META_HEADER 12u
#define PS_META_BLOB_MAX (PS_META_HEADER + BOOK_PROGRESS_SYNC_META_MAX * 8u)
// 合并行硬上限：本机最多 MAX_BOOKS 条记录，云端最多 MAX_BOOKS 条；两边互不重叠时行数翻倍，
// 所以合并数组按「本机行 + 云端行」的实际条数分配，再以 2×MAX_BOOKS 兜底。
// Merged row hard cap: up to MAX_BOOKS local records plus up to MAX_BOOKS remote-only entries, so
// the merged array is sized by the actual local+remote counts with 2xMAX_BOOKS as the hard bound.
#define PS_MERGED_CAP (2 * BOOK_PROGRESS_SYNC_MAX_BOOKS)
#define PS_DEVICE_MAX 64
#define PS_REMOTE_HEADER "PAGEISLE-PROGRESS\t1"
#define PS_DEVICE_FALLBACK "页屿"

// 合并行的来源/动作。
// Merge-row action.
enum {
    PS_SRC_UNCHANGED = 0, ///< 双方一致，输出云端值
    PS_SRC_UPLOAD,        ///< 保留本机值并写入云端
    PS_SRC_APPLY,         ///< 云端较新，写回本机
    PS_SRC_REMOTE_ONLY,   ///< 仅云端有，保留云端条目（本机无此文件）
};

/// 本机记录：path 内嵌，rel 指向 path 内部（相对书库根）。
/// Local record; rel points inside path (book-root relative).
typedef struct {
    char path[BOOK_STORE_PATH_MAX];
    const char *rel;
    book_progress_t value;
    uint32_t id;
    uint32_t fp;
    bool file_ok; ///< stat 成功且为普通文件、大小与记录一致
} ps_local_t;

/// 云端条目。
/// One remote entry.
typedef struct {
    char rel[BOOK_STORE_PATH_MAX];
    uint32_t id;
    uint32_t size;
    uint32_t offset;
    uint32_t updated;
    uint16_t chapter;
    uint8_t px;
    uint8_t pct;
} ps_remote_t;

/// 合并结果行：既描述写回云端的条目，也记住本机路径用于 apply 与快照。
/// A merged row: describes the cloud entry and keeps the local path for apply and the snapshot.
typedef struct {
    char path[BOOK_STORE_PATH_MAX]; ///< 本机绝对路径（无本机对应时为空）
    char rel[BOOK_STORE_PATH_MAX];
    uint32_t id;
    uint32_t size;
    uint32_t offset;
    uint32_t updated;
    uint16_t chapter;
    uint8_t px;
    uint8_t pct;
    uint8_t src;
    bool has_local; ///< path 有效（可 apply / 写快照）
} ps_merged_t;

typedef struct {
    uint32_t id;
    uint32_t fp;
} ps_meta_entry_t;

static ps_meta_entry_t s_meta[BOOK_PROGRESS_SYNC_META_MAX];
static uint16_t s_meta_count;
static uint32_t s_meta_last_sync;
static bool s_meta_loaded;

typedef struct {
    ps_local_t *items;
    uint16_t capacity;
    uint16_t count;
    uint16_t dropped;
} ps_collect_t;

/* ---- FNV-1a 与身份/指纹 / FNV-1a, identity and fingerprints ---- */

static uint32_t ps_fnv_init(void) { return UINT32_C(2166136261); }

static uint32_t ps_fnv(uint32_t hash, const void *data, size_t length) {
    const unsigned char *bytes = data;
    for (size_t i = 0; i < length; ++i) hash = (hash ^ bytes[i]) * UINT32_C(16777619);
    return hash;
}

// 书籍 id：小写化相对路径 + 文件大小（都参与哈希；大小不同即为不同书）。
// Book id: lowercase relative path plus the file size (a changed size means a different book).
static uint32_t ps_book_id(const char *rel, uint32_t size) {
    uint32_t hash = ps_fnv_init();
    for (const unsigned char *p = (const unsigned char *)rel; p && *p; ++p) {
        unsigned char c = *p;
        if (c >= 'A' && c <= 'Z') c = (unsigned char)(c + 32);
        hash = (hash ^ c) * UINT32_C(16777619);
    }
    unsigned char tail[4] = {(unsigned char)(size & 0xFF), (unsigned char)((size >> 8) & 0xFF),
                             (unsigned char)((size >> 16) & 0xFF),
                             (unsigned char)((size >> 24) & 0xFF)};
    return ps_fnv(hash, tail, sizeof(tail));
}

// 值指纹：大小/章节/章内偏移/字号/百分比，共 12 字节，小端手工序列化。
// Value fingerprint over size/chapter/offset/px/pct (12 little-endian bytes, manual serialization).
static uint32_t ps_value_fp(uint32_t size, uint16_t chapter, uint32_t offset,
                            uint8_t px, uint8_t pct) {
    unsigned char data[12] = {
        (unsigned char)(size & 0xFF), (unsigned char)((size >> 8) & 0xFF),
        (unsigned char)((size >> 16) & 0xFF), (unsigned char)((size >> 24) & 0xFF),
        (unsigned char)(chapter & 0xFF), (unsigned char)((chapter >> 8) & 0xFF),
        (unsigned char)(offset & 0xFF), (unsigned char)((offset >> 8) & 0xFF),
        (unsigned char)((offset >> 16) & 0xFF), (unsigned char)((offset >> 24) & 0xFF),
        px, pct,
    };
    return ps_fnv(ps_fnv_init(), data, sizeof(data));
}

static uint32_t ps_local_fp(const book_progress_t *value) {
    return ps_value_fp(value->file_size, value->chapter, value->byte_off, value->px, value->pct);
}

static uint32_t ps_remote_fp(const ps_remote_t *entry) {
    return ps_value_fp(entry->size, entry->chapter, entry->offset, entry->px, entry->pct);
}

// 相对书库根的路径：优先用设置里的书库目录，其次兼容常见挂载点；未知前缀去掉开头一个 '/'。
// Book-root-relative path: the configured books directory first, then common mounts; an unknown
// prefix simply drops one leading '/'.
static const char *ps_local_rel(const char *path) {
    if (!path || !path[0]) return "";
    static const char *const fallback_roots[] = {"/sdcard/books", "/sdcard/book", "/flash/books"};
    const char *dir = app_settings_books_dir();
    if (dir && dir[0]) {
        size_t length = strlen(dir);
        while (length > 1 && dir[length - 1] == '/') --length;
        if (!strncmp(path, dir, length) && path[length] == '/') return path + length + 1;
    }
    for (size_t i = 0; i < sizeof(fallback_roots) / sizeof(fallback_roots[0]); ++i) {
        const char *root = fallback_roots[i];
        size_t length = strlen(root);
        if (!strncmp(path, root, length) && path[length] == '/') return path + length + 1;
    }
    return path[0] == '/' ? path + 1 : path;
}

static const char *ps_basename(const char *path) {
    const char *slash = path ? strrchr(path, '/') : NULL;
    return slash ? slash + 1 : (path ? path : "");
}

/* ---- 本机同步快照（NVS rp_sync/meta） / Local snapshot in NVS ---- */

static void ps_meta_clear(void) {
    s_meta_count = 0;
    s_meta_last_sync = 0;
    s_meta_loaded = true;
}

static esp_err_t ps_meta_load(void) {
    if (s_meta_loaded) return ESP_OK;
    ps_meta_clear();
    nvs_handle_t handle;
    esp_err_t err = nvs_open(PS_NS, NVS_READONLY, &handle);
    if (err == ESP_ERR_NVS_NOT_FOUND) return ESP_OK;
    if (err != ESP_OK) {
        s_meta_loaded = false;
        return err;
    }
    unsigned char blob[PS_META_BLOB_MAX];
    size_t size = sizeof(blob);
    err = nvs_get_blob(handle, PS_META_KEY, blob, &size);
    nvs_close(handle);
    if (err == ESP_ERR_NVS_NOT_FOUND || err == ESP_ERR_NVS_INVALID_LENGTH) return ESP_OK;
    if (err != ESP_OK) {
        s_meta_loaded = false;
        return err;
    }
    if (size < PS_META_HEADER) return ESP_OK;
    uint32_t magic;
    uint16_t version, count;
    uint32_t last;
    memcpy(&magic, blob, 4);
    memcpy(&version, blob + 4, 2);
    memcpy(&count, blob + 6, 2);
    memcpy(&last, blob + 8, 4);
    if (magic != PS_META_MAGIC || version != PS_META_VERSION || count > BOOK_PROGRESS_SYNC_META_MAX ||
        size < PS_META_HEADER + (size_t)count * 8u) {
        return ESP_OK; // 版本不认识或损坏：当作没有快照（退化为首次合并）
    }
    s_meta_last_sync = last;
    for (uint16_t i = 0; i < count; ++i) {
        memcpy(&s_meta[i].id, blob + PS_META_HEADER + (size_t)i * 8u, 4);
        memcpy(&s_meta[i].fp, blob + PS_META_HEADER + (size_t)i * 8u + 4, 4);
    }
    s_meta_count = count;
    return ESP_OK;
}

static esp_err_t ps_meta_save(const ps_merged_t *merged, uint16_t count, uint32_t now) {
    unsigned char blob[PS_META_BLOB_MAX];
    uint16_t stored = 0;
    for (uint16_t i = 0; i < count && stored < BOOK_PROGRESS_SYNC_META_MAX; ++i) {
        if (!merged[i].has_local) continue;
        uint32_t fp = ps_value_fp(merged[i].size, merged[i].chapter, merged[i].offset,
                                  merged[i].px, merged[i].pct);
        memcpy(blob + PS_META_HEADER + (size_t)stored * 8u, &merged[i].id, 4);
        memcpy(blob + PS_META_HEADER + (size_t)stored * 8u + 4, &fp, 4);
        ++stored;
    }
    const uint32_t magic = PS_META_MAGIC;
    const uint16_t version = PS_META_VERSION;
    memcpy(blob, &magic, 4);
    memcpy(blob + 4, &version, 2);
    memcpy(blob + 6, &stored, 2);
    memcpy(blob + 8, &now, 4);
    nvs_handle_t handle;
    esp_err_t err = nvs_open(PS_NS, NVS_READWRITE, &handle);
    if (err != ESP_OK) return err;
    err = nvs_set_blob(handle, PS_META_KEY, blob, PS_META_HEADER + (size_t)stored * 8u);
    if (err == ESP_OK) err = nvs_commit(handle);
    nvs_close(handle);
    if (err == ESP_OK) {
        s_meta_count = stored;
        s_meta_last_sync = now;
        s_meta_loaded = true;
    }
    return err;
}

static bool ps_meta_find(uint32_t id, uint32_t *fp) {
    for (uint16_t i = 0; i < s_meta_count; ++i) {
        if (s_meta[i].id != id) continue;
        if (fp) *fp = s_meta[i].fp;
        return true;
    }
    return false;
}

/* ---- 本机记录收集 / Local record collection ---- */

static bool ps_collect_visit(const char *path, const book_progress_t *progress, void *ctx) {
    ps_collect_t *state = ctx;
    if (!state || !path || !progress) return true;
    if (state->count >= state->capacity) {
        ++state->dropped;
        return true;
    }
    ps_local_t *item = &state->items[state->count];
    memset(item, 0, sizeof(*item));
    size_t length = strlen(path);
    if (length >= sizeof(item->path)) {
        ++state->dropped;
        return true;
    }
    memcpy(item->path, path, length + 1);
    item->rel = ps_local_rel(item->path);
    item->value = *progress;
    item->id = ps_book_id(item->rel, progress->file_size);
    item->fp = ps_local_fp(progress);
    struct stat info;
    item->file_ok = stat(item->path, &info) == 0 && S_ISREG(info.st_mode) &&
                    info.st_size >= 0 && (uint64_t)info.st_size == progress->file_size;
    ++state->count;
    return true;
}

static bool ps_count_visit(const char *path, const book_progress_t *progress, void *ctx) {
    (void)path;
    (void)progress;
    uint16_t *count = ctx;
    if (*count < UINT16_MAX) ++*count;
    return true;
}

static bool ps_list_noop(void *ctx, const webdav_entry_t *entry) {
    (void)ctx;
    (void)entry;
    return true;
}

uint32_t book_progress_sync_last_time(void) {
    if (ps_meta_load() != ESP_OK) return 0;
    return s_meta_last_sync;
}

esp_err_t book_progress_sync_local_count(uint16_t *out) {
    if (!out) return ESP_ERR_INVALID_ARG;
    uint16_t count = 0;
    esp_err_t err = book_progress_list(ps_count_visit, &count);
    *out = err == ESP_OK ? count : 0;
    return err;
}

/* ---- 云端 TSV 解析与生成 / Remote TSV parse and build ---- */

static bool ps_valid_rel(const char *rel) {
    if (!rel || !rel[0] || rel[0] == '/') return false;
    if (strlen(rel) >= BOOK_STORE_PATH_MAX) return false;
    if (!strcmp(rel, ".") || !strcmp(rel, "..")) return false;
    if (!strncmp(rel, "../", 3) || strstr(rel, "/../") || (strlen(rel) >= 3 &&
        !strcmp(rel + strlen(rel) - 3, "/.."))) return false;
    return true;
}

// 解析一行 BOOK；rel 允许包含空格/中文，取第 8 个 '\t' 之后的整段。
// Parse one BOOK line; rel may contain spaces/CJK and is everything after the 8th tab.
static bool ps_parse_book_line(const char *line, size_t length, ps_remote_t *out, bool *rel_bad) {
    if (!line || !out || length < 6 || strncmp(line, "BOOK\t", 5)) return false;
    const char *fields[7];
    size_t field_lengths[7];
    const char *at = line + 5;
    const char *end = line + length;
    for (int i = 0; i < 7; ++i) {
        const char *tab = memchr(at, '\t', (size_t)(end - at));
        if (!tab) return false;
        fields[i] = at;
        field_lengths[i] = (size_t)(tab - at);
        at = tab + 1;
    }
    const size_t rel_length = (size_t)(end - at);
    if (!rel_length || rel_length >= sizeof(out->rel)) return false;
    char id_text[16];
    if (field_lengths[0] == 0 || field_lengths[0] >= sizeof(id_text)) return false;
    memcpy(id_text, fields[0], field_lengths[0]);
    id_text[field_lengths[0]] = 0;
    char *id_end = NULL;
    unsigned long id = strtoul(id_text, &id_end, 16);
    if (!id_end || id_end == id_text || id > UINT32_MAX) return false;
    const unsigned long size = strtoul(fields[1], NULL, 10);
    const unsigned long chapter = strtoul(fields[2], NULL, 10);
    const unsigned long offset = strtoul(fields[3], NULL, 10);
    const unsigned long px = strtoul(fields[4], NULL, 10);
    const unsigned long pct = strtoul(fields[5], NULL, 10);
    const unsigned long updated = strtoul(fields[6], NULL, 10);
    if (size > UINT32_MAX || chapter > 0xFFFFul || offset > UINT32_MAX || px > 255ul ||
        pct > 100ul || updated > UINT32_MAX) return false;
    // 与 book_progress_save() 的入参校验保持一致，坏数据绝不进 NVS。
    // Match book_progress_save()'s argument checks so corrupt data never reaches NVS.
    if (px < 18ul || px > 90ul) return false;
    memcpy(out->rel, at, rel_length);
    out->rel[rel_length] = 0;
    if (!ps_valid_rel(out->rel)) {
        if (rel_bad) *rel_bad = true;
        return false;
    }
    out->id = (uint32_t)id;
    out->size = (uint32_t)size;
    out->chapter = (uint16_t)chapter;
    out->offset = (uint32_t)offset;
    out->px = (uint8_t)px;
    out->pct = (uint8_t)pct;
    out->updated = (uint32_t)updated;
    return true;
}

// 解析整份云端文件；返回 BOOK 条数。corrupt=true 表示首行魔数/版本不对（拒绝覆盖）。
// Parse the whole remote file; returns the BOOK count. corrupt=true means the header magic or
// version is wrong, so the caller refuses to overwrite.
static uint16_t ps_tsv_parse(const char *text, size_t length, ps_remote_t *out, uint16_t cap,
                             uint16_t *bad_lines, uint16_t *dropped, bool *corrupt) {
    *corrupt = false;
    *bad_lines = 0;
    *dropped = 0;
    if (!text || !length) return 0;
    size_t at = 0;
    bool header = false;
    uint16_t count = 0;
    while (at < length) {
        size_t end = at;
        while (end < length && text[end] != '\n') ++end;
        size_t line_length = end - at;
        if (line_length && text[at + line_length - 1] == '\r') --line_length;
        const char *line = text + at;
        if (!header) {
            if (line_length != strlen(PS_REMOTE_HEADER) ||
                strncmp(line, PS_REMOTE_HEADER, line_length)) {
                *corrupt = true;
                return 0;
            }
            header = true;
        } else if (line_length && !strncmp(line, "DEVICE\t", 7)) {
            // 展示用，忽略 / display only, ignored
        } else if (line_length && !strncmp(line, "UPDATED\t", 8)) {
            // 展示用，忽略 / display only, ignored
        } else if (line_length) {
            ps_remote_t entry;
            memset(&entry, 0, sizeof(entry));
            bool rel_bad = false;
            if (ps_parse_book_line(line, line_length, &entry, &rel_bad)) {
                if (count < cap) out[count++] = entry;
                else ++*dropped;
            } else {
                ++*bad_lines;
            }
        }
        at = end + 1;
    }
    if (!header) *corrupt = true;
    return count;
}

static void ps_sanitize(char *text, size_t cap) {
    for (size_t i = 0; i < cap && text[i]; ++i) {
        unsigned char c = (unsigned char)text[i];
        if (c < 0x20 || c == 0x7f || c == '\t') text[i] = '_';
    }
}

// 生成整份 TSV（设备名/UPDATED 两个头行 + 有序 BOOK 行）。
// Build the whole TSV (two header lines plus ordered BOOK lines).
static size_t ps_tsv_build(char *out, size_t cap, const ps_merged_t *merged, uint16_t count,
                           const char *device, uint32_t now) {
    if (!out || cap < 32) return 0;
    char safe_device[PS_DEVICE_MAX];
    snprintf(safe_device, sizeof(safe_device), "%s", device && device[0] ? device : PS_DEVICE_FALLBACK);
    ps_sanitize(safe_device, sizeof(safe_device));
    int written = snprintf(out, cap, "%s\nDEVICE\t%s\nUPDATED\t%lu\n", PS_REMOTE_HEADER, safe_device,
                           (unsigned long)now);
    if (written < 0 || (size_t)written >= cap) return 0;
    size_t used = (size_t)written;
    for (uint16_t i = 0; i < count; ++i) {
        const ps_merged_t *row = &merged[i];
        char rel[BOOK_STORE_PATH_MAX];
        memcpy(rel, row->rel, strlen(row->rel) + 1);
        ps_sanitize(rel, sizeof(rel));
        written = snprintf(out + used, cap - used, "BOOK\t%08lx\t%lu\t%u\t%lu\t%u\t%u\t%lu\t%s\n",
                           (unsigned long)row->id, (unsigned long)row->size,
                           (unsigned)row->chapter, (unsigned long)row->offset,
                           (unsigned)row->px, (unsigned)row->pct,
                           (unsigned long)row->updated, rel);
        if (written < 0 || (size_t)written >= cap - used) return 0;
        used += (size_t)written;
    }
    return used;
}

/* ---- 合并 / Merge ---- */

static int ps_find_remote_id(const ps_remote_t *remote, uint16_t count, const bool *used,
                             uint32_t id) {
    for (uint16_t i = 0; i < count; ++i)
        if (!used[i] && remote[i].id == id) return (int)i;
    return -1;
}

// 改名/移动/换根兜底：basename 相同、大小相同、且候选唯一。
// Rename/move/root-change fallback: same basename, same size, unique candidate.
static int ps_find_remote_rename(const ps_remote_t *remote, uint16_t count, const bool *used,
                                 const ps_local_t *local) {
    const char *base = ps_basename(local->rel);
    int hit = -1;
    for (uint16_t i = 0; i < count; ++i) {
        if (used[i]) continue;
        if (remote[i].size != local->value.file_size) continue;
        if (strcmp(ps_basename(remote[i].rel), base)) continue;
        if (hit >= 0) return -1; // 多个候选不猜 / more than one candidate, do not guess
        hit = (int)i;
    }
    return hit;
}

static void ps_merge_row(ps_merged_t *row, const ps_local_t *local, const ps_remote_t *remote,
                         uint32_t id, uint32_t size, uint32_t offset, uint16_t chapter,
                         uint8_t px, uint8_t pct, uint32_t updated, uint8_t src, bool has_local) {
    memset(row, 0, sizeof(*row));
    row->id = id;
    row->size = size;
    row->offset = offset;
    row->chapter = chapter;
    row->px = px;
    row->pct = pct;
    row->updated = updated;
    row->src = src;
    row->has_local = has_local && local && local->path[0];
    const char *rel = local ? local->rel : (remote ? remote->rel : "");
    snprintf(row->rel, sizeof(row->rel), "%s", rel);
    if (local && local->path[0]) snprintf(row->path, sizeof(row->path), "%s", local->path);
}

// 探测「新设备恢复」：书库根 + rel（再退到 basename）能找到同名同大小的文件。
// Probe for new-device restore: books root + rel (then bare basename) holding a same-size file.
static bool ps_probe_local(const char *rel, uint32_t size, char *out, size_t cap) {
    static const char *const fallback_roots[] = {"/sdcard/books", "/sdcard/book", "/flash/books"};
    // 逐个拼接并立刻 stat：只占一个候选路径的栈，避免 worker 任务栈再压 8×BOOK_STORE_PATH_MAX。
    // Build and stat one candidate at a time: one path buffer instead of 8xBOOK_STORE_PATH_MAX on the
    // worker stack. The probe order and the "first match wins" rule stay identical.
    char candidate[BOOK_STORE_PATH_MAX];
    const char *dirs[4];
    size_t dir_count = 0;
    const char *configured = app_settings_books_dir();
    if (configured && configured[0]) dirs[dir_count++] = configured;
    for (size_t i = 0; i < sizeof(fallback_roots) / sizeof(fallback_roots[0]); ++i)
        dirs[dir_count++] = fallback_roots[i];
    const char *base = ps_basename(rel);
    for (size_t i = 0; i < dir_count; ++i) {
        for (int pass = 0; pass < 2; ++pass) {
            const char *tail = pass == 0 ? rel : base;
            if (pass == 1 && !strcmp(tail, rel)) continue;
            int n = snprintf(candidate, sizeof(candidate), "%s%s%s", dirs[i],
                             dirs[i][strlen(dirs[i]) - 1] == '/' ? "" : "/", tail);
            if (n <= 0 || n >= BOOK_STORE_PATH_MAX) continue;
            struct stat info;
            if (stat(candidate, &info) != 0 || !S_ISREG(info.st_mode) || info.st_size < 0) continue;
            if ((uint64_t)info.st_size != size) continue;
            // 手工有界拷贝：cap 是调用方给的任意大小，snprintf 会触发 -Wformat-truncation。
            // Bounded copy by hand: cap comes from the caller, and snprintf would trip the truncation check.
            size_t length = strnlen(candidate, sizeof(candidate) - 1);
            if (length + 1 > cap) length = cap - 1;
            memcpy(out, candidate, length);
            out[length] = 0;
            return true;
        }
    }
    return false;
}

/* ---- 主流程 / Main entry ---- */

esp_err_t book_progress_sync_run(const char *remote_dir, book_progress_sync_result_t *result,
                                 const volatile bool *cancel) {
    if (!result) return ESP_ERR_INVALID_ARG;
    if (!remote_dir || !remote_dir[0]) return ESP_ERR_INVALID_ARG;
    memset(result, 0, sizeof(*result));
    esp_err_t err = ESP_OK;
    ps_local_t *local = NULL;
    ps_remote_t *remote = NULL;
    ps_merged_t *merged = NULL;
    bool *remote_used = NULL;
    char *raw = NULL;
    char *out = NULL;
    uint16_t local_count = 0;
    uint16_t remote_count = 0;
    uint16_t merged_count = 0;
    uint16_t bad_lines = 0;
    uint16_t dropped_remote = 0;
    uint16_t apply_failed = 0;
    bool changed = false;
    uint16_t merged_cap = 0;

    const size_t alloc_caps = MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT;
    local = heap_caps_calloc(BOOK_PROGRESS_SYNC_MAX_BOOKS, sizeof(*local), alloc_caps);
    // 云端条目按合并上限分配：本机最多 MAX_BOOKS 行、云端文件最多 PS_MERGED_CAP 行，
    // 读写两端用同一个上限，避免「写出 192 行、读回只认 96 行」导致再次同步时删云端条目。
    // Size remote entries by the merged cap: the local side holds at most MAX_BOOKS rows and the
    // cloud file at most PS_MERGED_CAP; using one bound for both directions prevents the read-back
    // limit from truncating entries that the write side produced.
    remote = heap_caps_calloc(PS_MERGED_CAP, sizeof(*remote), alloc_caps);
    remote_used = heap_caps_calloc(PS_MERGED_CAP, sizeof(*remote_used), alloc_caps);
    raw = heap_caps_malloc(BOOK_PROGRESS_SYNC_MAX_BYTES, alloc_caps);
    out = heap_caps_malloc(BOOK_PROGRESS_SYNC_MAX_BYTES, alloc_caps);
    if (!local || !remote || !remote_used || !raw || !out) {
        snprintf(result->message, sizeof(result->message), "内存不足，无法同步阅读进度");
        err = ESP_ERR_NO_MEM;
        goto done;
    }

    // 1) 本机记录 + stat + 身份/指纹。
    // 1) Local records, stat probe, identity and fingerprints.
    ps_collect_t collect = {.items = local, .capacity = BOOK_PROGRESS_SYNC_MAX_BOOKS};
    err = book_progress_list(ps_collect_visit, &collect);
    if (err != ESP_OK) {
        snprintf(result->message, sizeof(result->message), "读取本机阅读进度失败，请重试");
        goto done;
    }
    local_count = collect.count;
    result->dropped = collect.dropped;

    // 2) 上次同步快照。
    // 2) Snapshot from the last successful sync.
    err = ps_meta_load();
    if (err != ESP_OK) {
        snprintf(result->message, sizeof(result->message), "读取同步快照失败，请重试");
        goto done;
    }

    // 3) 云端文件（404 时再探一次目录，区分“首次同步”与“文件夹不存在”）。
    // 3) Remote file; on 404 probe the directory to tell "first sync" from "folder missing".
    char remote_path[WEBDAV_PATH_MAX];
    int path_length = snprintf(remote_path, sizeof(remote_path), "%s%s%s", remote_dir,
                               remote_dir[strlen(remote_dir) - 1] == '/' ? "" : "/",
                               BOOK_PROGRESS_SYNC_FILE);
    if (path_length < 0 || path_length >= (int)sizeof(remote_path)) {
        snprintf(result->message, sizeof(result->message), "同步文件夹路径过长");
        err = ESP_ERR_INVALID_ARG;
        goto done;
    }
    size_t raw_length = 0;
    err = webdav_get_text(remote_path, raw, BOOK_PROGRESS_SYNC_MAX_BYTES, &raw_length, cancel);
    if (err == ESP_ERR_NOT_FOUND) {
        err = webdav_list(remote_dir, ps_list_noop, NULL, cancel);
        if (err == ESP_ERR_NOT_FOUND) {
            snprintf(result->message, sizeof(result->message),
                     "同步文件夹不存在，请先在坚果云网页创建该文件夹，或修改同步文件夹设置");
            goto done;
        }
        if (err != ESP_OK) {
            const char *text = webdav_error_text(err, result->message, sizeof(result->message));
            (void)text;
            goto done;
        }
        remote_count = 0;
        err = ESP_OK;
    } else if (err == ESP_ERR_INVALID_SIZE) {
        snprintf(result->message, sizeof(result->message), "云端进度文件过大，本次未覆盖");
        goto done;
    } else if (err != ESP_OK) {
        const char *text = webdav_error_text(err, result->message, sizeof(result->message));
        (void)text;
        goto done;
    } else {
        bool corrupt = false;
        remote_count = ps_tsv_parse(raw, raw_length, remote, PS_MERGED_CAP,
                                    &bad_lines, &dropped_remote, &corrupt);
        if (corrupt) {
            snprintf(result->message, sizeof(result->message),
                     "云端进度文件损坏或版本不兼容，本次未覆盖云端");
            err = ESP_ERR_INVALID_RESPONSE;
            goto done;
        }
    }
    if (cancel && *cancel) {
        err = ESP_ERR_INVALID_STATE;
        goto done;
    }

    // 合并行 = 本机行 + 仅云端行，最多 local_count + remote_count；按实际条数分配，
    // 再以 2×MAX_BOOKS 为硬上限，append 前仍逐次校验，绝不越界写堆。
    // Merged rows are local rows plus remote-only rows, so at most local_count + remote_count; size
    // the array by the actual counts, keep 2xMAX_BOOKS as the hard cap and still re-check before
    // every append so the heap block can never be overrun.
    merged_cap = (uint16_t)(local_count + remote_count);
    if (merged_cap > PS_MERGED_CAP) merged_cap = PS_MERGED_CAP;
    merged = heap_caps_calloc(merged_cap ? merged_cap : 1u, sizeof(*merged), alloc_caps);
    if (!merged) {
        snprintf(result->message, sizeof(result->message), "内存不足，无法同步阅读进度");
        err = ESP_ERR_NO_MEM;
        goto done;
    }

    // 4) 逐书合并（L/S/R 判定表）。
    // 4) Per-book merge using the L/S/R decision table.
    uint32_t now = 0;
    time_t wall = time(NULL);
    if (wall > 1704067200) now = (uint32_t)wall;
    // 先处理本机记录：每条产生一行输出（云端有匹配时可能采用云端值）。
    // Walk local records first: each yields one output row (remote values may win).
    for (uint16_t i = 0; i < local_count; ++i) {
        if (cancel && *cancel) {
            err = ESP_ERR_INVALID_STATE;
            goto done;
        }
        // 每条本机记录恰好 append 一行；容量满时跳过并计入截断，绝不越界写堆。
        // Each local record appends exactly one row; on a full buffer skip and count it as dropped
        // instead of writing past the heap block.
        if (merged_count >= merged_cap) {
            ++result->dropped;
            continue;
        }
        const ps_local_t *item = &local[i];
        int match = ps_find_remote_id(remote, remote_count, remote_used, item->id);
        bool renamed = false;
        if (match < 0) {
            match = ps_find_remote_rename(remote, remote_count, remote_used, item);
            renamed = match >= 0;
        }
        const ps_remote_t *entry = match >= 0 ? &remote[match] : NULL;
        if (match >= 0) remote_used[match] = true;
        if (!item->file_ok) {
            // 文件不可用：不 apply、不删除云端条目。
            // File unavailable: never apply and never delete the remote entry.
            ++result->stale;
            if (entry && !renamed) {
                ps_merge_row(&merged[merged_count++], item, entry, item->id, entry->size,
                             entry->offset, entry->chapter, entry->px, entry->pct, entry->updated,
                             PS_SRC_UNCHANGED, true);
            } else {
                ps_merge_row(&merged[merged_count++], item, NULL, item->id, item->value.file_size,
                             item->value.byte_off, item->value.chapter, item->value.px,
                             item->value.pct, now, PS_SRC_UPLOAD, true);
            }
            continue;
        }
        bool same_value = entry && !renamed && entry->size == item->value.file_size &&
                          ps_remote_fp(entry) == item->fp;
        uint32_t snapshot_fp = 0;
        bool has_snapshot = ps_meta_find(item->id, &snapshot_fp);
        if (!entry) {
            // 云端没有这条：本机写入云端。
            // Remote has no such entry: upload the local one.
            ps_merge_row(&merged[merged_count++], item, NULL, item->id, item->value.file_size,
                         item->value.byte_off, item->value.chapter, item->value.px, item->value.pct,
                         now, PS_SRC_UPLOAD, true);
            ++result->uploaded;
        } else if (same_value) {
            // 双方一致（含兜底配对后的同值）。
            // Both sides agree (including a rename fallback that matched an equal value).
            ps_merge_row(&merged[merged_count++], item, entry, entry->id, entry->size, entry->offset,
                         entry->chapter, entry->px, entry->pct, entry->updated, PS_SRC_UNCHANGED,
                         true);
            ++result->unchanged;
        } else if (has_snapshot && snapshot_fp == item->fp) {
            // L==S 且云端不同 → 云端较新，写回本机。
            // L==S with a different remote value: the remote is newer, apply it.
            ps_merge_row(&merged[merged_count++], item, entry, item->id, entry->size, entry->offset,
                         entry->chapter, entry->px, entry->pct, entry->updated, PS_SRC_APPLY, true);
            ++result->applied;
        } else if (has_snapshot && ps_remote_fp(entry) == snapshot_fp) {
            // 云端仍是上次同步值、本机已改 → 本机较新。
            // The remote still holds the last-sync value while local changed: the local is newer.
            ps_merge_row(&merged[merged_count++], item, NULL, item->id, item->value.file_size,
                         item->value.byte_off, item->value.chapter, item->value.px, item->value.pct,
                         now, PS_SRC_UPLOAD, true);
            ++result->uploaded;
        } else if (!has_snapshot && entry->size == item->value.file_size &&
                   entry->pct > item->value.pct) {
            // 首次同步同一本书：云端读得更远 → 采用云端；否则保留本机。
            // First sync of the same book: a further remote position wins, otherwise keep local.
            ps_merge_row(&merged[merged_count++], item, entry, item->id, entry->size, entry->offset,
                         entry->chapter, entry->px, entry->pct, entry->updated, PS_SRC_APPLY, true);
            ++result->applied;
        } else if (has_snapshot) {
            // 两边都改过：本机优先。
            // Both sides changed: local wins.
            ps_merge_row(&merged[merged_count++], item, NULL, item->id, item->value.file_size,
                         item->value.byte_off, item->value.chapter, item->value.px, item->value.pct,
                         now, PS_SRC_UPLOAD, true);
            ++result->conflicts;
        } else {
            ps_merge_row(&merged[merged_count++], item, NULL, item->id, item->value.file_size,
                         item->value.byte_off, item->value.chapter, item->value.px, item->value.pct,
                         now, PS_SRC_UPLOAD, true);
            ++result->uploaded;
        }
    }
    // 本机记录里出现过的 id（含 stale），用于墓碑判定。
    // Ids seen locally (stale included) for the tombstone decision.
    for (uint16_t i = 0; i < remote_count; ++i) {
        if (remote_used[i]) continue;
        uint32_t snapshot_fp = 0;
        if (ps_meta_find(remote[i].id, &snapshot_fp)) {
            // S 有、本机记录消失：用户清进度/删书 → 删除云端条目。
            // The snapshot exists but the local record is gone: drop the remote entry.
            ++result->removed;
            changed = true;
            continue;
        }
        // 仅云端：新设备/另一台设备的书，保留，并尝试按书库根探测恢复。
        // Remote-only: another device's book; keep it and try to restore it on this device.
        if (merged_count >= merged_cap) {
            ++result->dropped;
            continue;
        }
        ps_merged_t *row = &merged[merged_count++];
        ps_merge_row(row, NULL, &remote[i], remote[i].id, remote[i].size, remote[i].offset,
                     remote[i].chapter, remote[i].px, remote[i].pct, remote[i].updated,
                     PS_SRC_REMOTE_ONLY, false);
        snprintf(row->rel, sizeof(row->rel), "%s", remote[i].rel);
        // 探测结果直接写进 row->path（容量同为 BOOK_STORE_PATH_MAX），不再占一份栈缓冲。
        // Probe straight into row->path (same BOOK_STORE_PATH_MAX capacity) instead of another stack buffer.
        if (ps_probe_local(remote[i].rel, remote[i].size, row->path, sizeof(row->path))) {
            row->has_local = true;
            row->src = PS_SRC_APPLY;
            ++result->applied;
        } else {
            ++result->remote_only;
        }
    }
    // 合并结果按 id 排序，云端文件稳定、可 diff；apply 顺序另按 updated 升序。
    // Sort merged rows by id for a stable, diffable cloud file; apply order is by updated later.
    for (uint16_t i = 1; i < merged_count; ++i) {
        ps_merged_t row = merged[i];
        int j = (int)i - 1;
        while (j >= 0 && merged[j].id > row.id) {
            merged[j + 1] = merged[j];
            --j;
        }
        merged[j + 1] = row;
    }
    result->total = merged_count;

    // 5) apply：云端较新的条写回本机（按 updated 升序，减少“最近阅读”排序抖动）。
    // 5) Apply remote-ahead rows to local NVS in updated order to limit recency jitter.
    if (result->applied) {
        // 下标数组按合并行数分配：APPLY 行数最多等于合并行数，容量不再依赖计数恒等。
        // Size the index array by the merged row count: APPLY rows can never outnumber merged rows,
        // so the capacity no longer relies on the applied counter staying in lockstep.
        uint16_t *indices = heap_caps_malloc((size_t)merged_count * sizeof(uint16_t), alloc_caps);
        if (indices) {
            uint16_t apply_count = 0;
            for (uint16_t i = 0; i < merged_count; ++i)
                if (merged[i].src == PS_SRC_APPLY) indices[apply_count++] = i;
            for (uint16_t i = 1; i < apply_count; ++i) {
                uint16_t value = indices[i];
                int j = (int)i - 1;
                while (j >= 0 && merged[indices[j]].updated > merged[value].updated) {
                    indices[j + 1] = indices[j];
                    --j;
                }
                indices[j + 1] = value;
            }
            for (uint16_t i = 0; i < apply_count; ++i) {
                ps_merged_t *row = &merged[indices[i]];
                if (cancel && *cancel) {
                    heap_caps_free(indices);
                    err = ESP_ERR_INVALID_STATE;
                    goto done;
                }
                struct stat info;
                if (!row->path[0] || stat(row->path, &info) != 0 || !S_ISREG(info.st_mode) ||
                    info.st_size < 0 || (uint64_t)info.st_size != row->size) {
                    ++result->stale;
                    ++apply_failed;
                    continue;
                }
                book_progress_t progress;
                memset(&progress, 0, sizeof(progress));
                progress.file_size = row->size;
                progress.chapter = row->chapter;
                progress.byte_off = row->offset;
                progress.px = row->px;
                progress.pct = row->pct;
                if (book_progress_save(row->path, &progress) == ESP_OK) ++result->applied_ok;
                else ++apply_failed;
            }
            heap_caps_free(indices);
        } else {
            ++apply_failed;
        }
        book_progress_notify_changed();
    }

    // 6) 序列化；语义没有变化就不写云端（DEVICE/UPDATED 头行不算变化）。
    // 6) Serialize; skip the PUT when the BOOK set is semantically unchanged.
    if (merged_count > remote_count) changed = true;
    for (uint16_t i = 0; i < merged_count && !changed; ++i) {
        const ps_merged_t *row = &merged[i];
        bool found = false;
        for (uint16_t j = 0; j < remote_count; ++j) {
            if (remote[j].id != row->id) continue;
            found = true;
            if (remote[j].size != row->size || remote[j].chapter != row->chapter ||
                remote[j].offset != row->offset || remote[j].px != row->px ||
                remote[j].pct != row->pct || strcmp(remote[j].rel, row->rel)) {
                changed = true;
            }
            break;
        }
        if (!found) changed = true;
    }
    if (bad_lines || dropped_remote || result->removed || result->conflicts || result->uploaded)
        changed = true;
    if (changed || remote_count == 0) {
        size_t out_length = ps_tsv_build(out, BOOK_PROGRESS_SYNC_MAX_BYTES, merged, merged_count,
                                         app_settings_device_name(), now);
        if (!out_length) {
            snprintf(result->message, sizeof(result->message), "生成云端进度文件失败");
            err = ESP_FAIL;
            goto done;
        }
        err = webdav_put_text(remote_path, out, out_length, "text/plain; charset=utf-8", cancel);
        if (err != ESP_OK) {
            char error_text[96] = {0};
            (void)webdav_error_text(err, error_text, sizeof(error_text));
            snprintf(result->message, sizeof(result->message),
                     "云端写入失败：%s；本机进度已更新，可重试", error_text);
            goto done;
        }
        result->put_done = true;
    }
    if (ps_meta_save(merged, merged_count, now) != ESP_OK) {
        result->meta_saved = false;
    } else {
        result->meta_saved = true;
    }
    if (result->meta_saved) {
        if (result->applied_ok || result->uploaded || result->conflicts || result->removed)
            snprintf(result->message, sizeof(result->message),
                     "同步完成：上传 %u · 恢复 %u · 冲突 %u · 删除 %u",
                     (unsigned)result->uploaded, (unsigned)result->applied_ok,
                     (unsigned)result->conflicts, (unsigned)result->removed);
        else
            snprintf(result->message, sizeof(result->message), "进度已是最新：共 %u 本",
                     (unsigned)result->total);
    } else {
        snprintf(result->message, sizeof(result->message),
                 "同步完成，但快照保存失败，下次可能重复合并");
    }
    if (apply_failed > 0) {
        size_t used = strlen(result->message);
        if (used + 40 < sizeof(result->message))
            snprintf(result->message + used, sizeof(result->message) - used,
                     "（%u 本本机写入失败）", (unsigned)apply_failed);
    }
    err = ESP_OK;

done:
    heap_caps_free(local);
    heap_caps_free(remote);
    heap_caps_free(merged);
    heap_caps_free(remote_used);
    heap_caps_free(raw);
    heap_caps_free(out);
    return err;
}
