#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define BOOK_COVER_W 176
#define BOOK_COVER_H 240

/// 图片真实格式按文件内容识别：手机/社交软件/下载站复制来的文件经常扩展名与实际格式不符。
/// Real format detected from the file bytes: files copied from phones, social apps and download
/// sites often carry an extension that does not match their contents.
#define BOOK_IMAGE_FORMAT_UNKNOWN 0
#define BOOK_IMAGE_FORMAT_PNG 1
#define BOOK_IMAGE_FORMAT_JPEG 2
int book_image_format(const uint8_t *data, size_t size);

// Output is one grayscale byte per pixel (0=black, 255=white).
// `png` 只是旧调用方的提示，实际解码器按内容判定。/ `png` is only a legacy hint; the decoder sniffs the bytes.
bool book_cover_thumbnail(const uint8_t *data, size_t size, bool png,
                          uint8_t out[BOOK_COVER_W * BOOK_COVER_H]);
// Decode an image to a chosen grayscale size; output is one byte per pixel.
bool book_image_grayscale(const uint8_t *data, size_t size, bool png,
                          unsigned out_width, unsigned out_height, uint8_t *out);
bool book_image_dimensions(const uint8_t *data, size_t size, bool png,
                           unsigned *width, unsigned *height);

/// 源图取样窗口，按「填满目标再居中裁剪」计算。
/// 长宽比不同时按长边铺满、裁掉多余的一边，绝不拉伸。
/// Source sampling window computed as cover-then-centre-crop: the longer side fills the target
/// and the excess on the other axis is cropped, so a mismatched aspect ratio is never stretched.
typedef struct {
    unsigned x, y, width, height;
} book_crop_t;

book_crop_t book_cover_crop(unsigned src_width, unsigned src_height,
                            unsigned dst_width, unsigned dst_height);

/// 优先读取书内封面，缺少或无法解码时按书籍标识生成并缓存灰阶封面。
/// Prefer a valid embedded cover; otherwise generate and cache a deterministic grayscale cover.
bool book_cover_load_gray(const char *path, const char *title, const char *author,
                          uint8_t out[BOOK_COVER_W * BOOK_COVER_H],
                          bool allow_decode, bool *pending);

// TF 图片按文件流解码；输入最多 50 MiB，输出仍限制为一屏。/ Stream TF images up to 50 MiB, with a one-screen output bound.
#define BOOK_IMAGE_FILE_MAX (50u * 1024u * 1024u)
bool book_image_file_dimensions(const char *path, bool png, unsigned *width, unsigned *height);
bool book_image_file_grayscale(const char *path, bool png, unsigned width, unsigned height, uint8_t *out);

/// 图片解码结果：把界面上的「无法预览」拆成明确原因（格式/尺寸/内存/解码）。
/// Image decode outcome: lets the UI turn "cannot preview" into a specific reason.
typedef enum {
    BOOK_IMAGE_OK = 0,
    BOOK_IMAGE_ERR_OPEN,       // 文件打不开或为空 / cannot open or empty
    BOOK_IMAGE_ERR_FORMAT,     // 文件头无法识别或格式不支持 / unrecognised header or format
    BOOK_IMAGE_ERR_TOO_LARGE,  // 源图尺寸超出支持范围 / source dimensions out of range
    BOOK_IMAGE_ERR_MEMORY,     // 解码内存不足 / not enough decode memory
    BOOK_IMAGE_ERR_DECODE,     // 图片数据损坏、解码失败 / corrupt data, decode failed
} book_image_status_t;

/// 把图片直接解码为 4bpp 打包灰度平面（每字节高 nibble 是偶数 x，低 nibble 是奇数 x），
/// 每个目标像素用 dither(gray, x, y) 做一次抖动后取高 nibble 存放。
/// 非隔行 PNG 逐行双线性、Adam7 隔行 PNG 逐 pass 读行散射、JPEG 按 MCU 采样直写；
/// 三条路径都不分配整屏 8bit 灰度临时平面（省 831744B 连续内存）。
/// Decode straight into a packed 4bpp grayscale plane (high nibble is even x, low nibble odd x),
/// dithering each destination pixel through dither(gray, x, y) and keeping the high nibble.
/// Non-interlaced PNG streams rows through bilinear, Adam7 PNG scatters pass rows, and JPEG
/// samples straight per MCU; none of them allocates a full-screen 8-bit temporary plane
/// (saving a 831744-byte contiguous block).
bool book_image_file_gray4(const char *path, bool png, unsigned width, unsigned height,
                           uint8_t *packed, uint8_t (*dither)(uint8_t gray, unsigned x, unsigned y),
                           book_image_status_t *status);

bool book_jpeg_frame(const uint8_t *data, size_t size, uint8_t *sof, unsigned *width, unsigned *height);

/// 列表封面缓存保留完整原比例；输出不超过176×240，宽高返回有效像素区。/ Cache uncropped list covers, bounded to 176x240, returning the valid pixel dimensions.
bool book_cover_load_list_gray(const char *path, const char *title, const char *author,
                               uint8_t out[BOOK_COVER_W * BOOK_COVER_H], bool allow_decode,
                               bool *pending, unsigned *width, unsigned *height);

/// 快刷已处理的点阵封面；按书源身份、尺寸、对比度与抖动相位失效，像素带校验。
/// Finished fast-cover pixels: invalidate by source, geometry, contrast and dither phase; validate payload.
typedef struct { unsigned width, height, stride, contrast, phase; } book_fast_cover_key_t;
bool book_cover_fast_cache_read(const char *path, const char *title, const char *author,
                                book_fast_cover_key_t key, uint8_t *out, bool *white_edge);
void book_cover_fast_cache_write(const char *path, const char *title, const char *author,
                                 book_fast_cover_key_t key, const uint8_t *out, bool white_edge);

/// 仅文件/图像工作，不调用字库；1完成、0需要UI生成封面、-1失败。
/// File/image work only, no font calls:1 ready,0 UI-generated cover needed,-1 failure.
int book_cover_load_io(const char *path,const char *title,const char *author,uint8_t *out,bool list,unsigned *width,unsigned *height,bool *auto_cache);
/// 仅读取有效列表缓存的尺寸头，点阵命中时无需分配灰阶像素。/ Read validated list dimensions without a gray allocation on a packed-cache hit.
bool book_cover_list_cache_dimensions(const char *path,const char *title,const char *author,unsigned *width,unsigned *height);
/// 后台持久化UI生成的176x240封面。/ Persist an UI-generated176x240 cover in the worker.
void book_cover_store_generated(const char *path,const char *title,const char *author,const uint8_t *pixels,bool list,int64_t size,int64_t modified);

/// 异步结果仅在来源尺寸/修改时间仍匹配时持久化，防止换书后固化旧像素。
/// Persist asynchronous pixels only under their original source identity, never a replaced book's key.
void book_cover_fast_cache_write_checked(const char *path,const char *title,const char *author,book_fast_cover_key_t key,const uint8_t *pixels,bool edge,int64_t size,int64_t modified);

/// 透明层灰度与 alpha；输出缓冲各 width*height 字节。真实格式按内容识别：PNG 取预乘灰度+alpha，
/// JPEG 内容（常见于扩展名写错的 .png）按不透明层返回，alpha=255。
/// Layer gray and alpha; each output buffer holds width*height bytes. The real format is sniffed:
/// PNG gives premultiplied gray + alpha, while JPEG content (common in mislabelled .png files) is
/// returned as an opaque layer with alpha = 255.
bool book_png_file_layer(const char *path,unsigned width,unsigned height,uint8_t *gray,uint8_t *alpha);
/// 流式透明层：仅保留源行窗口和一条输出行；JPEG 内容按不透明层逐行送出。
/// Stream the layer: only a source row window and one output row are kept; JPEG content is streamed
/// as an opaque layer.
bool book_png_file_layer_rows(const char *path, unsigned width, unsigned height,
    bool (*sink)(void *, unsigned, unsigned, const uint8_t *, const uint8_t *), void *context);
