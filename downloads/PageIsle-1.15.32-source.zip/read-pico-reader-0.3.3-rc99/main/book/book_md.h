/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 * 中文：Markdown 书源：章节索引与 md → 块表/样式 run 解析，不依赖界面。
 * English: Markdown source: chapter index and md-to-blocks parser without UI dependencies.
 * 冻结：输出正文确定性（同输入同输出，进度偏移才稳定）；不写文件、不联网、不访问字体以外的全局状态。
 * Frozen: deterministic output so progress offsets stay stable; never writes files, never uses the network.
 */
#pragma once

#include <stddef.h>
#include <stdint.h>

#include "esp_err.h"
#include "html_text.h"

/// 单章输出正文上限；超过时在块边界截断（不返回失败）。/ Per-chapter output cap, truncated at a block boundary.
#define BOOK_MD_CHAPTER_OUTPUT_MAX (512u * 1024u)
/// 章节目录上限，与 TXT 一致。/ Chapter index cap, matching TXT.
#define BOOK_MD_CHAPTER_MAX 2048

/// 打开并重建索引；替换当前书源。/ Open and rebuild the index, replacing the current source.
esp_err_t book_md_open(const char *path);
/// 关闭书源并释放索引。/ Close the source and free the index.
void book_md_close(void);
/// 章节数。/ Chapter count.
size_t book_md_chapter_count(void);
/// 复制 UTF-8 章节标题，容量不足返回错误。/ Copy a chapter title, failing when capacity is short.
esp_err_t book_md_chapter_title(size_t chapter, char *buf, size_t cap);
/// 加载一章：正文块表 + 样式 run 表，调用方用 html_text_free 释放。
/// Load one chapter as blocks plus style runs; the caller frees with html_text_free.
esp_err_t book_md_chapter_load(size_t chapter, html_text_t *out);
/// 带源偏移加载，text_offset 恒为 0（偏移由输出文本自身携带，与 TXT 语义一致）。
/// Load with a source offset; text_offset is always 0 because offsets live in the output text.
esp_err_t book_md_load_target(size_t chapter, size_t source_offset, size_t *text_offset,
                              html_text_t *out);
/// 源文件长度。/ Source file length in bytes.
uint32_t book_md_total_bytes(void);
/// 章节在源文件里的字节起点。/ Byte offset of a chapter inside the source file.
uint32_t book_md_chapter_offset(size_t chapter);
/// 表格列宽度量所需的正文宽、字号与字间距；每次排版前由阅读页调用，未设置时表格退化为单列。
/// 字间距必须传布局实际使用的值（`book_layout_set_typography()` 的那个像素数），
/// 否则表格行在字距非 0 时会被二次折行、列也对不齐。
/// Body width, font size and tracking used for table column widths; the reader calls it before
/// every layout, and an unset metric degrades tables to a single column. The tracking value must
/// be exactly what book_layout_set_typography() receives, or a non-zero tracking wraps and
/// misaligns table rows.
void book_md_set_metrics(int body_width_px, int font_px, int tracking_px);
