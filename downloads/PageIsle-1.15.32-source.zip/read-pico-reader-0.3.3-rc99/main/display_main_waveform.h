/* SPDX-License-Identifier: Apache-2.0
 * 中文：主页面灰阶保持未变像素；书架退出加强同向擦白，主页水波纹端点单向推动，中灰保持原序列。
 * English: Main-page grays hold unchanged pixels; shelf exit strengthens directional whitening and main water uses directional endpoints while retaining original midgray sequences.
 */
#pragma once
#include "epdiy.h"
const EpdWaveform* display_main_gray_waveform(void);
/// 离开书架单向变白并补四相，避免GC16反向压黑；其他迁移用原DU，等值保持。/ Shelf exit whitens directionally with four extra phases, avoiding GC16 reverse darkening; other transitions use original DU and equal values hold.
const EpdWaveform* display_main_shelf_exit_waveform(void);
/// 水波纹与普通切页共用：端点单向驱动，中灰变色保留完整序列，等灰保持；调用者决定是否错相。
/// Shared by water and ordinary transitions: directional endpoints, complete changed midgray sequences and held equal grays; callers choose staggering.
const EpdWaveform* display_main_water_waveform(void);
/// 快刷首帧保留原DU并保持所有等值像素，亚克力首帧不驱动。/ Fast first pass retains original DU while holding every equal pair, including skipped acrylic.
const EpdWaveform* display_main_bw_waveform(void);

/// 普通模式灰边交错，端点/相数/推动数量不变；OOM回退原柔和灰阶。
/// Ordinary gray-edge interleaving keeps endpoints/phase counts/pulse counts; OOM falls back to original soft grays.
const EpdWaveform* display_main_normal_waveform(void);

/// 面板层切换的 AA 修复表：只重驱动等灰对里的中灰（抗锯齿边），纯黑/纯白保持（不整幅擦白、
/// 不变淡），非等灰对沿用原 GL16 动作；OOM/表不可用时回退原 E0470_WAVEFORM。
/// AA-repair waveform for panel-layer transitions: re-drives only equal-pair mid-grays (the
/// antialiased glyph fringes), holds pure black/white (no whole-frame wipe or fading), keeps the
/// original GL16 actions for non-equal pairs; falls back to E0470_WAVEFORM if the table is unavailable.
const EpdWaveform* display_aa_repair_waveform(void);

/// 阅读页白底推白表（1.15.27）：只对「纯白→纯白」施加纯白推帧，不含压黑段（1.15.24–1.15.26
/// 的压黑复位会让整片白底每页闪黑两次）；其余迁移保持、黑字/抗锯齿边/插图不驱动，白底视觉上不变。
/// Reader white-ground white-push table (1.15.27): pure white-push frames only on the equal-white
/// pair, no darken phase (the old darken reset made the white ground flash black twice per page);
/// every other transition holds, so glyphs/AA/artwork are untouched and the ground looks unchanged.
const EpdWaveform* display_reader_white_repair_waveform(void);

/// 书架封面/材质保留校准灰阶，白色留白只向白推动；只供普通切页，手动全刷保留原表。
/// Shelf art keeps calibrated grays while white space drives only white; ordinary transitions only, preserving vendor manual full refresh.
const EpdWaveform* display_main_shelf_waveform(enum EpdDrawMode mode);

/// 设置列表滚动保留抗锯齿灰阶，变白使用原DU擦除，不叠加书架的四相补白；低内存回退现有柔和表。
/// Settings scrolling retains AA grays with native DU whitening, omitting the shelf's four extra white phases; low memory keeps the existing soft table.
const EpdWaveform* display_settings_scroll_waveform(void);
/// 系统底色恢复原完整柔和灰阶，白底同向擦除；底栏由调用方裁剪保护，不改原始波形。
/// Restore complete original soft system grays with directional white erasure; callers crop navigation and vendor tables remain intact.
const EpdWaveform* display_main_ui_waveform(void);
