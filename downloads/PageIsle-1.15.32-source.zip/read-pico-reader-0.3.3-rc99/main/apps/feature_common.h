/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：特色功能子页的统一接口。入口页负责页眉、底栏与长按中键退出，子页只在固定的内容
 *       卡片里绘制；番茄、闹钟、游戏、待办都实现同一套回调，入口页因此不需要认识具体功能。
 * English: Shared contract for feature sub-pages. The hub owns the header, navigation bar and
 *          middle-key exit, while a child paints inside the fixed content card. Pomodoro/alarm,
 *          games and to-dos all implement the same callbacks, so the hub stays feature-agnostic.
 *
 * 冻结：render 只画像素；蜂鸣、NVS 写入、请求切页只能放在 enter / gesture / tick。
 * Frozen: render paints pixels only; buzzer calls, NVS writes and page requests live in
 *         enter / gesture / tick.
 */
#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "app.h"
#include "epdiy.h"
#include "ui_gesture.h"

// 内容卡片几何由入口页统一给出，子页不要自己改，切页时卡片和底栏才不会跳。
// The hub defines the content-card geometry; children must not move it so the card and the
// navigation bar stay put when switching features.
#define FEATURE_CARD_LEFT 36
#define FEATURE_CARD_TOP 196
#define FEATURE_CARD_WIDTH 612
#define FEATURE_CARD_HEIGHT 780
#define FEATURE_CARD_RIGHT (FEATURE_CARD_LEFT + FEATURE_CARD_WIDTH)
#define FEATURE_CARD_BOTTOM (FEATURE_CARD_TOP + FEATURE_CARD_HEIGHT)
// 卡片下方提示行的中心 y（长按中键返回入口）。
// Center y of the hint line under the card (hold the middle key to return).
#define FEATURE_HINT_CY 1060

// 游戏子页使用近全屏画布：入口页只画顶部标题和“长按中键返回”提示，不再画白卡、页眉分隔线
// 与底栏；棋盘和按钮全部落在下面这块区域里，比原来的 612×780 卡片大很多。
// Game sub-pages use a near-full-screen canvas: the hub keeps only the title and the middle-hold
// hint at the top, without the white card, header rule or bottom navigation. Boards and buttons
// live inside the region below, which is much larger than the old 612x780 card.
#define FEATURE_GAME_LEFT 12
#define FEATURE_GAME_TOP 92
#define FEATURE_GAME_WIDTH 660
#define FEATURE_GAME_HEIGHT 1084
#define FEATURE_GAME_RIGHT (FEATURE_GAME_LEFT + FEATURE_GAME_WIDTH)
#define FEATURE_GAME_BOTTOM (FEATURE_GAME_TOP + FEATURE_GAME_HEIGHT)
#define FEATURE_GAME_TITLE_Y 22
#define FEATURE_GAME_TITLE_PX 38

/// 游戏子页画布矩形（近全屏），绘制与命中测试共用。
/// Game-canvas rectangle (near full screen), shared by paint and hit-test.
EpdRect feature_game_rect(void);

/// 一个特色功能子页；入口页只调用这组回调。
/// One feature sub-page; the hub only calls this callback set.
typedef struct {
    /// 进页：恢复页内状态、启动必要的一次性动作（允许副作用）。
    /// Enter: restore page state and run one-shot side effects.
    void (*enter)(app_ctx_t *ctx);
    /// 离页：停掉页内动画/输入，不画屏。/ Leave: stop page animation/input, never paint.
    void (*exit)(app_ctx_t *ctx);
    /// 纯绘制：入口页已经清屏、画好页眉和底栏，这里只画内容卡片。
    /// Paint only: the hub already cleared the page and painted header/navigation; draw the card.
    void (*render)(uint8_t *fb, app_ctx_t *ctx);
    /// 内容区手势；返回 APP_REDRAW_PAGE 让入口页整页重绘，APP_REDRAW_AREA 走 area 局部刷。
    /// Content gesture; return APP_REDRAW_PAGE for a full repaint or APP_REDRAW_AREA with area().
    app_redraw_t (*gesture)(app_ctx_t *ctx, const ui_gesture_event_t *ev);
    /// 每轮主循环调用（约 5ms 一次），页面自己按时间节流，只在需要刷新时返回非 NONE。
    /// Called every loop tick (~5ms); throttle internally and only return non-NONE when needed.
    app_redraw_t (*tick)(app_ctx_t *ctx);
    /// APP_REDRAW_AREA 对应的局部刷新区域；不能返回空矩形。
    /// Region for APP_REDRAW_AREA; must not be an empty rectangle.
    EpdRect (*area)(app_ctx_t *ctx);
} feature_body_t;

/// 内容卡片矩形，绘制与命中测试共用。/ Content-card rectangle shared by paint and hit-test.
EpdRect feature_card_rect(void);
/// 画白色圆角卡片及其深色外框（入口页调用；子页通常不用再画）。
/// Paint the white rounded card and its dark frame (called by the hub; children usually skip it).
void feature_draw_card(uint8_t *fb);
/// 卡片下方的一行提示文字。/ One hint line under the card.
void feature_draw_hint(uint8_t *fb, const char *hint);
/// 卡片内的分区标题 + 细线，返回下一行的 y。
/// Section title plus hairline inside the card; returns the y of the next row.
int feature_draw_section(uint8_t *fb, int y, const char *title);
/// 卡片内圆角按钮；on 为主按钮（深底白字）。
/// Rounded button inside the card; on is the primary style (dark fill, light text).
void feature_draw_button(uint8_t *fb, EpdRect rect, const char *label, bool on);
/// 卡片内选择块（周几、预设分钟）；选中只加内圈，不整块反白以免残影。
/// Choice chip inside the card (weekday, preset minutes); selection thickens an inset ring
/// instead of inverting the whole block, which would ghost.
void feature_draw_choice(uint8_t *fb, EpdRect rect, const char *label, bool selected);

// 各子页实现；入口页按索引取用。/ Child implementations, indexed by the hub.
extern const feature_body_t feature_body_pomodoro;
extern const feature_body_t feature_body_alarm;
extern const feature_body_t feature_body_todo;
extern const feature_body_t feature_body_snake;
extern const feature_body_t feature_body_tetris;
extern const feature_body_t feature_body_2048;
extern const feature_body_t feature_body_gomoku;
