/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 * 中文：坚果云同步页（账号配置 / 目录浏览 / 下载 / 笔记本导出）。从设置页进入，不进主菜单。
 * English: Jianguoyun sync page (account, browsing, download, note export). Entered from Settings.
 */
#pragma once

#include "app.h"

/// 页面描述符；由 app_device_settings 通过 ctx->request_app 切进来。
/// Page descriptor; app_device_settings switches in through ctx->request_app.
extern const app_desc_t app_cloud;
/// 进入同步页；下一次设置页 tick 生效。/ Open the sync page; takes effect on the next settings tick.
void app_cloud_request_open(void);
/// 是否正在联网/传输，设置页据此禁止直接离开。/ Whether network work is running.
bool app_cloud_busy(void);
