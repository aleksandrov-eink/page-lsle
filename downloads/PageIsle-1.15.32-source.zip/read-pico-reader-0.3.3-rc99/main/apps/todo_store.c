/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：待办存 NVS（rp_todo/items），一个 blob 保存条数与文本，不占 TF 卡。
 * English: To-dos live in NVS (rp_todo/items) as one blob, no TF card dependency.
 */
#include "todo_store.h"

#include <string.h>

#include "esp_heap_caps.h"
#include "esp_log.h"
#include "nvs.h"

static const char *TAG = "todo_store";
#define TODO_NVS_NAMESPACE "rp_todo"
#define TODO_NVS_KEY "items"

typedef struct {
    uint32_t magic;
    uint16_t count;
    uint16_t reserved;
    todo_item_t items[TODO_MAX];
} todo_blob_t;
#define TODO_BLOB_MAGIC 0x54444f31u  // "TDO1"

int todo_load(todo_item_t *items, int max) {
    if (!items || max <= 0) return 0;
    nvs_handle_t h;
    if (nvs_open(TODO_NVS_NAMESPACE, NVS_READONLY, &h) != ESP_OK) return 0;
    size_t size = 0;
    int count = 0;
    if (nvs_get_blob(h, TODO_NVS_KEY, NULL, &size) == ESP_OK && size == sizeof(todo_blob_t)) {
        todo_blob_t *blob = NULL;
        nvs_close(h);
        // 用一次性 PSRAM 读整个 blob，避免占内部 RAM。
        blob = heap_caps_malloc(sizeof(todo_blob_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (!blob) return 0;
        if (nvs_open(TODO_NVS_NAMESPACE, NVS_READONLY, &h) == ESP_OK) {
            size = sizeof(todo_blob_t);
            if (nvs_get_blob(h, TODO_NVS_KEY, blob, &size) == ESP_OK &&
                blob->magic == TODO_BLOB_MAGIC && blob->count <= TODO_MAX) {
                count = blob->count < max ? blob->count : max;
                memcpy(items, blob->items, (size_t)count * sizeof(todo_item_t));
                for (int i = 0; i < count; ++i) items[i].text[TODO_TEXT_MAX - 1] = 0;
            }
            nvs_close(h);
        }
        heap_caps_free(blob);
        return count;
    }
    nvs_close(h);
    return 0;
}

bool todo_save(const todo_item_t *items, int count) {
    if (count < 0) count = 0;
    if (count > TODO_MAX) count = TODO_MAX;
    nvs_handle_t h;
    if (nvs_open(TODO_NVS_NAMESPACE, NVS_READWRITE, &h) != ESP_OK) return false;
    esp_err_t err;
    if (!count) {
        err = nvs_erase_key(h, TODO_NVS_KEY);
        if (err == ESP_ERR_NVS_NOT_FOUND) err = ESP_OK;
    } else {
        // 直接写一个栈上 blob（约 2.7 KB），NVS 写入后不再需要它。
        todo_blob_t blob;
        memset(&blob, 0, sizeof(blob));
        blob.magic = TODO_BLOB_MAGIC;
        blob.count = (uint16_t)count;
        memcpy(blob.items, items, (size_t)count * sizeof(todo_item_t));
        err = nvs_set_blob(h, TODO_NVS_KEY, &blob, sizeof(blob));
    }
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    if (err != ESP_OK) ESP_LOGW(TAG, "save failed: %s", esp_err_to_name(err));
    return err == ESP_OK;
}
