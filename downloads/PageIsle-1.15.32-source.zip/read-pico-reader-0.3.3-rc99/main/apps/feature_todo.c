/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：待办事项子页。卡片内分页列表：勾选完成、点行编辑、二次确认删除、新增与翻页；编辑
 *       复用系统手机式键盘，数据经 todo_store 与首页右下待办模块共用。
 * English: To-do child page. A paged card list with completion ticks, tap-to-edit,
 *          confirm-to-delete and add flow on the shared phone keyboard; entries persist
 *          through todo_store and are shared with the home panel.
 *
 * 冻结：render 只画像素；NVS 写入只在 enter / gesture / tick；关闭键盘必须 ui_keyboard_end()。
 * Frozen: paint-only render; NVS writes only in enter / gesture / tick; always release the
 *         keyboard through ui_keyboard_end().
 */
#include <stdio.h>
#include <string.h>

#include "feature_common.h"
#include "todo_store.h"
#include "ui_keyboard.h"
#include "ui_kit.h"
#include "ui_text_input.h"

// 卡片内布局；入口页已画好 (36,196,612,780) 的卡片，这里只排内部。
// Interior layout only; the hub already painted the 612x780 card at (36,196).
enum {
    TODO_ROW_MAX = 6, TODO_ROW_TOP = 280, TODO_ROW_PITCH = 88, TODO_ROW_H = 80,
    TODO_ROW_X = 64, TODO_ROW_W = 556, TODO_BOX = 56,
    TODO_TEXT_X = 136, TODO_TEXT_W = 338,
    TODO_DEL_X = 486, TODO_DEL_W = 130, TODO_DEL_H = 48,
    TODO_BTN_Y = 860, TODO_BTN_H = 78, TODO_FIELD_PX = 29,
};
#define TODO_NO_CONFIRM 0xFF

typedef enum { TODO_VIEW_LIST = 0, TODO_VIEW_EDIT } todo_view_t;

static todo_item_t s_items[TODO_MAX];
static int s_count;
static int s_page;
static int s_edit_index;  // 编辑中的条目下标，-1 表示新增 / Entry under edit, -1 for a new one
static uint8_t s_confirm; // 等待确认删除的条目下标 / Entry awaiting delete confirmation
static todo_view_t s_view;
static char s_text[TODO_TEXT_MAX];
static ui_text_edit_t s_edit;
static char s_notice[40];
static EpdRect s_area;

/* ---- 几何 / Geometry ---- */

static EpdRect row_rect(int row) {
    return (EpdRect){TODO_ROW_X, TODO_ROW_TOP + row * TODO_ROW_PITCH, TODO_ROW_W, TODO_ROW_H};
}
static EpdRect check_rect(int row) {
    EpdRect r = row_rect(row);
    return (EpdRect){r.x, r.y + (TODO_ROW_H - TODO_BOX) / 2, TODO_BOX, TODO_BOX};
}
static EpdRect del_rect(int row) {
    EpdRect r = row_rect(row);
    return (EpdRect){TODO_DEL_X, r.y + (TODO_ROW_H - TODO_DEL_H) / 2, TODO_DEL_W, TODO_DEL_H};
}
#define RECT_ADD ((EpdRect){64, TODO_BTN_Y, 200, TODO_BTN_H})
#define RECT_PREV ((EpdRect){284, TODO_BTN_Y, 132, TODO_BTN_H})
#define RECT_NEXT ((EpdRect){470, TODO_BTN_Y, 150, TODO_BTN_H})
#define RECT_FIELD ((EpdRect){64, 230, 556, 84})
#define RECT_CANCEL ((EpdRect){64, 460, 240, 70})
#define RECT_SAVE ((EpdRect){380, 460, 240, 70})

/* ---- 文字与状态 / Text and state ---- */

// 截到 max_w 并补省略号，不切断 UTF-8 字符。/ Trim to max_w at UTF-8 bounds, then append an ellipsis.
static void fit_text(char *out, size_t cap, const char *src, int px, int max_w) {
    if (!out || !cap) return;
    snprintf(out, cap, "%s", src ? src : "");
    if (ui_text_fixed_width_px(px, out) <= max_w) return;
    int tail = ui_text_fixed_width_px(px, "…");
    size_t n = strlen(out);
    while (n) {
        do { --n; } while (n && ((unsigned char)out[n] & 0xc0) == 0x80);
        out[n] = 0;
        if (ui_text_fixed_width_px(px, out) + tail <= max_w) break;
    }
    size_t used = strlen(out);
    if (used + 4 <= cap) snprintf(out + used, cap - used, "…");
}

// 清空目标后按 UTF-8 边界截断复制。/ Clear the target, then copy within a UTF-8 boundary.
static void copy_text(char *dst, size_t cap, const char *src) {
    if (!dst || !cap) return;
    memset(dst, 0, cap);
    size_t n = strlen(src);
    if (n >= cap) {
        n = cap - 1;
        while (n && ((unsigned char)src[n] & 0xc0) == 0x80) --n;
    }
    memcpy(dst, src, n);
}

static int page_count(void) {
    int pages = (s_count + TODO_ROW_MAX - 1) / TODO_ROW_MAX;
    return pages > 0 ? pages : 1;
}

static bool turn_page(int delta) {
    int target = s_page + delta;
    if (target < 0 || target >= page_count()) return false;
    s_page = target;
    s_confirm = TODO_NO_CONFIRM;
    s_notice[0] = 0;
    return true;
}

static void edit_begin(int index) {
    s_edit_index = index;
    copy_text(s_text, sizeof(s_text), index >= 0 && index < s_count ? s_items[index].text : "");
    ui_text_edit_init(&s_edit, s_text, sizeof(s_text));
    ui_keyboard_begin(&s_edit, false);
    s_confirm = TODO_NO_CONFIRM;
    s_notice[0] = 0;
    s_view = TODO_VIEW_EDIT;
}

static void edit_close(void) {
    ui_keyboard_end();
    s_edit_index = -1;
    s_view = TODO_VIEW_LIST;
}

static void toggle_done(int index) {
    s_items[index].done = s_items[index].done ? 0 : 1;
    s_confirm = TODO_NO_CONFIRM;
    s_notice[0] = 0;
    if (!todo_save(s_items, s_count)) snprintf(s_notice, sizeof(s_notice), "保存失败，请重试");
}

static void delete_item(int index) {
    for (int i = index; i + 1 < s_count; ++i) s_items[i] = s_items[i + 1];
    --s_count;
    memset(&s_items[s_count], 0, sizeof(s_items[s_count]));
    s_confirm = TODO_NO_CONFIRM;
    if (s_page >= page_count()) --s_page;
    snprintf(s_notice, sizeof(s_notice), todo_save(s_items, s_count) ? "已删除" : "删除后保存失败，请重试");
}

// 保存编辑内容：空文本忽略，新增追加到末尾，已满 32 条时提示。
// Commit: ignore empty text, append new entries, warn when all 32 slots are used.
static app_redraw_t save_edit(void) {
    if (ui_keyboard_pending()) {
        snprintf(s_notice, sizeof(s_notice), "请先选择候选字");
        return APP_REDRAW_PAGE;
    }
    char *start = s_text;
    while (*start == ' ') ++start;
    if (start != s_text) memmove(s_text, start, strlen(start) + 1);
    size_t len = strlen(s_text);
    while (len && s_text[len - 1] == ' ') s_text[--len] = 0;
    bool added = s_edit_index < 0;
    if (!len) {
        snprintf(s_notice, sizeof(s_notice), "内容为空，未保存");
    } else if (added && s_count >= TODO_MAX) {
        snprintf(s_notice, sizeof(s_notice), "最多 32 条，删除一条再新增");
    } else {
        todo_item_t *item = added ? &s_items[s_count] : &s_items[s_edit_index];
        if (added) memset(item, 0, sizeof(*item));
        copy_text(item->text, TODO_TEXT_MAX, s_text);
        if (added) {
            ++s_count;
            s_page = (s_count - 1) / TODO_ROW_MAX;
        }
        snprintf(s_notice, sizeof(s_notice), todo_save(s_items, s_count) ? "已保存" : "保存失败，请重试");
    }
    edit_close();
    return APP_REDRAW_PAGE;
}

/* ---- 绘制 / Painting ---- */

// 勾选框：选中深底白勾，斜线偏移画粗，不依赖额外图标资源。
// Checkbox: dark fill with an offset white check, without extra icon assets.
static void draw_check(uint8_t *fb, EpdRect box, bool done) {
    ui_fill_round_rect(fb, box, 12, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, box, 12, 0x60);
    if (!done) return;
    ui_fill_round_rect(fb, ui_inset_rect(box, 9), 7, 0x20);
    int x = box.x, y = box.y;
    for (int i = 0; i < 3; ++i) {
        epd_draw_line(x + 15 + i, y + 29, x + 24 + i, y + 38, UI_GRAY_WHITE, fb);
        epd_draw_line(x + 24 + i, y + 38, x + 41 + i, y + 19, UI_GRAY_WHITE, fb);
    }
}

static void draw_delete(uint8_t *fb, EpdRect rect, bool confirm) {
    ui_fill_round_rect(fb, rect, 12, confirm ? 0x20 : 0xf0);
    ui_draw_control_frame(fb, rect, 12, confirm ? 0x20 : 0x88);
    ui_text_fixed_vc(fb, rect.x + rect.width / 2, rect.y + rect.height / 2, confirm ? 22 : 24,
                     confirm ? "确认删除" : "删除", EPD_DRAW_ALIGN_CENTER, confirm);
}

static void draw_small_button(uint8_t *fb, EpdRect rect, const char *label, bool enabled) {
    ui_fill_round_rect(fb, rect, 14, 0xf0);
    ui_draw_control_frame(fb, rect, 14, enabled ? 0x88 : 0xb0);
    ui_text_fixed_ink_vc(fb, rect.x + rect.width / 2, rect.y + rect.height / 2, 24, label,
                         EPD_DRAW_ALIGN_CENTER, enabled ? 0x00 : 0xa0);
}

static void draw_row(uint8_t *fb, int row, int index) {
    EpdRect r = row_rect(row);
    if (row > 0) ui_hairline(fb, r.y - 8, TODO_ROW_X, TODO_ROW_W, UI_GRAY_LIGHT);
    draw_check(fb, check_rect(row), s_items[index].done != 0);
    char shown[TODO_TEXT_MAX + 8];
    fit_text(shown, sizeof(shown), s_items[index].text, 26, TODO_TEXT_W);
    int cy = r.y + r.height / 2;
    if (s_items[index].done) {
        ui_text_fixed_ink_vc(fb, TODO_TEXT_X, cy, 26, shown, EPD_DRAW_ALIGN_LEFT, 0x60);
        int width = ui_text_fixed_width_px(26, shown);
        if (width > 0) ui_fill_rect_fast((EpdRect){TODO_TEXT_X, cy, width, 2}, 0x60, fb);
    } else {
        ui_text_fixed_vc(fb, TODO_TEXT_X, cy, 26, shown, EPD_DRAW_ALIGN_LEFT, false);
    }
    draw_delete(fb, del_rect(row), s_confirm == (uint8_t)index);
}

static void draw_list(uint8_t *fb) {
    int done = 0;
    for (int i = 0; i < s_count; ++i) if (s_items[i].done) ++done;
    char summary[48];
    snprintf(summary, sizeof(summary), "共 %d 条 · 完成 %d 条", s_count, done);
    ui_text_fixed_vc(fb, TODO_ROW_X, 224, 22, summary, EPD_DRAW_ALIGN_LEFT, false);
    if (s_notice[0]) ui_text_fixed_vc(fb, 620, 224, 20, s_notice, EPD_DRAW_ALIGN_RIGHT, false);
    if (!s_count) {
        ui_text_fixed_vc(fb, FEATURE_CARD_LEFT + FEATURE_CARD_WIDTH / 2, 528, 26,
                         "还没有待办，点「新增」添加", EPD_DRAW_ALIGN_CENTER, false);
    }
    for (int row = 0; row < TODO_ROW_MAX; ++row) {
        int index = s_page * TODO_ROW_MAX + row;
        if (index >= s_count) break;
        draw_row(fb, row, index);
    }
    feature_draw_button(fb, RECT_ADD, "新增", true);
    int pages = page_count();
    bool can_prev = s_page > 0, can_next = s_page + 1 < pages;
    draw_small_button(fb, RECT_PREV, "上一页", can_prev);
    draw_small_button(fb, RECT_NEXT, "下一页", can_next);
    // 缓冲区按 int 的最坏宽度留足，避免 -Werror=format-truncation（页数实际很小）。
    // Size the buffer for the worst-case int width; real page counts are tiny.
    char indicator[32];
    snprintf(indicator, sizeof(indicator), "%d/%d", s_page + 1, pages);
    ui_text_fixed_ink_vc(fb, 443, TODO_BTN_Y + TODO_BTN_H / 2, 22, indicator,
                         EPD_DRAW_ALIGN_CENTER, can_prev || can_next ? 0x00 : 0xa0);
}

static void draw_edit(uint8_t *fb) {
    ui_text_fixed_vc(fb, 64, 210, 22, "待办内容", EPD_DRAW_ALIGN_LEFT, false);
    ui_text_fixed_ink_vc(fb, 620, 210, 20, s_edit_index < 0 ? "新增" : "编辑",
                         EPD_DRAW_ALIGN_RIGHT, 0x40);
    ui_text_input_draw(fb, &s_edit, RECT_FIELD, TODO_FIELD_PX, false, NULL);
    if (s_notice[0]) {
        ui_text_fixed_vc(fb, 64, 356, 20, s_notice, EPD_DRAW_ALIGN_LEFT, false);
    } else {
        ui_text_fixed_ink_vc(fb, 64, 356, 20, "输入内容后点「保存」", EPD_DRAW_ALIGN_LEFT, 0x40);
    }
    feature_draw_button(fb, RECT_CANCEL, "取消", false);
    feature_draw_button(fb, RECT_SAVE, "保存", true);
    ui_keyboard_draw(fb, UI_SYSTEM_KEYBOARD_TOP);
}

/* ---- 键盘局部刷新 / Keyboard local updates ---- */

// 事件里只重绘键盘变化区；布局切换与词栏定稿需要灰阶，改走整页重绘。
// Repaint changed keyboard regions only; layout/settle need grayscale, so repaint the page.
static app_redraw_t keyboard_paint(app_ctx_t *ctx, bool force_field) {
    ui_keyboard_update_t update = ui_keyboard_update(ctx->fb, UI_SYSTEM_KEYBOARD_TOP,
        RECT_FIELD, TODO_FIELD_PX, false, NULL, force_field);
    s_area = update.area;
    if (update.layout || update.settle) return APP_REDRAW_PAGE;
    return update.area.width ? APP_REDRAW_AREA : APP_REDRAW_NONE;
}

/* ---- 回调 / Callbacks ---- */

static void todo_enter(app_ctx_t *ctx) {
    (void)ctx;
    s_count = todo_load(s_items, TODO_MAX);
    s_page = 0;
    s_edit_index = -1;
    s_confirm = TODO_NO_CONFIRM;
    s_notice[0] = 0;
    s_view = TODO_VIEW_LIST;
}

static void todo_exit(app_ctx_t *ctx) {
    (void)ctx;
    ui_keyboard_end();
    s_edit_index = -1;
    s_view = TODO_VIEW_LIST;
}

static app_redraw_t edit_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type == UI_GESTURE_PRESS) {
        return ui_keyboard_press(ev->x0, ev->y0, UI_SYSTEM_KEYBOARD_TOP, ctx->now_ms)
            ? keyboard_paint(ctx, false) : APP_REDRAW_NONE;
    }
    bool feedback = ev->type != UI_GESTURE_LONG_PRESS && ui_keyboard_release();
    if (ev->type != UI_GESTURE_TAP) return feedback ? keyboard_paint(ctx, false) : APP_REDRAW_NONE;
    int x = ev->x0, y = ev->y0;
    if (ui_rect_hit(RECT_CANCEL, x, y)) {
        edit_close();
        s_notice[0] = 0;
        return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(RECT_SAVE, x, y)) return save_edit();
    if (ui_text_input_tap(&s_edit, RECT_FIELD, TODO_FIELD_PX, false, NULL, x, y))
        return keyboard_paint(ctx, true);
    ui_keyboard_result_t result = ui_keyboard_tap(x, y, UI_SYSTEM_KEYBOARD_TOP, ctx->now_ms);
    if (result == UI_KEYBOARD_DONE) return save_edit();
    if (result == UI_KEYBOARD_CHANGED) return keyboard_paint(ctx, false);
    return APP_REDRAW_NONE;
}

static app_redraw_t list_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    (void)ctx;
    if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
    int x = ev->x0, y = ev->y0;
    if (ui_rect_hit(RECT_ADD, x, y)) {
        if (s_count >= TODO_MAX) {
            snprintf(s_notice, sizeof(s_notice), "最多 32 条，删除一条再新增");
            return APP_REDRAW_PAGE;
        }
        edit_begin(-1);
        return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(RECT_PREV, x, y)) return turn_page(-1) ? APP_REDRAW_PAGE : APP_REDRAW_NONE;
    if (ui_rect_hit(RECT_NEXT, x, y)) return turn_page(1) ? APP_REDRAW_PAGE : APP_REDRAW_NONE;
    for (int row = 0; row < TODO_ROW_MAX; ++row) {
        int index = s_page * TODO_ROW_MAX + row;
        if (index >= s_count) break;
        EpdRect r = row_rect(row);
        if (!ui_rect_hit(r, x, y)) continue;
        if (ui_rect_hit(check_rect(row), x, y)) {
            toggle_done(index);
            return APP_REDRAW_PAGE;
        }
        if (ui_rect_hit(del_rect(row), x, y)) {
            if (s_confirm == (uint8_t)index) delete_item(index);
            else { s_confirm = (uint8_t)index; s_notice[0] = 0; }
            return APP_REDRAW_PAGE;
        }
        edit_begin(index);
        return APP_REDRAW_PAGE;
    }
    if (s_confirm != TODO_NO_CONFIRM) {
        s_confirm = TODO_NO_CONFIRM;
        return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}

static app_redraw_t todo_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    return s_view == TODO_VIEW_EDIT ? edit_gesture(ctx, ev) : list_gesture(ctx, ev);
}

// 本页不按时间自驱，编辑反馈全部来自手势事件。/ No time-driven work; feedback comes from gestures.
static app_redraw_t todo_tick(app_ctx_t *ctx) {
    (void)ctx;
    return APP_REDRAW_NONE;
}

static void todo_render(uint8_t *fb, app_ctx_t *ctx) {
    (void)ctx;
    if (s_view == TODO_VIEW_EDIT) draw_edit(fb);
    else draw_list(fb);
}

static EpdRect todo_area(app_ctx_t *ctx) {
    (void)ctx;
    return s_area.width ? s_area : RECT_FIELD;
}

const feature_body_t feature_body_todo = {
    .enter = todo_enter,
    .exit = todo_exit,
    .render = todo_render,
    .gesture = todo_gesture,
    .tick = todo_tick,
    .area = todo_area,
};
