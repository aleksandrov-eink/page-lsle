/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：定时任务服务：番茄倒计时与周闹钟共用墙钟、NVS 和 PMU RTC 闹钟。到点只置「待提醒」
 *       标记，蜂鸣与画面交给提醒页；锁屏和深睡前由 sleep.c 查询最近截止时间并设置唤醒。
 * English: Timer service: Pomodoro countdown and weekly alarm share the wall clock, NVS and the
 *          PMU RTC alarm. Firing only raises a pending-reminder flag; the reminder page owns the
 *          buzzer and the screen. sleep.c asks for the nearest deadline before light/deep sleep.
 *
 * 冻结：本服务不画屏、不蜂鸣；所有到点提醒必须经提醒页消费。
 * Frozen: this service never paints or beeps; every fired reminder is consumed by the page.
 */
#pragma once

#include <stdbool.h>
#include <stdint.h>

/// 到点提醒的种类；提醒页据此选择文案与图标。
/// Kind of fired reminder; the reminder page picks copy and icon from it.
typedef enum {
    TIMER_REMINDER_NONE = 0, ///< 无 / None
    TIMER_REMINDER_POMODORO, ///< 番茄到点 / Pomodoro finished
    TIMER_REMINDER_ALARM,    ///< 闹钟到点 / Alarm fired
} timer_reminder_t;

/// 番茄时钟状态。/ Pomodoro state.
typedef enum {
    POMODORO_IDLE = 0, ///< 未开始 / Not started
    POMODORO_RUNNING,  ///< 计时中 / Counting down
    POMODORO_PAUSED,   ///< 暂停 / Paused
} pomodoro_state_t;

#define ALARM_WEEKDAY_COUNT 7
// 周掩码：bit0=周一 … bit6=周日。全 0 视为无效，界面上至少选一天。
// Weekday mask: bit0=Monday … bit6=Sunday. Zero is invalid; the UI keeps at least one day.
#define ALARM_WEEKDAY_ALL 0x7F

/// 周闹钟：周几 + 时/分（北京时间），启用开关。
/// Weekly alarm: weekdays plus hour/minute in China local time.
typedef struct {
    bool enabled;
    uint8_t weekdays;
    uint8_t hour;
    uint8_t minute;
} alarm_schedule_t;

/// 开机装配完成后调用一次：读 NVS、处理睡眠期间到点的任务、重设 PMU 闹钟。
/// Call once after boot wiring: load NVS, settle reminders that fired while asleep, rearm the PMU.
void timer_service_init(void);
/// 主循环与锁屏浅睡每轮调用；内部按秒节流，只做墙钟比较和 PMU 闹钟重设。
/// Called every loop tick and every lock light-sleep round; internally throttled to one second
/// and limited to wall-clock comparison plus PMU alarm rearm.
void timer_service_poll(void);
/// 到点提醒是否待显示。/ Whether a fired reminder is waiting to be shown.
bool timer_service_reminder_pending(void);
/// 待显示提醒的种类（无提醒时返回 TIMER_REMINDER_NONE）。
/// Kind of the pending reminder (NONE when nothing waits).
timer_reminder_t timer_service_reminder_kind(void);
/// 提醒页关闭时消费掉当前提醒，随后允许下一个任务到点。
/// Consume the current reminder when the page closes, allowing the next task to fire.
void timer_service_reminder_consume(void);
/// 提醒页标题，只读静态文案。/ Reminder title, read-only static copy.
const char *timer_service_reminder_title(void);
/// 提醒页详情，只读静态文案。/ Reminder detail, read-only static copy.
const char *timer_service_reminder_detail(void);
/// 距最近定时任务到点的毫秒数；没有任何任务返回 0。
/// Milliseconds until the nearest timer task; 0 when no task exists.
uint32_t timer_service_deadline_ms(void);
/// 系统时间是否已经校时；未校时无法开始番茄/计算闹钟。
/// Whether the wall clock is calibrated; Pomodoro cannot start and the alarm cannot be computed
/// until it is.
bool timer_service_clock_ready(void);
/// 把最近的定时任务写进 PMU RTC 闹钟（没有任务则关闭），深睡前调用。
/// Program the nearest task into the PMU RTC alarm (off when idle); call before deep sleep.
void timer_service_arm_pmu_alarm(void);
/// 关闭 PMU RTC 闹钟；用户主动关机/关机流程中调用，避免到点自行开机。
/// Disable the PMU RTC alarm; used when the user powers off so it cannot boot itself later.
void timer_service_pmu_alarm_off(void);

// ---- 番茄时钟 / Pomodoro ----
/// 设置本轮专注分钟数（1..180），立即复位并保存；运行中调用等同重置。
/// Set this round's focus minutes (1..180), reset and persist immediately.
void pomodoro_set_minutes(uint32_t minutes);
/// 当前设定的分钟数。/ Current configured minutes.
uint32_t pomodoro_minutes(void);
/// 开始或继续计时；已到 0 时先复位再开始。/ Start or resume; resets first when already at zero.
void pomodoro_start(void);
/// 暂停计时并保存剩余秒数。/ Pause and persist the remaining seconds.
void pomodoro_pause(void);
/// 复位到设定时长并停止计时（已用时长丢弃）。/ Reset to the configured duration and stop.
void pomodoro_reset(void);
pomodoro_state_t pomodoro_state(void);
/// 剩余秒数；空闲时返回设定时长。/ Remaining seconds; the configured duration when idle.
uint32_t pomodoro_remaining_sec(void);

// ---- 周闹钟 / Weekly alarm ----
/// 当前闹钟设置（只读）。/ Current alarm schedule (read-only).
const alarm_schedule_t *alarm_schedule(void);
/// 保存并立即重算下次响铃、重设 PMU 闹钟；周三掩码为 0 时返回 false。
/// Persist, recompute the next ring and rearm the PMU; false when the weekday mask is zero.
bool alarm_schedule_set(const alarm_schedule_t *schedule);
/// 下次响铃的本地星期（0=周一…6=周日）、时、分与剩余秒数；未启用返回 false。
/// Next ring in local weekday (0=Monday…6=Sunday), hour, minute and seconds left; false when off.
bool alarm_next(int *weekday, int *hour, int *minute, uint32_t *in_sec);
