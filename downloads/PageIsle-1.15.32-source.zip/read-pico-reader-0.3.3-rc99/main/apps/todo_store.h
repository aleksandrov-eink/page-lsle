/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：待办事项持久化（NVS 一个 blob，最多 32 条）。首页右下模块和特色功能页共用。
 * English: To-do persistence (one NVS blob, up to 32 entries) shared by the home panel and
 *          the feature page.
 */
#pragma once

#include <stdbool.h>
#include <stdint.h>

#define TODO_MAX 32
#define TODO_TEXT_MAX 80

typedef struct {
    char text[TODO_TEXT_MAX];
    uint8_t done;
} todo_item_t;

/// 读取待办；返回条数（0..max），无记录时返回 0。
/// Load to-dos; returns the number copied (0..max), 0 when nothing is stored.
int todo_load(todo_item_t *items, int max);
/// 保存前 count 条；count 为 0 时清除记录。
/// Save the first count entries; count 0 clears the store.
bool todo_save(const todo_item_t *items, int count);
