/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：特色功能「闹钟」子页：编辑每周重复的周几、时和分，切换启用开关，再把整份设置交给
 *       timer_service 保存。页面只负责编辑与保存；到点提醒、锁屏唤醒和蜂鸣都由定时服务
 *       与提醒页处理，本页不参与。
 * English: Feature "alarm" sub-page: edit the weekly repeat days, hour and minute, toggle the
 *          enable switch, then hand the whole schedule to timer_service. This page only edits and
 *          saves; firing, sleep wake-up and the buzzer belong to the timer service and the
 *          reminder page, not here.
 *
 * 冻结：render 只画像素；NVS 写入只来自用户点「保存」；本页不切页、不蜂鸣、不碰睡眠。
 * Frozen: render paints pixels only; NVS writes come only from an explicit Save tap; this page
 *         never switches pages, drives the buzzer or touches sleep.
 */

#include <stdio.h>

#include "feature_common.h"
#include "timer_service.h"
#include "ui_kit.h"

/* ---- 布局：内容卡片内的固定坐标 / Layout: fixed coordinates inside the content card ---- */
// 卡片由入口页画好，本页只占 Card(36,196,612,780) 内部；四周留 28px 避开圆角。
// The hub paints the card; this page only fills Card(36,196,612,780) and keeps a 28 px inset so
// controls never run into the rounded corners.
#define ALARM_PAD 28
#define ALARM_LEFT (FEATURE_CARD_LEFT + ALARM_PAD)
#define ALARM_RIGHT (FEATURE_CARD_RIGHT - ALARM_PAD)
#define ALARM_CENTER_X (FEATURE_CARD_LEFT + FEATURE_CARD_WIDTH / 2)

// 「重复」分区标题、周几 chip 行：7 个 74x64 chip，间距 6，整行宽 554 落在 556 内。
// "Repeat" section header and the weekday chip row: seven 74x64 chips with 6 px gaps sit in 554 px.
#define ALARM_SECTION_Y 226
#define ALARM_CHIP_Y 300
#define ALARM_CHIP_W 74
#define ALARM_CHIP_H 64
#define ALARM_CHIP_GAP 6

// 时间行：大时间居中，左右各一组 76x76 加减按钮，上方 24px 小字标明调的是时还是分。
// Time row: the big time is centered, with a 76x76 step pair on each side and a 24 px unit label.
#define ALARM_UNIT_CY 412
#define ALARM_TIME_CY 520
#define ALARM_STEP_W 76
#define ALARM_STEP_H 76
#define ALARM_STEP_UP_Y 436
#define ALARM_STEP_DOWN_Y 528

// 分钟细调：时间行下方居中放两个 140x60 的小按钮。
// Minute fine tuning: two 140x60 buttons centered under the time row.
#define ALARM_FINE_Y 640
#define ALARM_FINE_W 140
#define ALARM_FINE_H 60
#define ALARM_FINE_GAP 24
#define ALARM_FINE_LEFT (ALARM_CENTER_X - ALARM_FINE_W - ALARM_FINE_GAP / 2)
#define ALARM_FINE_RIGHT (ALARM_FINE_LEFT + ALARM_FINE_W + ALARM_FINE_GAP)

// 状态提示、启用开关与保存按钮、底部下次响铃预览。
// Status notice, enable switch plus Save button, and the next-ring preview at the bottom.
#define ALARM_STATUS_CY 752
#define ALARM_ACTION_Y 800
#define ALARM_ACTION_W 260
#define ALARM_ACTION_H 84
#define ALARM_PREVIEW_CY 922

/* ---- 页内状态 / Page state ---- */
// 保存后的提示只在本页停留，用户在进页或下一次编辑时清掉。
// The save notice is page-local and is cleared on enter or on the next edit.
typedef enum {
    ALARM_NOTICE_NONE = 0, ///< 无提示 / No notice
    ALARM_NOTICE_SAVED,    ///< 保存成功 / Saved successfully
    ALARM_NOTICE_FAILED,   ///< 保存失败 / Save failed
    ALARM_NOTICE_NEED_DAY, ///< 未选周几 / No weekday selected
} alarm_notice_t;

// 命中编号：0..6 留给周几 chip，固定控件从 ALARM_WEEKDAY_COUNT 往后排。
// Hit ids: 0..6 are the weekday chips; fixed controls start at ALARM_WEEKDAY_COUNT.
enum {
    ALARM_HIT_NONE = -1,                              ///< 未命中 / No hit
    ALARM_HIT_HOUR_MINUS = ALARM_WEEKDAY_COUNT,       ///< 时 - / Hour minus
    ALARM_HIT_HOUR_PLUS,                              ///< 时 + / Hour plus
    ALARM_HIT_MINUTE_MINUS,                           ///< 分 -5 / Minute minus five
    ALARM_HIT_MINUTE_PLUS,                            ///< 分 +5 / Minute plus five
    ALARM_HIT_FINE_MINUS,                             ///< 分 -1 / Minute minus one
    ALARM_HIT_FINE_PLUS,                              ///< 分 +1 / Minute plus one
    ALARM_HIT_ENABLE,                                 ///< 启用开关 / Enable switch
    ALARM_HIT_SAVE,                                   ///< 保存 / Save
};

// 周几 chip 的单字与预览里的「周一…周日」，编号 0=周一 … 6=周日，和 alarm_next() 一致。
// Single-character chip labels and preview names, 0 = Monday … 6 = Sunday, matching alarm_next().
static const char *const s_weekday_chip[ALARM_WEEKDAY_COUNT] = {
    "一", "二", "三", "四", "五", "六", "日",
};
static const char *const s_weekday_name[ALARM_WEEKDAY_COUNT] = {
    "周一", "周二", "周三", "周四", "周五", "周六", "周日",
};

// 服务拿不到已存设置时的安全默认：全周 07:30、默认关闭，用户必须自己打开并保存。
// Safe default when the service has no stored schedule: all days at 07:30 but disabled, so only
// an explicit user action turns the alarm on.
static const alarm_schedule_t s_fallback_schedule = {
    .enabled = false,
    .weekdays = ALARM_WEEKDAY_ALL,
    .hour = 7,
    .minute = 30,
};

// 页内编辑副本：进页从 NVS 覆盖，保存失败也不回滚，保证用户输入不丢。
// In-page edit copy: overwritten from NVS on enter and never rolled back on a failed save, so the
// user's input survives.
static alarm_schedule_t s_edit;
static bool s_dirty;   // 编辑副本和已存设置不一致 / Edit copy differs from the stored schedule
static alarm_notice_t s_notice;

// 下次响铃快照：只在进页和保存成功时取，tick 不做走秒重绘。
// Next-ring snapshot, taken only on enter and after a successful save; tick does not repaint
// every second.
static bool s_next_valid;
static int s_next_weekday;
static int s_next_hour;
static int s_next_minute;
static uint32_t s_next_in_sec;

/* ---- 矩形与命中 / Rectangles and hit-testing ---- */
// 周几 chip：绘制和命中共用同一份固定矩形。
// Weekday chips: paint and hit-test share the same fixed rectangles.
static EpdRect alarm_chip_rect(int index) {
    return (EpdRect){ALARM_LEFT + index * (ALARM_CHIP_W + ALARM_CHIP_GAP), ALARM_CHIP_Y,
                     ALARM_CHIP_W, ALARM_CHIP_H};
}

// 时间两侧的加减按钮：minute_group 选右侧分针组，plus 选下面那个「+」。
// Step buttons beside the time: minute_group picks the right minute pair, plus picks the lower "+".
static EpdRect alarm_step_rect(bool minute_group, bool plus) {
    const int x = minute_group ? (ALARM_RIGHT - ALARM_STEP_W) : ALARM_LEFT;
    const int y = plus ? ALARM_STEP_DOWN_Y : ALARM_STEP_UP_Y;
    return (EpdRect){x, y, ALARM_STEP_W, ALARM_STEP_H};
}

// 分钟细调按钮：minus 为「-1 分」，否则为「+1 分」。
// Fine-minute buttons: minus is "-1 min", otherwise "+1 min".
static EpdRect alarm_fine_rect(bool plus) {
    const int x = plus ? ALARM_FINE_RIGHT : ALARM_FINE_LEFT;
    return (EpdRect){x, ALARM_FINE_Y, ALARM_FINE_W, ALARM_FINE_H};
}

// 底部并排的启用开关与保存按钮：save 选右侧主按钮。
// The enable switch and Save button in a row: save picks the right-hand primary button.
static EpdRect alarm_action_rect(bool save) {
    const int x = save ? (ALARM_RIGHT - ALARM_ACTION_W) : ALARM_LEFT;
    return (EpdRect){x, ALARM_ACTION_Y, ALARM_ACTION_W, ALARM_ACTION_H};
}

// 只认 TAP 的固定控件表；所有矩形都落在卡片内，页眉、提示行和底栏不参与。
// A fixed-control table answered on TAP only; every rectangle lives inside the card, so the
// header, hint line and navigation bar are never involved.
static int alarm_hit_test(uint16_t x, uint16_t y) {
    for (int i = 0; i < ALARM_WEEKDAY_COUNT; ++i) {
        if (ui_rect_hit(alarm_chip_rect(i), x, y)) return i;
    }
    if (ui_rect_hit(alarm_step_rect(false, false), x, y)) return ALARM_HIT_HOUR_MINUS;
    if (ui_rect_hit(alarm_step_rect(false, true), x, y)) return ALARM_HIT_HOUR_PLUS;
    if (ui_rect_hit(alarm_step_rect(true, false), x, y)) return ALARM_HIT_MINUTE_MINUS;
    if (ui_rect_hit(alarm_step_rect(true, true), x, y)) return ALARM_HIT_MINUTE_PLUS;
    if (ui_rect_hit(alarm_fine_rect(false), x, y)) return ALARM_HIT_FINE_MINUS;
    if (ui_rect_hit(alarm_fine_rect(true), x, y)) return ALARM_HIT_FINE_PLUS;
    if (ui_rect_hit(alarm_action_rect(false), x, y)) return ALARM_HIT_ENABLE;
    if (ui_rect_hit(alarm_action_rect(true), x, y)) return ALARM_HIT_SAVE;
    return ALARM_HIT_NONE;
}

/* ---- 预览文案 / Preview copy ---- */
// 把「下次响铃」快照格式化成一行；没有有效快照时按开关和勾选情况给出原因。
// Format the next-ring snapshot into one line; when it is invalid, explain why using the switch
// and the weekday mask.
static void alarm_format_preview(char *buf, size_t size) {
    if (!s_next_valid || s_next_weekday < 0 || s_next_weekday >= ALARM_WEEKDAY_COUNT) {
        if (!s_edit.enabled) {
            snprintf(buf, size, "未启用 / 打开开关后生效");
        } else if (s_edit.weekdays == 0) {
            snprintf(buf, size, "未启用 / 至少选择一天");
        } else {
            snprintf(buf, size, "暂无下次响铃");
        }
        return;
    }
    const char *name = s_weekday_name[s_next_weekday];
    const uint32_t sec = s_next_in_sec;
    const int days = (int)(sec / 86400u);
    const int hours = (int)((sec % 86400u) / 3600u);
    const int minutes = (int)((sec % 3600u) / 60u);
    if (days > 0) {
        snprintf(buf, size, "下次：%.12s %02d:%02d（还有 %d 天 %d 小时）",
                 name, s_next_hour, s_next_minute, days, hours);
    } else if (hours > 0) {
        snprintf(buf, size, "下次：%.12s %02d:%02d（还有 %d 小时 %d 分钟）",
                 name, s_next_hour, s_next_minute, hours, minutes);
    } else if (minutes > 0) {
        snprintf(buf, size, "下次：%.12s %02d:%02d（还有 %d 分钟）",
                 name, s_next_hour, s_next_minute, minutes);
    } else {
        snprintf(buf, size, "下次：%.12s %02d:%02d（不到 1 分钟）",
                 name, s_next_hour, s_next_minute);
    }
}

// 中部状态行：保存结果优先，其次提醒有未保存修改；没有要说的就不画。
// Middle status line: save result first, then the unsaved-changes hint; draw nothing otherwise.
static const char *alarm_notice_text(void) {
    switch (s_notice) {
        case ALARM_NOTICE_SAVED:
            return "已保存";
        case ALARM_NOTICE_FAILED:
            return "保存失败，已保留原设置";
        case ALARM_NOTICE_NEED_DAY:
            return "请至少选择一天";
        case ALARM_NOTICE_NONE:
        default:
            break;
    }
    return s_dirty ? "有未保存的修改" : NULL;
}

/* ---- 保存与生命周期 / Saving and lifecycle ---- */
// 重新读取定时服务算出的下次响铃；没有则把快照标记为无效。
// Re-read the next ring computed by the timer service, marking the snapshot invalid when absent.
static void alarm_refresh_next(void) {
    int weekday = 0;
    int hour = 0;
    int minute = 0;
    uint32_t in_sec = 0;
    s_next_valid = alarm_next(&weekday, &hour, &minute, &in_sec);
    s_next_weekday = s_next_valid ? weekday : 0;
    s_next_hour = s_next_valid ? hour : 0;
    s_next_minute = s_next_valid ? minute : 0;
    s_next_in_sec = s_next_valid ? in_sec : 0;
}

// 编辑动作：只置脏并清掉旧提示，不写 NVS；写入必须等用户点「保存」。
// An edit marks the copy dirty and clears the old notice; NVS stays untouched until Save.
static void alarm_mark_edited(void) {
    s_dirty = true;
    s_notice = ALARM_NOTICE_NONE;
}

// 保存：没有勾选任何一天时拒绝写入；成功则立刻重算下次响铃，失败保留原设置且不回滚编辑态。
// Save: refuse to write when no weekday is selected; on success recompute the next ring. On
// failure the stored schedule is kept and the edit copy is not rolled back.
static void alarm_save(void) {
    if (s_edit.weekdays == 0) {
        s_notice = ALARM_NOTICE_NEED_DAY;
        return;
    }
    if (!alarm_schedule_set(&s_edit)) {
        s_notice = ALARM_NOTICE_FAILED;
        return;
    }
    s_dirty = false;
    s_notice = ALARM_NOTICE_SAVED;
    alarm_refresh_next();
}

static void alarm_enter(app_ctx_t *ctx) {
    (void)ctx;
    // 进页重新从 NVS 覆盖编辑副本，丢弃上一次离页时的残留。
    // Reload the stored schedule on enter so leftovers from the previous visit are dropped.
    const alarm_schedule_t *saved = alarm_schedule();
    s_edit = (saved != NULL) ? *saved : s_fallback_schedule;
    s_dirty = false;
    s_notice = ALARM_NOTICE_NONE;
    alarm_refresh_next();
}

static void alarm_exit(app_ctx_t *ctx) {
    (void)ctx;
    // 离页不写 NVS、不改已保存设置，只清掉瞬时提示。
    // Leaving writes no NVS and keeps the stored schedule; only the transient notice is cleared.
    s_notice = ALARM_NOTICE_NONE;
}

/* ---- 回调 / Callbacks ---- */
static void alarm_render(uint8_t *fb, app_ctx_t *ctx) {
    (void)ctx;
    // 1. 「重复」分区标题和细线与其它子页共用同一套绘制。
    // The "repeat" section header and rule share the common drawing with other sub-pages.
    feature_draw_section(fb, ALARM_SECTION_Y, "重复");

    // 2. 七个周几 chip：选中只加内圈，不整块反白。
    // Seven weekday chips: selection thickens an inset ring instead of inverting the block.
    for (int i = 0; i < ALARM_WEEKDAY_COUNT; ++i) {
        const bool selected = (s_edit.weekdays & (uint8_t)(1u << i)) != 0;
        feature_draw_choice(fb, alarm_chip_rect(i), s_weekday_chip[i], selected);
    }

    // 3. 时和分各一组加减按钮：左组调时，右组每次调 5 分。
    // One step pair for hour and one for minute: the left pair moves the hour, the right pair
    // moves the minute by five.
    ui_text_fixed_vc(fb, ALARM_LEFT + ALARM_STEP_W / 2, ALARM_UNIT_CY, 24, "时",
                     EPD_DRAW_ALIGN_CENTER, false);
    ui_text_fixed_vc(fb, ALARM_RIGHT - ALARM_STEP_W / 2, ALARM_UNIT_CY, 24, "分",
                     EPD_DRAW_ALIGN_CENTER, false);
    feature_draw_button(fb, alarm_step_rect(false, false), "-", false);
    feature_draw_button(fb, alarm_step_rect(false, true), "+", false);
    feature_draw_button(fb, alarm_step_rect(true, false), "-", false);
    feature_draw_button(fb, alarm_step_rect(true, true), "+", false);

    // 4. 大时间固定 92px，居中显示「07 : 30」，不受系统字号缩放影响。
    // The big time uses a fixed 92 px and is centered as "07 : 30", ignoring the system UI scale.
    char time_text[16];
    snprintf(time_text, sizeof time_text, "%02u : %02u",
             (unsigned)s_edit.hour, (unsigned)s_edit.minute);
    ui_text_fixed_vc(fb, ALARM_CENTER_X, ALARM_TIME_CY, UI_PX_HERO, time_text,
                     EPD_DRAW_ALIGN_CENTER, false);

    // 5. 分钟细调：每次 ±1 分，方便补到非 5 的倍数。
    // Minute fine tuning: ±1 min so the minute can reach values that are not multiples of five.
    feature_draw_button(fb, alarm_fine_rect(false), "-1 分", false);
    feature_draw_button(fb, alarm_fine_rect(true), "+1 分", false);

    // 6. 保存状态：成功、失败、未选周几或还有未保存修改。
    // Save status: success, failure, missing weekday, or unsaved changes.
    const char *notice = alarm_notice_text();
    if (notice != NULL) {
        ui_text_fixed_vc(fb, ALARM_CENTER_X, ALARM_STATUS_CY, 24, notice,
                         EPD_DRAW_ALIGN_CENTER, false);
    }

    // 7. 启用开关 chip 和主按钮「保存」并排；chip 选中态就是当前开关状态。
    // The enable chip and the primary Save button share a row; the chip's selected state is the
    // current switch state.
    feature_draw_choice(fb, alarm_action_rect(false),
                        s_edit.enabled ? "已启用" : "已关闭", s_edit.enabled);
    feature_draw_button(fb, alarm_action_rect(true), "保存", true);

    // 8. 底部一行预览已经保存的下次响铃，而不是未保存的编辑值。
    // The bottom line previews the stored next ring rather than the unsaved edit copy.
    char preview[192];
    alarm_format_preview(preview, sizeof preview);
    ui_text_fixed_vc(fb, ALARM_CENTER_X, ALARM_PREVIEW_CY, 24, preview,
                     EPD_DRAW_ALIGN_CENTER, false);
}

static app_redraw_t alarm_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    (void)ctx;
    // 只认 TAP；本页不做拖拽，也不为按下反馈多刷一次整页。
    // TAP only: no dragging here, and no extra full-page repaint for press feedback.
    if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
    const int hit = alarm_hit_test(ev->x0, ev->y0);
    if (hit == ALARM_HIT_NONE) return APP_REDRAW_NONE;

    // 保存和点周几之外都是数值调整，统一改完再标脏。
    // Everything except Save and the weekday chips is a numeric adjustment; mark dirty afterwards.
    if (hit == ALARM_HIT_SAVE) {
        // 没有修改就不写 NVS，减少 flash 磨损，也不弹多余的“已保存”。
        // Skip the NVS write when nothing changed, saving flash wear and a redundant toast.
        if (!s_dirty) return APP_REDRAW_NONE;
        alarm_save();
        return APP_REDRAW_PAGE;
    }
    if (hit == ALARM_HIT_ENABLE) {
        s_edit.enabled = !s_edit.enabled;
        alarm_mark_edited();
        return APP_REDRAW_PAGE;
    }
    if (hit >= 0 && hit < ALARM_WEEKDAY_COUNT) {
        s_edit.weekdays ^= (uint8_t)(1u << hit);
        alarm_mark_edited();
        return APP_REDRAW_PAGE;
    }
    switch (hit) {
        case ALARM_HIT_HOUR_MINUS:
            s_edit.hour = (uint8_t)((s_edit.hour + 23) % 24);
            break;
        case ALARM_HIT_HOUR_PLUS:
            s_edit.hour = (uint8_t)((s_edit.hour + 1) % 24);
            break;
        case ALARM_HIT_MINUTE_MINUS:
            s_edit.minute = (uint8_t)((s_edit.minute + 55) % 60);
            break;
        case ALARM_HIT_MINUTE_PLUS:
            s_edit.minute = (uint8_t)((s_edit.minute + 5) % 60);
            break;
        case ALARM_HIT_FINE_MINUS:
            s_edit.minute = (uint8_t)((s_edit.minute + 59) % 60);
            break;
        case ALARM_HIT_FINE_PLUS:
            s_edit.minute = (uint8_t)((s_edit.minute + 1) % 60);
            break;
        default:
            return APP_REDRAW_NONE;
    }
    alarm_mark_edited();
    return APP_REDRAW_PAGE;
}

static app_redraw_t alarm_tick(app_ctx_t *ctx) {
    (void)ctx;
    // 预览是进页/保存时的快照；本页不做动画，也不为走秒每轮重绘。
    // The preview is a snapshot from enter/save; this page has no animation and does not repaint
    // every second.
    return APP_REDRAW_NONE;
}

static EpdRect alarm_area(app_ctx_t *ctx) {
    (void)ctx;
    // 本页只返回 APP_REDRAW_PAGE，这里给整张内容卡片以满足「不得为空」的约定。
    // This page only returns APP_REDRAW_PAGE; return the whole content card so the region is
    // never empty.
    return feature_card_rect();
}

const feature_body_t feature_body_alarm = {
    .enter = alarm_enter,
    .exit = alarm_exit,
    .render = alarm_render,
    .gesture = alarm_gesture,
    .tick = alarm_tick,
    .area = alarm_area,
};
