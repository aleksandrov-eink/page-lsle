/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：番茄时钟子页。入口页负责清屏、页眉、白卡与底栏，本文件只在内容卡片内部绘制；
 *       倒计时和到点标记归 timer_service 持有，本页只展示状态并把触摸翻译成开始 / 暂停 /
 *       重置 / 换时长，所以离开本页再回来计时仍在走。
 * English: Pomodoro sub-page. The hub clears the page and paints the header, card and navigation
 *          bar; this file paints inside the content card only. timer_service owns the countdown
 *          and its fired flag, so this page just renders state and maps taps to start / pause /
 *          reset / duration changes; a round keeps counting while the page is left.
 *
 * 冻结：不蜂鸣、不写 NVS、不请求切页；render 只画像素。
 * Frozen: never beep, never write NVS, never request a page switch; render paints pixels only.
 */
#include <stdio.h>

#include "feature_common.h"
#include "timer_service.h"
#include "ui_kit.h"

/* ---- 布局与几何 / Layout and geometry ---- */
// 卡片矩形 36..648 × 196..976；内容左右各留 28，中心线跟全屏中心对齐。
// Card is 36..648 x 196..976; keep a 28 px inner margin and center on the full-screen centerline.
#define POMO_CENTER_X (UI_LOCK_WIDTH / 2)
#define POMO_BUTTON_LEFT 64
#define POMO_BUTTON_WIDTH 556

#define POMO_STATUS_CY 300
#define POMO_STATUS_PX 28

// 倒计时固定 96px：不随系统字号缩放，数字位宽稳定，局部刷新矩形也就不用重算。
// The countdown is fixed at 96 px: it ignores the UI size preference so digit widths and the
// local-refresh rectangle stay stable.
#define POMO_COUNTDOWN_CY 455
#define POMO_COUNTDOWN_PX 96
// 秒级局部刷新矩形：正好包住 MM:SS 的字形，区域内没有其它内容，刷完不会留下残影。
// Second-level local-refresh rectangle: encloses the MM:SS ink and nothing else, so a fast
// differential update does not leave leftovers behind.
static const EpdRect POMO_COUNTDOWN_RECT = {120, 390, 444, 130};

// 预设块：两枚 200×76，间距 32，左右对称落在 556 的内容宽度里。
// Preset chips: two 200x76 blocks, 32 px apart, symmetric inside the 556 px content width.
#define POMO_CHIP_WIDTH 200
#define POMO_CHIP_HEIGHT 76
#define POMO_CHIP_GAP 32
#define POMO_CHIP_TOP 562

// 主按钮整行宽，重置是它下面居中的次要按钮。
// The primary button spans the row; reset is a centered secondary button beneath it.
#define POMO_PRIMARY_TOP 720
#define POMO_PRIMARY_HEIGHT 92
#define POMO_RESET_TOP 836
#define POMO_RESET_WIDTH 280
#define POMO_RESET_HEIGHT 72

// 卡片底部一句灰字，说明到点由提醒页响铃。
// One gray line near the card bottom: the reminder page rings when the round ends.
#define POMO_HINT_CY 932
#define POMO_HINT_PX 22
#define POMO_HINT_INK 0x60

// 轮询间隔：计时精度只到秒，不必每个 5ms tick 都去读一遍服务。
// Poll interval: the countdown is second-granular, so there is no need to read the service on
// every 5 ms tick.
#define POMO_POLL_MS 200

/* ---- 页内缓存 / Page-local cache ---- */
// 只用来判断这一轮有没有变化；权威状态永远从 timer_service 现读。
// Only used to decide whether something changed; the authoritative state is always read live.
static int64_t s_last_poll_ms;
static pomodoro_state_t s_last_state = POMODORO_IDLE;
static uint32_t s_last_remaining;

static EpdRect pomo_chip_rect(int index) {
    // 两枚块总宽 432，左起 126；index 0 是 25 分钟，1 是 5 分钟。
    // The pair is 432 px wide starting at x = 126; index 0 is 25 minutes, 1 is 5 minutes.
    const int left = POMO_CENTER_X - (2 * POMO_CHIP_WIDTH + POMO_CHIP_GAP) / 2;
    return (EpdRect){left + index * (POMO_CHIP_WIDTH + POMO_CHIP_GAP), POMO_CHIP_TOP,
                     POMO_CHIP_WIDTH, POMO_CHIP_HEIGHT};
}

static EpdRect pomo_primary_rect(void) {
    return (EpdRect){POMO_BUTTON_LEFT, POMO_PRIMARY_TOP, POMO_BUTTON_WIDTH, POMO_PRIMARY_HEIGHT};
}

static EpdRect pomo_reset_rect(void) {
    return (EpdRect){POMO_CENTER_X - POMO_RESET_WIDTH / 2, POMO_RESET_TOP,
                     POMO_RESET_WIDTH, POMO_RESET_HEIGHT};
}

/* ---- 状态文案 / State copy ---- */
// 墙钟刚越过截止点、服务还没来得及置停时会短暂出现「RUNNING 且剩余 0」，按「可开始」处理即可；
// pomodoro_start() 自己会先把 0 剩余复位成整段时长。
// The wall clock may just have passed the deadline before the service stops the round, briefly
// reporting RUNNING with zero left; treat that as startable because pomodoro_start() turns a zero
// remainder back into a full round.
static bool pomo_is_counting(pomodoro_state_t state, uint32_t remaining) {
    return state == POMODORO_RUNNING && remaining > 0u;
}

static const char *pomo_status_text(pomodoro_state_t state, uint32_t remaining) {
    // 系统时间未校准时不假装能开始：直接提示先等待校时，避免“点了没反应”。
    // With an uncalibrated wall clock, say so instead of silently ignoring the start tap.
    if (!timer_service_clock_ready()) return "等待校时";
    if (pomo_is_counting(state, remaining)) return "专注中";
    if (state == POMODORO_PAUSED) return "已暂停";
    return "准备开始";
}

static const char *pomo_primary_text(pomodoro_state_t state, uint32_t remaining) {
    if (pomo_is_counting(state, remaining)) return "暂停";
    if (state == POMODORO_PAUSED) return "继续";
    return "开始";
}

/* ---- 绘制 / Painting ---- */
static void pomo_draw_countdown(uint8_t *fb, uint32_t remaining_sec) {
    char text[16];
    // 分钟可设到 180，%02u 会在三位数时自然变宽；秒固定两位。
    // Minutes may reach 180, so %02u grows naturally past two digits; seconds stay two digits.
    snprintf(text, sizeof(text), "%02u:%02u",
             (unsigned)(remaining_sec / 60u), (unsigned)(remaining_sec % 60u));
    // 先清成卡片白再画字：局部刷新由本函数负责把 ctx->fb 的目标区域准备好。
    // Wipe to card white before painting: on a local refresh this function is what prepares the
    // targeted ctx->fb region.
    ui_clear_rect_fast(fb, POMO_COUNTDOWN_RECT);
    ui_text_fixed_vc(fb, POMO_CENTER_X, POMO_COUNTDOWN_CY, POMO_COUNTDOWN_PX, text,
                     EPD_DRAW_ALIGN_CENTER, false);
}

static void pomo_render(uint8_t *fb, app_ctx_t *ctx) {
    (void)ctx;
    // 整页重绘每次都从服务现读，保证从别的页返回时显示的就是真实状态。
    // Read the service live on every page repaint so returning from another page shows the truth.
    const pomodoro_state_t state = pomodoro_state();
    const uint32_t remaining = pomodoro_remaining_sec();
    const uint32_t minutes = pomodoro_minutes();

    ui_text_vc(fb, POMO_CENTER_X, POMO_STATUS_CY, POMO_STATUS_PX,
               pomo_status_text(state, remaining), EPD_DRAW_ALIGN_CENTER, false);
    pomo_draw_countdown(fb, remaining);

    // 选中只加内圈，不整块反白，和入口页的周几/预设块风格一致。
    // Selection thickens an inset ring instead of inverting the block, matching the hub's chips.
    feature_draw_choice(fb, pomo_chip_rect(0), "25 分钟", minutes == 25u);
    feature_draw_choice(fb, pomo_chip_rect(1), "5 分钟", minutes == 5u);

    feature_draw_button(fb, pomo_primary_rect(), pomo_primary_text(state, remaining), true);
    feature_draw_button(fb, pomo_reset_rect(), "重置", false);

    ui_text_fixed_ink_vc(fb, POMO_CENTER_X, POMO_HINT_CY, POMO_HINT_PX,
                         "到点会响铃提醒", EPD_DRAW_ALIGN_CENTER, POMO_HINT_INK);
}

/* ---- 手势 / Gestures ---- */
static void pomo_sync_cache(void) {
    // 动作处理完立刻同步缓存，避免下一轮 tick 把同一个变化再刷一次。
    // Sync right after acting so the next tick does not repaint the same change again.
    s_last_state = pomodoro_state();
    s_last_remaining = pomodoro_remaining_sec();
}

static app_redraw_t pomo_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    (void)ctx;
    // 只有轻点产生动作；按下不画反馈，避免慢速墨水屏上出现一次按键闪动。
    // Only taps act; presses paint no feedback, which would otherwise add one more slow flash.
    if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
    const uint16_t x = ev->x0;
    const uint16_t y = ev->y0;

    // 预设块：只有真的换了分钟数才调服务；重复点已选中的块不能把正在跑的计时清掉。
    // Presets: call the service only when the duration really changes; tapping the selected chip
    // must not wipe a round that is already running.
    if (ui_rect_hit(pomo_chip_rect(0), x, y)) {
        if (pomodoro_minutes() == 25u) return APP_REDRAW_NONE;
        pomodoro_set_minutes(25);
        pomo_sync_cache();
        return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(pomo_chip_rect(1), x, y)) {
        if (pomodoro_minutes() == 5u) return APP_REDRAW_NONE;
        pomodoro_set_minutes(5);
        pomo_sync_cache();
        return APP_REDRAW_PAGE;
    }

    if (ui_rect_hit(pomo_primary_rect(), x, y)) {
        const pomodoro_state_t state = pomodoro_state();
        const uint32_t remaining = pomodoro_remaining_sec();
        if (pomo_is_counting(state, remaining)) pomodoro_pause();
        else pomodoro_start();
        pomo_sync_cache();
        return APP_REDRAW_PAGE;
    }

    if (ui_rect_hit(pomo_reset_rect(), x, y)) {
        // 空闲且仍是完整时长时复位没有可见变化，直接不刷，省掉一次整页闪动。
        // Reset while idle at the full duration changes nothing visible; skip the page flash.
        if (pomodoro_state() == POMODORO_IDLE &&
            pomodoro_remaining_sec() == pomodoro_minutes() * 60u) {
            return APP_REDRAW_NONE;
        }
        pomodoro_reset();
        pomo_sync_cache();
        return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}

/* ---- 周期刷新 / Periodic refresh ---- */
static app_redraw_t pomo_tick(app_ctx_t *ctx) {
    // 主循环约 5ms 一轮；本页按 200ms 节流，避免每轮都查一次状态。
    // The loop runs about every 5 ms; this page throttles to 200 ms instead of polling each round.
    if (ctx->now_ms - s_last_poll_ms < POMO_POLL_MS) return APP_REDRAW_NONE;
    s_last_poll_ms = ctx->now_ms;

    const pomodoro_state_t state = pomodoro_state();
    const uint32_t remaining = pomodoro_remaining_sec();

    if (state == POMODORO_RUNNING) {
        if (remaining == s_last_remaining) {
            s_last_state = state;
            return APP_REDRAW_NONE;
        }
        s_last_state = state;
        s_last_remaining = remaining;
        if (remaining == 0u) {
            // 归零时服务会置提醒；整页重绘一次让状态行和主按钮跟上，之后不再局部刷。
            // At zero the service raises the reminder; one page repaint syncs the status line and
            // the primary button, and no further local refresh is needed.
            return APP_REDRAW_PAGE;
        }
        // 局部刷新只推倒计时矩形，所以必须先由页面自己把这块区域画好。
        // The local update pushes only the countdown rectangle, so the page must paint it first.
        pomo_draw_countdown(ctx->fb, remaining);
        return APP_REDRAW_AREA;
    }

    // 非运行状态若和缓存不同（例如到点后服务自行停下），整页同步一次即可。
    // If a non-running state differs from the cache (for example the service stopped on its own),
    // one page repaint resynchronises it.
    if (state != s_last_state || remaining != s_last_remaining) {
        s_last_state = state;
        s_last_remaining = remaining;
        return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}

static EpdRect pomo_area(app_ctx_t *ctx) {
    (void)ctx;
    return POMO_COUNTDOWN_RECT;
}

/* ---- 页面生命周期 / Page lifecycle ---- */
static void pomo_enter(app_ctx_t *ctx) {
    (void)ctx;
    // 计时状态由 timer_service 跨页面持有；进页只同步本地缓存，不触发任何计时动作。
    // timer_service keeps the countdown across pages; entering only refreshes the local cache and
    // never touches the timer itself.
    pomo_sync_cache();
    s_last_poll_ms = 0;
}

static void pomo_exit(app_ctx_t *ctx) {
    (void)ctx;
    // 不暂停、不复位：离开页面后计时继续；这里只丢掉缓存，下次进页重新同步。
    // Do not pause or reset: the countdown keeps running after leaving. Only the cache is dropped
    // and re-synced on the next enter.
    s_last_state = POMODORO_IDLE;
    s_last_remaining = 0;
    s_last_poll_ms = 0;
}

const feature_body_t feature_body_pomodoro = {
    .enter = pomo_enter,
    .exit = pomo_exit,
    .render = pomo_render,
    .gesture = pomo_gesture,
    .tick = pomo_tick,
    .area = pomo_area,
};
