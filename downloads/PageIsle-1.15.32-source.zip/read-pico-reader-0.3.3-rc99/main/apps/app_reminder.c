/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：定时提醒页。番茄/闹钟到点后由主循环切到本页：循环短鸣提示，整屏显示提醒内容，
 *       轻点屏幕或按任意键停止并返回原页面。提醒由 timer_service 持有，本页只负责呈现
 *       与消费，不自己计时。
 * English: Timer reminder page. When the Pomodoro or alarm fires, the loop switches here: the
 *          page chirps repeatedly and shows the reminder full screen. A tap or any key stops it
 *          and returns to the previous page. timer_service owns the state; this page only
 *          presents and consumes it.
 *
 * 冻结：本页不写 NVS、不改时间；停止只消费提醒，不重置用户设置。
 * Frozen: no NVS writes and no clock changes here; dismissing only consumes the reminder and
 *         never resets user settings.
 */
#include <stdio.h>
#include <string.h>

#include "app.h"
#include "app_registry.h"
#include "read_pico_buzzer.h"
#include "timer_service.h"
#include "ui_gesture.h"
#include "ui_kit.h"
#include "ui_nav.h"

// 提醒音：两声短促、音量足够但不刺耳；总时长小于 300ms，避免阻塞主循环太久。
// Chirp: two short tones loud enough without being harsh; under 300 ms so the loop never stalls.
#define REMINDER_BEEP_GAP_MS 2500
static const int64_t s_beep_period_ms = REMINDER_BEEP_GAP_MS;

static timer_reminder_t s_kind;
static char s_title[24];
static char s_detail[128];
static bool s_ringing;
static int64_t s_next_beep_ms;

static void reminder_beep(void) {
    read_pico_buzzer_tone(2350, 120);
    read_pico_buzzer_tone(1760, 150);
}

static void reminder_stop(app_ctx_t *ctx) {
    if (s_ringing) {
        s_ringing = false;
        if (s_kind != TIMER_REMINDER_NONE) timer_service_reminder_consume();
    }
    // 返回进入前的页面；从菜单进入时同样回到原页。
    // Return to the page that was active before; entering through the menu works the same way.
    ctx->request_return = true;
}

static void render(app_ctx_t *ctx, uint8_t *fb) {
    (void)ctx;
    ui_clear_page(fb);
    ui_nav_status(fb);
    const bool active = s_kind != TIMER_REMINDER_NONE;
    const int cx = UI_LOCK_WIDTH / 2;
    const ui_icon_t icon = s_kind == TIMER_REMINDER_ALARM ? UI_ICON_CLOCK : UI_ICON_TIMER;
    ui_draw_icon(fb, cx, 360, 150, icon, UI_GRAY_BLACK);
    ui_text_fixed_vc(fb, cx, 560, 56, s_title, EPD_DRAW_ALIGN_CENTER, false);
    if (s_detail[0] != 0) {
        ui_text_fixed_vc(fb, cx, 650, 26, s_detail, EPD_DRAW_ALIGN_CENTER, false);
    }
    ui_text_fixed_vc(fb, cx, 730, 24,
                     active ? "轻点屏幕或按任意键停止" : "当前没有待提醒的定时任务",
                     EPD_DRAW_ALIGN_CENTER, false);
    const EpdRect button = {36, 860, 612, 100};
    ui_fill_round_rect(fb, button, 32, 0x20);
    ui_text_fixed_vc(fb, cx, button.y + button.height / 2, 30,
                     active ? "停止响铃" : "返回", EPD_DRAW_ALIGN_CENTER, true);
    ui_text_fixed_vc(fb, cx, 1040, 20, "定时任务在 特色功能 → 番茄时钟/闹钟 里设置",
                     EPD_DRAW_ALIGN_CENTER, false);
}

static void reminder_enter(app_ctx_t *ctx) {
    s_kind = timer_service_reminder_kind();
    const char *title = timer_service_reminder_title();
    const char *detail = timer_service_reminder_detail();
    snprintf(s_title, sizeof(s_title), "%s", title != NULL ? title : "定时提醒");
    snprintf(s_detail, sizeof(s_detail), "%s", detail != NULL ? detail : "");
    s_ringing = s_kind != TIMER_REMINDER_NONE;
    s_next_beep_ms = ctx->now_ms;
    if (s_ringing) reminder_beep();
}

static void reminder_exit(app_ctx_t *ctx) {
    (void)ctx;
    s_ringing = false;
}

static app_redraw_t on_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type == UI_GESTURE_TAP || (ev->type == UI_GESTURE_LONG_PRESS && s_kind != TIMER_REMINDER_NONE)) {
        reminder_stop(ctx);
        return APP_REDRAW_NONE;
    }
    return APP_REDRAW_NONE;
}

static app_redraw_t on_tick(app_ctx_t *ctx) {
    if (!s_ringing || s_kind == TIMER_REMINDER_NONE) return APP_REDRAW_NONE;
    if (ctx->now_ms < s_next_beep_ms) return APP_REDRAW_NONE;
    s_next_beep_ms = ctx->now_ms + s_beep_period_ms;
    reminder_beep();
    return APP_REDRAW_NONE;
}

static app_redraw_t on_key(app_ctx_t *ctx, int key) {
    (void)key;
    reminder_stop(ctx);
    return APP_REDRAW_NONE;
}

static app_redraw_t on_key_long(app_ctx_t *ctx, int key) {
    (void)key;
    reminder_stop(ctx);
    return APP_REDRAW_NONE;
}

// 电源键短按也当“停止”：消费掉、不进入锁屏，避免用户按一下就锁屏并让提醒在解锁后再弹。
// A short power press also stops the reminder without locking, so it cannot bounce back after unlock.
static app_redraw_t on_power_short(app_ctx_t *ctx) {
    if (s_kind == TIMER_REMINDER_NONE) return APP_REDRAW_NONE;
    reminder_stop(ctx);
    return APP_REDRAW_DONE;
}

static bool menu_handle_enabled(app_ctx_t *ctx) {
    (void)ctx;
    return false;
}

const app_desc_t app_reminder = {
    .binary_ui = true,
    .title = "定时提醒",
    .detail = "番茄 / 闹钟到点提醒",
    .owns_keys = true,
    .defer_middle_short = true,
    .menu_handle_enabled = menu_handle_enabled,
    .on_enter = reminder_enter,
    .on_exit = reminder_exit,
    .on_power_short = on_power_short,
    .render = render,
    .on_gesture = on_gesture,
    .on_key = on_key,
    .on_key_long = on_key_long,
    .on_tick = on_tick,
};
