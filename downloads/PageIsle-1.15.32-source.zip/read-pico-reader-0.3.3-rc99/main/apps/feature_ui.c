/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：特色功能子页共用的卡片、分区标题、按钮与选择块绘制。所有子页共用同一套线宽、
 *       圆角和灰阶，避免每个功能各画一套导致界面不一致。
 * English: Shared card, section, button and chip painting for feature sub-pages. Every child
 *          uses the same stroke weight, corner radius and grays so the features look alike.
 *
 * 冻结：只画像素；不读设置、不写 NVS、不蜂鸣、不切换页面。
 * Frozen: pixels only; no settings reads, NVS writes, buzzer calls or page switches.
 */
#include "feature_common.h"

#include <string.h>

#include "ui_kit.h"

EpdRect feature_card_rect(void) {
    return (EpdRect){FEATURE_CARD_LEFT, FEATURE_CARD_TOP, FEATURE_CARD_WIDTH, FEATURE_CARD_HEIGHT};
}

EpdRect feature_game_rect(void) {
    return (EpdRect){FEATURE_GAME_LEFT, FEATURE_GAME_TOP, FEATURE_GAME_WIDTH, FEATURE_GAME_HEIGHT};
}

void feature_draw_card(uint8_t *fb) {
    const EpdRect card = feature_card_rect();
    ui_fill_round_rect(fb, card, 28, UI_GRAY_WHITE);
    ui_draw_control_frame(fb, card, 28, 0x80);
}

void feature_draw_hint(uint8_t *fb, const char *hint) {
    if (hint == NULL) return;
    ui_text_fixed_vc(fb, UI_LOCK_WIDTH / 2, FEATURE_HINT_CY, 20, hint, EPD_DRAW_ALIGN_CENTER, false);
}

int feature_draw_section(uint8_t *fb, int y, const char *title) {
    if (title != NULL) {
        ui_text(fb, FEATURE_CARD_LEFT + 28, y, 27, title, EPD_DRAW_ALIGN_LEFT, false);
    }
    ui_hairline(fb, y + 40, FEATURE_CARD_LEFT + 28, FEATURE_CARD_WIDTH - 56, UI_GRAY_LIGHT);
    return y + 58;
}

void feature_draw_button(uint8_t *fb, EpdRect rect, const char *label, bool on) {
    ui_fill_round_rect(fb, rect, 18, on ? 0x20 : 0xf0);
    ui_draw_control_frame(fb, rect, 18, on ? 0x20 : 0x88);
    if (label != NULL) {
        ui_text_fixed_vc(fb, rect.x + rect.width / 2, rect.y + rect.height / 2, 28, label,
                         EPD_DRAW_ALIGN_CENTER, on);
    }
}

void feature_draw_choice(uint8_t *fb, EpdRect rect, const char *label, bool selected) {
    ui_fill_round_rect(fb, rect, 14, selected ? 0xe0 : 0xf7);
    ui_draw_control_frame(fb, rect, 14, 0x90);
    if (selected) ui_draw_selected_round_rect(fb, rect, 14);
    if (label != NULL) {
        ui_text_fixed_vc(fb, rect.x + rect.width / 2, rect.y + rect.height / 2, 26, label,
                         EPD_DRAW_ALIGN_CENTER, false);
    }
}
