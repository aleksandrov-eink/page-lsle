/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：定时任务服务。番茄倒计时与周闹钟共用墙钟、NVS 与 PMU RTC 闹钟：运行中按秒比较
 *       墙钟到点，到点只置「待提醒」标记；锁屏浅睡与深睡前由 sleep.c 查询最近截止时间，
 *       深睡时用 PMU 的 RTC 闹钟把主机唤醒（wake_reason=6），开机初始化再补发提醒。
 * English: Timer service. Pomodoro countdown and the weekly alarm share the wall clock, NVS and
 *          the PMU RTC alarm: while awake we compare the wall clock every second and only raise a
 *          pending-reminder flag; sleep.c asks for the nearest deadline before sleeping, and in
 *          deep sleep the PMU RTC alarm powers the host back on (wake_reason=6) so the next boot
 *          can re-raise the reminder.
 *
 * 冻结：本文件不画屏、不蜂鸣；提醒必须由 app_reminder.c 消费。
 * Frozen: never paints or beeps here; app_reminder.c owns every reminder.
 */
#include "timer_service.h"

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>

#include "esp_log.h"
#include "esp_timer.h"
#include "nvs.h"
#include "read_pico_pmu.h"
#include "read_pico_pmu_protocol.h"
#include "sleep.h"

static const char *TAG = "timer_service";

#define TIMER_NVS_NAMESPACE "rp_timer"
#define TIMER_NVS_POMO "pomo"
#define TIMER_NVS_ALARM "alarm"
#define POMO_BLOB_MAGIC 0x504d4f31u  // "PMO1"
#define ALARM_BLOB_MAGIC 0x414c4d31u // "ALM1"

// 系统时钟是 UTC；界面与用户设定都按北京时间，与锁屏时钟保持一致。
// The system clock is UTC; UI and user schedules use China time like the lock clock.
#define TIMER_CHINA_OFFSET_SEC (8 * 3600)
// 开机时允许补发多久内到点的任务（深睡唤醒后开机需要几秒）。
// How late a task may fire and still be re-raised after a deep-sleep boot.
#define TIMER_BOOT_GRACE_SEC 180
// 轮询节流。/ Poll throttle.
#define TIMER_POLL_INTERVAL_MS 500
// PMU 闹钟允许的最短/最长剩余秒数（协议 10..31 天）。
// PMU alarm bounds from the wire protocol (10 s .. 31 days).
#define PMU_ALARM_MIN_SEC 10u
#define PMU_ALARM_MAX_SEC 2678400u
#define PMU_ALARM_MODE_ONCE 1u

typedef struct {
    uint32_t magic;
    uint32_t minutes;
    uint32_t end_unix;
    uint32_t remain_sec;
    uint8_t state;
    uint8_t reserved[3];
} pomo_blob_t;

typedef struct {
    uint32_t magic;
    uint8_t enabled;
    uint8_t weekdays;
    uint8_t hour;
    uint8_t minute;
} alarm_blob_t;

static pomo_blob_t s_pomo;
static alarm_schedule_t s_alarm;
static uint32_t s_alarm_target; // 下次响铃 unix 秒，0 表示无 / next ring, 0 = none
static timer_reminder_t s_pending;
static char s_detail[128];
static int64_t s_last_poll_ms;
static uint32_t s_armed_target; // 已写进 PMU 的截止时间，0xFFFFFFFF 表示未知
static bool s_inited;

/* ---- 时间与闹钟计算 / Time and alarm arithmetic ---- */

static bool clock_valid(void) {
    const time_t now = time(NULL);
    return now >= (time_t)1704067200 && now <= (time_t)4102444799U;
}

// 周一=0 … 周日=6；系统时钟按 UTC 走，故先把时间平移到北京时间再取 tm_wday。
// Monday=0 … Sunday=6; shift UTC to China time before reading tm_wday.
static int weekday_monday0(uint32_t unix_sec) {
    const time_t local = (time_t)((int64_t)unix_sec + TIMER_CHINA_OFFSET_SEC);
    struct tm tm = {0};
    if (gmtime_r(&local, &tm) == NULL) return -1;
    return (tm.tm_wday + 6) % 7;
}

// 从 now 之后找下一次符合星期掩码的时/分，最多向后看 8 天。
// Find the next hour/minute matching the weekday mask, looking at most 8 days ahead.
static uint32_t next_alarm_unix(const alarm_schedule_t *schedule, time_t now) {
    if (schedule == NULL || !schedule->enabled || schedule->weekdays == 0) return 0;
    if (schedule->hour > 23 || schedule->minute > 59) return 0;
    const int64_t china_now = (int64_t)now + TIMER_CHINA_OFFSET_SEC;
    const int64_t day_start = china_now - (china_now % 86400);
    for (int day = 0; day <= 8; ++day) {
        const int64_t local_target = day_start + (int64_t)day * 86400 +
                                     (int64_t)schedule->hour * 3600 + (int64_t)schedule->minute * 60;
        const int64_t target = local_target - TIMER_CHINA_OFFSET_SEC;
        // 留两秒余量，避免刚好落在当前秒上导致同一分钟内反复触发。
        // Keep a two-second margin so the current minute cannot trigger twice.
        if (target <= (int64_t)now + 2) continue;
        const int weekday = weekday_monday0((uint32_t)target);
        if (weekday < 0) continue;
        if (schedule->weekdays & (1u << weekday)) return (uint32_t)target;
    }
    return 0;
}

// 从 now 往回找最近一次应响但未处理的时刻，用于开机补发判断。
// Look back for the most recent scheduled moment, used when booting after deep sleep.
static uint32_t previous_alarm_unix(const alarm_schedule_t *schedule, time_t now) {
    if (schedule == NULL || !schedule->enabled || schedule->weekdays == 0) return 0;
    if (schedule->hour > 23 || schedule->minute > 59) return 0;
    const int64_t china_now = (int64_t)now + TIMER_CHINA_OFFSET_SEC;
    const int64_t day_start = china_now - (china_now % 86400);
    for (int day = 0; day >= -2; --day) {
        const int64_t local_target = day_start + (int64_t)day * 86400 +
                                     (int64_t)schedule->hour * 3600 + (int64_t)schedule->minute * 60;
        const int64_t target = local_target - TIMER_CHINA_OFFSET_SEC;
        if (target > (int64_t)now) continue;
        const int weekday = weekday_monday0((uint32_t)target);
        if (weekday < 0) continue;
        if (schedule->weekdays & (1u << weekday)) return (uint32_t)target;
    }
    return 0;
}

/// 当前剩余秒数（按 wall clock）。
static uint32_t pomo_remaining_now(void) {
    switch (s_pomo.state) {
        case POMODORO_RUNNING: {
            if (!clock_valid()) return s_pomo.remain_sec;
            const time_t now = time(NULL);
            if ((int64_t)s_pomo.end_unix <= (int64_t)now) return 0;
            return s_pomo.end_unix - (uint32_t)now;
        }
        case POMODORO_PAUSED:
            return s_pomo.remain_sec;
        default:
            return s_pomo.minutes * 60u;
    }
}

/* ---- NVS ---- */

static void pomo_persist(void) {
    nvs_handle_t handle;
    if (nvs_open(TIMER_NVS_NAMESPACE, NVS_READWRITE, &handle) != ESP_OK) return;
    pomo_blob_t blob;
    memset(&blob, 0, sizeof(blob));
    blob.magic = POMO_BLOB_MAGIC;
    blob.minutes = s_pomo.minutes;
    blob.end_unix = s_pomo.end_unix;
    blob.remain_sec = s_pomo.remain_sec;
    blob.state = s_pomo.state;
    esp_err_t err = nvs_set_blob(handle, TIMER_NVS_POMO, &blob, sizeof(blob));
    if (err == ESP_OK) err = nvs_commit(handle);
    nvs_close(handle);
    if (err != ESP_OK) ESP_LOGW(TAG, "pomodoro save failed: %s", esp_err_to_name(err));
}

static void alarm_persist(void) {
    nvs_handle_t handle;
    if (nvs_open(TIMER_NVS_NAMESPACE, NVS_READWRITE, &handle) != ESP_OK) return;
    alarm_blob_t blob;
    memset(&blob, 0, sizeof(blob));
    blob.magic = ALARM_BLOB_MAGIC;
    blob.enabled = s_alarm.enabled ? 1 : 0;
    blob.weekdays = s_alarm.weekdays;
    blob.hour = s_alarm.hour;
    blob.minute = s_alarm.minute;
    esp_err_t err = nvs_set_blob(handle, TIMER_NVS_ALARM, &blob, sizeof(blob));
    if (err == ESP_OK) err = nvs_commit(handle);
    nvs_close(handle);
    if (err != ESP_OK) ESP_LOGW(TAG, "alarm save failed: %s", esp_err_to_name(err));
}

static void load_defaults(void) {
    memset(&s_pomo, 0, sizeof(s_pomo));
    s_pomo.magic = POMO_BLOB_MAGIC;
    s_pomo.minutes = 25;
    s_pomo.state = POMODORO_IDLE;
    memset(&s_alarm, 0, sizeof(s_alarm));
    s_alarm.enabled = false;
    s_alarm.weekdays = ALARM_WEEKDAY_ALL;
    s_alarm.hour = 7;
    s_alarm.minute = 30;
}

static void load_nvs(void) {
    nvs_handle_t handle;
    if (nvs_open(TIMER_NVS_NAMESPACE, NVS_READONLY, &handle) != ESP_OK) return;
    pomo_blob_t pomo;
    size_t size = sizeof(pomo);
    if (nvs_get_blob(handle, TIMER_NVS_POMO, &pomo, &size) == ESP_OK &&
        size == sizeof(pomo) && pomo.magic == POMO_BLOB_MAGIC) {
        s_pomo.minutes = pomo.minutes;
        s_pomo.end_unix = pomo.end_unix;
        s_pomo.remain_sec = pomo.remain_sec;
        s_pomo.state = pomo.state;
        if (s_pomo.minutes < 1 || s_pomo.minutes > 180) s_pomo.minutes = 25;
        if (s_pomo.state > POMODORO_PAUSED) s_pomo.state = POMODORO_IDLE;
        if (s_pomo.state == POMODORO_PAUSED && s_pomo.remain_sec == 0) s_pomo.state = POMODORO_IDLE;
    }
    alarm_blob_t alarm;
    size = sizeof(alarm);
    if (nvs_get_blob(handle, TIMER_NVS_ALARM, &alarm, &size) == ESP_OK &&
        size == sizeof(alarm) && alarm.magic == ALARM_BLOB_MAGIC) {
        s_alarm.enabled = alarm.enabled != 0;
        s_alarm.weekdays = alarm.weekdays;
        s_alarm.hour = alarm.hour;
        s_alarm.minute = alarm.minute;
        if (s_alarm.weekdays == 0 || s_alarm.hour > 23 || s_alarm.minute > 59) {
            s_alarm.enabled = false;
            s_alarm.weekdays = ALARM_WEEKDAY_ALL;
            s_alarm.hour = 7;
            s_alarm.minute = 30;
        }
    }
    nvs_close(handle);
}

/* ---- PMU RTC 闹钟 / PMU RTC alarm ---- */

// 最早到点时刻：闹钟下次响铃与番茄结束取较早者。
// Earliest deadline between the next alarm ring and the running Pomodoro end.
static uint32_t earliest_target(void) {
    uint32_t target = 0;
    if (s_pomo.state == POMODORO_RUNNING && s_pomo.end_unix != 0) target = s_pomo.end_unix;
    if (s_alarm.enabled && s_alarm_target != 0) {
        if (target == 0 || s_alarm_target < target) target = s_alarm_target;
    }
    return target;
}

static void pmu_alarm_send(uint8_t mode, uint32_t seconds) {
    const uint8_t payload[5] = {
        mode,
        (uint8_t)(seconds & 0xff),
        (uint8_t)((seconds >> 8) & 0xff),
        (uint8_t)((seconds >> 16) & 0xff),
        (uint8_t)((seconds >> 24) & 0xff),
    };
    const esp_err_t err = read_pico_pmu_cmd(PMU_CMD_ALARM_SET, payload, sizeof(payload));
    if (err != ESP_OK) ESP_LOGW(TAG, "PMU alarm set failed: %s", esp_err_to_name(err));
}

void timer_service_pmu_alarm_off(void) {
    if (!read_pico_pmu_ready()) return;
    pmu_alarm_send(0, 0);
    s_armed_target = 0;
}

void timer_service_arm_pmu_alarm(void) {
    if (!read_pico_pmu_ready() || !clock_valid()) return;
    const uint32_t target = earliest_target();
    if (target == s_armed_target) return;
    if (target == 0) {
        pmu_alarm_send(0, 0);
        s_armed_target = 0;
        return;
    }
    const time_t now = time(NULL);
    if ((int64_t)target <= (int64_t)now) return;
    uint32_t remaining = target - (uint32_t)now;
    if (remaining > PMU_ALARM_MAX_SEC) return;  // 太远，等接近再设 / too far, arm later
    // 先校时再设剩余秒数，PMU 的 RTC 才会和主机墙钟对齐。
    // Sync host time into the PMU first so its RTC matches the wall clock.
    (void)app_sync_time_to_pmu();
    if (remaining < PMU_ALARM_MIN_SEC) remaining = PMU_ALARM_MIN_SEC;
    pmu_alarm_send(PMU_ALARM_MODE_ONCE, remaining);
    s_armed_target = target;
    ESP_LOGI(TAG, "PMU alarm armed in %u s", (unsigned)remaining);
}

/* ---- 到点 / Firing ---- */

static void raise_reminder(timer_reminder_t kind, const char *detail) {
    s_pending = kind;
    if (detail != NULL) {
        strncpy(s_detail, detail, sizeof(s_detail) - 1);
        s_detail[sizeof(s_detail) - 1] = 0;
    } else {
        s_detail[0] = 0;
    }
}

static void fire_alarm(time_t now) {
    char detail[128];
    snprintf(detail, sizeof(detail), "设定的 %02u:%02u 闹钟到点了。",
             (unsigned)s_alarm.hour, (unsigned)s_alarm.minute);
    raise_reminder(TIMER_REMINDER_ALARM, detail);
    s_alarm_target = next_alarm_unix(&s_alarm, now);
    s_armed_target = 0xFFFFFFFFu;
    timer_service_arm_pmu_alarm();
    ESP_LOGI(TAG, "alarm fired, next target %u", (unsigned)s_alarm_target);
}

static void fire_pomodoro(void) {
    char detail[128];
    snprintf(detail, sizeof(detail), "专注 %u 分钟结束，起来活动一下。",
             (unsigned)s_pomo.minutes);
    raise_reminder(TIMER_REMINDER_POMODORO, detail);
    s_pomo.state = POMODORO_IDLE;
    s_pomo.end_unix = 0;
    s_pomo.remain_sec = 0;
    pomo_persist();
    s_armed_target = 0xFFFFFFFFu;
    timer_service_arm_pmu_alarm();
    ESP_LOGI(TAG, "pomodoro fired");
}

/* ---- 对外接口 / Public API ---- */

void timer_service_init(void) {
    load_defaults();
    load_nvs();
    s_pending = TIMER_REMINDER_NONE;
    s_detail[0] = 0;
    s_alarm_target = 0;
    s_armed_target = 0xFFFFFFFFu;
    s_last_poll_ms = -1000000;
    s_inited = true;

    // 读一次 PMU 快照：RTC 闹钟唤醒的 boot 带 wake_reason=6，据此补发闹钟提醒。
    // Read one PMU snapshot: an alarm wake carries wake_reason=6, which re-raises the reminder.
    const bool clock_ok = clock_valid();
    uint8_t wake_reason = 0;
    if (read_pico_pmu_ready() && read_pico_pmu_refresh() == ESP_OK) {
        const pmu_snapshot_t *pmu = read_pico_pmu_get();
        if (pmu != NULL && pmu->present) wake_reason = pmu->wake_reason;
    }
    if (!clock_ok) {
        ESP_LOGW(TAG, "clock invalid, timers wait for time sync");
        return;
    }
    const time_t now = time(NULL);
    if (wake_reason == 6 && s_alarm.enabled) {
        ESP_LOGI(TAG, "boot from RTC alarm");
        fire_alarm(now);
        return;
    }
    // 深睡/断电期间番茄已经到点：较近才补提醒，太久的直接清掉。
    // Pomodoro already ended while asleep: re-raise only when recent, otherwise drop it.
    if (s_pomo.state == POMODORO_RUNNING) {
        if ((int64_t)s_pomo.end_unix <= (int64_t)now) {
            if ((int64_t)now - (int64_t)s_pomo.end_unix <= TIMER_BOOT_GRACE_SEC) {
                fire_pomodoro();
                return;
            }
            s_pomo.state = POMODORO_IDLE;
            s_pomo.end_unix = 0;
            s_pomo.remain_sec = 0;
            pomo_persist();
        }
    }
    if (s_alarm.enabled) {
        // 闹钟在睡眠中已经响过但 PMU 没报唤醒（例如设备本来就没睡）：按时间补发。
        // The alarm may have fired while the device stayed awake; re-raise it by time.
        const uint32_t previous = previous_alarm_unix(&s_alarm, now);
        if (previous != 0 && (int64_t)now - (int64_t)previous <= TIMER_BOOT_GRACE_SEC) {
            fire_alarm(now);
            return;
        }
        s_alarm_target = next_alarm_unix(&s_alarm, now);
    }
    timer_service_arm_pmu_alarm();
}

void timer_service_poll(void) {
    if (!s_inited) return;
    const int64_t now_ms = esp_timer_get_time() / 1000;
    if (s_last_poll_ms > 0 && now_ms - s_last_poll_ms < TIMER_POLL_INTERVAL_MS) return;
    s_last_poll_ms = now_ms;
    if (!clock_valid()) return;
    if (s_pending != TIMER_REMINDER_NONE) return;  // 提醒未消费前不叠加 / never stack reminders

    const time_t now = time(NULL);
    // 开机时时钟还没校准，闹钟目标会留在 0；这里在时钟可用后补算一次，
    // 否则用户设了闹钟也要等下次保存才会生效。
    // The clock may have been invalid at boot and left the alarm target at zero; compute it once
    // the clock becomes usable, otherwise a saved alarm would stay inactive until saved again.
    if (s_alarm.enabled && s_alarm_target == 0) {
        s_alarm_target = next_alarm_unix(&s_alarm, now);
        if (s_alarm_target != 0) {
            s_armed_target = 0xFFFFFFFFu;
            timer_service_arm_pmu_alarm();
        }
    }
    if (s_alarm.enabled && s_alarm_target != 0 &&
        (int64_t)now >= (int64_t)s_alarm_target) {
        fire_alarm(now);
        return;
    }
    if (s_pomo.state == POMODORO_RUNNING && s_pomo.end_unix != 0 &&
        (int64_t)now >= (int64_t)s_pomo.end_unix) {
        fire_pomodoro();
    }
}

bool timer_service_reminder_pending(void) {
    return s_pending != TIMER_REMINDER_NONE;
}

timer_reminder_t timer_service_reminder_kind(void) {
    return s_pending;
}

void timer_service_reminder_consume(void) {
    s_pending = TIMER_REMINDER_NONE;
    s_detail[0] = 0;
    s_last_poll_ms = 0;  // 下一轮立刻检查下一个任务 / poll the next task immediately
}

const char *timer_service_reminder_title(void) {
    switch (s_pending) {
        case TIMER_REMINDER_POMODORO: return "番茄完成";
        case TIMER_REMINDER_ALARM: return "闹钟响了";
        default: return "定时提醒";
    }
}

const char *timer_service_reminder_detail(void) {
    return s_detail;
}

bool timer_service_clock_ready(void) {
    return clock_valid();
}

uint32_t timer_service_deadline_ms(void) {
    if (!clock_valid()) return 0;
    const time_t now = time(NULL);
    uint32_t best = 0;
    if (s_pomo.state == POMODORO_RUNNING && s_pomo.end_unix != 0 &&
        (int64_t)s_pomo.end_unix > (int64_t)now) {
        best = (s_pomo.end_unix - (uint32_t)now) * 1000u;
    }
    if (s_alarm.enabled) {
        const uint32_t target = s_alarm_target != 0 ? s_alarm_target : next_alarm_unix(&s_alarm, now);
        if (target != 0 && (int64_t)target > (int64_t)now) {
            const uint32_t ms = (target - (uint32_t)now) * 1000u;
            if (best == 0 || ms < best) best = ms;
        }
    }
    return best;
}

/* ---- 番茄时钟 / Pomodoro ---- */

void pomodoro_set_minutes(uint32_t minutes) {
    if (minutes < 1) minutes = 1;
    if (minutes > 180) minutes = 180;
    s_pomo.minutes = minutes;
    s_pomo.state = POMODORO_IDLE;
    s_pomo.end_unix = 0;
    s_pomo.remain_sec = 0;
    pomo_persist();
    s_armed_target = 0xFFFFFFFFu;
    timer_service_arm_pmu_alarm();
}

uint32_t pomodoro_minutes(void) {
    return s_pomo.minutes;
}

void pomodoro_start(void) {
    if (s_pomo.state == POMODORO_RUNNING) return;
    if (!clock_valid()) {
        ESP_LOGW(TAG, "pomodoro start ignored: clock invalid");
        return;
    }
    uint32_t remaining = pomo_remaining_now();
    if (remaining == 0) remaining = s_pomo.minutes * 60u;
    s_pomo.end_unix = (uint32_t)time(NULL) + remaining;
    s_pomo.state = POMODORO_RUNNING;
    s_pomo.remain_sec = 0;
    pomo_persist();
    s_armed_target = 0xFFFFFFFFu;
    timer_service_arm_pmu_alarm();
}

void pomodoro_pause(void) {
    if (s_pomo.state != POMODORO_RUNNING) return;
    s_pomo.remain_sec = pomo_remaining_now();
    s_pomo.end_unix = 0;
    s_pomo.state = POMODORO_PAUSED;
    pomo_persist();
    s_armed_target = 0xFFFFFFFFu;
    timer_service_arm_pmu_alarm();
}

void pomodoro_reset(void) {
    s_pomo.state = POMODORO_IDLE;
    s_pomo.end_unix = 0;
    s_pomo.remain_sec = 0;
    pomo_persist();
    s_armed_target = 0xFFFFFFFFu;
    timer_service_arm_pmu_alarm();
}

pomodoro_state_t pomodoro_state(void) {
    return (pomodoro_state_t)s_pomo.state;
}

uint32_t pomodoro_remaining_sec(void) {
    return pomo_remaining_now();
}

/* ---- 周闹钟 / Weekly alarm ---- */

const alarm_schedule_t *alarm_schedule(void) {
    return &s_alarm;
}

bool alarm_schedule_set(const alarm_schedule_t *schedule) {
    if (schedule == NULL || schedule->weekdays == 0 || schedule->weekdays > ALARM_WEEKDAY_ALL ||
        schedule->hour > 23 || schedule->minute > 59) {
        return false;
    }
    s_alarm = *schedule;
    s_alarm.enabled = schedule->enabled;
    alarm_persist();
    s_alarm_target = s_alarm.enabled ? next_alarm_unix(&s_alarm, time(NULL)) : 0;
    s_armed_target = 0xFFFFFFFFu;
    timer_service_arm_pmu_alarm();
    ESP_LOGI(TAG, "alarm saved enabled=%d %02u:%02u weekdays=0x%02x next=%u",
             (int)s_alarm.enabled, (unsigned)s_alarm.hour, (unsigned)s_alarm.minute,
             (unsigned)s_alarm.weekdays, (unsigned)s_alarm_target);
    return true;
}

bool alarm_next(int *weekday, int *hour, int *minute, uint32_t *in_sec) {
    if (!s_alarm.enabled || !clock_valid()) return false;
    const time_t now = time(NULL);
    const uint32_t target = s_alarm_target != 0 ? s_alarm_target : next_alarm_unix(&s_alarm, now);
    if (target == 0 || (int64_t)target <= (int64_t)now) return false;
    if (weekday != NULL) *weekday = weekday_monday0(target);
    if (hour != NULL) *hour = s_alarm.hour;
    if (minute != NULL) *minute = s_alarm.minute;
    if (in_sec != NULL) *in_sec = target - (uint32_t)now;
    return true;
}
