/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：特色功能的贪吃蛇子页，使用近全屏游戏画布（FEATURE_GAME_*）：上部是 640×640 的
 *       20×20 棋盘，下部右侧是十字方向键、左侧是开始/暂停与重新开始按钮；页眉由入口页
 *       绘制。方向键与棋盘滑动都能转向，解决小屏转向困难的问题。
 * English: Snake sub-page on the near-full-screen game canvas: a 640x640 20x20 board on top,
 *          a cross D-pad at the lower right and start/pause plus restart buttons at the lower
 *          left; the hub paints the title. Both the D-pad and board swipes steer the snake.
 *
 * 冻结：render 只画像素；蜂鸣、食物随机和刷屏请求只在 enter / gesture / tick。
 * Frozen: render paints pixels only; buzzer, food placement and redraw requests live in
 *         enter / gesture / tick.
 */
#include <stdio.h>

#include "esp_random.h"
#include "feature_common.h"
#include "display.h"
#include "read_pico_buzzer.h"
#include "ui_kit.h"

/* ---- 几何与常量 / Geometry and constants ---- */
// 棋盘 20×20 格、每格 32px，合计 640×640，画在游戏画布上部。
// A 20x20 board with 32 px cells is 640x640 in the upper part of the game canvas.
#define SNAKE_GRID 20
#define SNAKE_CELL_PX 32
#define SNAKE_BOARD_PX (SNAKE_GRID * SNAKE_CELL_PX)
#define SNAKE_BOARD_X 22
#define SNAKE_BOARD_Y 100
// 每步约 350ms；每 20 步清一次残影：浅色模式整页重绘，反色模式先压黑清理再整页差分重绘。
// About 350 ms per step; residue is cleaned every 20 steps: light mode repaints the page, while
// inverted mode first presses the black ground and then repaints differentially.
#define SNAKE_STEP_MS 350
#define SNAKE_PAGE_STEPS 20
#define SNAKE_STATUS_CY 772

// 方向键每键 130×112，十字排在棋盘下方右侧；左侧竖排开始/暂停与重新开始。
// Each D-pad key is 130x112 in a cross below the board; start/pause and restart stack on the left.
static const EpdRect s_pad_up = {393, 808, 130, 112};
static const EpdRect s_pad_down = {393, 1048, 130, 112};
static const EpdRect s_pad_left = {255, 928, 130, 112};
static const EpdRect s_pad_right = {531, 928, 130, 112};
static const EpdRect s_start_button = {22, 830, 208, 130};
static const EpdRect s_restart_button = {22, 1000, 208, 130};

/* ---- 页内状态 / Page state ---- */
typedef enum {
    SNAKE_READY = 0, ///< 等待开始 / waiting to start
    SNAKE_RUNNING, ///< 运行中 / playing
    SNAKE_PAUSED, ///< 已暂停 / paused
    SNAKE_OVER, ///< 游戏结束 / game over
} snake_state_t;

// 蛇身存栅格坐标，索引 0 是蛇头。最高分只在内存里保留，不写 NVS。
// The snake stores grid cells with the head at index 0. The best score is RAM-only, never in NVS.
static int8_t s_body_x[SNAKE_GRID * SNAKE_GRID];
static int8_t s_body_y[SNAKE_GRID * SNAKE_GRID];
static uint8_t s_length;
static int8_t s_dir_x; ///< 已生效方向 / committed direction
static int8_t s_dir_y;
static int8_t s_turn_x; ///< 下一步生效的转向 / turn queued for the next step
static int8_t s_turn_y;
static int8_t s_food_x; ///< 食物坐标，-1 表示棋盘已满 / food cell, -1 when full
static int8_t s_food_y;
static snake_state_t s_state;
static uint16_t s_score;
static uint16_t s_best;
static int64_t s_step_ms;
static uint8_t s_steps_since_page;
static bool s_active;
// 本步脏区（只推变化的格子）与格子矩形换算，供渲染和 area() 共用。
// Dirty rect for one step (only changed cells) and the cell-rect helper shared by paint and area().
static EpdRect s_dirty_area;
static EpdRect snake_cell_rect(int cx, int cy);

/* ---- 小工具 / Helpers ---- */
static EpdRect board_rect(void) {
    return (EpdRect){SNAKE_BOARD_X, SNAKE_BOARD_Y, SNAKE_BOARD_PX, SNAKE_BOARD_PX};
}

// 该格是否已被蛇身占用，放食物与碰撞检测共用。
// Whether the cell is occupied by the snake; used by food placement and collision checks.
static bool cell_occupied(int x, int y) {
    for (int i = 0; i < (int)s_length; ++i) {
        if (s_body_x[i] == x && s_body_y[i] == y) return true;
    }
    return false;
}

// 新蛇头是否撞到蛇身；普通步蛇尾让位可跳过，吃食物时尾巴留下必须计入。
// Whether the new head hits the body; only a normal step may skip the vacating tail.
static bool snake_hits(int x, int y, bool ignore_tail) {
    const int last = (int)s_length - (ignore_tail ? 1 : 0);
    for (int i = 0; i < last; ++i) {
        if (s_body_x[i] == x && s_body_y[i] == y) return true;
    }
    return false;
}

// 在空格里均匀挑一格放食物；棋盘满了就没有食物。
// Pick a uniformly random free cell for food; a full board simply has none.
static void place_food(void) {
    const int free_cells = SNAKE_GRID * SNAKE_GRID - (int)s_length;
    s_food_x = -1;
    s_food_y = -1;
    if (free_cells <= 0) return;
    int pick = (int)(esp_random() % (uint32_t)free_cells);
    for (int y = 0; y < SNAKE_GRID; ++y) {
        for (int x = 0; x < SNAKE_GRID; ++x) {
            if (cell_occupied(x, y)) continue;
            if (pick-- == 0) {
                s_food_x = (int8_t)x;
                s_food_y = (int8_t)y;
                return;
            }
        }
    }
}

// 初始化一局并停在“等待开始”：蛇头居中朝右，食物随机落在空格。
// Start a round in the waiting state: centred head facing right, random food.
static void spawn_game(void) {
    s_length = 3;
    s_score = 0;
    s_dir_x = s_turn_x = 1;
    s_dir_y = s_turn_y = 0;
    for (int i = 0; i < 3; ++i) {
        s_body_x[i] = (int8_t)(10 - i);
        s_body_y[i] = 10;
    }
    s_steps_since_page = 0;
    s_state = SNAKE_READY;
    place_food();
}

/* ---- 绘制 / Painting ---- */
// 画一个网格方块；inset 给蛇身段之间留白缝。
// Paint one grid block; inset leaves a white gap between snake segments.
static void draw_block(uint8_t *fb, int gx, int gy, int inset) {
    const EpdRect board = board_rect();
    ui_fill_rect_fast(
        (EpdRect){board.x + gx * SNAKE_CELL_PX + inset,
                  board.y + gy * SNAKE_CELL_PX + inset,
                  SNAKE_CELL_PX - 2 * inset, SNAKE_CELL_PX - 2 * inset},
        UI_GRAY_BLACK, fb);
}

// 重画棋盘：白底 + 淡格线 + 食物 + 蛇身；局部刷新和整页渲染都走这里。
// Repaint the board: white base, pale grid, food and snake; shared by local and page draws.
static void draw_board(uint8_t *fb) {
    const EpdRect board = board_rect();
    ui_clear_rect_fast(fb, board);
    for (int i = 1; i < SNAKE_GRID; ++i) {
        ui_fill_rect_fast((EpdRect){board.x + i * SNAKE_CELL_PX, board.y, 1, SNAKE_BOARD_PX},
                          0xc0, fb);
        ui_fill_rect_fast((EpdRect){board.x, board.y + i * SNAKE_CELL_PX, SNAKE_BOARD_PX, 1},
                          0xc0, fb);
    }
    if (s_food_x >= 0 && s_food_y >= 0) {
        const int cx = board.x + s_food_x * SNAKE_CELL_PX + SNAKE_CELL_PX / 2;
        const int cy = board.y + s_food_y * SNAKE_CELL_PX + SNAKE_CELL_PX / 2;
        // 圆环加圆心，和方块蛇身一眼区分。/ A ring plus a dot reads apart from block segments.
        epd_fill_circle(cx, cy, 11, UI_GRAY_BLACK, fb);
        epd_fill_circle(cx, cy, 6, UI_GRAY_WHITE, fb);
        epd_fill_circle(cx, cy, 3, UI_GRAY_BLACK, fb);
    }
    for (int i = (int)s_length - 1; i >= 0; --i) {
        draw_block(fb, s_body_x[i], s_body_y[i], 2);
    }
    const int cx = board.x + s_body_x[0] * SNAKE_CELL_PX + SNAKE_CELL_PX / 2;
    const int cy = board.y + s_body_y[0] * SNAKE_CELL_PX + SNAKE_CELL_PX / 2;
    // 蛇头留一只白点眼睛，方向一眼可辨。/ A white eye shows the heading at a glance.
    ui_fill_rect_fast(
        (EpdRect){cx + s_dir_x * 7 - s_dir_y * 6 - 4, cy + s_dir_y * 7 + s_dir_x * 6 - 4, 9, 9},
        UI_GRAY_WHITE, fb);
}

static const char *state_label(void) {
    switch (s_state) {
        case SNAKE_RUNNING: return "游戏中";
        case SNAKE_PAUSED: return "已暂停";
        case SNAKE_OVER: return "游戏结束";
        default: return "等待开始";
    }
}

// 状态行：左分数、中最高分、右状态，三段按棋盘宽度对齐。
// Status row: score left, best centre, state right, aligned to the board width.
static void draw_status(uint8_t *fb) {
    char score[20];
    char best[20];
    snprintf(score, sizeof(score), "分数 %u", (unsigned)s_score);
    snprintf(best, sizeof(best), "最高 %u", (unsigned)s_best);
    const EpdRect board = board_rect();
    // 分数/最高分位数变化时先清整行白底：AREA 差分只推变化像素，旧字形留在 fb 里会形成
    // “新分数叠在旧分数上”的叠影。清底带在棋盘下边框（y=742）与按钮（y≥808）之间。
    // Clear the whole status band first: an AREA differential only drives changed pixels, so stale
    // glyphs would stay in fb and the new score would appear layered over the old one. The band sits
    // between the board's bottom frame (y=742) and the buttons (y>=808).
    ui_fill_rect_fast((EpdRect){12, 744, 660, 58}, UI_GRAY_WHITE, fb);
    ui_text_fixed_vc(fb, board.x, SNAKE_STATUS_CY, 30, score, EPD_DRAW_ALIGN_LEFT, false);
    ui_text_fixed_vc(fb, board.x + board.width / 2, SNAKE_STATUS_CY, 30, best,
                     EPD_DRAW_ALIGN_CENTER, false);
    ui_text_fixed_vc(fb, board.x + board.width, SNAKE_STATUS_CY, 30, state_label(),
                     EPD_DRAW_ALIGN_RIGHT, false);
}

// 主按钮按状态换“开始/继续/暂停”，重开按钮始终次要样式。
// The primary button shows start/resume/pause by state; restart stays secondary.
static void draw_controls(uint8_t *fb) {
    const char *label = s_state == SNAKE_RUNNING ? "暂停" :
                        s_state == SNAKE_PAUSED ? "继续" : "开始";
    feature_draw_button(fb, s_start_button, label, s_state != SNAKE_RUNNING);
    feature_draw_button(fb, s_restart_button, "重新开始", false);
}

// 方向键：深底白箭头；轻点只排队转向，不必重画按钮。
// Direction keys are white arrows on dark buttons; taps only queue a turn, no repaint needed.
static void draw_pad_key(uint8_t *fb, EpdRect rect, int8_t dx, int8_t dy) {
    feature_draw_button(fb, rect, NULL, true);
    const int cx = rect.x + rect.width / 2;
    const int cy = rect.y + rect.height / 2;
    const int tip = 30;
    const int half = 28;
    if (dx != 0) {
        epd_fill_triangle(cx + dx * tip, cy, cx - dx * half, cy - half, cx - dx * half, cy + half,
                          UI_GRAY_WHITE, fb);
    } else {
        epd_fill_triangle(cx, cy + dy * tip, cx - half, cy - dy * half, cx + half, cy - dy * half,
                          UI_GRAY_WHITE, fb);
    }
}

// 十字方向键 + 中心小方块，把四键在视觉上连成一区。
// Cross D-pad plus a small hub block so the four keys read as one control.
static void draw_dpad(uint8_t *fb) {
    draw_pad_key(fb, s_pad_up, 0, -1);
    draw_pad_key(fb, s_pad_down, 0, 1);
    draw_pad_key(fb, s_pad_left, -1, 0);
    draw_pad_key(fb, s_pad_right, 1, 0);
    ui_fill_round_rect(fb, (EpdRect){438, 964, 40, 40}, 12, 0x20);
}

static void snake_render(uint8_t *fb, app_ctx_t *ctx) {
    (void)ctx;
    const EpdRect board = board_rect();
    // 棋盘外框画在棋盘矩形之外，局部刷新只推棋盘内部，框线不必重画。
    // The board frame sits outside the playfield rect, so local updates skip it.
    ui_draw_control_frame(fb,
                          (EpdRect){board.x - 2, board.y - 2, board.width + 4, board.height + 4},
                          4, 0x70);
    draw_status(fb);
    draw_board(fb);
    draw_controls(fb);
    draw_dpad(fb);
}

/* ---- 玩法 / Gameplay ---- */
// 失败：定格在最后合法位置，更新最高分并播两声下行短音；蜂鸣只在 tick 里调用。
// Failure: freeze, refresh the best score and play two falling tones; buzzer only from tick.
static void fail_game(void) {
    s_state = SNAKE_OVER;
    if (s_score > s_best) s_best = s_score;
    s_steps_since_page = 0;
    read_pico_buzzer_tone(392, 120);
    read_pico_buzzer_tone(262, 120);
}

// 整体前移一格并写入新蛇头；grow 时尾部保留、长度加一。
// Shift one cell and write the new head; with grow the tail stays and the length increases.
static void move_head(int x, int y, bool grow) {
    const int last = grow ? (int)s_length : (int)s_length - 1;
    for (int i = last; i > 0; --i) {
        s_body_x[i] = s_body_x[i - 1];
        s_body_y[i] = s_body_y[i - 1];
    }
    if (grow) ++s_length;
    s_body_x[0] = (int8_t)x;
    s_body_y[0] = (int8_t)y;
}

// 走一步：提交排队方向、判墙与自身；普通步局部刷棋盘，吃食物或满 20 步清残影。清残影时浅色
// 模式整页重绘，反色模式先压黑清理再整页差分重绘。
// One step: commit the turn, test walls/self; normal steps refresh the area, while eating or every
// 20 steps runs the cleanup. Light mode repaints the page; inverted mode settles the black ground
// first and then repaints differentially.
static app_redraw_t step_game(app_ctx_t *ctx) {
    s_dir_x = s_turn_x;
    s_dir_y = s_turn_y;
    const int head_x = s_body_x[0] + s_dir_x;
    const int head_y = s_body_y[0] + s_dir_y;
    const bool eat = head_x == s_food_x && head_y == s_food_y;
    if (head_x < 0 || head_x >= SNAKE_GRID || head_y < 0 || head_y >= SNAKE_GRID ||
        snake_hits(head_x, head_y, !eat)) {
        fail_game();
        return APP_REDRAW_PAGE;
    }
    if (eat) {
        const int old_food_x = s_food_x, old_food_y = s_food_y;
        move_head(head_x, head_y, true);
        ++s_score;
        if (s_score > s_best) s_best = s_score;
        place_food();
        // 吃到食物不再整屏重画（之前每吃一次就闪一次）：只更新旧食物、新食物、旧头/新头与
        // 状态行分数所在的脏区；满 20 步的整页清理负责清残影。
        // Eating food no longer repaints the whole page (it used to flash on every bite): only the
        // old/new food cells, old/new head and the score row are refreshed; the 20-step page cleanup
        // clears the accumulated residue.
        draw_board(ctx->fb);
        draw_status(ctx->fb);
        EpdRect cells[4];
        int n = 0;
        cells[n++] = snake_cell_rect(head_x, head_y);
        if (s_length >= 2) cells[n++] = snake_cell_rect(s_body_x[1], s_body_y[1]);
        cells[n++] = snake_cell_rect(old_food_x, old_food_y);
        cells[n++] = snake_cell_rect(s_food_x, s_food_y);
        int left = cells[0].x, top = cells[0].y;
        int right = cells[0].x + cells[0].width, bottom = cells[0].y + cells[0].height;
        for (int i = 1; i < n; ++i) {
            if (cells[i].x < left) left = cells[i].x;
            if (cells[i].y < top) top = cells[i].y;
            if (cells[i].x + cells[i].width > right) right = cells[i].x + cells[i].width;
            if (cells[i].y + cells[i].height > bottom) bottom = cells[i].y + cells[i].height;
        }
        const EpdRect board = board_rect();
        if (board.x < left) left = board.x;
        if (board.x + board.width > right) right = board.x + board.width;
        if (SNAKE_STATUS_CY - 22 < top) top = SNAKE_STATUS_CY - 22;
        if (SNAKE_STATUS_CY + 22 > bottom) bottom = SNAKE_STATUS_CY + 22;
        s_dirty_area = (EpdRect){left, top, right - left, bottom - top};
        if (++s_steps_since_page >= SNAKE_PAGE_STEPS) {
            s_steps_since_page = 0;
            // 本帧棋盘与分数行已画好。反色模式先只压物理黑底（不驱动字形，无白闪），再走整页
            // 差分重绘；浅色模式保持原整页刷新。
            // This frame's board and score row are already painted. Inverted mode presses only the
            // physical black ground (never glyphs, no white flash), then takes the differential page
            // exit; light mode keeps the original page refresh.
            if (epd_get_inverted()) display_dark_settle(ctx->hl);
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_AREA;
    }
    const int old_tail_x = s_body_x[s_length - 1];
    const int old_tail_y = s_body_y[s_length - 1];
    move_head(head_x, head_y, false);
    // 新头写入、原尾格清空是这一步唯一变化的像素；只把这两格推上屏。
    // Only the new head and the vacated tail cell change this step; push just those cells.
    {
        // 旧蛇头这一格也要推：它从“带白眼的头”变成普通身段，不推就会留下一串白眼。
        // The old head cell must be pushed too: it changes from an eyed head into a body cell,
        // otherwise every step leaves another pair of eyes on the board.
        EpdRect cells[3];
        int n = 0;
        cells[n++] = snake_cell_rect(head_x, head_y);
        cells[n++] = snake_cell_rect(old_tail_x, old_tail_y);
        if (s_length >= 2) cells[n++] = snake_cell_rect(s_body_x[1], s_body_y[1]);
        int left = cells[0].x, top = cells[0].y;
        int right = cells[0].x + cells[0].width, bottom = cells[0].y + cells[0].height;
        for (int i = 1; i < n; ++i) {
            if (cells[i].x < left) left = cells[i].x;
            if (cells[i].y < top) top = cells[i].y;
            if (cells[i].x + cells[i].width > right) right = cells[i].x + cells[i].width;
            if (cells[i].y + cells[i].height > bottom) bottom = cells[i].y + cells[i].height;
        }
        s_dirty_area = (EpdRect){left, top, right - left, bottom - top};
    }
    if (++s_steps_since_page >= SNAKE_PAGE_STEPS) {
        s_steps_since_page = 0;
        // 反色模式先把本帧棋盘画进 fb（压黑清理只认逻辑白底，目标集必须来自新画面），再压黑并
        // 走整页差分重绘；浅色模式保持原整页刷新，不提前画。
        // Inverted mode paints this frame's board into fb first (the darken settle targets the
        // logical-white ground, so the set must come from the new frame), settles, then takes the
        // differential page exit; light mode keeps the original page refresh without the extra paint.
        if (epd_get_inverted()) {
            draw_board(ctx->fb);
            display_dark_settle(ctx->hl);
        }
        return APP_REDRAW_PAGE;
    }
    // 局部刷新：主循环只推 area()，返回前必须先把棋盘画进 fb。
    // Local update: the loop only pushes area(), so paint the board into fb first.
    draw_board(ctx->fb);
    return APP_REDRAW_AREA;
}

static void start_round(app_ctx_t *ctx) {
    if (s_state == SNAKE_OVER) spawn_game();
    s_state = SNAKE_RUNNING;
    s_step_ms = ctx->now_ms + SNAKE_STEP_MS;
    s_steps_since_page = 0;
}

// 排队一次转向：不能相对已生效方向 180° 掉头；已排队的方向可被新方向覆盖，
// 这样大按钮连点也不会卡住，真正的折返由下一格的自身碰撞兜底。
// Queue a turn: never reverse the committed direction. A queued turn may be replaced so quick
// taps on the big keys still register; an actual fold-back is caught by the self-hit test.
static void queue_turn(int8_t dx, int8_t dy) {
    if (dx == -s_dir_x && dy == -s_dir_y) return;
    s_turn_x = dx;
    s_turn_y = dy;
}

/* ---- feature_body_t 回调 / Callbacks ---- */
static void snake_enter(app_ctx_t *ctx) {
    (void)ctx;
    s_active = true;
    spawn_game();
}

static void snake_exit(app_ctx_t *ctx) {
    (void)ctx;
    // 离页即停表，tick 不再走步；重进时重新开局。
    // Leaving stops the clock so tick no longer steps; re-entering starts a fresh round.
    s_active = false;
    if (s_state == SNAKE_RUNNING) s_state = SNAKE_PAUSED;
}

static app_redraw_t snake_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (!s_active || ev == NULL) return APP_REDRAW_NONE;
    if (ev->type == UI_GESTURE_TAP) {
        if (ui_rect_hit(s_start_button, ev->x0, ev->y0)) {
            if (s_state == SNAKE_RUNNING) {
                s_state = SNAKE_PAUSED;
            } else {
                start_round(ctx);
            }
            return APP_REDRAW_PAGE;
        }
        if (ui_rect_hit(s_restart_button, ev->x0, ev->y0)) {
            spawn_game();
            return APP_REDRAW_PAGE;
        }
        // 方向键只在局内有效；转向本身不改变画面，等下一步局部刷新棋盘即可。
        // The D-pad works while a round is live; a turn changes nothing until the next step.
        if (s_state != SNAKE_OVER) {
            if (ui_rect_hit(s_pad_up, ev->x0, ev->y0)) queue_turn(0, -1);
            else if (ui_rect_hit(s_pad_down, ev->x0, ev->y0)) queue_turn(0, 1);
            else if (ui_rect_hit(s_pad_left, ev->x0, ev->y0)) queue_turn(-1, 0);
            else if (ui_rect_hit(s_pad_right, ev->x0, ev->y0)) queue_turn(1, 0);
        }
        return APP_REDRAW_NONE;
    }
    // 棋盘滑动作为补充转向；状态行和按钮区的滑动不处理。
    // Board swipes steer too; swipes on the status row or buttons are ignored.
    if (s_state != SNAKE_OVER && ui_rect_hit(board_rect(), ev->x0, ev->y0)) {
        switch (ev->type) {
            case UI_GESTURE_SWIPE_U: queue_turn(0, -1); break;
            case UI_GESTURE_SWIPE_D: queue_turn(0, 1); break;
            case UI_GESTURE_SWIPE_L: queue_turn(-1, 0); break;
            case UI_GESTURE_SWIPE_R: queue_turn(1, 0); break;
            default: break;
        }
    }
    return APP_REDRAW_NONE;
}

static app_redraw_t snake_tick(app_ctx_t *ctx) {
    if (!s_active || s_state != SNAKE_RUNNING) return APP_REDRAW_NONE;
    if (ctx->now_ms < s_step_ms) return APP_REDRAW_NONE;
    s_step_ms = ctx->now_ms + SNAKE_STEP_MS;
    return step_game(ctx);
}

// 每步只推变化的格子（新头和空出的尾格）：整块棋盘局部刷新会长时间占住面板，
// 触摸采样被挡住，按钮就显得“按不动”。
// Push only the cells that changed (new head and the vacated tail cell): refreshing the whole
// board kept the panel busy long enough to swallow touches, so buttons felt unresponsive.
static EpdRect snake_cell_rect(int cx, int cy) {
    const EpdRect b = board_rect();
    const int cell = b.width / SNAKE_GRID;
    return (EpdRect){b.x + cx * cell - 1, b.y + cy * cell - 1, cell + 2, cell + 2};
}
static EpdRect snake_area(app_ctx_t *ctx) {
    (void)ctx;
    return s_dirty_area.width > 0 ? s_dirty_area : board_rect();
}

// 入口页按索引取用；只导出这一份，其余符号留在本文件内。
// Indexed by the hub; this is the only exported symbol, everything else stays private.
const feature_body_t feature_body_snake = {
    .enter = snake_enter,
    .exit = snake_exit,
    .render = snake_render,
    .gesture = snake_gesture,
    .tick = snake_tick,
    .area = snake_area,
};
