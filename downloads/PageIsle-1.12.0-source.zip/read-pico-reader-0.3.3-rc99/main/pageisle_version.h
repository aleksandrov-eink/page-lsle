/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 页屿系统版本：与上游应用版本（0.3.3-rc99）分开递增，用于网页内测/正式通道和更新说明。
 * PageIsle system version: bumped independently of the upstream app version (0.3.3-rc99), used by
 * the beta/stable web channels and the release-notes page.
 */
#pragma once

#define PAGEISLE_SYSTEM_VERSION "1.12.0"
#define PAGEISLE_SYSTEM_DATE "2026-10-25"

