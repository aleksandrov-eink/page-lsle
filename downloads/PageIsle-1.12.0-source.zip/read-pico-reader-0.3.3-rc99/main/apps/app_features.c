/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：特色功能入口页。底部导航第 2 栏；2×4 圆角卡片铺满内容区，图标与文字全部在固件内
 *       绘制，不依赖卡上资源。入口页负责页眉、内容卡片和底栏，具体功能实现为
 *       feature_body_t 子页（番茄、闹钟、游戏、待办），长按硬件中键返回入口页。
 * English: Feature hub page, second tab in the bottom bar. A 2x4 rounded-card grid fills the
 *          content area with firmware-drawn icons and labels. The hub owns the header, content
 *          card and navigation bar; each feature is a feature_body_t child (Pomodoro, alarm,
 *          games, to-dos), and holding the hardware middle key returns to the hub.
 *
 * 冻结：render 纯绘制；子页副作用只经 enter/gesture/tick 触发。
 * Frozen: render stays pure; child side effects only through enter/gesture/tick.
 */
#include <stdio.h>
#include <string.h>

#include "app.h"
#include "app_registry.h"
#include "esp_log.h"
#include "esp_random.h"
#include "feature_common.h"
#include "ui_gesture.h"
#include "ui_kit.h"
#include "ui_nav.h"
#include "ui_menu.h"

static const char *TAG = "feature_hub";

typedef enum {
    FEATURE_HUB = 0,
    FEATURE_SNAKE,
    FEATURE_TETRIS,
    FEATURE_2048,
    FEATURE_GOMOKU,
    FEATURE_POMODORO,
    FEATURE_ALARM,
    FEATURE_COIN,
    FEATURE_TODO,
} feature_view_t;

typedef struct {
    const char *name;
    const char *detail;
} feature_desc_t;

static const feature_desc_t s_features[] = {
    {"贪吃蛇", "吃满分数，别撞墙"},
    {"俄罗斯方块", "消行得分，越堆越高"},
    {"2048", "滑动合并，到 2048"},
    {"五子棋", "人机对战，简单 / 困难"},
    {"番茄时钟", "专注计时，到点提醒"},
    {"闹钟", "周一到周日定时提醒"},
    {"做个决定", "投一枚硬币"},
    {"待办事项", "记下今天要做的事"},
};
#define FEATURE_COUNT ((int)(sizeof(s_features) / sizeof(s_features[0])))

static feature_view_t s_view = FEATURE_HUB;
static const feature_body_t *s_active;
static int s_pressed = -1;
// 硬币：0 未投，1 正面，2 反面；anim>0 时显示翻面过渡。
static uint8_t s_coin_result, s_coin_anim;
static int64_t s_coin_next_ms;

// 已接入的子页；待办页在后续批次追加到这张表。
// Children wired so far; the to-do page is appended in a later batch.
static const feature_body_t *body_for_view(feature_view_t view) {
    switch (view) {
        case FEATURE_SNAKE: return &feature_body_snake;
        case FEATURE_TETRIS: return &feature_body_tetris;
        case FEATURE_2048: return &feature_body_2048;
        case FEATURE_GOMOKU: return &feature_body_gomoku;
        case FEATURE_POMODORO: return &feature_body_pomodoro;
        case FEATURE_ALARM: return &feature_body_alarm;
        case FEATURE_TODO: return &feature_body_todo;
        default: return NULL;
    }
}

static EpdRect feature_cell_rect(int index) {
    const int left = 36, top = 176, gap = 16;
    const int width = (UI_LOCK_WIDTH - 72 - gap) / 2;
    const int bottom = UI_NAV_TOP - 24;
    const int height = (bottom - top - 3 * gap) / 4;
    return (EpdRect){left + (index % 2) * (width + gap),
                     top + (index / 2) * (height + gap), width, height};
}

// 图标统一按 64px 盒、4px 轴对齐笔画绘制，线宽/密度与底栏 Lucide 图标一致；
// 全部水平/垂直/正圆，杜绝细线歪斜。
// All feature icons use a 64 px box with 4 px axis-aligned strokes, matching the weight of the
// Lucide bar icons; only horizontal/vertical lines and true circles, no thin skewed geometry.
static void thick_hline(uint8_t *fb, int x0, int x1, int cy, int t, uint8_t ink) {
    if (x1 <= x0 || t <= 0) return;
    ui_fill_rect_fast((EpdRect){x0, cy - t / 2, x1 - x0, t}, ink, fb);
}
static void thick_vline(uint8_t *fb, int cx, int y0, int y1, int t, uint8_t ink) {
    if (y1 <= y0 || t <= 0) return;
    ui_fill_rect_fast((EpdRect){cx - t / 2, y0, t, y1 - y0}, ink, fb);
}
static void thick_ring(uint8_t *fb, int cx, int cy, int r, int t, uint8_t ink) {
    for (int i = 0; i < t; ++i) epd_draw_circle(cx, cy, r - i, ink, fb);
}
static void icon_block(uint8_t *fb, int x, int y, int w, int h, uint8_t ink) {
    ui_fill_round_rect(fb, (EpdRect){x, y, w, h}, 6, ink);
}

static void icon_snake(uint8_t *fb, int cx, int cy, uint8_t ink) {
    const int s = 16, gap = 4;
    icon_block(fb, cx + 2 + gap, cy - 30, s, s, ink);
    icon_block(fb, cx + 2, cy - 30, s, s, ink);
    icon_block(fb, cx + 2, cy - 10, s, s, ink);
    icon_block(fb, cx - 18, cy - 10, s, s, ink);
    icon_block(fb, cx - 18, cy + 10, s, s, ink);
    icon_block(fb, cx + 2, cy + 10, s + 4, s + 4, ink);
    epd_fill_circle(cx + 11, cy + 15, 2, UI_GRAY_WHITE, fb);
}

static void icon_tetris(uint8_t *fb, int cx, int cy, uint8_t ink) {
    const int s = 16, gap = 2;
    // 对称的 T 形方阵，全部轴对齐。
    icon_block(fb, cx - s - gap, cy - s * 2 - gap * 2, s, s, ink);
    icon_block(fb, cx, cy - s * 2 - gap * 2, s, s, ink);
    icon_block(fb, cx + s + gap, cy - s * 2 - gap * 2, s, s, ink);
    icon_block(fb, cx, cy - s - gap, s, s, ink);
    icon_block(fb, cx, cy, s, s, ink);
    icon_block(fb, cx, cy + s + gap, s, s, ink);
}

static void icon_2048(uint8_t *fb, int cx, int cy, uint8_t ink) {
    const int s = 24, gap = 6;
    const int x0 = cx - s - gap / 2, y0 = cy - s - gap / 2;
    icon_block(fb, x0, y0, s, s, ink);
    icon_block(fb, x0 + s + gap, y0, s, s, ink);
    icon_block(fb, x0, y0 + s + gap, s, s, ink);
    icon_block(fb, x0 + s + gap, y0 + s + gap, s, s, ink);
    // 右下角留白短块，表示“合并出 2048”。
    ui_fill_round_rect(fb, (EpdRect){x0 + s + gap + 8, y0 + s + gap + 8, 8, 8}, 2, UI_GRAY_WHITE);
}

static void icon_gomoku(uint8_t *fb, int cx, int cy, uint8_t ink) {
    const int half = 28, gap = 14;
    for (int i = -2; i <= 2; ++i) {
        thick_hline(fb, cx - half, cx + half + 1, cy + i * gap, 3, ink);
        thick_vline(fb, cx + i * gap, cy - half, cy + half + 1, 3, ink);
    }
    epd_fill_circle(cx - gap, cy - gap, 7, ink, fb);
    epd_fill_circle(cx + gap, cy + gap, 7, ink, fb);
    thick_ring(fb, cx + gap, cy - gap, 7, 3, ink);
    thick_ring(fb, cx - gap, cy + gap, 7, 3, ink);
}

static void icon_pomodoro(uint8_t *fb, int cx, int cy, uint8_t ink) {
    ui_draw_icon(fb, cx, cy, 64, UI_ICON_TIMER, ink);
}

static void icon_alarm(uint8_t *fb, int cx, int cy, uint8_t ink) {
    ui_draw_icon(fb, cx, cy, 64, UI_ICON_CLOCK, ink);
}

static void icon_coin(uint8_t *fb, int cx, int cy, uint8_t ink) {
    thick_ring(fb, cx, cy, 26, 4, ink);
    ui_text_fixed_vc(fb, cx, cy, 30, "1", EPD_DRAW_ALIGN_CENTER, false);
    thick_hline(fb, cx - 18, cx + 19, cy + 12, 3, ink);
}

static void icon_todo(uint8_t *fb, int cx, int cy, uint8_t ink) {
    ui_draw_icon(fb, cx, cy, 64, UI_ICON_LIST, ink);
}

static void draw_feature_icon(uint8_t *fb, int index, int cx, int cy) {
    const uint8_t ink = UI_GRAY_BLACK;
    switch (index) {
        case FEATURE_SNAKE - 1: icon_snake(fb, cx, cy, ink); break;
        case FEATURE_TETRIS - 1: icon_tetris(fb, cx, cy, ink); break;
        case FEATURE_2048 - 1: icon_2048(fb, cx, cy, ink); break;
        case FEATURE_GOMOKU - 1: icon_gomoku(fb, cx, cy, ink); break;
        case FEATURE_POMODORO - 1: icon_pomodoro(fb, cx, cy, ink); break;
        case FEATURE_ALARM - 1: icon_alarm(fb, cx, cy, ink); break;
        case FEATURE_COIN - 1: icon_coin(fb, cx, cy, ink); break;
        case FEATURE_TODO - 1: icon_todo(fb, cx, cy, ink); break;
        default: break;
    }
}

// 单张入口卡片：按下时只重画这一张，走局部 DU，不能整页刷新——整页刷新会让主循环
// 取消当前手势，松手时的 TAP 就永远到不了，表现为“按钮全都没反应”。
// One hub card: a press repaints only this card through a local DU. A whole-page repaint would
// make the loop cancel the active gesture, so the release TAP never arrives and every button
// looks dead.
static void draw_hub_card(uint8_t *fb, int index) {
    const EpdRect card = feature_cell_rect(index);
    const uint8_t fill = s_pressed == index ? 0xd8 : UI_GRAY_WHITE;
    ui_fill_round_rect(fb, card, 24, fill);
    ui_draw_control_frame(fb, card, 24, 0x70);
    draw_feature_icon(fb, index, card.x + card.width / 2, card.y + 78);
    ui_text_vc(fb, card.x + card.width / 2, card.y + card.height - 44, 27,
               s_features[index].name, EPD_DRAW_ALIGN_CENTER, false);
}

static void draw_hub(uint8_t *fb) {
    ui_clear_page(fb);
    ui_nav_status(fb);
    ui_text(fb, 36, 90, 52, "特色功能", EPD_DRAW_ALIGN_LEFT, false);
    for (int i = 0; i < FEATURE_COUNT; ++i) draw_hub_card(fb, i);
    ui_nav_draw(fb, 4);
}

// 做个决定：独立的功能页。必须自己清屏并画页眉/卡片/底栏，否则会残留入口页的卡片与图标，
// 看起来像“和特色功能界面重合”。
// Coin flip: a self-contained feature page. It must clear and paint its own header, card,
// footer hint and navigation, otherwise the hub's cards and icons stay underneath and the two
// interfaces look overlapped.
static void draw_coin_page(uint8_t *fb) {
    ui_clear_page(fb);
    ui_nav_status(fb);
    ui_text(fb, 36, 90, 46, "做个决定", EPD_DRAW_ALIGN_LEFT, false);
    ui_hairline(fb, 160, 36, 612, UI_GRAY_LIGHT);
    feature_draw_card(fb);
    const int cx = UI_LOCK_WIDTH / 2, cy = 420;
    thick_ring(fb, cx, cy, 150, 8, UI_GRAY_BLACK);
    const char *face = s_coin_anim ? "?" :
        (s_coin_result == 1 ? "正" : s_coin_result == 2 ? "反" : "?");
    ui_text_fixed_vc(fb, cx, cy, 96, face, EPD_DRAW_ALIGN_CENTER, false);
    const char *hint = s_coin_anim ? "投掷中…" :
        (s_coin_result ? (s_coin_result == 1 ? "正面朝上" : "反面朝上") : "点下方按钮投币");
    ui_text_fixed_vc(fb, cx, 640, 26, hint, EPD_DRAW_ALIGN_CENTER, false);
    const EpdRect button = {36, 800, 612, 100};
    ui_fill_round_rect(fb, button, 32, 0x20);
    ui_text_fixed_vc(fb, button.x + button.width / 2, button.y + button.height / 2, 30,
                     "投掷硬币", EPD_DRAW_ALIGN_CENTER, true);
    feature_draw_hint(fb, "长按中键返回入口");
    // 番茄钟/闹钟/待办/做个决定保留底栏；四个小游戏仍不画底栏（棋盘占满屏幕）。
    // Clock/alarm/to-do/coin keep the footer; the four games still hide it (the board owns the screen).
    ui_nav_draw(fb, 4);
}

// 子页骨架：页眉、内容卡片、底部提示和底栏都由入口页统一绘制。
// Child frame: header, content card, footer hint and navigation are drawn once by the hub.
static void draw_subpage(uint8_t *fb, app_ctx_t *ctx) {
    ui_clear_page(fb);
    ui_nav_status(fb);
    const int index = (int)s_view - 1;
    if (index < 0 || index >= FEATURE_COUNT) {
        draw_hub(fb);
        return;
    }
    ui_text(fb, 36, 90, 46, s_features[index].name, EPD_DRAW_ALIGN_LEFT, false);
    ui_hairline(fb, 160, 36, 612, UI_GRAY_LIGHT);
    feature_draw_card(fb);
    // 提示行先画：待办编辑态的键盘会从 y=560 画到 y≈1070，后画提示会把键盘底排盖住。
    // Paint the hint first: the to-do editor's keyboard covers y≈560..1070, so drawing the hint
    // afterwards would paint over its bottom row.
    feature_draw_hint(fb, "长按中键返回入口");
    if (s_active != NULL && s_active->render != NULL) {
        s_active->render(fb, ctx);
    } else {
        // 尚未接入的功能保持旧占位画面，入口页不会因为缺子页而空白。
        // Not-yet-wired features keep the old placeholder so the hub never goes blank.
        draw_feature_icon(fb, index, FEATURE_CARD_LEFT + FEATURE_CARD_WIDTH / 2,
                          FEATURE_CARD_TOP + 200);
        ui_text_fixed_vc(fb, FEATURE_CARD_LEFT + FEATURE_CARD_WIDTH / 2,
                         FEATURE_CARD_TOP + 380, 30, s_features[index].name,
                         EPD_DRAW_ALIGN_CENTER, false);
        ui_text_fixed_vc(fb, FEATURE_CARD_LEFT + FEATURE_CARD_WIDTH / 2,
                         FEATURE_CARD_TOP + 434, 21, s_features[index].detail,
                         EPD_DRAW_ALIGN_CENTER, false);
        ui_text_fixed_vc(fb, FEATURE_CARD_LEFT + FEATURE_CARD_WIDTH / 2,
                         FEATURE_CARD_TOP + 620, 20, "此功能在后续里程碑接入",
                         EPD_DRAW_ALIGN_CENTER, false);
    }
    // 非游戏子页保留底栏（游戏页在 draw_game_page 里不画）。
    // Non-game sub-pages keep the footer (game pages omit it in draw_game_page).
    ui_nav_draw(fb, 4);
}

// 游戏子页专属：近全屏画布，顶部只保留游戏名和“长按中键返回”提示，不画状态栏、白卡、
// 页眉线和底栏，把整块屏幕让给棋盘与按钮。
// Game sub-pages get a near-full-screen canvas: only the title and the middle-hold hint stay at
// the top; the status bar, white card, header rule and navigation bar are omitted so the board
// and buttons own the whole screen.
static bool is_game_view(feature_view_t view) {
    return view >= FEATURE_SNAKE && view <= FEATURE_GOMOKU;
}

static void draw_game_page(uint8_t *fb, app_ctx_t *ctx) {
    ui_clear_page(fb);
    const int index = (int)s_view - 1;
    if (index < 0 || index >= FEATURE_COUNT) {
        draw_hub(fb);
        return;
    }
    ui_text(fb, 36, FEATURE_GAME_TITLE_Y, FEATURE_GAME_TITLE_PX, s_features[index].name,
            EPD_DRAW_ALIGN_LEFT, false);
    ui_text_fixed_vc(fb, UI_LOCK_WIDTH - 36,
                     FEATURE_GAME_TITLE_Y + FEATURE_GAME_TITLE_PX / 2, 20,
                     "长按中键返回", EPD_DRAW_ALIGN_RIGHT, false);
    if (s_active != NULL && s_active->render != NULL) s_active->render(fb, ctx);
}

static void leave_active_body(app_ctx_t *ctx) {
    if (s_active != NULL) {
        if (s_active->exit != NULL) s_active->exit(ctx);
        s_active = NULL;
    }
}

static void enter_view(app_ctx_t *ctx, feature_view_t view) {
    leave_active_body(ctx);
    s_view = view;
    s_pressed = -1;
    s_active = body_for_view(view);
    if (s_active != NULL && s_active->enter != NULL) s_active->enter(ctx);
}

static void render(app_ctx_t *ctx, uint8_t *fb) {
    if (s_view == FEATURE_HUB) draw_hub(fb);
    else if (s_view == FEATURE_COIN) draw_coin_page(fb);
    else if (is_game_view(s_view)) draw_game_page(fb, ctx);
    else draw_subpage(fb, ctx);
}

static void features_on_enter(app_ctx_t *ctx) {
    enter_view(ctx, FEATURE_HUB);
    ESP_LOGI(TAG, "feature hub enter");
}

static void features_on_exit(app_ctx_t *ctx) {
    leave_active_body(ctx);
    s_pressed = -1;
}

// 特色功能里只有入口页有底栏；所有子页（含游戏）底部都留白，主循环不得把底部触摸
// 特色功能里除四个小游戏外都有底栏；游戏页底部留白，主循环不得把底部触摸当作切页。
// Every feature view except the four games owns the footer; the loop must not treat bottom
// taps as navigation on game pages.
static bool features_navigation_enabled(app_ctx_t *ctx) {
    (void)ctx;
    return !is_game_view(s_view);
}

// 旧版右下角“功能”菜单把手在特色功能里全部关闭：二级页底部已无工具栏，点那个位置
// 不应再弹出旧菜单；入口页的右下角就是新底栏的“设置”，也不能被旧把手抢走。
// Disable the legacy bottom-right menu handle across the features app: sub-pages have no
// footer, and on the hub that corner belongs to the new navigation bar's Settings tab.
static bool features_menu_handle_enabled(app_ctx_t *ctx) {
    (void)ctx;
    return false;
}

// 只有入口页是“主页面”：子页（含游戏）必须报告 false，否则主循环会把它们当主页处理，
// 中键长按会被 main_key_action 吃掉（回不了入口页），底栏区域也会被冻结。
// Only the hub counts as the main page: sub-pages must report false, otherwise the loop treats
// them as main pages (middle-hold goes to main_key_action and cannot return to the hub) and the
// footer region gets frozen into them.
static bool features_main_page_visible(app_ctx_t *ctx) {
    (void)ctx;
    return s_view == FEATURE_HUB;
}

static app_redraw_t on_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type == UI_GESTURE_PRESS) {
        const int previous = s_pressed;
        s_pressed = -1;
        if (s_view == FEATURE_HUB) {
            for (int i = 0; i < FEATURE_COUNT; ++i) {
                if (ui_rect_hit(feature_cell_rect(i), ev->x0, ev->y0)) s_pressed = i;
            }
            // 按下反馈必须走局部刷新：整页刷新会让主循环取消手势，松手 TAP 丢失。
            // Press feedback must be local: a full-page repaint would cancel the gesture and the
            // release TAP would never arrive.
            if (s_pressed >= 0) {
                draw_hub_card(ctx->fb, s_pressed);
                return APP_REDRAW_AREA;
            }
            if (previous >= 0) return APP_REDRAW_AREA;
            return APP_REDRAW_NONE;
        }
        if (s_view != FEATURE_COIN && s_active != NULL && s_active->gesture != NULL) {
            return s_active->gesture(ctx, ev);
        }
        return APP_REDRAW_NONE;
    }
    if (ev->type == UI_GESTURE_CANCEL) {
        if (s_pressed >= 0) {
            const int index = s_pressed;
            s_pressed = -1;
            draw_hub_card(ctx->fb, index);
            return APP_REDRAW_AREA;
        }
        if (s_view != FEATURE_HUB && s_view != FEATURE_COIN &&
            s_active != NULL && s_active->gesture != NULL) {
            return s_active->gesture(ctx, ev);
        }
        return APP_REDRAW_NONE;
    }
    if (ev->type != UI_GESTURE_TAP) {
        // 滑动/长按等交给子页（游戏滑动操作），入口页只认识轻点。
        // Swipes and holds go to the child (game controls); the hub only interprets taps.
        if (s_view != FEATURE_HUB && s_view != FEATURE_COIN &&
            s_active != NULL && s_active->gesture != NULL) {
            return s_active->gesture(ctx, ev);
        }
        return APP_REDRAW_NONE;
    }
    // 游戏页没有底栏，底部坐标不能当成切页；其他页面恢复底栏切页。
    // Game pages have no footer, so bottom taps are never navigation there; other views
    // restore normal footer switching.
    int tab = ui_nav_hit(ev->x0, ev->y0);
    if (tab >= 0 && !is_game_view(s_view)) {
        s_pressed = -1;
        // 子页点「特色」= 回入口页；其他栏正常切页。
        if (tab == 4 && s_view != FEATURE_HUB) {
            enter_view(ctx, FEATURE_HUB);
            return APP_REDRAW_PAGE;
        }
        ui_nav_request(ctx, tab);
        return APP_REDRAW_NONE;
    }
    if (s_view == FEATURE_COIN) {
        if (ev->y0 >= 800 && ev->y0 < 900 && !s_coin_anim) {
            s_coin_result = (uint8_t)(1 + esp_random() % 2);
            s_coin_anim = 4;
            s_coin_next_ms = ctx->now_ms + 120;
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_view == FEATURE_HUB) {
        for (int i = 0; i < FEATURE_COUNT; ++i) {
            if (ui_rect_hit(feature_cell_rect(i), ev->x0, ev->y0)) {
                s_pressed = -1;
                enter_view(ctx, (feature_view_t)(FEATURE_SNAKE + i));
                return APP_REDRAW_PAGE;
            }
        }
        return APP_REDRAW_NONE;
    }
    if (s_active != NULL && s_active->gesture != NULL) {
        return s_active->gesture(ctx, ev);
    }
    return APP_REDRAW_NONE;
}

static app_redraw_t on_key_long(app_ctx_t *ctx, int key) {
    if (key != UI_KEY_2) return APP_REDRAW_NONE;
    if (s_view != FEATURE_HUB) {
        enter_view(ctx, FEATURE_HUB);
        return APP_REDRAW_PAGE;
    }
    ctx->request_app = app_home_page();
    return APP_REDRAW_NONE;
}

static app_redraw_t on_key(app_ctx_t *ctx, int key) {
    (void)ctx;
    (void)key;
    return APP_REDRAW_NONE;
}

// 推屏期间捕获的轻点：游戏页不能丢，否则开始/重开/方向键看起来“按不动”。
// Captured taps must reach game pages, otherwise the start/restart and direction buttons look
// unresponsive while the panel is refreshing.
#define FEATURE_CAP_TAPS 3
static uint8_t s_cap_tap_n;
static uint16_t s_cap_tap_x[FEATURE_CAP_TAPS], s_cap_tap_y[FEATURE_CAP_TAPS];
static void features_captured_tap(app_ctx_t *ctx, uint16_t x, uint16_t y) {
    (void)ctx;
    if (!is_game_view(s_view) || s_active == NULL || s_active->gesture == NULL) return;
    if (s_cap_tap_n >= FEATURE_CAP_TAPS) return;
    s_cap_tap_x[s_cap_tap_n] = x;
    s_cap_tap_y[s_cap_tap_n] = y;
    ++s_cap_tap_n;
}
static app_redraw_t on_tick(app_ctx_t *ctx) {
    while (s_cap_tap_n > 0) {
        if (!is_game_view(s_view) || s_active == NULL || s_active->gesture == NULL) { s_cap_tap_n = 0; break; }
        const uint16_t cx = s_cap_tap_x[0], cy = s_cap_tap_y[0];
        for (uint8_t i = 1; i < s_cap_tap_n; ++i) {
            s_cap_tap_x[i - 1] = s_cap_tap_x[i];
            s_cap_tap_y[i - 1] = s_cap_tap_y[i];
        }
        --s_cap_tap_n;
        ui_gesture_event_t ev = {0};
        ev.type = UI_GESTURE_TAP;
        ev.x0 = cx;
        ev.y0 = cy;
        ev.x = cx;
        ev.y = cy;
        app_redraw_t redraw = s_active->gesture(ctx, &ev);
        if (redraw != APP_REDRAW_NONE) return redraw;
    }
    if (s_view == FEATURE_COIN && s_coin_anim && ctx->now_ms >= s_coin_next_ms) {
        --s_coin_anim;
        s_coin_next_ms = ctx->now_ms + 120;
        return APP_REDRAW_PAGE;
    }
    if (s_view != FEATURE_HUB && s_view != FEATURE_COIN &&
        s_active != NULL && s_active->tick != NULL) {
        return s_active->tick(ctx);
    }
    return APP_REDRAW_NONE;
}

static EpdRect area_hint(app_ctx_t *ctx) {
    if (s_view == FEATURE_HUB && s_pressed >= 0 && s_pressed < FEATURE_COUNT) {
        return feature_cell_rect(s_pressed);
    }
    if (s_view != FEATURE_HUB && s_view != FEATURE_COIN &&
        s_active != NULL && s_active->area != NULL) {
        const EpdRect area = s_active->area(ctx);
        if (area.width > 0 && area.height > 0) return area;
    }
    return ui_content_refresh_area();
}

const app_desc_t app_features = {
    .binary_ui = true,
    .title = "特色功能 Features",
    .detail = "小游戏 / 番茄钟 / 闹钟 / 待办",
    .enter_full = false,
    .owns_keys = true,
    // 入口页/子页由 main_page_visible 报告“有底栏”，游戏页报告“没有底栏”，
    // 避免底栏区域被主页刷新冻结在游戏页上。
    // The hub/sub-pages report a footer through main_page_visible while game pages report none,
    // so the main-page refresh never freezes the navigation bar onto a game page.
    .persistent_navigation = false,
    .navigation_enabled = features_navigation_enabled,
    .menu_handle_enabled = features_menu_handle_enabled,
    .main_page_visible = features_main_page_visible,
    .defer_middle_short = true,
    .page_owns_middle_hold = true,
    .on_enter = features_on_enter,
    .on_exit = features_on_exit,
    .render = render,
    .on_gesture = on_gesture,
    .on_captured_tap = features_captured_tap,
    .on_key = on_key,
    .on_key_long = on_key_long,
    .on_tick = on_tick,
    .area_hint = area_hint,
};
