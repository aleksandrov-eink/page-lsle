/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：特色功能里的 2048 子页。入口页只保留游戏名和右上「长按中键返回」，把
 *       (12,92,660,1084) 的近全屏画布交给子页；本文件在这块画布内绘制分数/最高分行、
 *       放大到 636×636 的 4×4 棋盘、状态行和「重新开始」按钮。上下左右滑动棋盘合并数字，
 *       首次合出 2048 时播胜利三连音；棋盘既无空格又没有可合并的相邻格时判负并播失败两音。
 * English: 2048 sub-page of the feature hub. The hub keeps only the game title and the
 *          middle-hold hint, handing a near-full-screen (12,92,660,1084) canvas to the child;
 *          this file paints the score/best line, an enlarged 636x636 4x4 board, the status line
 *          and the restart button inside it. Swipe to merge tiles; the first 2048 plays a
 *          three-note victory melody, and a board without empty cells or equal neighbours
 *          loses with a two-note failure melody.
 *
 * 冻结：render 只画像素，不蜂鸣、不分配内存、不写 NVS；蜂鸣只从 gesture 触发，每个音 ≤300ms；
 *       每步走子只返回 APP_REDRAW_PAGE，不做动画，也不返回局部刷新区域；只画游戏画布内部，
 *       不碰顶部标题区（y<92）和最下沿（y≥1176）。
 * Frozen: render paints pixels only: no buzzer, allocation or NVS write. Buzzing is reachable
 *         from the gesture callback only, and each tone lasts at most 300 ms. A move returns
 *         APP_REDRAW_PAGE only; no animation and no partial refresh region. Paint inside the
 *         game canvas only, never the title band (y<92) or the bottom edge (y>=1176).
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "esp_random.h"
#include "feature_common.h"
#include "read_pico_buzzer.h"
#include "ui_kit.h"

/* ---- 布局 / Layout ---- */

// 近全屏画布 660×1084：[12,92]-[672,1176]。棋盘按画布宽度取满：每格 150px、格间 12px，
// 整块 636px，左右各留 12px 到画布边。
// Near-full-screen canvas 660x1084: [12,92]-[672,1176]. The board uses the canvas width:
// 150 px tiles with 12 px gaps, 636 px overall and 12 px to each canvas edge.
#define BOARD_SIDE 4
#define TILE_COUNT (BOARD_SIDE * BOARD_SIDE)
#define TILE_SIDE 150
#define TILE_GAP 12
#define TILE_STEP (TILE_SIDE + TILE_GAP)
#define TILE_RADIUS 16
#define BOARD_WIDTH (BOARD_SIDE * TILE_STEP - TILE_GAP)
#define BOARD_LEFT ((UI_LOCK_WIDTH - BOARD_WIDTH) / 2)
#define BOARD_TOP 234

// 竖向排布：分数行（y=162 中心）→ 细线（y=198）→ 棋盘 234..870 → 状态行（y=918 中心）
// → 大按钮 976..1096，全部落在 92..1176 内。
// Vertical order: score line (center y=162), hairline (y=198), board 234..870, status line
// (center y=918), large button 976..1096, all within 92..1176.
#define SCORE_CY 162
#define SCORE_PX 34
#define RULE_Y 198
#define STATUS_CY 918
#define STATUS_PX 30

// 「重新开始」主按钮放大到 280×120，水平居中；标签用 36px 才配得上这块按钮。
// The primary restart button grows to 280x120 and is horizontally centered; a 36 px label fits
// its size.
#define RESTART_W 280
#define RESTART_H 120
#define RESTART_X ((UI_LOCK_WIDTH - RESTART_W) / 2)
#define RESTART_Y 976
#define RESTART_RADIUS 26
#define RESTART_PX 36

// 棋盘数字按位数选字号：3 位及以下 48px、4 位 44px、5 位（16384/32768）38px，保证连用户
// 自定义的宽字体也不会溢出 150px 方格。
// Board numbers shrink with their digit count: 48 px up to three digits, 44 px for four and
// 38 px for five (16384/32768), so even a wide user font stays inside a 150 px tile.
#define TILE_PX_MAX 48
#define TILE_PX_FOUR 44
#define TILE_PX_FIVE 38

// 空格底灰；数字格的灰阶由 tile_gray() 给出。/ Empty-cell gray; tile grays come from tile_gray().
#define EMPTY_GRAY 0xEC
#define EMPTY_FRAME_GRAY 0xB0
#define TILE_FRAME_GRAY 0x50

// 单格矩形，index 按行优先。/ One cell rectangle; index is row-major.
static EpdRect tile_rect(int index) {
    return (EpdRect){BOARD_LEFT + (index % BOARD_SIDE) * TILE_STEP,
                     BOARD_TOP + (index / BOARD_SIDE) * TILE_STEP,
                     TILE_SIDE, TILE_SIDE};
}

static EpdRect restart_rect(void) {
    return (EpdRect){RESTART_X, RESTART_Y, RESTART_W, RESTART_H};
}

/* ---- 棋局状态 / Game state ---- */

// 棋盘按 2 的幂存每格数值，0 表示空格；16 格只占 32 字节，不用大数组。
// The board stores one power of two per cell with 0 for empty; all 16 cells take 32 bytes, so
// no large arrays are needed.
static uint16_t s_tiles[TILE_COUNT];
static uint32_t s_score;
// 最高分只在本次开机内累计：本批次不碰 NVS，也不改共享设置。
// The best score lives for the current boot only: this batch touches neither NVS nor shared
// settings.
static uint32_t s_best;
static bool s_started; // 本次开机是否已开过一局 / a game has been started since boot
static bool s_won;     // 本局是否已合出 2048 / 2048 reached this game
static bool s_over;    // 本局是否已无路可走 / no move left this game
static bool s_new_win; // 本步是否刚合出 2048 / this move just created 2048

/* ---- 棋盘规则 / Board rules ---- */

// 滑动方向；枚举顺序跟手势一一对应，由 game_gesture() 显式映射。
// Swipe directions; the order matches the gestures, mapped explicitly in game_gesture().
typedef enum {
    DIR_LEFT = 0, ///< 左滑 / swipe left
    DIR_RIGHT,    ///< 右滑 / swipe right
    DIR_UP,       ///< 上滑 / swipe up
    DIR_DOWN,     ///< 下滑 / swipe down
} move_dir_t;

// 把一行/一列的第 slot 个位置映射到棋盘下标，四个方向共用同一套读写路径。
// Map slot slot of one line/column to a board index; all four directions share the same path.
static int tile_index(move_dir_t dir, int line, int slot) {
    switch (dir) {
        case DIR_LEFT:
            return line * BOARD_SIDE + slot;
        case DIR_RIGHT:
            return line * BOARD_SIDE + (BOARD_SIDE - 1 - slot);
        case DIR_UP:
            return slot * BOARD_SIDE + line;
        default:
            return (BOARD_SIDE - 1 - slot) * BOARD_SIDE + line;
    }
}

// 单行合并：先压缩空格，再让相同数值两两合并，每格每步最多合并一次。
// Merge one line: drop the gaps first, then merge equal neighbours; each tile merges at most
// once per move.
static void merge_line(const uint16_t *in, uint16_t *out) {
    bool merged[BOARD_SIDE] = {false};
    int count = 0;
    for (int i = 0; i < BOARD_SIDE; ++i) {
        const uint16_t value = in[i];
        if (value == 0) continue;
        if (count > 0 && !merged[count - 1] && out[count - 1] == value) {
            out[count - 1] = (uint16_t)(out[count - 1] * 2);
            merged[count - 1] = true;
            s_score += out[count - 1];
            if (!s_won && out[count - 1] == 2048) {
                s_won = true;
                s_new_win = true;
            }
        } else {
            out[count] = value;
            ++count;
        }
    }
    for (int i = count; i < BOARD_SIDE; ++i) out[i] = 0;
}

// 执行一次移动；棋盘有变化才返回 true。/ Apply one move; true only when the board changed.
static bool move_board(move_dir_t dir) {
    bool moved = false;
    s_new_win = false;
    for (int line = 0; line < BOARD_SIDE; ++line) {
        uint16_t in[BOARD_SIDE];
        uint16_t out[BOARD_SIDE] = {0};
        for (int slot = 0; slot < BOARD_SIDE; ++slot)
            in[slot] = s_tiles[tile_index(dir, line, slot)];
        merge_line(in, out);
        for (int slot = 0; slot < BOARD_SIDE; ++slot) {
            const int index = tile_index(dir, line, slot);
            if (s_tiles[index] != out[slot]) {
                s_tiles[index] = out[slot];
                moved = true;
            }
        }
    }
    return moved;
}

// 在随机空格生成一个新块：90% 出 2、10% 出 4，和常见 2048 一致。
// Spawn one new tile in a random empty cell: 90% a 2 and 10% a 4, as usual.
static void spawn_tile(void) {
    int empty = 0;
    for (int i = 0; i < TILE_COUNT; ++i)
        if (s_tiles[i] == 0) ++empty;
    if (empty == 0) return;
    int pick = (int)(esp_random() % (uint32_t)empty);
    for (int i = 0; i < TILE_COUNT; ++i) {
        if (s_tiles[i] != 0) continue;
        if (pick-- == 0) {
            s_tiles[i] = (esp_random() % 10u == 0u) ? 4 : 2;
            return;
        }
    }
}

// 还有空位，或存在可合并的相邻格，就还能走。/ A move is still possible with an empty cell or
// an equal neighbour.
static bool board_has_move(void) {
    for (int row = 0; row < BOARD_SIDE; ++row) {
        for (int col = 0; col < BOARD_SIDE; ++col) {
            const int index = row * BOARD_SIDE + col;
            if (s_tiles[index] == 0) return true;
            if (col + 1 < BOARD_SIDE && s_tiles[index] == s_tiles[index + 1]) return true;
            if (row + 1 < BOARD_SIDE && s_tiles[index] == s_tiles[index + BOARD_SIDE]) return true;
        }
    }
    return false;
}

// 开新局：清空棋盘、分数归零、先放两个块；最高分跨局保留。
// Start a new game: clear the board, zero the score and place two tiles; the best score
// survives between games.
static void new_game(void) {
    for (int i = 0; i < TILE_COUNT; ++i) s_tiles[i] = 0;
    s_score = 0;
    s_won = false;
    s_over = false;
    s_new_win = false;
    s_started = true;
    spawn_tile();
    spawn_tile();
}

/* ---- 短旋律 / Short melodies ---- */

// read_pico_buzzer_tone() 会阻塞到音长结束，只能在 gesture / tick / enter 里调用；render 不碰它。
// read_pico_buzzer_tone() blocks for the tone duration and is only called from gesture / tick /
// enter; render never touches it.
static void play_win_melody(void) {
    (void)read_pico_buzzer_tone(880, 90);
    (void)read_pico_buzzer_tone(1175, 90);
    (void)read_pico_buzzer_tone(1568, 90);
}

static void play_lose_melody(void) {
    (void)read_pico_buzzer_tone(392, 120);
    (void)read_pico_buzzer_tone(262, 120);
}

/* ---- 绘制 / Painting ---- */

// 数字格的底灰：数值越大底色越深，256 起用深底反白字。
// Tile fill: the larger the value the darker the fill; from 256 on the ink is inverted.
static uint8_t tile_gray(uint16_t value) {
    switch (value) {
        case 2:
            return 0xF2;
        case 4:
            return 0xE4;
        case 8:
            return 0xD0;
        case 16:
            return 0xC0;
        case 32:
            return 0xB0;
        case 64:
            return 0xA0;
        case 128:
            return 0x90;
        default:
            return 0x60;
    }
}

// 分数行：左分数、右最高分，与棋盘同宽对齐，下面一条浅色细线跟棋盘分开。
// Score line: score on the left, best on the right, aligned with the board width, with a light
// rule separating it from the board.
static void draw_score_row(uint8_t *fb) {
    char text[32];
    snprintf(text, sizeof(text), "分数 %lu", (unsigned long)s_score);
    ui_text_fixed_vc(fb, BOARD_LEFT, SCORE_CY, SCORE_PX, text, EPD_DRAW_ALIGN_LEFT, false);
    snprintf(text, sizeof(text), "最高分 %lu", (unsigned long)s_best);
    ui_text_fixed_vc(fb, BOARD_LEFT + BOARD_WIDTH, SCORE_CY, SCORE_PX, text,
                     EPD_DRAW_ALIGN_RIGHT, false);
    ui_hairline(fb, RULE_Y, BOARD_LEFT, BOARD_WIDTH, UI_GRAY_LIGHT);
}

// 4×4 棋盘：空格画浅灰底和浅框，数字格按数值给灰阶并居中写数字。
// The 4x4 board: empty cells get a light fill and frame, numbered tiles get their gray and the
// value centered inside.
static void draw_board(uint8_t *fb) {
    for (int i = 0; i < TILE_COUNT; ++i) {
        const EpdRect cell = tile_rect(i);
        const uint16_t value = s_tiles[i];
        ui_fill_round_rect(fb, cell, TILE_RADIUS, value ? tile_gray(value) : EMPTY_GRAY);
        ui_draw_round_rect(fb, cell, TILE_RADIUS, value ? TILE_FRAME_GRAY : EMPTY_FRAME_GRAY);
        if (value == 0) continue;
        const int px = value >= 10000 ? TILE_PX_FIVE : (value >= 1000 ? TILE_PX_FOUR : TILE_PX_MAX);
        char text[8];
        snprintf(text, sizeof(text), "%u", (unsigned)value);
        ui_text_fixed_vc(fb, cell.x + TILE_SIDE / 2, cell.y + TILE_SIDE / 2, px, text,
                         EPD_DRAW_ALIGN_CENTER, value >= 256);
    }
}

// 「重新开始」按钮：沿用主按钮的深底白字样式，但按 280×120 用 36px 标签重画。
// Restart button: same primary dark-fill/white-label style, redrawn with a 36 px label for the
// 280x120 size.
static void draw_restart_button(uint8_t *fb) {
    const EpdRect rect = restart_rect();
    ui_fill_round_rect(fb, rect, RESTART_RADIUS, 0x20);
    ui_draw_control_frame(fb, rect, RESTART_RADIUS, 0x20);
    ui_text_fixed_vc(fb, rect.x + rect.width / 2, rect.y + rect.height / 2, RESTART_PX,
                     "重新开始", EPD_DRAW_ALIGN_CENTER, true);
}

// 状态行优先级：无路可走 > 已达成 2048 > 操作提示。
// Status priority: no move left > 2048 reached > play hint.
static const char *status_text(void) {
    if (s_over) return "无路可走，点重新开始";
    if (s_won) return "达成 2048！继续滑动";
    return "上下左右滑动合并";
}

/* ---- 回调 / Callbacks ---- */

// 首次进入或上一局结束时开新局；没结束的棋局继续，离页再回来不会丢进度。
// Start a new game on first entry or after a finished one; an unfinished game continues, so
// leaving and returning does not lose progress.
static void game_enter(app_ctx_t *ctx) {
    (void)ctx;
    if (!s_started || s_over) new_game();
}

// 离页没有副作用：棋局留在静态变量里，回页继续。
// Leaving has no side effects: the game stays in RAM and resumes on return.
static void game_exit(app_ctx_t *ctx) { (void)ctx; }

// 纯绘制游戏画布内部；顶部游戏名和右上提示由入口页负责，页面其余部分是纯白底。
// Paint the game-canvas interior only; the hub owns the title and the top-right hint, and the
// rest of the page stays plain white.
static void game_render(uint8_t *fb, app_ctx_t *ctx) {
    (void)ctx;
    draw_score_row(fb);
    draw_board(fb);
    ui_text_fixed_vc(fb, UI_LOCK_WIDTH / 2, STATUS_CY, STATUS_PX, status_text(),
                     EPD_DRAW_ALIGN_CENTER, false);
    draw_restart_button(fb);
}

// 走一步后统一收尾：生成新块、刷新最高分、判定胜负并蜂鸣，然后整页重绘。
// Finish one move: spawn a tile, update the best score, decide win/lose and beep, then repaint
// the whole page.
static app_redraw_t apply_move(move_dir_t dir) {
    if (s_over) return APP_REDRAW_NONE;
    if (!move_board(dir)) return APP_REDRAW_NONE;
    spawn_tile();
    if (s_score > s_best) s_best = s_score;
    const bool won_now = s_new_win;
    s_over = !board_has_move();
    if (won_now) {
        play_win_melody();
    } else if (s_over) {
        play_lose_melody();
    }
    return APP_REDRAW_PAGE;
}

// 游戏画布内起手的滑动走子；轻点「重新开始」按钮重开一局。
// Swipes that start inside the game canvas move the board; a tap on the restart button resets
// it.
static app_redraw_t game_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    (void)ctx;
    if (ev->type == UI_GESTURE_TAP) {
        if (ui_rect_hit(restart_rect(), ev->x0, ev->y0)) {
            new_game();
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    move_dir_t dir;
    switch (ev->type) {
        case UI_GESTURE_SWIPE_L:
            dir = DIR_LEFT;
            break;
        case UI_GESTURE_SWIPE_R:
            dir = DIR_RIGHT;
            break;
        case UI_GESTURE_SWIPE_U:
            dir = DIR_UP;
            break;
        case UI_GESTURE_SWIPE_D:
            dir = DIR_DOWN;
            break;
        default:
            return APP_REDRAW_NONE;
    }
    // 顶部标题区和画布外的起手不属于棋盘，滑动直接忽略。
    // Swipes starting in the title band or outside the canvas are not board input and are
    // ignored.
    if (!ui_rect_hit(feature_game_rect(), ev->x0, ev->y0)) return APP_REDRAW_NONE;
    return apply_move(dir);
}

// 本页没有动画，tick 只回 NONE，避免空转整页刷新。
// This page has no animation; tick always returns NONE so it never repaints on its own.
static app_redraw_t game_tick(app_ctx_t *ctx) {
    (void)ctx;
    return APP_REDRAW_NONE;
}

// 只用整页刷新，不会请求 APP_REDRAW_AREA；仍返回一个有效矩形以满足接口契约。
// This page only repaints whole pages and never asks for APP_REDRAW_AREA; it still returns a
// valid rectangle to satisfy the contract.
static EpdRect game_area(app_ctx_t *ctx) {
    (void)ctx;
    return (EpdRect){BOARD_LEFT, BOARD_TOP, BOARD_WIDTH, BOARD_WIDTH};
}

const feature_body_t feature_body_2048 = {
    .enter = game_enter,
    .exit = game_exit,
    .render = game_render,
    .gesture = game_gesture,
    .tick = game_tick,
    .area = game_area,
};
