/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：五子棋人机对战子页。入口页顶部只保留游戏名和「长按中键返回」，其余近全屏画布
 *       都归本页；这里画状态行、放大的 15x15 棋盘和难度/重新开始/悔棋按钮，并实现简单
 *       与困难两档 AI。玩家执黑先手，电脑执白，落子后延时一拍再回应。
 * English: Gomoku versus-AI sub-page. The hub keeps only the title and the middle-hold hint
 *          on top; the near-full-screen canvas belongs to this page, which paints the status
 *          row, an enlarged 15x15 board and difficulty/restart/undo buttons, with easy and
 *          hard AI. The player moves first as black.
 *
 * 冻结：render 只画像素，禁止蜂鸣/写 NVS/切页；胜负短旋律只能在 gesture 或 tick 里播放。
 * Frozen: render paints pixels only; no buzzer, NVS writes or page switches. Result melodies
 *         play from gesture/tick only.
 */
#include "feature_common.h"

#include <string.h>

#include "read_pico_buzzer.h"
#include "ui_kit.h"

// 几何：全部绘制在近全屏游戏画布 FEATURE_GAME_* 内，棋盘 44px 格放大并居中。
// Geometry: near-full-screen FEATURE_GAME_* canvas, 44px cells, board centred.
enum {
    GN = 15, GCELL = 44, GSTONE_R = GCELL / 2 - 3,
    GGRID_X = (UI_LOCK_WIDTH - (GN - 1) * GCELL) / 2,
    GGRID_Y = 200,
    GPAD = 20,
    GFRAME_X = GGRID_X - GPAD, GFRAME_Y = GGRID_Y - GPAD,
    GFRAME_W = (GN - 1) * GCELL + 2 * GPAD,
    GSTATUS_CY = 136, GSTATUS_PX = 40,
    GBTN_Y = 956, GBTN_W = 204, GBTN_H = 104,
    GBTN_DIFF_X = 16, GBTN_RESTART_X = 240, GBTN_UNDO_X = 464,
    // 思考一拍，让状态行先显示。/ One beat so "thinking" shows first.
    GTHINK_MS = 350,
};

enum { ST_EMPTY = 0, ST_BLACK = 1, ST_WHITE = 2 };
enum { TURN_PLAYER = 0, TURN_AI = 1 };
enum { WIN_NONE = 0, WIN_BLACK = 1, WIN_WHITE = 2, WIN_DRAW = 3 };

static int8_t s_board[GN][GN];
static uint8_t s_history[GN * GN];
static uint8_t s_moves, s_turn, s_winner;
static bool s_hard;                 // 困难 AI 开关 / hard AI enabled
static int8_t s_last_r = -1, s_last_c = -1;
static int64_t s_ai_due_ms;
static uint32_t s_rng;
static const int s_dirs[4][2] = {{0, 1}, {1, 0}, {1, 1}, {1, -1}};  // 横竖斜 / lines

/* ---- 棋盘判定 / Board rules ---- */

static bool in_board(int r, int c) { return r >= 0 && r < GN && c >= 0 && c < GN; }

static int run_len(int r, int c, int dr, int dc, int8_t color) {
    int n = 0;
    while (in_board(r, c) && s_board[r][c] == color) {
        ++n;
        r += dr;
        c += dc;
    }
    return n;
}

// 含 (r,c) 自身的一方向连子数。/ Run length through (r,c) along one direction.
static int line_len(int r, int c, int dr, int dc, int8_t color) {
    return 1 + run_len(r + dr, c + dc, dr, dc, color) + run_len(r - dr, c - dc, -dr, -dc, color);
}

static bool wins_at(int r, int c, int8_t color) {
    for (int i = 0; i < 4; ++i) {
        if (line_len(r, c, s_dirs[i][0], s_dirs[i][1], color) >= 5) return true;
    }
    return false;
}

// 空位下 color 后立即成五的方向数。/ How many directions immediately make five.
static int five_dirs(int r, int c, int8_t color) {
    int n = 0;
    for (int i = 0; i < 4; ++i) {
        if (line_len(r, c, s_dirs[i][0], s_dirs[i][1], color) >= 5) ++n;
    }
    return n;
}

// 单点形状分：五>活四>冲四>活三>眠三，不做多层搜索。
// One-cell shape score: five > open four > four > open three, no multi-ply search.
static int shape_score(int r, int c, int8_t color) {
    static const int w[5][3] = {
        {0, 0, 0}, {0, 12, 40}, {0, 60, 400}, {0, 800, 5000}, {0, 12000, 100000}};
    int total = 0;
    for (int i = 0; i < 4; ++i) {
        const int dr = s_dirs[i][0], dc = s_dirs[i][1];
        const int n1 = run_len(r + dr, c + dc, dr, dc, color);
        const int n2 = run_len(r - dr, c - dc, -dr, -dc, color);
        const int n = 1 + n1 + n2;
        if (n >= 5) {
            total += 1000000;
            continue;
        }
        int open = 0;
        const int e1r = r + (n1 + 1) * dr, e1c = c + (n1 + 1) * dc;
        const int e2r = r - (n2 + 1) * dr, e2c = c - (n2 + 1) * dc;
        if (in_board(e1r, e1c) && s_board[e1r][e1c] == ST_EMPTY) ++open;
        if (in_board(e2r, e2c) && s_board[e2r][e2c] == ST_EMPTY) ++open;
        total += w[n][open];
    }
    return total;
}

// 空位两圈内的棋子才算候选。/ Candidates within two cells of a stone.
static bool near_stone(int r, int c) {
    for (int dr = -2; dr <= 2; ++dr) {
        for (int dc = -2; dc <= 2; ++dc) {
            if (dr == 0 && dc == 0) continue;
            const int rr = r + dr, cc = c + dc;
            if (in_board(rr, cc) && s_board[rr][cc] != ST_EMPTY) return true;
        }
    }
    return false;
}

static uint32_t next_rand(void) {
    s_rng = s_rng * 1664525u + 1013904223u;
    return s_rng >> 16;
}

/* ---- AI 选点 / AI moves ---- */

// 简单：邻域随机加贴身贪心。/ Easy: neighbour noise plus greedy adjacency.
static bool ai_easy(int *out_r, int *out_c) {
    int best = -1, best_r = -1, best_c = -1;
    for (int r = 0; r < GN; ++r) {
        for (int c = 0; c < GN; ++c) {
            if (s_board[r][c] != ST_EMPTY || !near_stone(r, c)) continue;
            int score = (int)(next_rand() % 4);
            for (int dr = -1; dr <= 1; ++dr) {
                for (int dc = -1; dc <= 1; ++dc) {
                    const int rr = r + dr, cc = c + dc;
                    if ((dr == 0 && dc == 0) || !in_board(rr, cc)) continue;
                    if (s_board[rr][cc] == ST_WHITE) score += 3;
                    else if (s_board[rr][cc] == ST_BLACK) score += 2;
                }
            }
            const int dr = r > 7 ? r - 7 : 7 - r;
            const int dc = c > 7 ? c - 7 : 7 - c;
            score += (14 - dr - dc) / 4;
            if (score > best) {
                best = score;
                best_r = r;
                best_c = c;
            }
        }
    }
    if (best < 0) return false;
    *out_r = best_r;
    *out_c = best_c;
    return true;
}

// 困难：先成五、再堵五，再按形状分加中心偏好，不搜索。
// Hard: take five, block five, else shape score plus centre bias, no search.
static bool ai_hard(int *out_r, int *out_c) {
    int best_r = -1, best_c = -1, block = 0;
    for (int r = 0; r < GN; ++r) {
        for (int c = 0; c < GN; ++c) {
            if (s_board[r][c] != ST_EMPTY || !near_stone(r, c)) continue;
            if (five_dirs(r, c, ST_WHITE) > 0) {
                *out_r = r;
                *out_c = c;
                return true;
            }
            const int dirs = five_dirs(r, c, ST_BLACK);
            if (dirs > block) {
                block = dirs;
                best_r = r;
                best_c = c;
            }
        }
    }
    if (block > 0) {
        *out_r = best_r;
        *out_c = best_c;
        return true;
    }
    int best = -1;
    best_r = best_c = -1;
    for (int r = 0; r < GN; ++r) {
        for (int c = 0; c < GN; ++c) {
            if (s_board[r][c] != ST_EMPTY || !near_stone(r, c)) continue;
            const int dr = r > 7 ? r - 7 : 7 - r;
            const int dc = c > 7 ? c - 7 : 7 - c;
            // 防守略高于进攻，同等形状先堵。/ Defence outweighs offence on ties.
            const int score = shape_score(r, c, ST_WHITE) * 10 +
                              shape_score(r, c, ST_BLACK) * 11 + (14 - dr - dc) * 20;
            if (score > best) {
                best = score;
                best_r = r;
                best_c = c;
            }
        }
    }
    if (best < 0) return false;
    *out_r = best_r;
    *out_c = best_c;
    return true;
}

/* ---- 对局流程 / Game flow ---- */

// 胜负短旋律：胜 880/1175/1568Hz，负 392/262Hz，每音 90/120ms，总时长 <300ms。
// Result melody: 880/1175/1568Hz win, 392/262Hz loss, each 90/120ms, <300ms total.
static void melody(bool win) {
    static const uint16_t win_hz[3] = {880, 1175, 1568};
    static const uint16_t lose_hz[2] = {392, 262};
    if (win) {
        for (int i = 0; i < 3; ++i) (void)read_pico_buzzer_tone(win_hz[i], 90);
    } else {
        for (int i = 0; i < 2; ++i) (void)read_pico_buzzer_tone(lose_hz[i], 120);
    }
}

static void reset_game(int64_t now_ms) {
    memset(s_board, 0, sizeof(s_board));
    s_moves = 0;
    s_turn = TURN_PLAYER;
    s_winner = WIN_NONE;
    s_last_r = -1;
    s_last_c = -1;
    s_ai_due_ms = 0;
    s_rng = (uint32_t)now_ms * 2654435761u + 1013904223u;
    if (s_rng == 0) s_rng = 1;
}

static void place_stone(int r, int c, int8_t color) {
    s_board[r][c] = color;
    s_history[s_moves++] = (uint8_t)(r * GN + c);
    s_last_r = (int8_t)r;
    s_last_c = (int8_t)c;
}

static app_redraw_t ai_turn(void) {
    int r = 0, c = 0;
    if (!(s_hard ? ai_hard(&r, &c) : ai_easy(&r, &c))) {
        s_winner = WIN_DRAW;
        return APP_REDRAW_PAGE;
    }
    place_stone(r, c, ST_WHITE);
    if (wins_at(r, c, ST_WHITE)) {
        s_winner = WIN_WHITE;
        melody(false);
    } else if (s_moves >= GN * GN) {
        s_winner = WIN_DRAW;
    } else {
        s_turn = TURN_PLAYER;
    }
    return APP_REDRAW_PAGE;
}

// 点交叉点落子：半格内命中，越界或已有子忽略。/ Tap within half a cell of a cross point.
static app_redraw_t tap_board(app_ctx_t *ctx, int x, int y) {
    if (s_winner != WIN_NONE || s_turn != TURN_PLAYER) return APP_REDRAW_NONE;
    const int half = GCELL / 2;
    const int reach = (GN - 1) * GCELL + half;
    const int dx = x - GGRID_X, dy = y - GGRID_Y;
    if (dx < -half || dx > reach || dy < -half || dy > reach) return APP_REDRAW_NONE;
    const int col = (dx + half) / GCELL, row = (dy + half) / GCELL;
    if (!in_board(row, col) || s_board[row][col] != ST_EMPTY) return APP_REDRAW_NONE;
    place_stone(row, col, ST_BLACK);
    if (wins_at(row, col, ST_BLACK)) {
        s_winner = WIN_BLACK;
        melody(true);
        return APP_REDRAW_PAGE;
    }
    if (s_moves >= GN * GN) {
        s_winner = WIN_DRAW;
        return APP_REDRAW_PAGE;
    }
    s_turn = TURN_AI;
    s_ai_due_ms = ctx->now_ms + GTHINK_MS;
    return APP_REDRAW_PAGE;
}

// 悔棋：偶数手退一回合，奇数手退刚下的黑子。
// Undo: even count drops a round, odd count drops the last black stone.
static bool undo_move(void) {
    if (s_moves == 0) return false;
    for (int remove = s_moves % 2 ? 1 : 2; remove > 0 && s_moves > 0; --remove) {
        const uint8_t idx = s_history[--s_moves];
        s_board[idx / GN][idx % GN] = ST_EMPTY;
    }
    s_turn = TURN_PLAYER;
    s_winner = WIN_NONE;
    s_ai_due_ms = 0;
    if (s_moves > 0) {
        const uint8_t idx = s_history[s_moves - 1];
        s_last_r = (int8_t)(idx / GN);
        s_last_c = (int8_t)(idx % GN);
    } else {
        s_last_r = -1;
        s_last_c = -1;
    }
    return true;
}

/* ---- 绘制 / Painting ---- */

static int grid_x(int c) { return GGRID_X + c * GCELL; }
static int grid_y(int r) { return GGRID_Y + r * GCELL; }
static EpdRect btn_rect(int x) { return (EpdRect){x, GBTN_Y, GBTN_W, GBTN_H}; }

static const char *status_text(void) {
    if (s_winner == WIN_BLACK) return "黑棋胜";
    if (s_winner == WIN_WHITE) return "白棋胜";
    if (s_winner == WIN_DRAW) return "平局";
    return s_turn == TURN_AI ? "电脑思考中" : "你的回合";
}

// 状态行：棋盘上方居中大字。/ Status row: one big centred label above the board.
static void draw_status(uint8_t *fb) {
    ui_text_fixed_vc(fb, UI_LOCK_WIDTH / 2, GSTATUS_CY, GSTATUS_PX, status_text(),
                     EPD_DRAW_ALIGN_CENTER, false);
}

// 棋盘：外框、网格、星位、棋子与最后一手标记。
// Board: frame, grid, star points, stones and the last-move dot.
static void draw_board(uint8_t *fb) {
    const int span = (GN - 1) * GCELL;
    ui_draw_control_frame(fb, (EpdRect){GFRAME_X, GFRAME_Y, GFRAME_W, GFRAME_W}, 14, 0x70);
    for (int i = 0; i < GN; ++i) {
        const int off = i * GCELL;
        ui_hairline(fb, GGRID_Y + off, GGRID_X, span, 0x88);
        ui_fill_rect_fast((EpdRect){GGRID_X + off, GGRID_Y, 1, span}, 0x88, fb);
    }
    static const int stars[5][2] = {{7, 7}, {3, 3}, {3, 11}, {11, 3}, {11, 11}};
    for (int i = 0; i < 5; ++i) {
        epd_fill_circle(grid_x(stars[i][1]), grid_y(stars[i][0]), 4, 0x70, fb);
    }
    for (int r = 0; r < GN; ++r) {
        for (int c = 0; c < GN; ++c) {
            const int v = s_board[r][c];
            if (v == ST_EMPTY) continue;
            const int cx = grid_x(c), cy = grid_y(r);
            if (v == ST_BLACK) {
                epd_fill_circle(cx, cy, GSTONE_R, 0x00, fb);
            } else {
                epd_fill_circle(cx, cy, GSTONE_R, 0xff, fb);
                epd_draw_circle(cx, cy, GSTONE_R, 0x00, fb);
                epd_draw_circle(cx, cy, GSTONE_R - 1, 0x00, fb);
            }
            if (r == s_last_r && c == s_last_c) {
                epd_fill_circle(cx, cy, 4, v == ST_BLACK ? 0xff : 0x30, fb);
            }
        }
    }
}

/* ---- feature_body_t 回调 / Callbacks ---- */

static void enter(app_ctx_t *ctx) { reset_game(ctx->now_ms); }

static void exit_page(app_ctx_t *ctx) { (void)ctx; }

static void render(uint8_t *fb, app_ctx_t *ctx) {
    (void)ctx;
    draw_status(fb);
    draw_board(fb);
    feature_draw_button(fb, btn_rect(GBTN_DIFF_X), s_hard ? "困难" : "简单", s_hard);
    feature_draw_button(fb, btn_rect(GBTN_RESTART_X), "重新开始", false);
    feature_draw_button(fb, btn_rect(GBTN_UNDO_X), "悔棋", false);
}

static app_redraw_t gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
    // 顶部标题/长按提示归入口页，这里只认游戏画布内的点按。/ Game-canvas taps only.
    if (ev->y0 < FEATURE_GAME_TOP || ev->y0 >= FEATURE_GAME_BOTTOM) return APP_REDRAW_NONE;
    if (ev->x0 < FEATURE_GAME_LEFT || ev->x0 >= FEATURE_GAME_RIGHT) return APP_REDRAW_NONE;
    if (ui_rect_hit(btn_rect(GBTN_DIFF_X), ev->x0, ev->y0)) {
        s_hard = !s_hard;
        return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(btn_rect(GBTN_RESTART_X), ev->x0, ev->y0)) {
        reset_game(ctx->now_ms);
        return APP_REDRAW_PAGE;
    }
    if (ui_rect_hit(btn_rect(GBTN_UNDO_X), ev->x0, ev->y0)) {
        return undo_move() ? APP_REDRAW_PAGE : APP_REDRAW_NONE;
    }
    return tap_board(ctx, ev->x0, ev->y0);
}

static app_redraw_t tick(app_ctx_t *ctx) {
    if (s_turn == TURN_AI && s_winner == WIN_NONE && ctx->now_ms >= s_ai_due_ms) {
        return ai_turn();
    }
    return APP_REDRAW_NONE;
}

static EpdRect area(app_ctx_t *ctx) {
    (void)ctx;
    return feature_game_rect();
}

const feature_body_t feature_body_gomoku = {
    .enter = enter,
    .exit = exit_page,
    .render = render,
    .gesture = gesture,
    .tick = tick,
    .area = area,
};
