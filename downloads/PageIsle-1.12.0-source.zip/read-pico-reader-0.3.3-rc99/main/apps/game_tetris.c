/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：俄罗斯方块子页。入口页只画顶部游戏名和“长按中键返回”，本文件在近全屏游戏画布
 *       feature_game_rect() 内画 10x20 棋盘、右侧分数/下一块栏与六个大按钮并推进方块下落。
 * English: Tetris child page on the near-full-screen game canvas. The hub keeps only the title and
 *          the middle-hold hint; this file paints the board, score/next column and six controls.
 *
 * 冻结：render 只画像素；蜂鸣和页面切换只能出现在 enter / gesture / tick。
 * Frozen: render paints pixels only; buzzer calls and page requests live in enter/gesture/tick.
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "esp_random.h"
#include "feature_common.h"
#include "read_pico_buzzer.h"
#include "ui_kit.h"

/* ---- 几何 / Geometry ---- */
#define CELL 36
#define COLS 10
#define ROWS 20
#define BX 20
#define BY 168
#define PX 392
#define PW 268
#define BW 126
#define BH 88
#define BTN_TOP 582
#define BTN_STEP 112
#define TARGET_LINES 10

/* ---- 页内状态 / Page state ---- */
typedef enum {
    ST_READY = 0, ///< 等待开始 / Waiting to start
    ST_RUN,       ///< 游戏中 / Playing
    ST_PAUSE,     ///< 暂停 / Paused
    ST_OVER,      ///< 堆到顶失败 / Stack reached the top
    ST_WIN,       ///< 消满目标行 / Target rows cleared
} tetris_state_t;

typedef enum {
    EV_NONE = 0, ///< 无特殊事件 / Nothing special
    EV_CLEAR,    ///< 消行 / Rows cleared
    EV_OVER,     ///< 失败 / Game over
    EV_WIN,      ///< 胜利 / Victory
} tetris_evt_t;

// 棋盘为黑白两态，落定后并入当前块。/ Binary board; the piece merges when it locks.
static uint8_t s_board[ROWS][COLS];
static tetris_state_t s_state = ST_READY;
static int s_score, s_lines;
static int64_t s_fall_ms;
static uint8_t s_piece, s_next, s_size; // 块编号与方阵边长 / Piece id and square side
static uint16_t s_mask;                 // 当前方位掩码 / Mask of the current rotation
static int s_px, s_py;                  // 方阵左上角 / Grid top-left cell

/* ---- 七种方块 / Seven pieces ---- */
// 基础位掩码，行优先；旋转运行时算。/ Base masks row-major; rotations computed at runtime.
static const uint16_t s_base[7] = {0x00F0, 0x000F, 0x003A, 0x001E, 0x0033, 0x0039, 0x003C};
static const uint8_t s_side[7] = {4, 2, 3, 3, 3, 3, 3};
// 生成左列，所有块居中。/ Spawn column keeps every piece centred.
static const uint8_t s_col[7] = {3, 4, 3, 3, 3, 3, 3};

/* ---- 短提示音 / Short tunes ---- */
// 失败三声下行、胜利四声上行，均 <300ms。/ Fail: 3 descending; win: 4 rising; both <300 ms.
static void play_tune(bool win) {
    (void)read_pico_buzzer_tone(win ? 523 : 392, 55);
    (void)read_pico_buzzer_tone(win ? 659 : 311, 55);
    (void)read_pico_buzzer_tone(win ? 784 : 247, 55);
    if (win) (void)read_pico_buzzer_tone(1047, 80);
}

/* ---- 游戏逻辑 / Game logic ---- */
// 顺时针 90°，不做踢墙，2x2 块不变。/ Clockwise 90°; no wall kicks; 2x2 invariant.
static uint16_t rotate_mask(uint16_t mask, uint8_t n) {
    uint16_t out = 0;
    if (n == 2) return mask;
    for (int i = 0; i < n * n; ++i) {
        if (!(mask & (uint16_t)(1u << i))) continue;
        out |= (uint16_t)(1u << ((i % n) * n + (n - 1 - i / n)));
    }
    return out;
}

// 越界或重叠即碰撞，棋盘上方允许。/ Collides on bounds/overlap; rows above allowed.
static bool collides(int x, int y, uint16_t mask, uint8_t n) {
    for (int i = 0; i < n * n; ++i) {
        if (!(mask & (uint16_t)(1u << i))) continue;
        const int bx = x + i % n, by = y + i / n;
        if (bx < 0 || bx >= COLS || by >= ROWS) return true;
        if (by >= 0 && s_board[by][bx]) return true;
    }
    return false;
}

static bool try_move(int dx, int dy) {
    if (collides(s_px + dx, s_py + dy, s_mask, s_size)) return false;
    s_px += dx;
    s_py += dy;
    return true;
}

// 生成下一块；被占（堆到顶）返回 false。/ Spawn the pending piece; false when blocked.
static bool spawn_piece(void) {
    s_piece = s_next;
    s_next = (uint8_t)(esp_random() % 7u);
    s_size = s_side[s_piece];
    s_mask = s_base[s_piece];
    s_px = s_col[s_piece];
    s_py = 0;
    return !collides(s_px, s_py, s_mask, s_size);
}

static void reset_game(void) {
    memset(s_board, 0, sizeof(s_board));
    s_score = s_lines = 0;
    s_next = (uint8_t)(esp_random() % 7u);
    (void)spawn_piece();
    s_fall_ms = 0;
}

// 每消 2 行升一级，每级快 40ms。/ 40 ms faster per two cleared rows.
static int fall_ms(void) {
    const int level = 1 + s_lines / 2;
    const int ms = 550 - (level - 1) * 40;
    return ms < 270 ? 270 : ms;
}

// 落定当前块、消行计分并生成下一块。/ Stamp, clear rows, score and spawn.
static tetris_evt_t lock_piece(void) {
    for (int i = 0; i < s_size * s_size; ++i) {
        if (!(s_mask & (uint16_t)(1u << i))) continue;
        const int bx = s_px + i % s_size, by = s_py + i / s_size;
        if (bx >= 0 && bx < COLS && by >= 0 && by < ROWS) s_board[by][bx] = 1;
    }
    int cleared = 0;
    for (int row = ROWS - 1; row >= 0; --row) {
        bool full = true;
        for (int c = 0; c < COLS; ++c) full = full && s_board[row][c];
        if (!full) continue;
        ++cleared;
        for (int r = row; r > 0; --r) memcpy(s_board[r], s_board[r - 1], sizeof(s_board[0]));
        memset(s_board[0], 0, sizeof(s_board[0]));
        ++row; // 压行后同一行要再看一次 / Re-check the row after compaction
    }
    if (cleared) {
        static const int points[5] = {0, 100, 300, 500, 800};
        s_score += points[cleared > 4 ? 4 : cleared] * (1 + s_lines / 2);
        s_lines += cleared;
        if (s_lines >= TARGET_LINES) return EV_WIN;
    }
    if (!spawn_piece()) return EV_OVER;
    return cleared ? EV_CLEAR : EV_NONE;
}

// 开始或重开一局。/ Start or restart a game.
static void start_game(app_ctx_t *ctx) {
    reset_game();
    s_state = ST_RUN;
    s_fall_ms = ctx->now_ms + fall_ms();
}

/* ---- 画布绘制 / Canvas painting ---- */
// 单格留 3px 缝。/ One cell with a 3 px seam.
static void draw_block(uint8_t *fb, int x, int y) {
    ui_fill_rect_fast((EpdRect){x + 3, y + 3, CELL - 6, CELL - 6}, UI_GRAY_BLACK, fb);
}

// 整块刷白后重画。/ Wipe, then repaint.
static void draw_board(uint8_t *fb) {
    const EpdRect board = {BX, BY, COLS * CELL, ROWS * CELL};
    ui_clear_rect_fast(fb, board);
    for (int r = 0; r < ROWS; ++r)
        for (int c = 0; c < COLS; ++c)
            if (s_board[r][c]) draw_block(fb, BX + c * CELL, BY + r * CELL);
    for (int i = 0; i < s_size * s_size; ++i) {
        if (!(s_mask & (uint16_t)(1u << i))) continue;
        const int bx = s_px + i % s_size, by = s_py + i / s_size;
        if (bx >= 0 && bx < COLS && by >= 0 && by < ROWS)
            draw_block(fb, BX + bx * CELL, BY + by * CELL);
    }
    ui_draw_control_frame(fb, board, 12, UI_GRAY_BLACK);
}

// 预览按方阵居中。/ Preview centres the grid.
static void draw_next(uint8_t *fb) {
    const EpdRect box = {444, 380, 164, 164};
    const int n = (int)s_side[s_next];
    const uint16_t mask = s_base[s_next];
    ui_clear_rect_fast(fb, box);
    ui_draw_control_frame(fb, box, 10, UI_GRAY_BLACK);
    const int x0 = box.x + (box.width - n * CELL) / 2;
    const int y0 = box.y + (box.height - n * CELL) / 2;
    for (int i = 0; i < n * n; ++i) {
        if (!(mask & (uint16_t)(1u << i))) continue;
        draw_block(fb, x0 + (i % n) * CELL, y0 + (i / n) * CELL);
    }
}

// 右侧栏先清后画。/ Clear the right column before repainting.
static void draw_panel(uint8_t *fb) {
    char buf[24];
    ui_clear_rect_fast(fb, (EpdRect){PX, 160, PW, 410});
    ui_text_fixed(fb, PX, 172, 28, "分数", EPD_DRAW_ALIGN_LEFT, false);
    snprintf(buf, sizeof(buf), "%d", s_score);
    ui_text_fixed(fb, PX, 204, 58, buf, EPD_DRAW_ALIGN_LEFT, false);
    snprintf(buf, sizeof(buf), "行数 %d/%d",
                     s_lines > TARGET_LINES ? TARGET_LINES : s_lines, TARGET_LINES);
    ui_text_fixed(fb, PX, 300, 26, buf, EPD_DRAW_ALIGN_LEFT, false);
    ui_text_fixed(fb, PX, 348, 26, "下一块", EPD_DRAW_ALIGN_LEFT, false);
    draw_next(fb);
}

/* ---- 操作按钮 / Controls ---- */
enum {
    BTN_LEFT = 0, ///< 左移 / Move left
    BTN_RIGHT,    ///< 右移 / Move right
    BTN_ROT,      ///< 旋转 / Rotate
    BTN_DOWN,     ///< 下降 / Soft drop
    BTN_PAUSE,    ///< 开始/暂停/继续 / Start, pause or resume
    BTN_RESTART,  ///< 重开 / Restart
    BTN_COUNT,
};

// 两列三行按钮，绘制与命中共用。/ Two columns by three rows; paint and hit share.
static EpdRect btn_rect(int i) {
    return (EpdRect){PX + (i % 2) * (BW + 16), BTN_TOP + (i / 2) * BTN_STEP, BW, BH};
}

// 暂停键随状态换标签，其余固定。/ Only the pause key is relabelled by state.
static const char *btn_label(int i) {
    switch (i) {
        case BTN_LEFT: return "左移";
        case BTN_RIGHT: return "右移";
        case BTN_ROT: return "旋转";
        case BTN_DOWN: return "下降";
        case BTN_PAUSE:
            return s_state == ST_RUN ? "暂停" : s_state == ST_PAUSE ? "继续" : "开始";
        default: return "重开";
    }
}

static void draw_buttons(uint8_t *fb) {
    for (int i = 0; i < BTN_COUNT; ++i) {
        // 非游戏中为主按钮。/ Primary outside play.
        const bool primary = i == BTN_PAUSE && s_state != ST_RUN;
        feature_draw_button(fb, btn_rect(i), btn_label(i), primary);
    }
}

// 状态行只占一行，随整页重绘更新。/ One compact status line, repainted with the page.
static void draw_status(uint8_t *fb) {
    const char *msg = s_state == ST_READY ? "点「开始」或点棋盘开局"
                    : s_state == ST_PAUSE ? "已暂停"
                    : s_state == ST_OVER ? "堆到顶了，点「重开」"
                    : s_state == ST_WIN ? "胜利！消满 10 行" : "消满 10 行获胜";
    ui_text_fixed_vc(fb, UI_LOCK_WIDTH / 2, 938, 32, msg, EPD_DRAW_ALIGN_CENTER, false);
}

// 十格目标进度。/ Ten target ticks.
static void draw_progress(uint8_t *fb) {
    const int x0 = (UI_LOCK_WIDTH - (TARGET_LINES * 56 + (TARGET_LINES - 1) * 8)) / 2;
    for (int i = 0; i < TARGET_LINES; ++i) {
        const EpdRect seg = {x0 + i * 64, 996, 56, 34};
        if (i < s_lines) ui_fill_rect_fast(seg, UI_GRAY_BLACK, fb);
        else ui_draw_control_frame(fb, seg, 8, 0x70);
    }
}

// 局部刷新只画棋盘与分数区。/ Partial refresh paints the board and score column.
static void draw_motion(uint8_t *fb) {
    draw_board(fb);
    draw_panel(fb);
}

/* ---- 刷新映射 / Redraw mapping ---- */
// 消行/结束/胜利整页重绘，普通移动局部刷新（已画好 fb）。/ Clears repaint; moves refresh after painting fb.
static app_redraw_t finish_event(app_ctx_t *ctx, tetris_evt_t evt) {
    s_fall_ms = ctx->now_ms + fall_ms();
    if (evt == EV_OVER || evt == EV_WIN) {
        s_state = evt == EV_OVER ? ST_OVER : ST_WIN;
        play_tune(evt == EV_WIN);
        return APP_REDRAW_PAGE;
    }
    if (evt == EV_CLEAR) return APP_REDRAW_PAGE;
    draw_motion(ctx->fb);
    return APP_REDRAW_AREA;
}

/* ---- 回调 / Callbacks ---- */
static void tetris_enter(app_ctx_t *ctx) {
    reset_game();
    s_state = ST_READY;
    s_fall_ms = ctx->now_ms + fall_ms();
}

static void tetris_exit(app_ctx_t *ctx) {
    if (s_state == ST_RUN) s_state = ST_PAUSE;
}

static void tetris_render(uint8_t *fb, app_ctx_t *ctx) {
    draw_board(fb);
    draw_panel(fb);
    draw_buttons(fb);
    draw_status(fb);
    draw_progress(fb);
}

// 开始/暂停/继续一键流转。/ One key cycles start/pause/resume.
static app_redraw_t toggle_pause(app_ctx_t *ctx) {
    if (s_state == ST_RUN) s_state = ST_PAUSE;
    else if (s_state == ST_PAUSE) {
        s_state = ST_RUN;
        s_fall_ms = ctx->now_ms + fall_ms();
    } else {
        start_game(ctx);
    }
    return APP_REDRAW_PAGE;
}

static app_redraw_t act_move(app_ctx_t *ctx, int dx) {
    if (s_state != ST_RUN || !try_move(dx, 0)) return APP_REDRAW_NONE;
    draw_motion(ctx->fb);
    return APP_REDRAW_AREA;
}

static app_redraw_t act_rotate(app_ctx_t *ctx) {
    const uint16_t mask = rotate_mask(s_mask, s_size);
    if (s_state != ST_RUN || collides(s_px, s_py, mask, s_size)) return APP_REDRAW_NONE;
    s_mask = mask;
    draw_motion(ctx->fb);
    return APP_REDRAW_AREA;
}

static app_redraw_t act_button(app_ctx_t *ctx, int i) {
    if (i == BTN_LEFT) return act_move(ctx, -1);
    if (i == BTN_RIGHT) return act_move(ctx, 1);
    if (i == BTN_ROT) return act_rotate(ctx);
    if (i == BTN_PAUSE) return toggle_pause(ctx);
    if (i == BTN_RESTART) { start_game(ctx); return APP_REDRAW_PAGE; }
    if (i == BTN_DOWN && s_state == ST_RUN) {
        return finish_event(ctx, try_move(0, 1) ? EV_NONE : lock_piece());
    }
    return APP_REDRAW_NONE;
}

static app_redraw_t tetris_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    const EpdRect board = {BX, BY, COLS * CELL, ROWS * CELL};
    // 画布外手势不消费。/ Gestures outside the canvas are ignored.
    if (!ui_rect_hit(feature_game_rect(), ev->x0, ev->y0)) return APP_REDRAW_NONE;
    if (ev->type == UI_GESTURE_TAP) {
        for (int i = 0; i < BTN_COUNT; ++i)
            if (ui_rect_hit(btn_rect(i), ev->x0, ev->y0)) return act_button(ctx, i);
        if (!ui_rect_hit(board, ev->x0, ev->y0)) return APP_REDRAW_NONE;
        // 棋盘点按：旋转或开始。/ Board tap: rotate or start.
        return s_state == ST_RUN ? act_rotate(ctx) : toggle_pause(ctx);
    }
    // 棋盘滑动：移动或硬降。/ Board swipes: move or hard-drop.
    if (!ui_rect_hit(board, ev->x0, ev->y0)) return APP_REDRAW_NONE;
    if (ev->type == UI_GESTURE_SWIPE_L) return act_move(ctx, -1);
    if (ev->type == UI_GESTURE_SWIPE_R) return act_move(ctx, 1);
    if (ev->type == UI_GESTURE_SWIPE_D && s_state == ST_RUN) {
        while (try_move(0, 1)) {
        }
        return finish_event(ctx, lock_piece());
    }
    return APP_REDRAW_NONE;
}

static app_redraw_t tetris_tick(app_ctx_t *ctx) {
    if (s_state != ST_RUN) return APP_REDRAW_NONE;
    if (ctx->now_ms < s_fall_ms) return APP_REDRAW_NONE;
    s_fall_ms = ctx->now_ms + fall_ms();
    if (try_move(0, 1)) {
        draw_motion(ctx->fb);
        return APP_REDRAW_AREA;
    }
    return finish_event(ctx, lock_piece());
}

static EpdRect tetris_area(app_ctx_t *ctx) {
    // 覆盖棋盘与右栏，不含状态/进度行；不能为空。
    // Covers the board and right column, not the status/progress rows; never empty.
    return (EpdRect){12, 160, 656, 740};
}

const feature_body_t feature_body_tetris = {
    .enter = tetris_enter,
    .exit = tetris_exit,
    .render = tetris_render,
    .gesture = tetris_gesture,
    .tick = tetris_tick,
    .area = tetris_area,
};
