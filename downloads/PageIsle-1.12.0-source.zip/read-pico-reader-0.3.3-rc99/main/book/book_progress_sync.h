/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：坚果云阅读进度同步：把逐书阅读进度（章节/章内偏移/字号/百分比）与同步文件夹里的
 * PageIsle-progress.dat 做一次双向合并。book_progress 的记录格式与 NVS 布局一律不动，
 * 本模块只调用 book_progress_list()/book_progress_save() 两个冻结接口。
 * English: Jianguoyun reading-progress sync: merge per-book progress (chapter, byte offset,
 * font size, percentage) with PageIsle-progress.dat in the sync folder. The book_progress record
 * format and NVS layout stay frozen; this module only uses book_progress_list()/save().
 */
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "esp_err.h"

/// 同步文件放在同步文件夹根目录；扩展名刻意不用 .txt/.md/.epub，目录浏览不会把它当书。
/// The sync file lives in the sync folder root; the extension avoids .txt/.md/.epub so the remote
/// browser never offers it as a book.
#define BOOK_PROGRESS_SYNC_FILE "PageIsle-progress.dat"
/// 单次同步最多多少本书与文件上限。
/// Books per sync and the hard file budget.
#define BOOK_PROGRESS_SYNC_MAX_BOOKS 96
#define BOOK_PROGRESS_SYNC_MAX_BYTES (24 * 1024)
/// 本机快照（上次成功同步时的逐书值指纹）上限。
/// Local snapshot (per-book value fingerprints from the last successful sync).
#define BOOK_PROGRESS_SYNC_META_MAX 64

/// 一次同步的统计与结果；message 非空时可直接给页面显示。
/// Counters for one sync; message carries a user-facing Chinese note when set.
typedef struct {
    uint16_t uploaded;    ///< 本机较新，已写入云端（含补回缺失条目）
    uint16_t applied;     ///< 云端较新，已恢复到本机
    uint16_t applied_ok;  ///< 其中真正写入 NVS 成功的本数
    uint16_t unchanged;   ///< 双方一致
    uint16_t conflicts;   ///< 两边都改过，保留本机
    uint16_t removed;     ///< 本机已清进度/删书，云端条目已删除
    uint16_t remote_only; ///< 云端有、本机没有对应文件，保留云端
    uint16_t stale;       ///< 本机有记录但文件不可用，未处理
    uint16_t dropped;     ///< 超过上限被截断的条目
    uint16_t total;       ///< 合并后云端条目数
    bool put_done;        ///< 本次是否真的 PUT（false 表示语义无变化）
    bool meta_saved;      ///< 同步快照是否写入成功
    char message[128];    ///< 出错/提示文案（UTF-8，可为空）
} book_progress_sync_result_t;

/// 最近一次成功同步的 Unix 秒；0=从未成功同步或时钟无效。
/// Unix seconds of the last successful sync; 0 means never or no valid clock.
uint32_t book_progress_sync_last_time(void);
/// 本机有进度记录的书籍数量（只数记录，不做 stat）。
/// Number of local progress records (record count only, no stat probing).
esp_err_t book_progress_sync_local_count(uint16_t *out);
/// 与 <remote_dir>/PageIsle-progress.dat 做一次双向合并；阻塞到结束，cancel 置位尽快返回。
/// remote_dir 是服务器绝对路径（形如 "/dav/同步文件夹"），可直接来自 app_cloud 的 cloud_remote_root()。
/// One blocking two-way merge with <remote_dir>/PageIsle-progress.dat; returns promptly when the
/// cancel flag is raised. remote_dir is the server-absolute directory (e.g. "/dav/notes").
esp_err_t book_progress_sync_run(const char *remote_dir, book_progress_sync_result_t *result,
                                 const volatile bool *cancel);
