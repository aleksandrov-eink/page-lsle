/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：字体分配失败的现场记录。频率极低（每次开机最多 8 条），写入 TF 卡根目录
 *       `pageisle_font_diag.log`，方便没有串口的用户把证据带回排查；同时打一条错误日志。
 *
 * English: On-device record of font allocation failures. Very low frequency (at most eight lines
 * per boot). Appends to `pageisle_font_diag.log` in the TF-card root so users without a serial
 * console can hand back evidence, and mirrors each line to the error log.
 */
#include "font_diag.h"

#include <stdio.h>

#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_timer.h"

static const char *TAG = "font_diag";
#define FONT_DIAG_MAX_NOTES 8
#define FONT_DIAG_PATH "/sdcard/pageisle_font_diag.log"

static int s_notes;

void font_diag_note(const char *where, unsigned need) {
    if (s_notes >= FONT_DIAG_MAX_NOTES) return;
    ++s_notes;
    const unsigned psram = (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    const unsigned psram_big =
        (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    const unsigned internal = (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    const unsigned internal_big =
        (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    ESP_LOGE(TAG, "%s need=%u psram=%u/%u internal=%u/%u", where ? where : "?", need,
             psram, psram_big, internal, internal_big);
    FILE *file = fopen(FONT_DIAG_PATH, "a");
    if (file == NULL) return;
    fprintf(file, "t=%lldms %s need=%u psram=%u/%u internal=%u/%u\n",
            (long long)(esp_timer_get_time() / 1000), where ? where : "?", need,
            psram, psram_big, internal, internal_big);
    fclose(file);
}
